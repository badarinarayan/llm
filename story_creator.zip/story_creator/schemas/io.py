"""Typed inputs for every agent invocation (outputs are the artifact models)."""
from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

from .brief import StoryBrief
from .character import CastPlan, CharacterCard, DerivedNumber
from .location import LocationPlan
from .situation import StorySituation
from .story import StoryDraft, ValidationIssue


class NormalizeBriefInput(BaseModel):
    phase: Literal["normalize"] = "normalize"
    raw_brief: dict[str, Any]
    defaults: dict[str, Any] = Field(default_factory=dict)
    repair_notes: list[str] = Field(default_factory=list)


class SituationInput(BaseModel):
    brief: StoryBrief
    repair_notes: list[str] = Field(default_factory=list)


class CastingInput(BaseModel):
    brief: StoryBrief
    situation: StorySituation
    library: list[CharacterCard] = Field(default_factory=list)
    repair_notes: list[str] = Field(default_factory=list)


class LocationInput(BaseModel):
    brief: StoryBrief
    situation: StorySituation
    repair_notes: list[str] = Field(default_factory=list)


class NumerologyInput(BaseModel):
    brief: StoryBrief
    situation: StorySituation
    character: CharacterCard
    derived: DerivedNumber
    interpretation_seed: dict[str, Any] = Field(default_factory=dict)  # configured trait table row


class DraftInput(BaseModel):
    phase: Literal["draft"] = "draft"
    brief: StoryBrief
    situation: StorySituation
    cast: CastPlan
    locations: LocationPlan


class ReviewInput(BaseModel):
    phase: Literal["review"] = "review"
    brief: StoryBrief
    draft: StoryDraft
    cast: CastPlan
    locations: LocationPlan


class EditInput(BaseModel):
    phase: Literal["edit"] = "edit"
    brief: StoryBrief
    situation: StorySituation
    cast: CastPlan
    locations: LocationPlan
    draft: StoryDraft
    issues: list[ValidationIssue] = Field(default_factory=list)
    instructions: list[str] = Field(default_factory=list)
