"""Shared base for every versioned artifact that crosses an agent boundary."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import ClassVar

from pydantic import BaseModel, ConfigDict, Field


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# Provenance fields (design section 7). Agents leave these blank; the
# ArtifactStore stamps them when an artifact is saved.
META_FIELDS = ("run_id", "artifact_type", "version", "created_by", "created_at", "parent_artifact_versions")


class Artifact(BaseModel):
    model_config = ConfigDict(extra="ignore")

    ARTIFACT_TYPE: ClassVar[str] = "artifact"

    run_id: str = ""
    artifact_type: str = ""
    version: int = 0
    created_by: str = ""
    created_at: str = ""
    parent_artifact_versions: dict[str, int] = Field(default_factory=dict)
