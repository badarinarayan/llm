from __future__ import annotations

from typing import ClassVar, Literal

from pydantic import BaseModel, Field

from .common import Artifact

SettingMode = Literal["fictional", "real_verified", "real_inspired"]


class Source(BaseModel):
    title: str
    url: str = ""


class LocationCard(BaseModel):
    location_id: str
    name: str
    role: Literal["primary", "secondary"] = "primary"
    setting_mode: SettingMode = "fictional"
    # Truth status: what the story may claim about this place.
    fiction_status: Literal["fictional", "real_verified", "real_inspired", "unverified_real"] = "fictional"
    suitability: str = ""
    scene_affordances: list[str] = Field(default_factory=list)
    sensory_palette: list[str] = Field(default_factory=list)
    constraints: list[str] = Field(default_factory=list)
    supports_beats: list[int] = Field(default_factory=list)  # StoryBeat.order values
    facts_to_verify: list[str] = Field(default_factory=list)
    sources: list[Source] = Field(default_factory=list)
    locked: bool = False


class LocationPlan(Artifact):
    ARTIFACT_TYPE: ClassVar[str] = "location_plan"

    locations: list[LocationCard]
    notes: str = ""
