from __future__ import annotations

from typing import ClassVar, Literal, Optional

from pydantic import BaseModel, Field

from .common import Artifact

Severity = Literal["error", "warning"]
OwnerAgent = Literal[
    "language_expert", "situation_creator", "casting_agent", "location_finder", "numerology_expert", "orchestrator"
]

EVAL_DIMENSIONS = (
    "narrative_coherence",
    "character_distinctiveness",
    "language_quality",
    "tone_match",
    "location_utility",
    "numerology_use",
    "continuity",
    "constraint_adherence",
)


class ValidationIssue(BaseModel):
    code: str
    severity: Severity = "error"
    message: str
    owner: OwnerAgent = "orchestrator"  # which agent a repair request is routed to


class ValidationReport(BaseModel):
    stage: str
    issues: list[ValidationIssue] = Field(default_factory=list)

    @property
    def errors(self) -> list[ValidationIssue]:
        return [i for i in self.issues if i.severity == "error"]

    @property
    def warnings(self) -> list[ValidationIssue]:
        return [i for i in self.issues if i.severity == "warning"]

    @property
    def ok(self) -> bool:
        return not self.errors


class StoryDraft(Artifact):
    ARTIFACT_TYPE: ClassVar[str] = "story_draft"

    title: str
    synopsis: str = ""
    body: str
    language: str = "en"
    actual_word_count: int = 0
    continuity_notes: list[str] = Field(default_factory=list)
    validation_results: list[ValidationIssue] = Field(default_factory=list)
    unresolved_questions: list[str] = Field(default_factory=list)
    numerology_note: Optional[str] = None


class EditorialReview(Artifact):
    ARTIFACT_TYPE: ClassVar[str] = "editorial_review"

    scores: dict[str, int] = Field(default_factory=dict)  # EVAL_DIMENSIONS -> 1..5, kept separate
    notes: str = ""
    needs_edit: bool = False
    edit_instructions: list[str] = Field(default_factory=list)


class RunReport(Artifact):
    ARTIFACT_TYPE: ClassVar[str] = "run_report"

    status: str
    harness: str = ""
    started_at: str = ""
    finished_at: str = ""
    agent_calls: int = 0
    tokens_in: int = 0
    tokens_out: int = 0
    stage_results: list[ValidationReport] = Field(default_factory=list)
    repairs: list[str] = Field(default_factory=list)
    retries: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    artifact_versions: dict[str, int] = Field(default_factory=dict)
    scores: dict[str, int] = Field(default_factory=dict)
