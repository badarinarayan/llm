from __future__ import annotations

from typing import ClassVar, Literal, Optional

from pydantic import BaseModel, Field

from .common import Artifact

NumberSource = Literal[
    "user_supplied",          # explicit base number from the brief / registry
    "calculated_name",        # derived from a name with a documented mapping
    "calculated_birth_date",  # derived from a (fictional) birth date
    "suggested_fictional",    # fallback; clearly a suggestion, never user data
]


class DerivedNumber(BaseModel):
    """Deterministic output of number derivation, kept apart from trait interpretation."""

    number: int
    method: str
    input_source: NumberSource
    input_value: str = ""
    note: str = ""


class NumerologyProfile(Artifact):
    ARTIFACT_TYPE: ClassVar[str] = "numerology_profile"

    character_id: str = ""
    number: int
    method: str
    input_source: NumberSource
    input_value: str = ""
    archetype: str = ""
    symbolic_traits: list[str] = Field(default_factory=list)
    strengths: list[str] = Field(default_factory=list)
    blind_spots: list[str] = Field(default_factory=list)
    emotional_trigger: str = ""
    conflict_response: str = ""
    relationship_tendencies: str = ""
    arc_suggestion: str = ""
    disclaimer: str = "Symbolic creative prompt for fiction; not a claim about real people."


class Relationship(BaseModel):
    with_id: str
    nature: str


class CharacterCard(BaseModel):
    character_id: str
    name: str
    status: Literal["existing", "proposed"] = "proposed"
    story_role: str = ""
    dramatic_function: str = ""
    why_needed: str = ""
    relationships: list[Relationship] = Field(default_factory=list)
    external_goal: str = ""
    internal_need: str = ""
    strengths: list[str] = Field(default_factory=list)
    flaws: list[str] = Field(default_factory=list)
    speech_style: str = ""
    arc: str = ""
    fixed_number: Optional[int] = None  # a number supplied by the user or the registry
    birth_date: Optional[str] = None    # fictional, user-supplied only
    numerology: Optional[NumerologyProfile] = None
    locked: bool = False


class CastPlan(Artifact):
    ARTIFACT_TYPE: ClassVar[str] = "cast_plan"

    characters: list[CharacterCard]
    relationship_summary: str = ""
    casting_notes: str = ""
