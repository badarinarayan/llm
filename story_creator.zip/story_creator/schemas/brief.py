from __future__ import annotations

from typing import ClassVar, Literal, Optional

from pydantic import BaseModel, Field

from .character import CharacterCard
from .common import Artifact
from .location import LocationCard, SettingMode

NumerologyMethod = Literal["explicit_base_number", "pythagorean_name", "chaldean_name", "birth_date"]


class StyleGuide(BaseModel):
    formality: str = ""
    voice: str = ""
    dialogue_style: str = ""
    sentence_rhythm: str = ""
    language_notes: list[str] = Field(default_factory=list)


class StoryBrief(Artifact):
    ARTIFACT_TYPE: ClassVar[str] = "story_brief"

    language: str = "en"  # ISO 639-1 code, e.g. "kn", "en"
    genre: str = "general fiction"
    theme: str = ""
    premise: str = ""
    tone: str = ""
    target_word_count: int = 800
    word_count_tolerance: float = 0.1  # fraction, 0.1 = +/-10%
    audience: str = "general"
    point_of_view: str = "third_person_limited"
    tense: str = "past"
    setting_mode: SettingMode = "fictional"
    setting_hint: str = ""
    cast_source_mode: Literal["registry_only", "new_characters", "mixed"] = "new_characters"
    desired_cast_size: int = 3
    numerology_method: NumerologyMethod = "pythagorean_name"
    explicit_base_numbers: list[int] = Field(default_factory=list)  # assigned in cast order
    missing_number_policy: Literal["ask", "suggest"] = "suggest"
    locked_fields: list[str] = Field(default_factory=list)
    locked_characters: list[CharacterCard] = Field(default_factory=list)
    locked_location: Optional[LocationCard] = None
    content_boundaries: list[str] = Field(default_factory=list)
    must_include: list[str] = Field(default_factory=list)
    must_avoid: list[str] = Field(default_factory=list)
    continuity_id: Optional[str] = None
    style_guide: Optional[StyleGuide] = None

    @property
    def min_words(self) -> int:
        return int(self.target_word_count * (1 - self.word_count_tolerance))

    @property
    def max_words(self) -> int:
        return int(self.target_word_count * (1 + self.word_count_tolerance))
