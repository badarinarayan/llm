from __future__ import annotations

from typing import ClassVar

from pydantic import BaseModel, Field

from .common import Artifact


class StoryBeat(BaseModel):
    order: int
    summary: str
    location_hint: str = ""


class StorySituation(Artifact):
    ARTIFACT_TYPE: ClassVar[str] = "story_situation"

    logline: str
    opening_situation: str
    inciting_incident: str
    protagonist_goal: str
    opposing_force: str
    stakes: str
    central_question: str
    story_beats: list[StoryBeat]
    turning_point: str = ""
    candidate_endings: list[str] = Field(default_factory=list)
    must_include: list[str] = Field(default_factory=list)
    must_avoid: list[str] = Field(default_factory=list)
    alternatives: list[str] = Field(default_factory=list)
