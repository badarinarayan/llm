"""Versioned, append-only artifact store (SQLite) with an optional JSON mirror.

Every save creates a new (run_id, key, version) row; earlier versions are never
overwritten, so the event trail of decisions is preserved (design section 7).
"""
from __future__ import annotations

import json
import sqlite3
import threading
from pathlib import Path
from typing import Optional, TypeVar

from schemas.common import Artifact, utc_now

A = TypeVar("A", bound=Artifact)

_SCHEMA = """
CREATE TABLE IF NOT EXISTS artifacts (
    run_id TEXT NOT NULL,
    key TEXT NOT NULL,
    version INTEGER NOT NULL,
    artifact_type TEXT NOT NULL,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL,
    parents TEXT NOT NULL,
    payload TEXT NOT NULL,
    PRIMARY KEY (run_id, key, version)
);
"""


class ArtifactStore:
    def __init__(self, db_path: str | Path = ":memory:", mirror_dir: str | Path | None = None):
        if db_path != ":memory:":
            Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._db = sqlite3.connect(str(db_path), check_same_thread=False)
        self._db.executescript(_SCHEMA)
        self._lock = threading.Lock()
        self.mirror_dir = Path(mirror_dir) if mirror_dir else None

    def save(self, run_id: str, key: str, artifact: A, created_by: str,
             parents: Optional[dict[str, int]] = None) -> A:
        """Stamp provenance, assign the next version for (run_id, key), persist, return the stamped copy."""
        with self._lock:
            row = self._db.execute(
                "SELECT COALESCE(MAX(version), 0) FROM artifacts WHERE run_id=? AND key=?", (run_id, key)
            ).fetchone()
            stamped = artifact.model_copy(update={
                "run_id": run_id,
                "artifact_type": type(artifact).ARTIFACT_TYPE,
                "version": row[0] + 1,
                "created_by": created_by,
                "created_at": utc_now(),
                "parent_artifact_versions": dict(parents or {}),
            })
            payload = stamped.model_dump_json()
            self._db.execute(
                "INSERT INTO artifacts VALUES (?,?,?,?,?,?,?,?)",
                (run_id, key, stamped.version, stamped.artifact_type, created_by, stamped.created_at,
                 json.dumps(stamped.parent_artifact_versions), payload),
            )
            self._db.commit()
        if self.mirror_dir:
            d = self.mirror_dir / run_id
            d.mkdir(parents=True, exist_ok=True)
            fname = f"{key.replace(':', '__')}.v{stamped.version}.json"
            (d / fname).write_text(json.dumps(json.loads(payload), indent=2, ensure_ascii=False), encoding="utf-8")
        return stamped

    def latest(self, run_id: str, key: str, model: type[A]) -> Optional[A]:
        with self._lock:
            row = self._db.execute(
                "SELECT payload FROM artifacts WHERE run_id=? AND key=? ORDER BY version DESC LIMIT 1",
                (run_id, key),
            ).fetchone()
        return model.model_validate_json(row[0]) if row else None

    def get(self, run_id: str, key: str, version: int, model: type[A]) -> Optional[A]:
        with self._lock:
            row = self._db.execute(
                "SELECT payload FROM artifacts WHERE run_id=? AND key=? AND version=?", (run_id, key, version)
            ).fetchone()
        return model.model_validate_json(row[0]) if row else None

    def history(self, run_id: str, key: Optional[str] = None) -> list[dict]:
        q = "SELECT key, version, artifact_type, created_by, created_at, parents FROM artifacts WHERE run_id=?"
        args: list = [run_id]
        if key:
            q += " AND key=?"
            args.append(key)
        q += " ORDER BY created_at, key, version"
        with self._lock:
            rows = self._db.execute(q, args).fetchall()
        return [dict(key=r[0], version=r[1], artifact_type=r[2], created_by=r[3], created_at=r[4],
                     parents=json.loads(r[5])) for r in rows]

    def latest_versions(self, run_id: str) -> dict[str, int]:
        with self._lock:
            rows = self._db.execute(
                "SELECT key, MAX(version) FROM artifacts WHERE run_id=? GROUP BY key", (run_id,)
            ).fetchall()
        return {k: v for k, v in rows}

    def keys(self, run_id: str, prefix: str = "") -> list[str]:
        return sorted(k for k in self.latest_versions(run_id) if k.startswith(prefix))

    def list_runs(self) -> list[str]:
        with self._lock:
            rows = self._db.execute("SELECT run_id, MIN(created_at) FROM artifacts GROUP BY run_id ORDER BY 2").fetchall()
        return [r[0] for r in rows]

    def close(self) -> None:
        self._db.close()
