"""Existing-character registry (YAML or JSON list of CharacterCard-shaped dicts)."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable, Optional

import yaml

from schemas.character import CharacterCard


class CharacterLibrary:
    def __init__(self, characters: Iterable[CharacterCard] = ()):
        self._by_id: dict[str, CharacterCard] = {}
        for c in characters:
            self.add(c)

    @classmethod
    def load(cls, path: str | Path) -> "CharacterLibrary":
        p = Path(path)
        text = p.read_text(encoding="utf-8")
        data = json.loads(text) if p.suffix == ".json" else yaml.safe_load(text)
        if isinstance(data, dict):
            data = data.get("characters", [])
        return cls(CharacterCard.model_validate({**d, "status": "existing"}) for d in data or [])

    def add(self, card: CharacterCard) -> None:
        self._by_id[card.character_id] = card.model_copy(update={"status": "existing"})

    def get(self, character_id: str) -> Optional[CharacterCard]:
        return self._by_id.get(character_id)

    def all(self) -> list[CharacterCard]:
        return list(self._by_id.values())

    def __len__(self) -> int:
        return len(self._by_id)
