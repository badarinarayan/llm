"""Versioned story bible for ongoing universes (keyed by StoryBrief.continuity_id).

Canon changes only through explicit approval; what a run produces is stored as
*suggestions* (draft, not canon). Design section 13: "require explicit approval
to change canon".
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from schemas.character import CharacterCard
from schemas.location import LocationCard


class StoryBible:
    def __init__(self, directory: str | Path):
        self.dir = Path(directory)
        self.dir.mkdir(parents=True, exist_ok=True)

    def _path(self, continuity_id: str) -> Path:
        safe = "".join(ch for ch in continuity_id if ch.isalnum() or ch in "-_")
        return self.dir / f"{safe}.json"

    def load(self, continuity_id: str) -> dict[str, Any]:
        p = self._path(continuity_id)
        if p.exists():
            return json.loads(p.read_text(encoding="utf-8"))
        return {"continuity_id": continuity_id, "canon": {"characters": [], "locations": [], "facts": []},
                "suggestions": [], "revision": 0}

    def _save(self, data: dict[str, Any]) -> None:
        data["revision"] += 1
        self._path(data["continuity_id"]).write_text(
            json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

    def canon_characters(self, continuity_id: str) -> list[CharacterCard]:
        return [CharacterCard.model_validate(c) for c in self.load(continuity_id)["canon"]["characters"]]

    def suggest(self, continuity_id: str, kind: str, payload: dict[str, Any], run_id: str) -> int:
        data = self.load(continuity_id)
        sid = len(data["suggestions"]) + 1
        data["suggestions"].append({"id": sid, "kind": kind, "payload": payload, "run_id": run_id,
                                    "status": "pending"})
        self._save(data)
        return sid

    def suggest_from_run(self, continuity_id: str, run_id: str, characters: list[CharacterCard],
                         locations: list[LocationCard]) -> None:
        for c in characters:
            self.suggest(continuity_id, "character", c.model_dump(mode="json"), run_id)
        for loc in locations:
            self.suggest(continuity_id, "location", loc.model_dump(mode="json"), run_id)

    def approve(self, continuity_id: str, suggestion_id: int) -> None:
        data = self.load(continuity_id)
        for s in data["suggestions"]:
            if s["id"] == suggestion_id and s["status"] == "pending":
                bucket = {"character": "characters", "location": "locations"}.get(s["kind"], "facts")
                data["canon"][bucket].append(s["payload"])
                s["status"] = "approved"
                self._save(data)
                return
        raise KeyError(f"no pending suggestion {suggestion_id}")
