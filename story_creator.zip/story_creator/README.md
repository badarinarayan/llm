# Multi-Agent Story Creator

Implementation of the design in [`docs/design.md`](docs/design.md): five specialist agents (Language Expert, Numerology Expert, Casting Agent, Location Finder, Situation Creator) coordinated by a lightweight, non-creative **Orchestrator** over typed, versioned artifacts.

## Quick start (offline, no API key)

```bash
cd story_creator
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
pytest                                           # 50+ tests, all offline

story-creator run examples/sample_brief.yaml     # the design's Kannada example, stub harness
story-creator run examples/sample_brief_en.yaml
```

Output goes to `./runs/<run_id>/`: `story.md`, every artifact version as JSON (`brief.v1.json`, `cast.v2.json`, ...), `artifacts.db` (SQLite) and `events.jsonl`.

The **stub harness** is deterministic and produces formulaic placeholder text (English and Kannada). It proves the orchestration, contracts, gates and repairs; it is not a story generator. For real stories use a live harness:

| Harness | Use | Needs |
|---|---|---|
| `stub` | replayable tests, dry runs | nothing |
| `openai` | direct OpenAI API (JSON mode), one stateless call per specialist; default when `OPENAI_API_KEY` is set | `pip install -e ".[openai]"`, `OPENAI_API_KEY`, optional `OPENAI_MODEL` (default `gpt-5`), `OPENAI_BASE_URL` |
| `anthropic` | direct Claude API, one stateless call per specialist | `pip install -e ".[anthropic]"`, `ANTHROPIC_API_KEY`, optional `STORY_MODEL` |
| `tantra` | [Tantra](https://github.com/malayh/tantra) agent runtime (Apache-2.0) | `pip install -e ".[tantra]"` (Python >= 3.13), `TANTRA_BASE_URL`, `TANTRA_API_KEY`, `TANTRA_MODEL` (OpenAI-compatible endpoint, which includes OpenAI itself) |

```bash
export OPENAI_API_KEY=sk-...
story-creator run examples/sample_brief.yaml --harness openai
```

## Pipeline

```
brief -> [1 Language: normalize] -> [2 Situation] -> [3 Casting || Location] -> [4 Numerology x N, parallel]
      -> [5 Coherence gate (+<=2 targeted repair cycles)] -> [6 Language: draft] -> [7 validate, review, <=1 edit pass] -> report
```

* **Typed handoffs.** Every stage exchanges Pydantic models (`schemas/`) carrying `run_id`, `artifact_type`, `version`, `created_by`, `created_at`, `parent_artifact_versions`. The store is append-only.
* **Deterministic gates** (`orchestrator/validators.py`): brief, situation, plan coherence (cast size and purpose, numerology provenance, every beat has a location, real-place sourcing, locks) and final draft (script-based language check, word-count tolerance, every character and the primary location present, no placeholders, `must_avoid`). Each issue names its owner agent, so repairs are specific.
* **Locks.** `locked_fields`, `locked_characters`, `locked_location` and `explicit_base_numbers` are user-owned: agents may only fill blanks.
* **Numerology** is split into deterministic derivation (`agents/numerology_expert.py`: explicit number, Pythagorean/Chaldean name, birth date, or an explicitly *suggested fictional* fallback, or `missing_number_policy: ask` to stop) and LLM interpretation seeded from `config/numerology.yaml`. Method and source are stored on every profile. Only characters whose inputs changed are re-profiled after a cast repair. Names without Latin letters (e.g. Kannada script) cannot use the name methods; they take explicit numbers or the labelled fallback.
* **Budgets and retries**: call, time and token limits (`config/defaults.yaml`); one retry per agent call on bad JSON or provider errors; all retries and repairs appear in the run report.
* **Human override.** `--stop-after plan` pauses after the gate; edit an artifact and save it as a new version; then resume. The resumed plan is validated but never auto-repaired.

```bash
story-creator run brief.yaml --stop-after plan
story-creator show RUN_ID cast > cast.json        # edit it
story-creator override RUN_ID cast cast.json      # saved as v+1, created_by=human
story-creator resume RUN_ID
```

* **Story bible.** With `continuity_id`, a successful run writes characters and locations to `runs/bible/<id>.json` as *suggestions*; canon changes only via `StoryBible.approve()`. Canon characters are offered to the Casting Agent.

## Layout

```
app/cli.py            CLI            orchestrator/   pipeline, state, policy, validators, events
agents/               5 specialists  schemas/        typed contracts (+ io.py agent inputs)
harness/              base interface, stub, anthropic, tantra_adapter
memory/               artifact_store, character_library, story_bible
prompts/              one instruction file per agent (phase sections for the Language Expert)
config/               defaults.yaml, numerology.yaml
tests/                unit, contract, pipeline, evaluations
```

## Brief fields

See `schemas/brief.py`; `examples/` has two briefs. Minimum useful brief: `language`, `premise`, `target_word_count`. Everything else has a default in `config/defaults.yaml`.

## Status against the design

Built: all sections 1-8, 10-14 (agents, contracts, pipeline, gates, locks, repair loop, numerology policy, replayable tests, evaluation dimensions, CLI). Tantra (section 9): the spike was done against Tantra 1.4.0; `TantraAdapter` is tested with Tantra's `FakeProvider` (typed output, error mapping) but **not against a live model**. The `openai` and `anthropic` harnesses are tested with fake clients only. Live-model quality (prompts, Kannada fluency) has not been evaluated; use the eight rubric dimensions in `EditorialReview.scores`, and have a human review languages without strong automated checks.

Not done on purpose: HTTP API (`app/api.py` in the design is optional), vector retrieval, cross-run Tantra session memory (the story bible is the canon source), web verification for `real_verified` locations (the agent must supply sources or the gate rejects it).
