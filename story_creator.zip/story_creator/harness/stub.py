"""Deterministic offline runtime: replayable pipeline tests and a zero-cost dry run.

Output is intentionally formulaic placeholder fiction (English and Kannada only) that
satisfies the contracts; it exercises orchestration, not literary quality.
Test hooks: pass `overrides={"casting_agent": fn}` where fn(input, call_index) returns an
output (or None to fall through to the default) or raises AgentError.
"""
from __future__ import annotations

import math
from typing import Callable, Optional

from pydantic import BaseModel

from schemas.brief import StoryBrief, StyleGuide
from schemas.character import CastPlan, CharacterCard, NumerologyProfile, Relationship
from schemas.io import (CastingInput, DraftInput, EditInput, LocationInput, NormalizeBriefInput, NumerologyInput,
                        ReviewInput, SituationInput)
from schemas.location import LocationCard, LocationPlan
from schemas.situation import StoryBeat, StorySituation
from schemas.story import EVAL_DIMENSIONS, EditorialReview, StoryDraft

from .base import AgentResult, InvokeContext, StoryRuntime, T, Usage

NAMES = {
    "en": ["Meera", "Ravi", "Tara", "Dev", "Isha"],
    "kn": ["ಶಾರದಮ್ಮ", "ಗೋಪಾಲಯ್ಯ", "ಅನು", "ಸುಬ್ಬಣ್ಣ", "ಲಕ್ಷ್ಮಿ"],
}
PLACES = {
    "en": ["Lakeside Reading Room", "Market Lane", "Old Verandah"],
    "kn": ["ಕೆರೆದಡದ ಓದುವ ಕೋಣೆ", "ಸಂತೆ ಬೀದಿ", "ಹಳೆಯ ಜಗುಲಿ"],
}
ROLES = [
    ("protagonist", "Carries the central goal and makes the costly choice.",
     "Resolve the matter at the heart of the story", "To let go of an old pride"),
    ("opposing force", "Embodies the obstacle and pressures the protagonist.",
     "Protect a long-held position", "To be understood rather than obeyed"),
    ("catalyst", "Brings fresh eyes that surface what others avoid.",
     "Find out what everyone is hiding", "To be taken seriously"),
    ("ally", "Supports the protagonist and tests the plan.",
     "Keep the peace", "To speak up"),
    ("witness", "Observes and reflects the cost of the choice.",
     "Understand what happened", "To belong"),
]
SENTENCES = {
    "en": [
        "{a} woke early and walked toward {place}, carrying a quiet worry.",
        "There {b} looked up, smiled, and greeted {a} like an old friend.",
        "For a long while the two of them spoke about the things that had gone unsaid.",
        "{c} came closer, curious, and asked what everyone was whispering about.",
        "Some promises had been waiting for years, but the time to keep them had arrived.",
        "The old silence between {a} and {b} slowly began to melt.",
        "Inside {place} the air was calm, and every small sound seemed to matter.",
        "{c} told a joke so gentle that even {a} could not help laughing.",
        "{b} admitted that pride had been the real obstacle all along.",
        "By evening they had agreed to begin again, together.",
    ],
    "kn": [
        "{a} ಬೆಳಗ್ಗೆ ಎದ್ದು ಹೊರಟಿದ್ದು {place} ಕಡೆಗೆ.",
        "ಅಲ್ಲಿ {b} ಅವರನ್ನು ನೋಡಿ ನಗುತ್ತ ಮಾತಾಡಿಸಿದರು.",
        "ಹೇಳದೆ ಉಳಿದಿದ್ದ ಮಾತುಗಳ ಬಗ್ಗೆ ಅವರಿಬ್ಬರೂ ಬಹಳ ಹೊತ್ತು ಮಾತಾಡಿದರು.",
        "{c} ಹತ್ತಿರ ಬಂದು, ಏನಿದು ಎಂದು ಕುತೂಹಲದಿಂದ ಕೇಳಿದರು.",
        "ಕೆಲವು ಮಾತುಗಳು ವರ್ಷಗಳಿಂದ ಉಳಿದಿದ್ದವು, ಆದರೆ ಈಗ ಅವುಗಳನ್ನು ಹೇಳುವ ಸಮಯ ಬಂದಿತ್ತು.",
        "{a} ಮತ್ತು {b} ನಡುವಿನ ಹಳೆಯ ಮೌನ ನಿಧಾನವಾಗಿ ಕರಗಿತು.",
        "ಆ ಹೊತ್ತಿನಲ್ಲಿ {place} ತುಂಬ ಶಾಂತವಾಗಿತ್ತು.",
        "{c} ಹೇಳಿದ ತಮಾಷೆಗೆ ಎಲ್ಲರೂ ನಕ್ಕರು.",
    ],
}

Override = Callable[[BaseModel, int], Optional[BaseModel]]


def _lang(code: str) -> str:
    return code if code in NAMES else "en"


class StubRuntime(StoryRuntime):
    name = "stub"

    def __init__(self, overrides: Optional[dict[str, Override]] = None):
        self.overrides = overrides or {}
        self.calls: list[tuple[str, str]] = []  # (agent, input type) log, in call order
        self._count: dict[str, int] = {}

    # ------------------------------------------------------------------ API
    def invoke_agent(self, agent_name: str, input_model: BaseModel, output_type: type[T],
                     context: InvokeContext) -> AgentResult[T]:
        self.calls.append((agent_name, type(input_model).__name__))
        idx = self._count[agent_name] = self._count.get(agent_name, 0) + 1
        out: Optional[BaseModel] = None
        if agent_name in self.overrides:
            out = self.overrides[agent_name](input_model, idx)
        if out is None:
            handler = getattr(self, "_" + type(input_model).__name__, None)
            if handler is None:
                raise NotImplementedError(f"stub has no handler for {type(input_model).__name__}")
            out = handler(input_model)
        assert isinstance(out, output_type), f"{agent_name}: expected {output_type.__name__}, got {type(out).__name__}"
        size = len(input_model.model_dump_json()) // 4
        return AgentResult(out, Usage(size, len(out.model_dump_json()) // 4))  # type: ignore[arg-type]

    # ------------------------------------------------------------- handlers
    def _NormalizeBriefInput(self, inp: NormalizeBriefInput) -> StoryBrief:
        brief = StoryBrief.model_validate({**inp.defaults, **inp.raw_brief})
        if brief.style_guide is None:
            brief = brief.model_copy(update={"style_guide": StyleGuide(
                formality="conversational", voice=brief.tone,
                dialogue_style="short, natural exchanges", sentence_rhythm="varied",
                language_notes=[f"write in '{brief.language}'"])})
        return brief

    def _SituationInput(self, inp: SituationInput) -> StorySituation:
        b = inp.brief
        premise = b.premise or b.theme or "an unexpected discovery"
        beats = [
            "An ordinary day is interrupted: " + premise,
            "The protagonist decides to act on it",
            "An opposing force complicates matters",
            "A turning point forces a costly choice",
            "The choice is made and its consequence settles",
        ]
        return StorySituation(
            logline=f"{b.genre.capitalize()} ({b.tone or 'balanced tone'}): {premise}",
            opening_situation="A quiet routine, with something left unresolved beneath it.",
            inciting_incident=premise,
            protagonist_goal="Resolve what the discovery has stirred up",
            opposing_force="Old pride and the fear of reopening the past",
            stakes="A relationship that matters, and the chance to repair it",
            central_question="Can they say what went unsaid before it is too late?",
            story_beats=[StoryBeat(order=i + 1, summary=t) for i, t in enumerate(beats)],
            turning_point=beats[3],
            candidate_endings=["Reconciliation", "A hopeful beginning"],
            must_include=list(b.must_include), must_avoid=list(b.must_avoid))

    def _CastingInput(self, inp: CastingInput) -> CastPlan:
        b, lang = inp.brief, _lang(inp.brief.language)
        chosen: list[CharacterCard] = [c.model_copy() for c in b.locked_characters]
        used = {c.character_id for c in chosen}
        if b.cast_source_mode in ("registry_only", "mixed"):
            limit = b.desired_cast_size if b.cast_source_mode == "registry_only" else math.ceil(b.desired_cast_size / 2)
            for c in inp.library:
                if len(chosen) >= limit:
                    break
                if c.character_id not in used:
                    chosen.append(c.model_copy(update={"status": "existing"}))
                    used.add(c.character_id)
        names = iter(NAMES[lang])
        n = 0
        while b.cast_source_mode != "registry_only" and len(chosen) < b.desired_cast_size:
            n += 1
            cid = f"c{n}"
            if cid in used:
                continue
            used.add(cid)
            chosen.append(CharacterCard(character_id=cid, name=next(names, f"{NAMES['en'][0]}{n}"), status="proposed"))
        out: list[CharacterCard] = []
        lead = chosen[0].character_id if chosen else ""
        for i, c in enumerate(chosen):
            role, func, goal, need = ROLES[i % len(ROLES)]
            upd = {
                "story_role": c.story_role or role,
                "dramatic_function": c.dramatic_function or func,
                "why_needed": c.why_needed or f"Needed as the {role}.",
                "external_goal": c.external_goal or goal,
                "internal_need": c.internal_need or need,
                "speech_style": c.speech_style or ("measured" if i % 2 == 0 else "quick and warm"),
                "arc": c.arc or "Moves from avoidance toward honesty",
                "strengths": c.strengths or ["observant"], "flaws": c.flaws or ["stubborn"],
            }
            if i and not c.relationships and lead:
                upd["relationships"] = [Relationship(with_id=lead, nature="shared history")]
            out.append(c.model_copy(update=upd))
        return CastPlan(characters=out, relationship_summary=f"{len(out)} characters tied through {lead or 'the lead'}.",
                        casting_notes="Roles chosen for dramatic function.")

    def _LocationInput(self, inp: LocationInput) -> LocationPlan:
        b = inp.brief
        n = len(inp.situation.story_beats)
        orders = [bt.order for bt in inp.situation.story_beats]
        second_beats = [orders[-2]] if n >= 3 else []
        primary_beats = [o for o in orders if o not in second_beats]
        if b.locked_location is not None:
            return LocationPlan(locations=[b.locked_location.model_copy(
                update={"role": "primary", "locked": True,
                        "supports_beats": b.locked_location.supports_beats or orders})], notes="locked by user")
        if b.setting_mode == "fictional":
            names, status = PLACES[_lang(b.language)], "fictional"
            facts: list[str] = []
        else:
            hint = b.setting_hint or "a real town"
            names = [hint, f"{hint} (secondary)", f"{hint} (outskirts)"]
            status = "real_inspired" if b.setting_mode == "real_inspired" else "unverified_real"
            facts = [f"Geography and landmarks of {hint}"] if status == "unverified_real" else []
        primary = LocationCard(
            location_id="l1", name=names[0], role="primary", setting_mode=b.setting_mode, fiction_status=status,  # type: ignore[arg-type]
            suitability="Quiet enough for confession; public enough for chance meetings.",
            scene_affordances=["unplanned encounters", "private conversation"],
            sensory_palette=["soft light", "distant voices"], constraints=["daytime only"],
            supports_beats=primary_beats, facts_to_verify=facts)
        plan = [primary]
        if second_beats:
            plan.append(primary.model_copy(update={
                "location_id": "l2", "name": names[1], "role": "secondary", "supports_beats": second_beats,
                "suitability": "A busier place where the turning point is witnessed."}))
        return LocationPlan(locations=plan, notes="stub location plan")

    def _NumerologyInput(self, inp: NumerologyInput) -> NumerologyProfile:
        seed = inp.interpretation_seed or {}
        return NumerologyProfile(
            number=inp.derived.number, method=inp.derived.method, input_source=inp.derived.input_source,
            input_value=inp.derived.input_value, character_id=inp.character.character_id,
            archetype=seed.get("archetype", "Unspecified"),
            symbolic_traits=list(seed.get("symbolic_traits", ["undetermined"])),
            strengths=list(seed.get("strengths", [])), blind_spots=list(seed.get("blind_spots", [])),
            emotional_trigger=seed.get("emotional_trigger", ""), conflict_response=seed.get("conflict_response", ""),
            relationship_tendencies=seed.get("relationship_tendencies", ""),
            arc_suggestion=seed.get("arc_suggestion", ""))

    def _build_story(self, brief: StoryBrief, cast: CastPlan, locs: LocationPlan, logline: str) -> StoryDraft:
        lang = _lang(brief.language)
        names = [c.name.split()[0] for c in cast.characters] or ["Someone"]
        a, b, c = (names[i % len(names)] for i in range(3))
        place = next((loc.name for loc in locs.locations if loc.role == "primary"), "the place")
        templates = SENTENCES[lang]
        target = brief.target_word_count
        sentences: list[str] = []
        total, i = 0, 0
        while total < target:
            s = templates[i % len(templates)].format(a=a, b=b, c=c, place=place)
            sentences.append(s)
            total += len(s.split())
            i += 1
        # make sure every cast member appears even in very short stories
        for nm in names[3:]:
            sentences.append(templates[0].format(a=nm, b=b, c=c, place=place))
        paras = [" ".join(sentences[k:k + 5]) for k in range(0, len(sentences), 5)]
        body = "\n\n".join(paras)
        return StoryDraft(title=place, synopsis=logline if lang == "en" else "", body=body, language=brief.language,
                          actual_word_count=len(body.split()),
                          continuity_notes=["stub text: structure test only"])

    def _DraftInput(self, inp: DraftInput) -> StoryDraft:
        return self._build_story(inp.brief, inp.cast, inp.locations, inp.situation.logline)

    def _EditInput(self, inp: EditInput) -> StoryDraft:
        return self._build_story(inp.brief, inp.cast, inp.locations, inp.situation.logline)

    def _ReviewInput(self, inp: ReviewInput) -> EditorialReview:
        return EditorialReview(scores={d: 4 for d in EVAL_DIMENSIONS}, notes="stub review", needs_edit=False)
