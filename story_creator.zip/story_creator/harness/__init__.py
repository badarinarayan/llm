from __future__ import annotations

from .base import AgentError, AgentResult, HarnessUnavailable, InvokeContext, StoryRuntime, Usage

HARNESSES = ("stub", "openai", "anthropic", "tantra")


def get_runtime(name: str, **kwargs) -> StoryRuntime:
    """Factory used by the CLI. Heavy imports stay lazy so the stub works with no extra dependencies."""
    if name == "stub":
        from .stub import StubRuntime
        return StubRuntime(**kwargs)
    if name == "openai":
        from .openai_runtime import OpenAIRuntime
        return OpenAIRuntime(**kwargs)
    if name == "anthropic":
        from .anthropic_runtime import AnthropicRuntime
        return AnthropicRuntime(**kwargs)
    if name == "tantra":
        from .tantra_adapter import TantraAdapter
        return TantraAdapter(**kwargs)
    raise ValueError(f"unknown harness '{name}'; choose from {HARNESSES}")


__all__ = ["AgentError", "AgentResult", "HarnessUnavailable", "InvokeContext", "StoryRuntime", "Usage",
           "HARNESSES", "get_runtime"]
