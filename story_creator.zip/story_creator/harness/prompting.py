"""Shared prompt assembly and JSON parsing for LLM-backed runtimes."""
from __future__ import annotations

import json
import re
from typing import Any

from pydantic import BaseModel

from agents.base import all_specs
from schemas.common import META_FIELDS

from .base import AgentError, T


def output_json_schema(output_type: type[BaseModel]) -> dict[str, Any]:
    """JSON schema of the output with provenance fields removed (the store owns those)."""
    schema = output_type.model_json_schema()
    for f in META_FIELDS:
        schema.get("properties", {}).pop(f, None)
    return schema


def build_system_prompt(agent_name: str, output_type: type[BaseModel]) -> str:
    spec = all_specs()[agent_name]
    return (
        f"{spec.load_prompt()}\n\n"
        "## Output contract\n"
        "Reply with exactly one JSON object and nothing else (no prose, no code fences) that validates against "
        f"this JSON schema ({output_type.__name__}):\n"
        f"{json.dumps(output_json_schema(output_type), ensure_ascii=False)}\n"
        "Leave provenance fields (run_id, version, created_by, ...) out."
    )


def build_user_message(input_model: BaseModel) -> str:
    return ("Input artifacts (JSON). Follow the section of your instructions that matches the input's `phase`, "
            "if it has one:\n" + input_model.model_dump_json())


def parse_json_output(text: str, output_type: type[T]) -> T:
    """Extract the first JSON object from model text and validate it; AgentError on failure."""
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text)
    start, end = text.find("{"), text.rfind("}")
    if start < 0 or end <= start:
        raise AgentError(f"no JSON object in model output: {text[:120]!r}")
    try:
        return output_type.model_validate(json.loads(text[start:end + 1]))
    except (json.JSONDecodeError, ValueError) as exc:
        raise AgentError(f"invalid {output_type.__name__} JSON: {exc}") from exc
