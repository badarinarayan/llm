"""Tantra adapter (https://github.com/malayh/tantra, Apache-2.0, PyPI `tantra-harness`, import `tantra`).

Written against the Tantra 1.4.0 public API as inspected locally (Agent / Runtime / Connection.prompt /
`output_schema`). Mapping:
  * each (specialist, output type) pair -> one declarative `Agent` subclass; `output_schema` makes
    Tantra validate the model's structured submission;
  * each invocation -> a fresh Tantra session (isolation between stories); the orchestrator already
    passes only the relevant artifacts, not transcripts;
  * the story application is synchronous, so a private event loop on a worker thread bridges to
    Tantra's async API (safe to call from the pipeline's thread pools).

Configuration (env): TANTRA_BASE_URL, TANTRA_API_KEY, TANTRA_MODEL for any OpenAI-compatible endpoint.
Tests inject `provider=` (e.g. tantra.FakeProvider) instead. Cross-run session memory for continuity
universes is deliberately not used yet; the Story Bible is the canon source.
"""
from __future__ import annotations

import asyncio
import os
import threading
from typing import Any, Optional
from uuid import uuid4

from pydantic import BaseModel, ValidationError

from agents.base import all_specs
from schemas.brief import StoryBrief
from schemas.character import CastPlan, NumerologyProfile
from schemas.location import LocationPlan
from schemas.situation import StorySituation
from schemas.story import EditorialReview, StoryDraft

from .base import AgentError, AgentResult, HarnessUnavailable, InvokeContext, StoryRuntime, T, Usage
from .prompting import build_system_prompt, build_user_message

#: every (agent, output type) combination the pipeline uses
COMBOS: list[tuple[str, type[BaseModel]]] = [
    ("language_expert", StoryBrief), ("language_expert", StoryDraft), ("language_expert", EditorialReview),
    ("numerology_expert", NumerologyProfile), ("casting_agent", CastPlan),
    ("location_finder", LocationPlan), ("situation_creator", StorySituation),
]


def _registry_name(agent_name: str, output_type: type[BaseModel]) -> str:
    return f"{agent_name}__{output_type.__name__}"


class TantraAdapter(StoryRuntime):
    name = "tantra"

    def __init__(self, provider: Any = None, store: Any = None, model: Optional[str] = None,
                 timeout: float = 300.0):
        try:
            import tantra
        except ImportError as exc:
            raise HarnessUnavailable("pip install tantra-harness (Python >= 3.13)") from exc
        self._tantra = tantra
        self.model = model or os.environ.get("TANTRA_MODEL", "")
        self.timeout = timeout
        if provider is None:
            base, key = os.environ.get("TANTRA_BASE_URL"), os.environ.get("TANTRA_API_KEY")
            if not (base and key and self.model):
                raise HarnessUnavailable("set TANTRA_BASE_URL, TANTRA_API_KEY and TANTRA_MODEL "
                                         "(OpenAI-compatible endpoint), or pass provider=")
            provider = tantra.OpenAICompatible(base, key)
        self._agents: dict[str, type] = {}
        for agent_name, out in COMBOS:
            self._agents[_registry_name(agent_name, out)] = type(
                f"{agent_name}_{out.__name__}", (tantra.Agent,),
                {"name": _registry_name(agent_name, out), "model": self.model or "story-model",
                 "prompt": build_system_prompt(agent_name, out), "output_schema": out})
        self._loop = asyncio.new_event_loop()
        self._thread = threading.Thread(target=self._loop.run_forever, name="tantra-loop", daemon=True)
        self._thread.start()
        self._store = store or tantra.MemoryStore()
        self._runtime = self._call(self._start(provider))

    async def _start(self, provider: Any) -> Any:
        await self._store.setup()
        return self._tantra.Runtime(provider, self._store, list(self._agents.values()),
                                    default_model=self.model or "story-model")

    def _call(self, coro: Any) -> Any:
        return asyncio.run_coroutine_threadsafe(coro, self._loop).result(self.timeout)

    async def _invoke(self, reg_name: str, user_message: str) -> Any:
        agent_cls = self._agents[reg_name]
        root = await self._runtime.create(agent_cls)
        async with self._runtime.connect(root, writable=True) as conn:
            return await conn.prompt(user_message, command_id=uuid4())

    def invoke_agent(self, agent_name: str, input_model: BaseModel, output_type: type[T],
                     context: InvokeContext) -> AgentResult[T]:
        reg = _registry_name(agent_name, output_type)
        if reg not in self._agents or agent_name not in all_specs():
            raise AgentError(f"no Tantra agent registered for {reg}")
        try:
            result = self._call(self._invoke(reg, build_user_message(input_model)))
        except Exception as exc:  # TantraError, provider errors, timeouts: retryable at orchestrator level
            raise AgentError(f"{type(exc).__name__}: {exc}") from exc
        if result.outcome != "completed" or result.output is None:
            raise AgentError(f"tantra outcome={result.outcome} error={result.error}")
        try:
            out = result.output if isinstance(result.output, output_type) else output_type.model_validate(result.output)
        except ValidationError as exc:
            raise AgentError(f"invalid {output_type.__name__}: {exc}") from exc
        return AgentResult(out, Usage(result.usage.input_tokens, result.usage.output_tokens))

    def close(self) -> None:
        try:
            self._call(self._runtime.aclose())
        finally:
            self._loop.call_soon_threadsafe(self._loop.stop)
