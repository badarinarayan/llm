"""Framework-independent runtime interface (design section 9).

The application only ever talks to a `StoryRuntime`. Tantra, a direct LLM API,
or a deterministic stub can implement it.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Generic, TypeVar

from pydantic import BaseModel

T = TypeVar("T", bound=BaseModel)


class AgentError(Exception):
    """A retryable agent failure (bad JSON, schema mismatch, provider hiccup)."""


class HarnessUnavailable(Exception):
    """The chosen harness cannot run in this environment (missing dependency/credentials)."""


@dataclass
class Usage:
    input_tokens: int = 0
    output_tokens: int = 0


@dataclass
class InvokeContext:
    run_id: str
    stage: str = ""
    attempt: int = 1
    session_id: str = ""  # isolates memory between stories; shared within a continuity universe


@dataclass
class AgentResult(Generic[T]):
    output: T
    usage: Usage = field(default_factory=Usage)


class StoryRuntime(ABC):
    name: str = "base"

    @abstractmethod
    def invoke_agent(self, agent_name: str, input_model: BaseModel, output_type: type[T],
                     context: InvokeContext) -> AgentResult[T]:
        """Run the named specialist on a typed input and return a validated typed output."""

    def close(self) -> None:  # pragma: no cover - optional hook
        pass
