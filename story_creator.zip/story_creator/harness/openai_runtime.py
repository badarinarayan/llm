"""Direct OpenAI runtime: one stateless Chat Completions call per specialist, JSON mode.

Needs `pip install openai` and OPENAI_API_KEY. Model: OPENAI_MODEL (or STORY_MODEL), default "gpt-5".
OPENAI_BASE_URL is honoured by the SDK, so any OpenAI-compatible endpoint also works.
JSON mode (not strict json_schema) is used because our artifact schemas have optional/defaulted fields;
the schema is embedded in the system prompt and every reply is validated against the Pydantic model.
"""
from __future__ import annotations

import os
from typing import Any, Optional

from pydantic import BaseModel

from .base import AgentError, AgentResult, HarnessUnavailable, InvokeContext, StoryRuntime, T, Usage
from .prompting import build_system_prompt, build_user_message, parse_json_output


class OpenAIRuntime(StoryRuntime):
    name = "openai"

    def __init__(self, model: Optional[str] = None, max_completion_tokens: int = 8000, client: Any = None):
        self.model = model or os.environ.get("OPENAI_MODEL") or os.environ.get("STORY_MODEL") or "gpt-5"
        self.max_completion_tokens = max_completion_tokens
        if client is None:
            try:
                import openai
            except ImportError as exc:
                raise HarnessUnavailable("pip install openai") from exc
            if not os.environ.get("OPENAI_API_KEY"):
                raise HarnessUnavailable("OPENAI_API_KEY is not set")
            client = openai.OpenAI()
        self.client = client

    def invoke_agent(self, agent_name: str, input_model: BaseModel, output_type: type[T],
                     context: InvokeContext) -> AgentResult[T]:
        try:
            resp = self.client.chat.completions.create(
                model=self.model,
                max_completion_tokens=self.max_completion_tokens,
                response_format={"type": "json_object"},
                messages=[{"role": "system", "content": build_system_prompt(agent_name, output_type)},
                          {"role": "user", "content": build_user_message(input_model)}])
        except Exception as exc:  # provider/network error: retryable at the orchestrator level
            raise AgentError(f"{type(exc).__name__}: {exc}") from exc
        choice = resp.choices[0]
        if getattr(choice, "finish_reason", None) == "length":
            raise AgentError("output truncated (max_completion_tokens reached)")
        text = choice.message.content or ""
        u = getattr(resp, "usage", None)
        usage = Usage(getattr(u, "prompt_tokens", 0) or 0, getattr(u, "completion_tokens", 0) or 0)
        return AgentResult(parse_json_output(text, output_type), usage)
