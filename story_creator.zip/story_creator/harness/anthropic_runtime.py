"""Direct Claude API runtime (no agent framework): one stateless call per specialist.

Needs `pip install anthropic` and ANTHROPIC_API_KEY. Set STORY_MODEL to choose the model.
Not exercised against the live API in this repo's tests (they use the stub and a fake client).
"""
from __future__ import annotations

import os
from typing import Any, Optional

from pydantic import BaseModel

from .base import AgentError, AgentResult, HarnessUnavailable, InvokeContext, StoryRuntime, T, Usage
from .prompting import build_system_prompt, build_user_message, parse_json_output


class AnthropicRuntime(StoryRuntime):
    name = "anthropic"

    def __init__(self, model: Optional[str] = None, max_tokens: int = 8000, client: Any = None):
        self.model = model or os.environ.get("STORY_MODEL", "claude-sonnet-5-5")
        self.max_tokens = max_tokens
        if client is None:
            try:
                import anthropic
            except ImportError as exc:
                raise HarnessUnavailable("pip install anthropic") from exc
            if not os.environ.get("ANTHROPIC_API_KEY"):
                raise HarnessUnavailable("ANTHROPIC_API_KEY is not set")
            client = anthropic.Anthropic()
        self.client = client

    def invoke_agent(self, agent_name: str, input_model: BaseModel, output_type: type[T],
                     context: InvokeContext) -> AgentResult[T]:
        try:
            resp = self.client.messages.create(
                model=self.model, max_tokens=self.max_tokens,
                system=build_system_prompt(agent_name, output_type),
                messages=[{"role": "user", "content": build_user_message(input_model)}])
        except Exception as exc:  # provider/network error: retryable at the orchestrator level
            raise AgentError(f"{type(exc).__name__}: {exc}") from exc
        text = "".join(getattr(b, "text", "") for b in resp.content)
        usage = Usage(getattr(resp.usage, "input_tokens", 0), getattr(resp.usage, "output_tokens", 0))
        return AgentResult(parse_json_output(text, output_type), usage)
