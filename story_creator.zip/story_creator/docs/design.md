# Multi-Agent Story Creator
## System Design and Agent Orchestration

**Version:** 0.1  
**Status:** Proposed design - no agents implemented yet  
**Date:** 9 October 2026  
**Preferred harness to evaluate:** [malayh/tantra](https://github.com/malayh/tantra)

> **Design decision:** Define the agent boundaries, shared data contracts, run sequence, and validation gates before creating individual agents. This document is the implementation blueprint, not the agents themselves.

## 1. Executive summary

The Multi-Agent Story Creator turns a story brief into a coherent story by coordinating five specialist agents:

1. **Language Expert** - normalizes the brief and ultimately writes and edits the story in the requested language and style.
2. **Numerology Expert** - maps configured numerology inputs to symbolic character traits for creative use.
3. **Casting Agent** - selects or proposes the characters needed to carry the situation and its conflict.
4. **Location Finder** - selects a setting that supports the story's action, mood, and practical needs.
5. **Situation Creator** - turns the brief into a dramatic situation with a goal, conflict, stakes, and possible beats.

A lightweight **Orchestrator** is responsible for routing, state, schemas, retries, budgets, and audit logs. It is not a sixth creative agent. The recommended run is staged: normalize the brief, create the situation, find characters and location in parallel, derive character profiles from numerology, validate the story plan, write the story, and run final checks.

The design keeps all agents behind typed input/output contracts. Tantra is the preferred harness to evaluate because its public project description advertises multi-agent/sub-agent trees, persistent sessions and memory, dynamic skills, tools, and pluggable guardrails. Exact API calls, current compatibility, and license must be checked against a local checkout before implementation. The application should remain portable if Tantra does not meet a requirement.

## 2. Goals and non-goals

### Goals

- Produce a complete short story from a user brief with traceable intermediate artifacts.
- Give each agent a narrow area of responsibility and a defined output contract.
- Use numerology as a consistent **creative archetype system**, not as a factual or scientific claim about real people's personalities.
- Support user-supplied base numbers, configured name/date-based methods, existing character libraries, and newly generated characters.
- Support multiple output languages, including Kannada and English, without hard-coding language-specific story logic into the orchestrator.
- Make runs observable and reproducible enough to debug: retain artifacts, agent inputs/outputs, versions, validation results, and retry reasons.
- Keep location generation flexible: fictional locations can be invented; real-world accuracy must be sourced and marked.

### Non-goals for the first version

- Fully autonomous publication or posting to social platforms.
- Training custom language models.
- Treating numerology as a validated personality assessment or making consequential decisions about real people from it.
- Maintaining a complex vector database before there is a clear retrieval need.
- Creating the five agents before the contracts and pipeline are agreed.

## 3. Design principles

1. **Artifacts over free-form handoffs.** Agents pass structured artifacts rather than relying on long conversational transcripts.
2. **One source of truth.** Every stage reads the latest version of a shared `StoryState` and writes a versioned artifact.
3. **Separate invention from verification.** A fictional place can be invented. A real town's geography, culture, or landmarks must be verified when factual specificity matters.
4. **Numerology is configurable and explicit.** Store the method and number source with each profile. Never silently mix systems or invent a birth date while presenting it as user-supplied.
5. **Bounded autonomy.** The orchestrator sets retry limits, call budgets, and a clear stopping condition.
6. **Human override.** The user can lock the cast, location, base numbers, language, ending, or other constraints.
7. **Keep the harness replaceable.** Application contracts must not depend directly on undocumented Tantra classes or method names.

## 4. High-level architecture

| Stage | Component | Output / responsibility |
|---|---|---|
| Entry | Story Orchestrator | Creates the run; owns state, budgets, tracing, retries, and run report. |
| 1 | Language Expert | Normalizes the brief and defines the initial style guide. |
| 2 | Situation Creator | Produces the dramatic situation, conflict, stakes, and story beats. |
| 3A - parallel | Casting Agent | Proposes/selects a compact cast and relationship map. |
| 3B - parallel | Location Finder | Finds suitable places and records sensory and continuity notes. |
| 4 | Numerology Expert | Derives a profile for each character after cast names/numbers are stable. |
| Gate | Coherence check | Validates that situation, characters, numerology, and locations work together. |
| Draft + deliver | Language Expert + validators | Produces the story, Story Bible updates, and run report. |

The casting and location steps can run concurrently after the situation is available. Numerology runs after the cast is stable because it needs the chosen character names and/or explicitly supplied numbers. If casting changes after numerology, only affected profiles should be recomputed.

## 5. Agent responsibilities and boundaries

### 5.1 Language Expert

**Purpose:** Preserve the requested language, voice, readability, and narrative consistency.

**Phase A - brief normalization:** convert the user's input into a normalized `StoryBrief`; identify missing but non-blocking details and choose conservative defaults. Do not invent hard constraints silently.

**Phase B - story drafting and editing:** combine the approved situation, cast profiles, and location brief into a story. Keep dialogue, narration, point of view, tense, tone, pacing, and word count consistent.

**Inputs:** raw brief; approved story plan; character cards; location card; style/voice settings; user locks.  
**Outputs:** normalized brief/style guide, then `StoryDraft` and editorial notes.

**Must not:** redefine the numerology method; silently replace a locked character or location; assert real-world details that were not verified; override user content boundaries.

### 5.2 Numerology Expert

**Purpose:** Translate an explicit or configured number into a symbolic character profile that helps generate consistent behavior and conflict.

**Inputs:** character name, optional date of birth, optional user-supplied base number, numerology method, genre, character role, and situation.  
**Outputs:** selected number, method, source of number, symbolic traits, strengths, blind spots, emotional trigger, conflict response, relationship tendencies, and an arc suggestion.

**Configuration:**
- `explicit_base_number` - use only a number supplied by the user or approved in the story brief.
- `pythagorean_name` or `chaldean_name` - calculate from a name using a documented mapping.
- `birth_date` - calculate from a supplied fictional birth date.
- `ask_or_suggest` - if the required data is absent, ask the user or suggest a clearly labelled fictional value.

For the MVP, prefer explicit base numbers when supplied; otherwise use one configured name-based method. The chosen method is saved with the artifact. The traits are creative conventions, not claims about actual people. Numerology should enrich character choices, not dictate every action or make all characters with the same number interchangeable.

### 5.3 Casting Agent

**Purpose:** Build a cast that can create, escalate, and resolve the situation.

**Inputs:** situation, genre, target length, existing character library (if any), cast size, casting mode, and constraints.  
**Outputs:** a cast list with role purpose, relationship map, external goal, internal need, tension with other characters, likely arc, and whether each character is existing or newly proposed.

**Casting modes:** `registry_only`, `new_characters`, or `mixed`. Characters should be selected for dramatic function and story fit, not just because their numerology looks convenient. Keep the cast proportionate to the requested length and avoid redundant roles.

**Must not:** assign final numerology traits itself; make a character's traits purely stereotypical; add an essential role without recording why it is needed.

### 5.4 Location Finder

**Purpose:** Choose the setting or locations that enable the story to happen and contribute to its atmosphere.

**Inputs:** situation, genre, mood, scene needs, user setting hints, and `setting_mode`.  
**Outputs:** a primary location plus optional secondary locations, a suitability rationale, scene affordances, sensory palette, logistical constraints, and provenance/truth status.

**Setting modes:**
- `fictional` - invent a plausible place and label it as fictional.
- `real_verified` - use a real place and verify material geographic/historical details with sources.
- `real_inspired` - use broad inspiration from a real setting without claiming the invented details are factual.

A location is more than a name: record why the plot needs it, what action it makes possible, and what continuity constraints it imposes (travel, time, weather, access, or local context). The system should avoid fake citations or invented factual certainty.

### 5.5 Situation Creator

**Purpose:** Convert the brief into a dramatic engine before the detailed cast and setting are selected.

**Inputs:** normalized brief, genre, theme, mood, length, content boundaries, and any user-provided story seed.  
**Outputs:** logline, opening situation, inciting incident, protagonist goal, opposing force, stakes, central question, 3-7 story beats, possible turning point, and candidate endings.

The situation should be specific enough to guide casting and location selection while leaving room for those agents to improve the story. It should not write the full story. If the brief is extremely open-ended, propose one strong situation and optionally two alternatives, then let the orchestrator select or ask the user depending on interaction mode.

## 6. Orchestration workflow

### Stage 0 - Create a run

Validate the user request, assign `run_id`, resolve defaults, load any relevant story bible, and establish a model/token/time budget. Preserve explicit user constraints as locked fields.

### Stage 1 - Normalize the brief

Language Expert creates a normalized brief and style guide. A deterministic validator checks required fields such as language, genre (or default), approximate length, and setting mode.

### Stage 2 - Create the dramatic situation

Situation Creator returns `StorySituation`. The orchestrator checks for a protagonist goal, a conflict, stakes, and beats. If any are missing, allow one targeted repair attempt.

### Stage 3 - Find cast and locations in parallel

Casting Agent proposes/selects characters. Location Finder identifies the place(s) that support the situation. Run in parallel because they depend on the situation but do not normally depend on one another. If the user has locked a cast or location, treat it as input rather than replacing it.

### Stage 4 - Derive numerology profiles

Numerology Expert creates one profile for each character requiring a profile. Validate that all number values have a recorded source and method. The orchestrator may request profiles in parallel by character. If a required number is missing, use the configured fallback policy; never fabricate user-provided data.

### Stage 5 - Coherence gate

A rules-based gate checks that the situation, cast, numerology, and location fit together. Check that each primary character has a reason to be in the story, the location supports key beats, traits create choices rather than contradictions, and no user-locked fields were changed. If the plan fails, route a specific repair request to the owning agent. Limit the repair loop to two cycles by default.

### Stage 6 - Draft and edit

Language Expert drafts the story from the approved plan. It should not receive unnecessary tool transcripts; it receives the latest, relevant artifacts. It may deliver a title, story, short synopsis, and optional note explaining how numerology influenced the characters.

### Stage 7 - Final validation and delivery

Run deterministic checks: required language, word-count tolerance, all required characters represented, primary location used, prohibited content absent, and no placeholders left behind. Then run an editorial review for flow, continuity, dialogue, and tone. Return the story and a compact run report. If checks fail, permit one focused edit pass before returning a transparent status.

## 7. Shared data contracts

Use Pydantic models (or an equivalent typed schema) at agent boundaries. Store JSON-compatible artifacts and validate every handoff.

### `StoryBrief`

- `run_id`: string
- `language`: requested output language
- `genre`, `theme`, `premise`, `tone`
- `target_word_count` and `word_count_tolerance`
- `audience`, `point_of_view`, `tense`
- `setting_mode`, `setting_hint`
- `cast_source_mode`, `desired_cast_size`
- `numerology_method`, `missing_number_policy`
- `locked_fields`: list of fields the user has fixed
- `content_boundaries`, `must_include`, `must_avoid`
- `continuity_id`: optional identifier for an ongoing story universe

### `StorySituation`

- `logline`, `opening_situation`, `inciting_incident`
- `protagonist_goal`, `opposing_force`, `stakes`, `central_question`
- `story_beats`: ordered list of 3-7 beats
- `candidate_endings`, `must_include`, `must_avoid`

### `CharacterCard`

- `character_id`, `name`, `status` (`existing` or `proposed`), `story_role`
- `dramatic_function`, `relationships`, `external_goal`, `internal_need`
- `strengths`, `flaws`, `speech_style`, `arc`
- `numerology`: number, method, input source, symbolic traits, tension patterns
- `locked`: boolean

### `LocationCard`

- `location_id`, `name`, `setting_mode`, `fiction_status`
- `suitability`, `scene_affordances`, `sensory_palette`, `constraints`
- `facts_to_verify`, `sources` (when applicable)

### `StoryDraft`

- `title`, `synopsis`, `body`, `language`, `actual_word_count`
- `continuity_notes`, `validation_results`, `unresolved_questions`

### Version and provenance fields

Every artifact should include `run_id`, `artifact_type`, `version`, `created_by`, `created_at`, and `parent_artifact_versions`. Store both the latest version and the event trail; do not overwrite the only record of earlier decisions.

## 8. Numerology policy and character design

The numerology system is an optional creative layer. It is not the orchestration engine and is not used to classify real users. The agent must:

- record which mapping was used and what input produced the number;
- keep number derivation separate from trait interpretation;
- express traits as tendencies or dramatic prompts, not immutable destiny;
- adapt the expression of a trait to the character's age, role, experience, and story context;
- allow contradictory or surprising behavior when motivated by the plot;
- explain when it used an explicitly supplied number versus a calculated or proposed one.

A character profile should connect symbolism to action. For example, an archetype associated with responsibility may over-function for family, avoid delegating, and face a plot choice about letting someone else help. A profile associated with idealism may take a principled stand that creates a cost. These are writing prompts, not universal statements about people with a given number.

## 9. Harness choice: Tantra

**Repository:** https://github.com/malayh/tantra

The project's public description advertises a Python harness with a FastAPI-inspired developer experience, persistent sessions/memory (SQLite and PostgreSQL options), tools, dynamically loaded skills, multi-agent/sub-agent trees, and pluggable guardrails. These capabilities appear relevant to this design. However, the current repository source and exact API surface have not been locally inspected as part of this design pass, so API names and compatibility are intentionally not assumed. See the [public project overview by its author](https://www.linkedin.com/posts/malay-hazarika_github-malayhtantra-agent-harness-framework-activity-7495737867487563776-VaMh); recheck all claims against the current checkout before adoption.

### Recommended integration approach

Put a thin adapter between the story application and Tantra:

- `StoryRuntime` - application-facing interface for starting a run and invoking a named specialist.
- `TantraAdapter` - maps the interface to the current Tantra APIs after the repository is checked out.
- `ArtifactStore` - typed JSON artifacts and version history; SQLite is a suitable MVP starting point.
- `RunObserver` - structured events, timings, token/cost estimates, retries, and validation outcomes.

The orchestrator should call application-level functions such as `invoke_agent(name, input_model, context)` rather than importing Tantra internals throughout the application. If Tantra does not satisfy requirements, a different harness can implement the same adapter interface.

### Pre-adoption checklist

1. Clone the repository and review its current README, license, examples, and dependency constraints.
2. Run a minimal example and tests in a clean virtual environment.
3. Confirm how agents/sub-agents are declared, invoked in parallel, and given structured inputs/outputs.
4. Verify the skill format and whether agent instructions can be versioned in this project.
5. Verify session/memory isolation for separate stories and ongoing universes.
6. Verify guardrail hooks, exception handling, cancellation, and retry semantics.
7. Confirm the selected model provider, secrets handling, and offline/test mode.
8. Build a tiny proof of concept with two stub agents before porting all five specialists.

Do not make the story product dependent on optional search, PDF, or shell tools unless a concrete story use case needs them.

## 10. Suggested project structure

```text
story_creator/
  pyproject.toml
  README.md
  .env.example
  config/
    defaults.yaml
    numerology.yaml
  app/
    api.py                 # optional FastAPI entry point
    cli.py                 # initial user-facing entry point
  orchestrator/
    pipeline.py
    state.py
    policy.py
    validators.py
    events.py
  agents/
    language_expert.py
    numerology_expert.py
    casting_agent.py
    location_finder.py
    situation_creator.py
  schemas/
    brief.py
    situation.py
    character.py
    location.py
    story.py
  harness/
    base.py
    tantra_adapter.py
  memory/
    artifact_store.py
    character_library.py
    story_bible.py
  prompts/
    language_expert.md
    numerology_expert.md
    casting_agent.md
    location_finder.md
    situation_creator.md
  tests/
    unit/
    contract/
    pipeline/
    evaluations/
  examples/
    sample_brief.yaml
```

This is a proposed structure, not generated agent code.

## 11. Illustrative run

**Brief:** Write an 800-1,000 word Kannada family drama with gentle humor. A discarded diary reconnects neighbors in a fictional town. Use three main characters and base numbers 6, 9, and 3.

1. **Language Expert** normalizes Kannada, family drama, gentle humor, 800-1,000 words, fictional setting, and three-character limit.
2. **Situation Creator** proposes that an old diary found in a reading room reveals an unfinished promise between neighbors and creates a present-day choice.
3. **Casting Agent** proposes a retired teacher, a shop owner with a long memory, and a curious teenager. It gives each a different goal and story function.
4. **Location Finder** creates a fictional lakeside reading room, market lane, and verandah, explaining which beats each supports.
5. **Numerology Expert** applies the configured mapping to the user-supplied 6, 9, and 3. As illustrative creative prompts, 6 may become over-responsible, 9 principled or idealistic, and 3 expressive or humorous; the story must still individualize each character.
6. **Coherence gate** checks the character count, relationships, scene logic, and whether the setting supports the turning point.
7. **Language Expert** writes and edits the Kannada story. Validators check language choice, word-count tolerance, required cast, setting, and unresolved placeholders.

The example describes the intended workflow; it is not a generated story or an assertion that one numerology interpretation is authoritative.

## 12. Evaluation and acceptance criteria

An MVP run is accepted when:

- all five specialist roles are invoked in the defined order, with casting and location eligible to run in parallel;
- every handoff validates against its schema;
- the final story follows the requested language and stays within the configured word-count tolerance;
- all required characters and the selected setting appear meaningfully in the story;
- every numerology-derived profile states its method and source;
- the story plan and final draft do not violate locked user constraints;
- factual claims about real locations are sourced or labelled unverified;
- failures and repairs are visible in the run report;
- the same saved brief can be replayed in stub mode for pipeline tests;
- a human can override any proposed artifact before drafting.

Suggested evaluation dimensions (score 1-5): narrative coherence, character distinctiveness, language quality, tone match, location utility, meaningful use of numerology, continuity, constraint adherence. Track these independently; do not collapse all quality into one unexplained score.

## 13. Risks and mitigations

| Risk | Mitigation |
|---|---|
| Agents contradict or overwrite one another | Typed artifacts, field ownership, locked fields, coherence gate |
| Numerology becomes deterministic stereotyping | Treat traits as prompts; allow individuality, contradictions, and user edits |
| Too many agents increase cost and latency | Parallelize cast/location; use short structured handoffs and bounded retries |
| Location agent invents factual details | Separate fictional and real modes; require sources for material real-world claims |
| Framework APIs change or are unsuitable | Thin `TantraAdapter`; keep application logic framework-independent |
| Long-running universes accumulate stale facts | Versioned story bible; identify canon vs draft suggestion; require explicit approval to change canon |
| Language quality varies across languages | Language-specific evaluation examples; human review for languages without strong automated checks |

## 14. Implementation sequence

1. **Design sign-off:** agree on agent boundaries, numerology policy, story brief fields, and expected artifacts.
2. **Tantra spike:** inspect repository/license/API locally and run two stub agents plus one structured handoff.
3. **Contract layer:** implement Pydantic schemas and deterministic validators before production prompts.
4. **Thin vertical slice:** connect Situation Creator, Casting Agent, and Language Expert with stub outputs.
5. **Add parallelism:** introduce Location Finder, then Numerology Expert and the coherence gate.
6. **Quality loop:** add replayable tests, evaluation cases, traces, budgets, and retry handling.
7. **User entry point:** start with CLI; add API/UI only after the story artifacts are stable.

**Decision requested before implementation:** approve the five-agent responsibilities, default numerology fallback, supported story settings (fictional vs verified real), and the Tantra adapter approach. No agents should be implemented until these design choices are accepted or consciously revised.

