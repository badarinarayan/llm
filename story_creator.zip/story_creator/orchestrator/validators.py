"""Deterministic validators: brief, situation, plan coherence gate, and final draft.

Each issue names an `owner` so a failure is routed as a *specific* repair request
to the responsible agent (design section 6, stage 5).
"""
from __future__ import annotations

import re
from typing import Any, Optional

from schemas.brief import StoryBrief
from schemas.character import CastPlan
from schemas.location import LocationPlan
from schemas.situation import StorySituation
from schemas.story import StoryDraft, ValidationIssue, ValidationReport

# Unicode script ranges for automated language checks. Languages not listed get a
# warning that only human review can confirm the language.
SCRIPT_RANGES: dict[str, tuple[int, int]] = {
    "kn": (0x0C80, 0x0CFF), "hi": (0x0900, 0x097F), "mr": (0x0900, 0x097F), "sa": (0x0900, 0x097F),
    "ta": (0x0B80, 0x0BFF), "te": (0x0C00, 0x0C7F), "ml": (0x0D00, 0x0D7F),
    "bn": (0x0980, 0x09FF), "gu": (0x0A80, 0x0AFF), "pa": (0x0A00, 0x0A7F),
}
LATIN_LANGS = {"en", "fr", "es", "de", "it", "pt", "nl"}
MIN_SCRIPT_RATIO = 0.6

PLACEHOLDER_RE = re.compile(
    r"\bTODO\b|\bTBD\b|\bFIXME\b|lorem ipsum|\{\{.*?\}\}|\[\[.*?\]\]|<[A-Za-z_ ]{2,30}>|\bXXX+\b|\[(?:name|place|insert)[^\]]*\]",
    re.IGNORECASE,
)


def _issue(code: str, message: str, owner: str = "orchestrator", severity: str = "error") -> ValidationIssue:
    return ValidationIssue(code=code, message=message, owner=owner, severity=severity)  # type: ignore[arg-type]


def word_count(text: str) -> int:
    return len(text.split())


# ----------------------------------------------------------------- stage 1
def validate_brief(brief: StoryBrief) -> ValidationReport:
    r = ValidationReport(stage="brief")
    if not brief.language:
        r.issues.append(_issue("brief.language", "language is required", "language_expert"))
    if not brief.genre:
        r.issues.append(_issue("brief.genre", "genre is required (or a default)", "language_expert"))
    if brief.target_word_count < 50:
        r.issues.append(_issue("brief.length", "target_word_count must be >= 50", "language_expert"))
    if not 0 <= brief.word_count_tolerance <= 0.5:
        r.issues.append(_issue("brief.tolerance", "word_count_tolerance must be within 0..0.5", "language_expert"))
    if brief.desired_cast_size < 1:
        r.issues.append(_issue("brief.cast_size", "desired_cast_size must be >= 1", "language_expert"))
    if not brief.premise and not brief.theme:
        r.issues.append(_issue("brief.premise", "brief has neither premise nor theme", "language_expert", "warning"))
    for n in brief.explicit_base_numbers:
        if n < 1 or n > 33:
            r.issues.append(_issue("brief.number", f"explicit base number {n} out of range 1..33", "language_expert"))
    if len(brief.explicit_base_numbers) > brief.desired_cast_size:
        r.issues.append(_issue("brief.number_count", "more base numbers than cast slots", "language_expert", "warning"))
    if brief.language not in SCRIPT_RANGES and brief.language not in LATIN_LANGS:
        r.issues.append(_issue("brief.language_check", f"no automated check for '{brief.language}'; human review needed",
                               "language_expert", "warning"))
    return r


# ----------------------------------------------------------------- stage 2
def validate_situation(s: StorySituation) -> ValidationReport:
    r = ValidationReport(stage="situation")
    for name in ("protagonist_goal", "opposing_force", "stakes"):
        if not getattr(s, name).strip():
            r.issues.append(_issue(f"situation.{name}", f"{name} is missing", "situation_creator"))
    if not 3 <= len(s.story_beats) <= 7:
        r.issues.append(_issue("situation.beats", f"need 3-7 story beats, got {len(s.story_beats)}", "situation_creator"))
    orders = [b.order for b in s.story_beats]
    if sorted(orders) != list(range(1, len(orders) + 1)):
        r.issues.append(_issue("situation.beat_order", "beats must be numbered 1..N without gaps", "situation_creator"))
    return r


# ----------------------------------------------------------------- stage 5
def validate_plan(brief: StoryBrief, situation: StorySituation, cast: CastPlan, locs: LocationPlan) -> ValidationReport:
    r = ValidationReport(stage="coherence_gate")
    chars = cast.characters

    # cast
    ids = [c.character_id for c in chars]
    if len(set(ids)) != len(ids):
        r.issues.append(_issue("cast.duplicate_ids", "character_id values must be unique", "casting_agent"))
    if not chars:
        r.issues.append(_issue("cast.empty", "cast is empty", "casting_agent"))
    if len(chars) > brief.desired_cast_size:
        r.issues.append(_issue("cast.size", f"cast has {len(chars)} characters; limit is {brief.desired_cast_size}",
                               "casting_agent"))
    elif len(chars) < brief.desired_cast_size and brief.cast_source_mode != "registry_only":
        r.issues.append(_issue("cast.size_short", f"cast has {len(chars)} of {brief.desired_cast_size} requested",
                               "casting_agent", "warning"))
    for c in chars:
        if not (c.dramatic_function.strip() or c.why_needed.strip()):
            r.issues.append(_issue("cast.purpose", f"{c.name}: no recorded reason to be in the story", "casting_agent"))
        if not c.external_goal.strip():
            r.issues.append(_issue("cast.goal", f"{c.name}: missing external goal", "casting_agent", "warning"))
        if brief.cast_source_mode == "registry_only" and c.status != "existing":
            r.issues.append(_issue("cast.registry_only", f"{c.name} is proposed but cast mode is registry_only",
                                   "casting_agent"))
        for rel in c.relationships:
            if rel.with_id not in ids:
                r.issues.append(_issue("cast.relationship", f"{c.name}: relationship to unknown id {rel.with_id}",
                                       "casting_agent", "warning"))
    for lock in brief.locked_characters:
        match = next((c for c in chars if c.character_id == lock.character_id), None)
        if match is None or not match.locked:
            r.issues.append(_issue("lock.character", f"locked character {lock.character_id} missing/unlocked",
                                   "casting_agent"))

    # numerology
    for c in chars:
        p = c.numerology
        if p is None:
            r.issues.append(_issue("numerology.missing", f"{c.name}: no numerology profile", "numerology_expert"))
            continue
        if not p.method or not p.input_source:
            r.issues.append(_issue("numerology.provenance", f"{c.name}: profile lacks method/source", "numerology_expert"))
        if p.input_source == "suggested_fictional":
            r.issues.append(_issue("numerology.suggested",
                                   f"{c.name}: number {p.number} is a suggested fictional value, not user data",
                                   "numerology_expert", "warning"))
        if not p.symbolic_traits:
            r.issues.append(_issue("numerology.traits", f"{c.name}: no symbolic traits", "numerology_expert"))
    # same number must not make characters interchangeable
    by_number: dict[int, list[str]] = {}
    for c in chars:
        if c.numerology:
            by_number.setdefault(c.numerology.number, []).append(c.name)
    for n, names in by_number.items():
        if len(names) > 1:
            r.issues.append(_issue("numerology.shared_number",
                                   f"{', '.join(names)} share number {n}; keep them individually distinct",
                                   "casting_agent", "warning"))

    # locations
    locations = locs.locations
    primaries = [loc for loc in locations if loc.role == "primary"]
    if len(primaries) != 1:
        r.issues.append(_issue("location.primary", f"expected exactly 1 primary location, got {len(primaries)}",
                               "location_finder"))
    covered = {b for loc in locations for b in loc.supports_beats}
    missing = [b.order for b in situation.story_beats if b.order not in covered]
    if missing:
        r.issues.append(_issue("location.beats", f"no location supports beats {missing}", "location_finder"))
    for loc in locations:
        if not loc.suitability.strip():
            r.issues.append(_issue("location.suitability", f"{loc.name}: missing suitability rationale",
                                   "location_finder", "warning"))
        if brief.setting_mode == "fictional" and loc.fiction_status != "fictional":
            r.issues.append(_issue("location.mode", f"{loc.name}: setting_mode is fictional but status is "
                                   f"{loc.fiction_status}", "location_finder"))
        if loc.fiction_status == "real_verified" and not loc.sources:
            r.issues.append(_issue("location.sources", f"{loc.name}: real_verified requires sources",
                                   "location_finder"))
        if loc.fiction_status == "unverified_real":
            r.issues.append(_issue("location.unverified", f"{loc.name}: real place with unverified facts "
                                   f"({len(loc.facts_to_verify)} to verify); do not state them as fact",
                                   "location_finder", "warning"))
    if brief.locked_location and not any(loc.location_id == brief.locked_location.location_id and loc.locked
                                         for loc in locations):
        r.issues.append(_issue("lock.location", "locked location missing/unlocked", "location_finder"))
    return r


# ----------------------------------------------------------------- stage 7
def _letters(text: str) -> list[str]:
    return [ch for ch in text if ch.isalpha()]


def language_ratio(text: str, language: str) -> Optional[float]:
    letters = _letters(text)
    if not letters:
        return 0.0
    if language in SCRIPT_RANGES:
        lo, hi = SCRIPT_RANGES[language]
        return sum(lo <= ord(ch) <= hi for ch in letters) / len(letters)
    if language in LATIN_LANGS:
        return sum(ch.isascii() or "LATIN" in _name(ch) for ch in letters) / len(letters)
    return None


def _name(ch: str) -> str:
    import unicodedata
    return unicodedata.name(ch, "")


def _name_present(name: str, body: str) -> bool:
    if name in body:
        return True
    first = name.split()[0] if name.split() else name
    return len(first) >= 2 and first in body


def validate_draft(brief: StoryBrief, cast: CastPlan, locs: LocationPlan, draft: StoryDraft) -> ValidationReport:
    r = ValidationReport(stage="draft")
    body = draft.body or ""
    n = word_count(body)
    if n != draft.actual_word_count:
        r.issues.append(_issue("draft.word_count_field", f"reported {draft.actual_word_count} words, counted {n}",
                               "language_expert", "warning"))
    if not (brief.min_words <= n <= brief.max_words):
        r.issues.append(_issue("draft.length", f"{n} words; required {brief.min_words}-{brief.max_words}",
                               "language_expert"))
    ratio = language_ratio(body, brief.language)
    if ratio is None:
        r.issues.append(_issue("draft.language_unchecked", f"language '{brief.language}' needs human review",
                               "language_expert", "warning"))
    elif ratio < (MIN_SCRIPT_RATIO if brief.language in SCRIPT_RANGES else 0.9):
        r.issues.append(_issue("draft.language", f"text does not look like '{brief.language}' (ratio {ratio:.2f})",
                               "language_expert"))
    if draft.language != brief.language:
        r.issues.append(_issue("draft.language_field", f"draft.language={draft.language}, brief={brief.language}",
                               "language_expert"))
    for c in cast.characters:
        if not _name_present(c.name, body):
            r.issues.append(_issue("draft.character_missing", f"character '{c.name}' not in story", "language_expert"))
    primary = next((loc for loc in locs.locations if loc.role == "primary"), None)
    if primary and primary.name not in body:
        r.issues.append(_issue("draft.location_missing", f"primary location '{primary.name}' not used", "language_expert"))
    if PLACEHOLDER_RE.search(body) or PLACEHOLDER_RE.search(draft.title):
        r.issues.append(_issue("draft.placeholder", "placeholder text left in title/body", "language_expert"))
    if not draft.title.strip():
        r.issues.append(_issue("draft.title", "missing title", "language_expert"))
    lowered = body.lower()
    for term in brief.must_avoid:
        if term and term.lower() in lowered:
            r.issues.append(_issue("draft.must_avoid", f"contains prohibited content '{term}'", "language_expert"))
    for term in brief.must_include:
        if term and term.lower() not in lowered:
            r.issues.append(_issue("draft.must_include", f"missing required element '{term}'", "language_expert",
                                   "warning"))
    for loc in locs.locations:
        if loc.fiction_status == "unverified_real" and loc.facts_to_verify:
            r.issues.append(_issue("draft.unverified_facts", f"{loc.name}: unverified real-world facts need a check",
                                   "language_expert", "warning"))
    return r


def issues_by_owner(report: ValidationReport) -> dict[str, list[ValidationIssue]]:
    out: dict[str, list[ValidationIssue]] = {}
    for i in report.errors:
        out.setdefault(i.owner, []).append(i)
    return out
