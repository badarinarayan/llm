"""Structured run events (RunObserver)."""
from __future__ import annotations

import json
import threading
import time
from contextlib import contextmanager
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterator, Optional

from schemas.common import utc_now


@dataclass
class Event:
    ts: str
    run_id: str
    kind: str
    stage: Optional[str]
    data: dict[str, Any] = field(default_factory=dict)


class RunObserver:
    def __init__(self, path: str | Path | None = None):
        self.events: list[Event] = []
        self._lock = threading.Lock()
        self._path = Path(path) if path else None
        if self._path:
            self._path.parent.mkdir(parents=True, exist_ok=True)

    def emit(self, run_id: str, kind: str, stage: Optional[str] = None, **data: Any) -> Event:
        ev = Event(utc_now(), run_id, kind, stage, data)
        with self._lock:
            self.events.append(ev)
            if self._path:
                with open(self._path, "a", encoding="utf-8") as fh:
                    fh.write(json.dumps(asdict(ev), ensure_ascii=False, default=str) + "\n")
        return ev

    @contextmanager
    def span(self, run_id: str, kind: str, stage: Optional[str] = None, **data: Any) -> Iterator[dict[str, Any]]:
        start = time.perf_counter()
        extra: dict[str, Any] = {}
        try:
            yield extra
        finally:
            self.emit(run_id, kind, stage, seconds=round(time.perf_counter() - start, 4), **data, **extra)

    def of_kind(self, kind: str) -> list[Event]:
        return [e for e in self.events if e.kind == kind]
