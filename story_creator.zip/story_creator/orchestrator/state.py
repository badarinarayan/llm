"""Shared StoryState: the single source of truth that stages read and write."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from schemas.brief import StoryBrief
from schemas.character import CastPlan, NumerologyProfile
from schemas.location import LocationPlan
from schemas.situation import StorySituation
from schemas.story import EditorialReview, RunReport, StoryDraft, ValidationReport


@dataclass
class StoryState:
    run_id: str
    raw_brief: dict
    brief: Optional[StoryBrief] = None
    situation: Optional[StorySituation] = None
    cast: Optional[CastPlan] = None
    locations: Optional[LocationPlan] = None
    profiles: dict[str, NumerologyProfile] = field(default_factory=dict)
    # fingerprint of the inputs each profile was derived from (for selective recompute)
    profile_fingerprints: dict[str, str] = field(default_factory=dict)
    draft: Optional[StoryDraft] = None
    review: Optional[EditorialReview] = None
    reports: list[ValidationReport] = field(default_factory=list)
    repairs: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    versions: dict[str, int] = field(default_factory=dict)  # latest saved version per artifact key
    status: str = "created"
    report: Optional[RunReport] = None
