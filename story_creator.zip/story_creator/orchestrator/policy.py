"""Run policy, budgets and lock enforcement."""
from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from typing import Any

from pydantic import BaseModel

from schemas.brief import StoryBrief
from schemas.character import CastPlan, CharacterCard
from schemas.location import LocationCard, LocationPlan


class StoryError(Exception):
    """Base class for orchestrator-level failures."""


class BudgetExceeded(StoryError):
    pass


class MissingNumberError(StoryError):
    """Raised when a required numerology number is missing and policy is 'ask'."""


@dataclass
class RunPolicy:
    max_repair_cycles: int = 2
    max_situation_repairs: int = 1
    max_edit_passes: int = 1
    max_agent_retries: int = 1
    max_agent_calls: int = 40
    max_seconds: float = 900
    max_tokens: int = 400_000
    max_parallel: int = 4

    @classmethod
    def from_config(cls, cfg: dict[str, Any]) -> "RunPolicy":
        known = {k: v for k, v in (cfg.get("policy") or {}).items() if k in cls.__dataclass_fields__}
        return cls(**known)


class Budget:
    """Call / time / token budget shared by all stages of one run (thread-safe)."""

    def __init__(self, policy: RunPolicy):
        self.policy = policy
        self.calls = 0
        self.tokens_in = 0
        self.tokens_out = 0
        self._start = time.monotonic()
        self._lock = threading.Lock()

    def check(self) -> None:
        with self._lock:
            if self.calls >= self.policy.max_agent_calls:
                raise BudgetExceeded(f"agent call budget exhausted ({self.policy.max_agent_calls})")
            if time.monotonic() - self._start > self.policy.max_seconds:
                raise BudgetExceeded(f"time budget exhausted ({self.policy.max_seconds}s)")
            if self.tokens_in + self.tokens_out > self.policy.max_tokens:
                raise BudgetExceeded(f"token budget exhausted ({self.policy.max_tokens})")

    def record(self, tokens_in: int = 0, tokens_out: int = 0) -> None:
        with self._lock:
            self.calls += 1
            self.tokens_in += tokens_in
            self.tokens_out += tokens_out


def enforce_locked_fields(raw: dict[str, Any], brief: StoryBrief) -> tuple[StoryBrief, list[str]]:
    """User-locked brief fields can never be changed by the Language Expert."""
    restored: list[str] = []
    updates: dict[str, Any] = {}
    for name in brief.locked_fields:
        if name in raw and getattr(brief, name, None) != raw[name]:
            updates[name] = raw[name]
            restored.append(name)
    return (brief.model_copy(update=updates) if updates else brief), restored


def _is_empty(v: Any) -> bool:
    return v is None or v == "" or v == [] or v == {}


def _merge_locked(lock: BaseModel, agent_card: BaseModel, skip: tuple[str, ...] = ()) -> dict[str, Any]:
    """User-supplied (non-empty) values win; fields the user left empty may be filled by the agent."""
    agent = agent_card.model_dump()
    return {k: (agent[k] if _is_empty(v) and k not in skip and k in agent else v)
            for k, v in lock.model_dump().items()}


def enforce_locked_cast(brief: StoryBrief, cast: CastPlan) -> tuple[CastPlan, list[str]]:
    """Locked characters keep every field the user supplied; agents may only fill the blanks."""
    notes: list[str] = []
    chars = list(cast.characters)
    index = {c.character_id: i for i, c in enumerate(chars)}
    for lock in brief.locked_characters:
        if lock.character_id in index:
            i = index[lock.character_id]
            merged = CharacterCard.model_validate({**_merge_locked(lock, chars[i], skip=("numerology",)),
                                                   "locked": True, "numerology": chars[i].numerology})
            if merged != chars[i]:
                chars[i] = merged
                notes.append(f"restored locked character {lock.character_id}")
        else:
            chars.insert(0, lock.model_copy(update={"locked": True}))
            notes.append(f"re-inserted locked character {lock.character_id}")
    return (cast.model_copy(update={"characters": chars}) if notes else cast), notes


def enforce_locked_location(brief: StoryBrief, plan: LocationPlan) -> tuple[LocationPlan, list[str]]:
    lock = brief.locked_location
    if lock is None:
        return plan, []
    agent = next((loc for loc in plan.locations if loc.location_id == lock.location_id), None)
    merged = LocationCard.model_validate(
        {**(_merge_locked(lock, agent) if agent else lock.model_dump()), "locked": True, "role": "primary"})
    others = [loc.model_copy(update={"role": "secondary"}) for loc in plan.locations
              if loc.location_id != lock.location_id]
    new_locs = [merged] + others
    if agent is not None and agent == merged and [l.location_id for l in plan.locations][0] == lock.location_id:
        return plan, []
    return plan.model_copy(update={"locations": new_locs}), [f"restored locked location {lock.location_id}"]
