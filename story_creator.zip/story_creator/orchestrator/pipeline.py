"""Story pipeline: staged orchestration with typed handoffs, gates and bounded repair.

Stages (design section 6):
  0 create run -> 1 normalize brief -> 2 situation -> 3 cast || location ->
  4 numerology (per character, parallel) -> 5 coherence gate (+repair) ->
  6 draft -> 7 validate / review / one edit pass -> report
"""
from __future__ import annotations

import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, ValidationError

from agents.casting_agent import CastingAgent
from agents.language_expert import LanguageExpert
from agents.location_finder import LocationFinder
from agents.numerology_expert import NumerologyExpert, assign_explicit_numbers, profile_fingerprint
from agents.situation_creator import SituationCreator
from config import load_defaults, load_numerology
from harness.base import AgentError, InvokeContext, StoryRuntime
from memory.artifact_store import ArtifactStore
from memory.character_library import CharacterLibrary
from memory.story_bible import StoryBible
from schemas.brief import StoryBrief
from schemas.character import CastPlan, CharacterCard, NumerologyProfile
from schemas.common import utc_now
from schemas.location import LocationPlan
from schemas.situation import StorySituation
from schemas.story import RunReport, StoryDraft, ValidationReport

from .events import RunObserver
from .policy import (Budget, BudgetExceeded, MissingNumberError, RunPolicy, StoryError, enforce_locked_cast,
                     enforce_locked_fields, enforce_locked_location)
from .state import StoryState
from .validators import (issues_by_owner, validate_brief, validate_draft, validate_plan, validate_situation,
                         word_count)

USER_OWNED_BRIEF_FIELDS = ("locked_fields", "locked_characters", "locked_location", "explicit_base_numbers",
                           "continuity_id")
PLAN_KEYS = {"brief": StoryBrief, "situation": StorySituation, "cast": CastPlan, "locations": LocationPlan}


def new_run_id() -> str:
    return f"run-{datetime.now():%Y%m%d-%H%M%S}-{uuid.uuid4().hex[:6]}"


def render_story(draft: StoryDraft) -> str:
    parts = [f"# {draft.title}", ""]
    if draft.synopsis:
        parts += [f"*{draft.synopsis}*", ""]
    parts += [draft.body.strip(), ""]
    if draft.numerology_note:
        parts += ["---", f"_Numerology note:_ {draft.numerology_note}", ""]
    return "\n".join(parts)


class StoryPipeline:
    def __init__(self, runtime: StoryRuntime, store: ArtifactStore, *, config: Optional[dict[str, Any]] = None,
                 numerology_cfg: Optional[dict[str, Any]] = None, observer: Optional[RunObserver] = None,
                 policy: Optional[RunPolicy] = None, library: Optional[CharacterLibrary] = None,
                 bible: Optional[StoryBible] = None):
        self.runtime = runtime
        self.store = store
        self.config = config or load_defaults()
        self.numerology_cfg = numerology_cfg or load_numerology()
        self.observer = observer or RunObserver()
        self.policy = policy or RunPolicy.from_config(self.config)
        self.library = library or CharacterLibrary()
        self.bible = bible

    # ------------------------------------------------------------------ public
    def run(self, raw_brief: dict[str, Any], *, stop_after: Optional[str] = None,
            run_id: Optional[str] = None) -> StoryState:
        """Run the full pipeline. `stop_after="plan"` pauses after the coherence gate so a human
        can override artifacts (`override` + `resume`)."""
        state = StoryState(run_id=run_id or new_run_id(), raw_brief=raw_brief)
        return _Run(self, state).execute(stop_after=stop_after)

    def resume(self, run_id: str) -> StoryState:
        """Continue from the latest saved plan artifacts (including human overrides) to a draft.

        The plan is validated but never auto-repaired: a human edit is authoritative."""
        loaded: dict[str, BaseModel] = {}
        for key, model in PLAN_KEYS.items():
            art = self.store.latest(run_id, key, model)
            if art is None:
                raise StoryError(f"run {run_id} has no '{key}' artifact; cannot resume")
            loaded[key] = art
        state = StoryState(run_id=run_id, raw_brief={}, brief=loaded["brief"], situation=loaded["situation"],  # type: ignore[arg-type]
                           cast=loaded["cast"], locations=loaded["locations"])  # type: ignore[arg-type]
        state.versions = self.store.latest_versions(run_id)
        return _Run(self, state).execute(resume=True)


class _Run:
    """State and behaviour of one run (kept apart so the pipeline object stays reusable)."""

    def __init__(self, p: StoryPipeline, state: StoryState):
        self.p, self.s = p, state
        self.obs, self.store = p.observer, p.store
        self.budget = Budget(p.policy)
        self.stage = ""
        self.retries: list[str] = []
        self.started = utc_now()
        self.session_id = state.run_id
        self.lang = LanguageExpert(self.invoke)
        self.situations = SituationCreator(self.invoke)
        self.casting = CastingAgent(self.invoke)
        self.locations = LocationFinder(self.invoke)
        self.numerology = NumerologyExpert(self.invoke, p.numerology_cfg)

    # ------------------------------------------------------------ plumbing
    def invoke(self, agent_name: str, input_model: BaseModel, output_type: type[BaseModel]) -> Any:
        """Runtime call with budget, retry-on-schema/transient failure, and event logging."""
        last: Optional[Exception] = None
        for attempt in range(1, self.p.policy.max_agent_retries + 2):
            self.budget.check()
            ctx = InvokeContext(self.s.run_id, self.stage, attempt, self.session_id)
            try:
                with self.obs.span(self.s.run_id, "agent_call", self.stage, agent=agent_name, attempt=attempt,
                                   output=output_type.__name__):
                    res = self.p.runtime.invoke_agent(agent_name, input_model, output_type, ctx)
                self.budget.record(res.usage.input_tokens, res.usage.output_tokens)
                return res.output
            except (AgentError, ValidationError) as exc:
                self.budget.record()
                last = exc
                msg = f"{agent_name} attempt {attempt}: {type(exc).__name__}: {str(exc)[:200]}"
                self.retries.append(msg)
                self.obs.emit(self.s.run_id, "agent_retry", self.stage, agent=agent_name, reason=msg)
        raise StoryError(f"{agent_name} failed after {self.p.policy.max_agent_retries + 1} attempts: {last}")

    def save(self, key: str, art: Any, created_by: str, parents: tuple[str, ...] = ()) -> Any:
        stamped = self.store.save(self.s.run_id, key, art, created_by,
                                  {k: self.s.versions[k] for k in parents if k in self.s.versions})
        self.s.versions[key] = stamped.version
        return stamped

    def stage_span(self, name: str):
        self.stage = name
        return self.obs.span(self.s.run_id, "stage", name)

    def fail(self, status: str, message: str) -> None:
        self.s.status = status
        self.s.notes.append(message)
        self.obs.emit(self.s.run_id, "run_failed", self.stage, status=status, message=message)

    # ------------------------------------------------------------ driver
    def execute(self, stop_after: Optional[str] = None, resume: bool = False) -> StoryState:
        s = self.s
        self.obs.emit(s.run_id, "run_started", None, resume=resume, harness=self.p.runtime.name,
                      raw_brief=s.raw_brief if not resume else None)
        try:
            if not resume:
                if not self.stage_brief() or not self.stage_situation():
                    return self.finish()
                self.stage_cast_and_location()
                self.stage_numerology()
            ok = self.stage_gate(allow_repair=not resume)
            if not ok:
                self.fail("failed_plan", "coherence gate failed; see run report")
            elif stop_after == "plan":
                s.status = "plan_ready"
            else:
                self.stage_draft()
        except BudgetExceeded as exc:
            self.fail("failed_budget", str(exc))
        except MissingNumberError as exc:
            self.fail("needs_input", str(exc))
        except StoryError as exc:
            self.fail("failed_error", str(exc))
        return self.finish()

    # ------------------------------------------------------------ stage 0/1
    def stage_brief(self) -> bool:
        s, cfg = self.s, self.p.config
        with self.stage_span("brief"):
            raw = s.raw_brief
            user_brief = StoryBrief.model_validate({**cfg.get("brief", {}), **raw})  # parses user-owned data
            brief = self.lang.normalize_brief(raw, cfg.get("brief", {}))
            brief = self._pin_user_fields(brief, user_brief)
            report = validate_brief(brief)
            if not report.ok:
                notes = [i.message for i in report.errors]
                s.repairs.append("brief: " + "; ".join(notes))
                brief = self._pin_user_fields(self.lang.normalize_brief(raw, cfg.get("brief", {}), notes), user_brief)
                report = validate_brief(brief)
            s.reports.append(report)
            if not report.ok:
                self.fail("failed_brief", "; ".join(i.message for i in report.errors))
                return False
            s.brief = self.save("brief", brief, "language_expert")
            self.session_id = brief.continuity_id or s.run_id
            return True

    def _pin_user_fields(self, brief: StoryBrief, user_brief: StoryBrief) -> StoryBrief:
        """User-supplied locks and numbers are authoritative, whatever the Language Expert returned."""
        brief = brief.model_copy(update={f: getattr(user_brief, f) for f in USER_OWNED_BRIEF_FIELDS
                                         if f in self.s.raw_brief})
        brief, restored = enforce_locked_fields(self.s.raw_brief, brief)
        if restored:
            self.s.notes.append(f"restored locked brief fields: {restored}")
            self.obs.emit(self.s.run_id, "locked_field_restored", self.stage, fields=restored)
        return brief

    # ------------------------------------------------------------ stage 2
    def stage_situation(self) -> bool:
        s = self.s
        with self.stage_span("situation"):
            sit = self.situations.create(s.brief)  # type: ignore[arg-type]
            report = validate_situation(sit)
            for _ in range(self.p.policy.max_situation_repairs):
                if report.ok:
                    break
                notes = [i.message for i in report.errors]
                s.repairs.append("situation: " + "; ".join(notes))
                sit = self.situations.create(s.brief, notes)  # type: ignore[arg-type]
                report = validate_situation(sit)
            s.reports.append(report)
            if not report.ok:
                self.fail("failed_situation", "; ".join(i.message for i in report.errors))
                return False
            s.situation = self.save("situation", sit, "situation_creator", ("brief",))
            return True

    # ------------------------------------------------------------ stage 3
    def _library_cards(self) -> list[CharacterCard]:
        cards = {c.character_id: c for c in self.p.library.all()}
        b = self.s.brief
        if self.p.bible and b and b.continuity_id:
            cards.update({c.character_id: c for c in self.p.bible.canon_characters(b.continuity_id)})
        return list(cards.values())

    def _make_cast(self, notes: Optional[list[str]] = None) -> CastPlan:
        cast = self.casting.cast(self.s.brief, self.s.situation, self._library_cards(), notes)  # type: ignore[arg-type]
        cast, restored = enforce_locked_cast(self.s.brief, cast)  # type: ignore[arg-type]
        self._note_restored(restored)
        return cast

    def _make_locations(self, notes: Optional[list[str]] = None) -> LocationPlan:
        plan = self.locations.find(self.s.brief, self.s.situation, notes)  # type: ignore[arg-type]
        plan, restored = enforce_locked_location(self.s.brief, plan)  # type: ignore[arg-type]
        self._note_restored(restored)
        return plan

    def _note_restored(self, restored: list[str]) -> None:
        for r in restored:
            self.s.notes.append(r)
            self.obs.emit(self.s.run_id, "lock_enforced", self.stage, detail=r)

    def stage_cast_and_location(self) -> None:
        s = self.s
        with self.stage_span("cast_and_location"):
            with ThreadPoolExecutor(max_workers=min(2, self.p.policy.max_parallel)) as pool:
                f_cast, f_loc = pool.submit(self._make_cast), pool.submit(self._make_locations)
                cast, locs = f_cast.result(), f_loc.result()
            s.cast = self.save("cast", cast, "casting_agent", ("brief", "situation"))
            s.locations = self.save("locations", locs, "location_finder", ("brief", "situation"))

    # ------------------------------------------------------------ stage 4
    def stage_numerology(self, force: bool = False) -> None:
        s = self.s
        with self.stage_span("numerology"):
            brief, cast = s.brief, s.cast
            assert brief and cast and s.situation
            assignments = assign_explicit_numbers(brief, cast)
            jobs = []
            for c in cast.characters:
                derived = self.numerology.derive(c, assignments.get(c.character_id), brief)
                fp = profile_fingerprint(c, derived)
                if not force and s.profile_fingerprints.get(c.character_id) == fp and c.character_id in s.profiles:
                    continue  # inputs unchanged: keep the existing profile
                jobs.append((c, derived, fp))

            def one(job: tuple) -> tuple[str, NumerologyProfile, str]:
                c, derived, fp = job
                prof = self.numerology.profile(brief, s.situation, c, derived)  # type: ignore[arg-type]
                prof = self.save(f"numerology:{c.character_id}", prof, "numerology_expert",
                                 ("brief", "situation", "cast"))
                return c.character_id, prof, fp

            with ThreadPoolExecutor(max_workers=max(1, self.p.policy.max_parallel)) as pool:
                for cid, prof, fp in pool.map(one, jobs):
                    s.profiles[cid], s.profile_fingerprints[cid] = prof, fp
            ids = {c.character_id for c in cast.characters}
            for stale in set(s.profiles) - ids:
                s.profiles.pop(stale), s.profile_fingerprints.pop(stale, None)
            merged = cast.model_copy(update={"characters": [
                c.model_copy(update={"numerology": s.profiles.get(c.character_id)}) for c in cast.characters]})
            s.cast = self.save("cast", merged, "orchestrator", ("brief", "situation", "cast"))

    # ------------------------------------------------------------ stage 5
    def stage_gate(self, allow_repair: bool = True) -> bool:
        s = self.s
        with self.stage_span("coherence_gate"):
            cycle = 0
            while True:
                report = validate_plan(s.brief, s.situation, s.cast, s.locations)  # type: ignore[arg-type]
                report.stage = f"coherence_gate#{cycle}"
                s.reports.append(report)
                if report.ok or not allow_repair or cycle >= self.p.policy.max_repair_cycles:
                    return report.ok
                groups = issues_by_owner(report)
                repairable = {o: i for o, i in groups.items()
                              if o in ("casting_agent", "location_finder", "numerology_expert")}
                if not repairable:
                    return False
                cycle += 1
                force_profiles = False
                for owner, issues in repairable.items():
                    notes = [i.message for i in issues]
                    s.repairs.append(f"{owner} (cycle {cycle}): " + "; ".join(notes))
                    self.obs.emit(s.run_id, "repair_requested", self.stage, owner=owner, cycle=cycle, notes=notes)
                    if owner == "casting_agent":
                        s.cast = self.save("cast", self._make_cast(notes), "casting_agent", ("brief", "situation"))
                    elif owner == "location_finder":
                        s.locations = self.save("locations", self._make_locations(notes), "location_finder",
                                                ("brief", "situation"))
                    else:
                        force_profiles = True
                # only characters whose inputs changed are recomputed (unless numerology itself was flagged)
                self.stage_numerology(force=force_profiles)
                self.stage = "coherence_gate"

    # ------------------------------------------------------------ stage 6/7
    def _stamp(self, draft: StoryDraft) -> StoryDraft:
        return draft.model_copy(update={"actual_word_count": word_count(draft.body)})

    def stage_draft(self) -> None:
        s = self.s
        b, sit, cast, locs = s.brief, s.situation, s.cast, s.locations
        assert b and sit and cast and locs
        with self.stage_span("draft"):
            draft = self._stamp(self.lang.draft_story(b, sit, cast, locs))
        with self.stage_span("final_validation"):
            report = validate_draft(b, cast, locs, draft)
            review = self.lang.review(b, draft, cast, locs)
            edits = 0
            while (not report.ok or review.needs_edit) and edits < self.p.policy.max_edit_passes:
                edits += 1
                s.repairs.append(f"draft edit pass {edits}: " + "; ".join(
                    [i.message for i in report.errors] + review.edit_instructions))
                draft = self._stamp(self.lang.edit(b, sit, cast, locs, draft, report.errors, review.edit_instructions))
                report = validate_draft(b, cast, locs, draft)
                review = self.lang.review(b, draft, cast, locs)
            report.stage = "draft"
            s.reports.append(report)
            numerology_note = draft.numerology_note or self._numerology_note(cast)
            draft = draft.model_copy(update={"validation_results": report.issues, "numerology_note": numerology_note})
            s.draft = self.save("draft", draft, "language_expert", ("brief", "situation", "cast", "locations"))
            s.review = self.save("review", review, "language_expert", ("draft",))
        if not report.ok:
            self.fail("failed_validation", "; ".join(i.message for i in report.errors))
        else:
            s.status = "ok_with_warnings" if any(r.warnings for r in s.reports) else "ok"
            if self.p.bible and b.continuity_id:
                self.p.bible.suggest_from_run(b.continuity_id, s.run_id, cast.characters, locs.locations)

    @staticmethod
    def _numerology_note(cast: CastPlan) -> str:
        bits = [f"{c.name}: {c.numerology.number} ({c.numerology.input_source.replace('_', ' ')})"
                for c in cast.characters if c.numerology]
        return "Symbolic creative prompts only. " + "; ".join(bits) if bits else ""

    # ------------------------------------------------------------ wrap-up
    def finish(self) -> StoryState:
        s = self.s
        report = RunReport(
            status=s.status, harness=self.p.runtime.name, started_at=self.started, finished_at=utc_now(),
            agent_calls=self.budget.calls, tokens_in=self.budget.tokens_in, tokens_out=self.budget.tokens_out,
            stage_results=s.reports, repairs=s.repairs, retries=self.retries, notes=s.notes,
            artifact_versions=dict(s.versions), scores=s.review.scores if s.review else {})
        s.report = self.save("report", report, "orchestrator")
        self.obs.emit(s.run_id, "run_finished", None, status=s.status, calls=self.budget.calls)
        return s
