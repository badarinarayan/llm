"""Config loading (YAML) with package-relative defaults."""
from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

CONFIG_DIR = Path(__file__).resolve().parent
ROOT = CONFIG_DIR.parent


def _load(name: str, directory: Path | None = None) -> dict[str, Any]:
    with open((directory or CONFIG_DIR) / name, encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


def load_defaults(directory: Path | None = None) -> dict[str, Any]:
    return _load("defaults.yaml", directory)


def load_numerology(directory: Path | None = None) -> dict[str, Any]:
    return _load("numerology.yaml", directory)
