import json

import pytest

from harness.base import AgentError
from harness.stub import StubRuntime
from memory.story_bible import StoryBible
from orchestrator.pipeline import StoryPipeline
from schemas import (CastPlan, CharacterCard, LocationCard, LocationPlan, StoryBrief, StoryDraft)
from schemas.io import CastingInput, DraftInput

from conftest import EN_BRIEF, KN_BRIEF


def agents_called(rt):
    return [a for a, _ in rt.calls]


# ------------------------------------------------------------------ happy path / acceptance criteria
def test_design_example_end_to_end(make):
    p, rt = make()
    s = p.run(KN_BRIEF)
    assert s.status == "ok", s.notes
    names = agents_called(rt)
    # all five roles invoked, in the defined order (cast/location may interleave)
    assert names[:2] == ["language_expert", "situation_creator"]
    assert set(names[2:4]) == {"casting_agent", "location_finder"}
    assert names[4:7] == ["numerology_expert"] * 3
    assert names[7:] == ["language_expert", "language_expert"]
    assert [c[1] for c in rt.calls if c[0] == "language_expert"] == [
        "NormalizeBriefInput", "DraftInput", "ReviewInput"]
    # user-supplied numbers 6, 9, 3 assigned in cast order, with method + source recorded
    nums = [(c.numerology.number, c.numerology.method, c.numerology.input_source) for c in s.cast.characters]
    assert nums == [(6, "explicit_base_number", "user_supplied"), (9, "explicit_base_number", "user_supplied"),
                    (3, "explicit_base_number", "user_supplied")]
    # story meets language, length, cast, location
    d, b = s.draft, s.brief
    assert b.min_words <= d.actual_word_count <= b.max_words
    assert all(c.name in d.body for c in s.cast.characters)
    assert s.locations.locations[0].name in d.body
    assert d.validation_results == [] or all(i.severity == "warning" for i in d.validation_results)
    assert s.report.status == "ok" and s.report.agent_calls == 9
    assert "numerology" in (d.numerology_note or "").lower() or "Symbolic" in d.numerology_note


def test_every_artifact_is_versioned_with_parents(make):
    p, _ = make()
    s = p.run(EN_BRIEF)
    h = p.store.history(s.run_id)
    keys = {r["key"] for r in h}
    assert {"brief", "situation", "cast", "locations", "draft", "review", "report"} <= keys
    assert any(k.startswith("numerology:") for k in keys)
    cast_versions = [r for r in h if r["key"] == "cast"]
    assert [r["version"] for r in cast_versions] == [1, 2]          # casting, then merged with profiles
    assert p.store.latest(s.run_id, "draft", StoryDraft).parent_artifact_versions["cast"] == 2


def test_replay_in_stub_mode_is_deterministic(make):
    p1, _ = make()
    p2, _ = make()
    a, b = p1.run(KN_BRIEF), p2.run(KN_BRIEF)
    assert a.run_id != b.run_id
    assert a.draft.body == b.draft.body
    strip = lambda s: [c.model_dump(exclude={"numerology"}) for c in s.cast.characters]
    assert strip(a) == strip(b)
    assert [c.numerology.archetype for c in a.cast.characters] == [c.numerology.archetype for c in b.cast.characters]


def test_cast_and_location_run_concurrently(make):
    import threading
    gate = threading.Barrier(2, timeout=5)
    rt = StubRuntime()

    def wait(inp, i):
        gate.wait()      # both must be in flight at the same time or the barrier times out
        return None
    rt.overrides = {"casting_agent": wait, "location_finder": wait}
    p, _ = make(rt)
    assert p.run(EN_BRIEF).status in ("ok", "ok_with_warnings")


def test_calculated_numbers_when_none_supplied(make):
    p, _ = make()
    s = p.run({**EN_BRIEF, "numerology_method": "chaldean_name"})
    for c in s.cast.characters:
        assert c.numerology.method == "chaldean_name" and c.numerology.input_source == "calculated_name"


# ------------------------------------------------------------------ locks
def test_locked_brief_fields_cannot_be_changed_by_language_expert(make):
    rt = StubRuntime()

    def tamper(inp, i):
        b = rt._NormalizeBriefInput(inp)
        return b.model_copy(update={"genre": "horror", "locked_fields": []})
    rt.overrides = {"language_expert": lambda inp, i: tamper(inp, i) if type(inp).__name__ == "NormalizeBriefInput" else None}
    p, _ = make(rt)
    s = p.run({**EN_BRIEF, "genre": "comedy", "locked_fields": ["genre"]})
    assert s.brief.genre == "comedy" and s.brief.locked_fields == ["genre"]
    assert any("locked brief fields" in n for n in s.notes)


def test_locked_character_and_location_survive_agents_that_ignore_them(make):
    rt = StubRuntime()
    rt.overrides = {
        "casting_agent": lambda inp, i: CastPlan(characters=[CharacterCard(
            character_id="z", name="Zed", dramatic_function="x", external_goal="g")] * 1),
        "location_finder": lambda inp, i: LocationPlan(locations=[LocationCard(
            location_id="other", name="Elsewhere", suitability="s", supports_beats=[1, 2, 3, 4, 5])]),
    }
    p, _ = make(rt)
    brief = {**EN_BRIEF, "desired_cast_size": 2,
             "locked_characters": [{"character_id": "hero", "name": "Asha", "dramatic_function": "lead"}],
             "locked_location": {"location_id": "home", "name": "Rose Cottage"}}
    s = p.run(brief)
    assert s.status in ("ok", "ok_with_warnings"), s.notes
    hero = next(c for c in s.cast.characters if c.character_id == "hero")
    assert hero.locked and hero.name == "Asha" and hero.dramatic_function == "lead"
    assert s.locations.locations[0].location_id == "home" and s.locations.locations[0].locked
    assert "Rose Cottage" in s.draft.body and "Asha" in s.draft.body


# ------------------------------------------------------------------ repair loops
def test_coherence_repair_is_routed_to_owner_and_recomputes_only_changed_profiles(make):
    rt = StubRuntime()

    def oversize_once(inp, i):
        if i > 1:
            return None
        cast = rt._CastingInput(inp)
        extra = CharacterCard(character_id="x1", name="Extra", dramatic_function="d", external_goal="g")
        return cast.model_copy(update={"characters": cast.characters + [extra]})   # 4 > desired 3
    rt.overrides = {"casting_agent": oversize_once}
    p, _ = make(rt)
    s = p.run({**EN_BRIEF, "numerology_method": "explicit_base_number", "explicit_base_numbers": [1, 2, 3]})
    assert s.status in ("ok", "ok_with_warnings"), s.notes
    assert agents_called(rt).count("casting_agent") == 2
    assert agents_called(rt).count("location_finder") == 1                  # not asked to repair
    assert any(r.startswith("casting_agent (cycle 1)") for r in s.repairs)
    # initial: 4 profiles; after repair the 3 survivors are unchanged except the one whose number shifted,
    # but a profile is never recomputed when its inputs are identical
    assert agents_called(rt).count("numerology_expert") <= 4 + 1


def test_repair_loop_is_bounded(make):
    rt = StubRuntime()
    rt.overrides = {"casting_agent": lambda inp, i: CastPlan(characters=[])}   # always broken; locks irrelevant
    p, _ = make(rt, max_repair_cycles=2)
    s = p.run(EN_BRIEF)
    assert s.status == "failed_plan"
    assert agents_called(rt).count("casting_agent") == 3                      # initial + 2 repairs
    assert s.draft is None and s.report.status == "failed_plan"
    assert "language_expert" not in agents_called(rt)[-1:]


def test_transient_agent_failure_is_retried_and_reported(make):
    rt = StubRuntime()

    def flaky(inp, i):
        if i == 1:
            raise AgentError("bad json")
        return None
    rt.overrides = {"situation_creator": flaky}
    p, _ = make(rt)
    s = p.run(EN_BRIEF)
    assert s.status in ("ok", "ok_with_warnings")
    assert len(s.report.retries) == 1 and "bad json" in s.report.retries[0]


def test_persistent_agent_failure_stops_the_run_with_status(make):
    rt = StubRuntime()

    def broken(inp, i):
        raise AgentError("down")
    rt.overrides = {"casting_agent": broken}
    p, _ = make(rt)
    s = p.run(EN_BRIEF)
    assert s.status == "failed_error" and "casting_agent" in s.notes[0]


def test_budget_is_enforced(make):
    p, _ = make(max_agent_calls=3)
    s = p.run(EN_BRIEF)
    assert s.status == "failed_budget" and s.draft is None


def test_missing_number_with_ask_policy_needs_input(make):
    p, _ = make()
    s = p.run({**KN_BRIEF, "numerology_method": "birth_date", "explicit_base_numbers": [],
               "missing_number_policy": "ask"})
    assert s.status == "needs_input" and "birth date" in s.notes[0]


def test_suggested_numbers_are_flagged_as_warnings(make):
    p, _ = make()
    s = p.run({**KN_BRIEF, "numerology_method": "birth_date", "explicit_base_numbers": []})
    assert s.status == "ok_with_warnings"
    assert all(c.numerology.input_source == "suggested_fictional" for c in s.cast.characters)
    assert any(i.code == "numerology.suggested" for r in s.report.stage_results for i in r.warnings)


# ------------------------------------------------------------------ draft stage
def test_one_focused_edit_pass_fixes_a_bad_draft(make):
    rt = StubRuntime()

    def bad_first(inp, i):
        if type(inp).__name__ != "DraftInput":
            return None
        d = rt._DraftInput(inp)
        return d.model_copy(update={"body": d.body + " TODO fix ending"})
    rt.overrides = {"language_expert": bad_first}
    p, _ = make(rt)
    s = p.run(EN_BRIEF)
    assert s.status in ("ok", "ok_with_warnings")
    assert "TODO" not in s.draft.body
    assert [c[1] for c in rt.calls if c[0] == "language_expert"].count("EditInput") == 1
    assert any(r.startswith("draft edit pass 1") for r in s.repairs)


def test_unrecoverable_draft_is_returned_transparently(make):
    rt = StubRuntime()
    rt.overrides = {"language_expert": lambda inp, i: (
        rt._DraftInput(inp).model_copy(update={"title": "x", "body": "too short"})
        if type(inp).__name__ in ("DraftInput", "EditInput") else None)}
    p, _ = make(rt)
    s = p.run(EN_BRIEF)
    assert s.status == "failed_validation"
    assert s.draft is not None and any(i.code == "draft.length" for i in s.draft.validation_results)


def test_must_avoid_is_enforced_in_final_check(make):
    rt = StubRuntime()
    p, _ = make(rt)
    s = p.run({**EN_BRIEF, "must_avoid": ["quiet worry"]})       # the stub's first sentence contains it
    assert s.status == "failed_validation"
    assert any(i.code == "draft.must_avoid" for i in s.draft.validation_results)


# ------------------------------------------------------------------ human override / resume
def test_plan_pause_human_override_and_resume(make):
    p, rt = make()
    s = p.run(EN_BRIEF, stop_after="plan")
    assert s.status == "plan_ready" and s.draft is None
    assert "language_expert" not in [a for a, _ in rt.calls if a == "language_expert" and _ == "DraftInput"]
    # a human renames a character in the saved cast, as a new version
    cast = p.store.latest(s.run_id, "cast", CastPlan)
    edited = cast.model_copy(update={"characters": [cast.characters[0].model_copy(update={"name": "Zubin"})]
                                    + cast.characters[1:]})
    saved = p.store.save(s.run_id, "cast", edited, "human")
    assert saved.created_by == "human" and saved.version == 3
    s2 = p.resume(s.run_id)
    assert s2.status in ("ok", "ok_with_warnings"), s2.notes
    assert "Zubin" in s2.draft.body
    assert p.store.latest(s.run_id, "draft", StoryDraft).parent_artifact_versions["cast"] == 3


def test_resume_does_not_auto_repair_a_human_edit(make):
    p, rt = make()
    s = p.run(EN_BRIEF, stop_after="plan")
    cast = p.store.latest(s.run_id, "cast", CastPlan)
    p.store.save(s.run_id, "cast", cast.model_copy(update={"characters": []}), "human")
    before = len(rt.calls)
    s2 = p.resume(s.run_id)
    assert s2.status == "failed_plan" and len(rt.calls) == before        # no agent was invoked


def test_resume_requires_a_saved_plan(make):
    from orchestrator.policy import StoryError
    p, _ = make()
    with pytest.raises(StoryError):
        p.resume("does-not-exist")


# ------------------------------------------------------------------ story bible
def test_story_bible_gets_suggestions_never_direct_canon(make, tmp_path):
    p, _ = make()
    p.bible = StoryBible(tmp_path / "bible")
    s = p.run({**EN_BRIEF, "continuity_id": "uni-1"})
    data = p.bible.load("uni-1")
    assert data["canon"]["characters"] == [] and len(data["suggestions"]) >= 3
    first = data["suggestions"][0]["id"]
    p.bible.approve("uni-1", first)
    assert len(p.bible.canon_characters("uni-1")) + len(p.bible.load("uni-1")["canon"]["locations"]) == 1
