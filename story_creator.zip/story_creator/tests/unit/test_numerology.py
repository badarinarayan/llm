import pytest

from agents.numerology_expert import (assign_explicit_numbers, birth_date_number, derive_number, name_number,
                                      profile_fingerprint, reduce_number)
from orchestrator.policy import MissingNumberError
from schemas import CastPlan, CharacterCard, StoryBrief


def card(name, **kw):
    return CharacterCard(character_id=kw.pop("cid", name.lower()), name=name, **kw)


def test_reduction_and_master_numbers():
    assert reduce_number(29) == 11            # master number kept
    assert reduce_number(29, keep_master=False) == 2
    assert reduce_number(48) == 3          # 4+8=12 -> 3
    assert reduce_number(9) == 9


def test_name_methods_are_documented_mappings(numcfg):
    assert name_number("ABC", "pythagorean_name", numcfg) == 6      # 1+2+3
    assert name_number("Meera", "pythagorean_name", numcfg) == 6    # 4+5+5+9+1=24 -> 6
    assert name_number("Ravi", "chaldean_name", numcfg) == 1        # 2+1+6+1=10 -> 1
    assert name_number("José", "pythagorean_name", numcfg) == name_number("Jose", "pythagorean_name", numcfg)
    assert name_number("ಶಾರದಮ್ಮ", "pythagorean_name", numcfg) is None   # no Latin letters


def test_birth_date(numcfg):
    assert birth_date_number("1990-05-14", numcfg) == 11            # digits sum to 29 -> 11 (master number kept)
    assert birth_date_number("no date", numcfg) is None


def test_explicit_numbers_win_and_record_source(numcfg):
    b = StoryBrief(numerology_method="chaldean_name")
    d = derive_number(card("Ravi"), 9, b, numcfg)
    assert (d.number, d.method, d.input_source) == (9, "explicit_base_number", "user_supplied")


def test_calculated_number_records_method_and_input(numcfg):
    d = derive_number(card("Ravi"), None, StoryBrief(numerology_method="chaldean_name"), numcfg)
    assert (d.number, d.method, d.input_source, d.input_value) == (1, "chaldean_name", "calculated_name", "Ravi")


def test_missing_data_policy_ask_raises(numcfg):
    b = StoryBrief(numerology_method="birth_date", missing_number_policy="ask")
    with pytest.raises(MissingNumberError):
        derive_number(card("Ravi"), None, b, numcfg)


def test_missing_data_policy_suggest_is_labelled_and_deterministic(numcfg):
    b = StoryBrief(numerology_method="birth_date", missing_number_policy="suggest")
    d1 = derive_number(card("ಶಾರದಮ್ಮ"), None, b, numcfg)
    d2 = derive_number(card("ಶಾರದಮ್ಮ"), None, b, numcfg)
    assert d1.input_source == "suggested_fictional" and "not user data" in d1.note
    assert d1 == d2 and 1 <= d1.number <= 9


def test_explicit_numbers_assigned_in_cast_order_fixed_numbers_do_not_consume_slots():
    cast = CastPlan(characters=[card("A", fixed_number=4), card("B"), card("C"), card("D")])
    out = assign_explicit_numbers(StoryBrief(explicit_base_numbers=[6, 9]), cast)
    assert out == {"a": 4, "b": 6, "c": 9}


def test_fingerprint_changes_only_with_inputs(numcfg):
    b = StoryBrief()
    c = card("Ravi", story_role="lead")
    d = derive_number(c, 6, b, numcfg)
    assert profile_fingerprint(c, d) == profile_fingerprint(c.model_copy(update={"external_goal": "x"}), d)
    assert profile_fingerprint(c, d) != profile_fingerprint(c.model_copy(update={"story_role": "foil"}), d)
