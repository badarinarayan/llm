import json

from harness.stub import StubRuntime
from memory.artifact_store import ArtifactStore
from orchestrator.validators import (validate_brief, validate_draft, validate_plan, validate_situation,
                                     word_count)
from schemas import (CastPlan, CharacterCard, LocationCard, LocationPlan, StoryBeat, StoryBrief, StoryDraft,
                     StorySituation)


# ----------------------------------------------------------------- store
def test_versions_increment_and_history_is_kept(tmp_path):
    s = ArtifactStore(tmp_path / "a.db", mirror_dir=tmp_path / "runs")
    a = s.save("r1", "brief", StoryBrief(genre="x"), "language_expert")
    b = s.save("r1", "brief", StoryBrief(genre="y"), "human", {"situation": 3})
    assert (a.version, b.version) == (1, 2)
    assert s.latest("r1", "brief", StoryBrief).genre == "y"
    assert s.get("r1", "brief", 1, StoryBrief).genre == "x"           # nothing overwritten
    assert b.created_by == "human" and b.parent_artifact_versions == {"situation": 3}
    assert b.artifact_type == "story_brief" and b.run_id == "r1" and b.created_at
    assert len(s.history("r1", "brief")) == 2
    mirrored = json.loads((tmp_path / "runs" / "r1" / "brief.v2.json").read_text())
    assert mirrored["genre"] == "y"
    s.close()


# ----------------------------------------------------------------- validators
def sit(n=4):
    return StorySituation(logline="l", opening_situation="o", inciting_incident="i", protagonist_goal="g",
                          opposing_force="f", stakes="s", central_question="q",
                          story_beats=[StoryBeat(order=i + 1, summary="b") for i in range(n)])


def plan_for(brief, situation):
    rt = StubRuntime()
    from schemas.io import CastingInput, LocationInput
    cast = rt._CastingInput(CastingInput(brief=brief, situation=situation))
    locs = rt._LocationInput(LocationInput(brief=brief, situation=situation))
    return cast, locs


def test_brief_validation():
    assert validate_brief(StoryBrief(premise="p")).ok
    r = validate_brief(StoryBrief(premise="p", target_word_count=10, explicit_base_numbers=[40]))
    assert {i.code for i in r.errors} == {"brief.length", "brief.number"}


def test_situation_validation():
    assert validate_situation(sit()).ok
    bad = sit(2).model_copy(update={"stakes": " "})
    assert {i.code for i in validate_situation(bad).errors} == {"situation.stakes", "situation.beats"}


def test_plan_gate_reports_owner_for_each_defect():
    b, s = StoryBrief(premise="p"), sit()
    cast, locs = plan_for(b, s)
    codes = {i.code: i.owner for i in validate_plan(b, s, cast, locs).errors}
    assert codes == {"numerology.missing": "numerology_expert"}      # profiles come later
    locs_bad = LocationPlan(locations=[locs.locations[0].model_copy(update={"supports_beats": [1]})])
    codes = {i.code: i.owner for i in validate_plan(b, s, cast, locs_bad).errors}
    assert codes["location.beats"] == "location_finder"
    too_many = CastPlan(characters=cast.characters + [CharacterCard(character_id="x", name="X", why_needed="w")] * 2)
    assert validate_plan(b, s, too_many, locs).errors[0].owner in ("casting_agent", "numerology_expert")
    assert any(i.code == "cast.size" for i in validate_plan(b, s, too_many, locs).errors)


def test_real_verified_requires_sources():
    b, s = StoryBrief(setting_mode="real_verified"), sit()
    cast, locs = plan_for(b, s)
    forced = LocationPlan(locations=[locs.locations[0].model_copy(update={"fiction_status": "real_verified"})])
    assert any(i.code == "location.sources" for i in validate_plan(b, s, cast, forced).errors)
    assert any(i.code == "location.unverified" for i in validate_plan(b, s, cast, locs).warnings)


def draft(body, **kw):
    return StoryDraft(title=kw.pop("title", "T"), body=body, language=kw.pop("language", "en"),
                      actual_word_count=word_count(body), **kw)


def test_draft_validation_catches_each_defect():
    b = StoryBrief(language="en", target_word_count=10, word_count_tolerance=0.2, must_avoid=["gore"])
    s = sit()
    cast = CastPlan(characters=[CharacterCard(character_id="a", name="Meera Rao")])
    locs = LocationPlan(locations=[LocationCard(location_id="l", name="the Mill")])
    ok = draft("Meera walked to the Mill and waited there patiently today.")   # 10 words
    assert validate_draft(b, cast, locs, ok).ok
    assert any(i.code == "draft.length" for i in validate_draft(b, cast, locs, draft("Meera Mill")).errors)
    assert any(i.code == "draft.character_missing"
               for i in validate_draft(b, cast, locs, draft("Someone walked to the Mill and waited there today.")).errors)
    assert any(i.code == "draft.location_missing"
               for i in validate_draft(b, cast, locs, draft("Meera walked to the shop and waited there today ok.")).errors)
    assert any(i.code == "draft.placeholder"
               for i in validate_draft(b, cast, locs, draft("Meera walked to the Mill TODO and waited there ok.")).errors)
    assert any(i.code == "draft.must_avoid"
               for i in validate_draft(b, cast, locs, draft("Meera walked to the Mill and hid the gore there ok.")).errors)
    assert any(i.code == "draft.language"
               for i in validate_draft(b, cast, locs, draft("ಮೀರಾ Meera Mill ಕಡೆಗೆ ಹೋದಳು ಮತ್ತು ಅಲ್ಲಿ ಕಾದಳು ಬಹಳ ಹೊತ್ತು")).errors)


def test_kannada_language_check():
    b = StoryBrief(language="kn", target_word_count=6, word_count_tolerance=0.5)
    cast = CastPlan(characters=[CharacterCard(character_id="a", name="ಅನು")])
    locs = LocationPlan(locations=[LocationCard(location_id="l", name="ಜಗುಲಿ")])
    good = draft("ಅನು ಜಗುಲಿ ಮೇಲೆ ಕುಳಿತು ಓದಿದಳು ಇಂದು", language="kn")
    assert validate_draft(b, cast, locs, good).ok
    english = draft("Anu sat on the verandah today ಅನು ಜಗುಲಿ", language="kn")
    assert not validate_draft(b, cast, locs, english).ok
