from pathlib import Path

import pytest
import yaml

HERE = Path(__file__).parent
CASES = yaml.safe_load((HERE / "cases.yaml").read_text(encoding="utf-8"))


@pytest.mark.parametrize("case", CASES, ids=[c["name"] for c in CASES])
def test_case(case, make):
    brief = yaml.safe_load((HERE / case["brief"]).resolve().read_text(encoding="utf-8"))
    p, _ = make()
    s = p.run(brief)
    exp = case["expect"]
    allowed = exp["status"] if isinstance(exp["status"], list) else [exp["status"]]
    assert s.status in allowed, s.notes
    assert s.draft.language == exp["language"]
    assert len(s.cast.characters) == exp["cast_size"]
    if "numbers" in exp:
        assert [c.numerology.number for c in s.cast.characters] == exp["numbers"]
    assert set(s.review.scores) == {
        "narrative_coherence", "character_distinctiveness", "language_quality", "tone_match",
        "location_utility", "numerology_use", "continuity", "constraint_adherence"}
