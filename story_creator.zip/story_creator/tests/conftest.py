from __future__ import annotations

import pytest

from config import load_defaults, load_numerology
from harness.stub import StubRuntime
from memory.artifact_store import ArtifactStore
from orchestrator.pipeline import StoryPipeline
from orchestrator.policy import RunPolicy

KN_BRIEF = {  # the design's illustrative run (section 11)
    "language": "kn", "genre": "family drama", "tone": "gentle humor",
    "premise": "A discarded diary reconnects neighbors in a fictional town.",
    "target_word_count": 900, "word_count_tolerance": 0.12, "setting_mode": "fictional",
    "desired_cast_size": 3, "numerology_method": "explicit_base_number", "explicit_base_numbers": [6, 9, 3],
}
EN_BRIEF = {"language": "en", "genre": "mystery", "tone": "warm", "premise": "A letter arrives for the dead.",
            "target_word_count": 400, "desired_cast_size": 3, "numerology_method": "pythagorean_name"}


@pytest.fixture
def store():
    s = ArtifactStore(":memory:")
    yield s
    s.close()


@pytest.fixture
def numcfg():
    return load_numerology()


@pytest.fixture
def make(store):
    """make(runtime=None, **policy) -> (pipeline, runtime)"""
    def _make(runtime=None, **policy):
        rt = runtime or StubRuntime()
        cfg = load_defaults()
        pol = RunPolicy.from_config(cfg)
        for k, v in policy.items():
            setattr(pol, k, v)
        return StoryPipeline(rt, store, config=cfg, policy=pol), rt
    return _make
