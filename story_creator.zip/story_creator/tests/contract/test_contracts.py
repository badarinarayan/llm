import json
from types import SimpleNamespace

import pytest

from agents.base import all_specs
from harness.anthropic_runtime import AnthropicRuntime
from harness.base import AgentError, InvokeContext
from harness.prompting import build_system_prompt, output_json_schema, parse_json_output
from harness.stub import StubRuntime
from schemas import (CastPlan, EditorialReview, LocationPlan, NumerologyProfile, StoryBrief, StoryDraft,
                     StorySituation)
from schemas.io import SituationInput

OUTPUTS = [StoryBrief, StorySituation, CastPlan, LocationPlan, NumerologyProfile, StoryDraft, EditorialReview]


def test_five_agents_with_prompts():
    specs = all_specs()
    assert set(specs) == {"language_expert", "numerology_expert", "casting_agent", "location_finder",
                          "situation_creator"}
    for spec in specs.values():
        text = spec.load_prompt()
        assert text.startswith("#") and len(text) > 300 and spec.must_not


@pytest.mark.parametrize("model", OUTPUTS)
def test_output_schema_hides_provenance_fields(model):
    props = output_json_schema(model)["properties"]
    assert not {"run_id", "version", "created_by", "created_at", "parent_artifact_versions"} & set(props)


def test_every_handoff_roundtrips_through_json(make):
    p, rt = make()
    s = p.run({"language": "en", "premise": "x", "target_word_count": 300, "numerology_method": "chaldean_name"})
    for key, model in [("brief", StoryBrief), ("situation", StorySituation), ("cast", CastPlan),
                       ("locations", LocationPlan), ("draft", StoryDraft), ("review", EditorialReview)]:
        art = p.store.latest(s.run_id, key, model)
        assert model.model_validate_json(art.model_dump_json()) == art
        assert art.run_id == s.run_id and art.created_by and art.version >= 1


def test_parse_json_output_accepts_fenced_and_rejects_garbage():
    payload = StoryDraft(title="t", body="b").model_dump()
    assert parse_json_output("```json\n" + json.dumps(payload) + "\n```", StoryDraft).title == "t"
    assert parse_json_output("Sure! " + json.dumps(payload) + " done", StoryDraft).body == "b"
    with pytest.raises(AgentError):
        parse_json_output("no json here", StoryDraft)
    with pytest.raises(AgentError):
        parse_json_output('{"title": 3}', StoryDraft)


def test_system_prompt_embeds_schema_and_instructions():
    sp = build_system_prompt("situation_creator", StorySituation)
    assert "Situation Creator" in sp and "protagonist_goal" in sp and '"parent_artifact_versions"' not in sp


def test_anthropic_runtime_with_fake_client():
    situation = StubRuntime()._SituationInput(SituationInput(brief=StoryBrief(premise="p")))
    captured = {}

    class FakeMessages:
        def create(self, **kw):
            captured.update(kw)
            return SimpleNamespace(content=[SimpleNamespace(text=situation.model_dump_json())],
                                   usage=SimpleNamespace(input_tokens=11, output_tokens=7))

    rt = AnthropicRuntime(model="m", client=SimpleNamespace(messages=FakeMessages()))
    res = rt.invoke_agent("situation_creator", SituationInput(brief=StoryBrief(premise="p")), StorySituation,
                          InvokeContext("r"))
    assert res.output.protagonist_goal == situation.protagonist_goal
    assert (res.usage.input_tokens, res.usage.output_tokens) == (11, 7)
    assert captured["model"] == "m" and "Situation Creator" in captured["system"]


def test_anthropic_runtime_wraps_provider_errors():
    class Boom:
        def create(self, **kw):
            raise RuntimeError("503")

    rt = AnthropicRuntime(model="m", client=SimpleNamespace(messages=Boom()))
    with pytest.raises(AgentError):
        rt.invoke_agent("situation_creator", SituationInput(brief=StoryBrief()), StorySituation, InvokeContext("r"))


def test_openai_runtime_with_fake_client():
    from harness.openai_runtime import OpenAIRuntime
    situation = StubRuntime()._SituationInput(SituationInput(brief=StoryBrief(premise="p")))
    captured = {}

    class FakeCompletions:
        def create(self, **kw):
            captured.update(kw)
            msg = SimpleNamespace(content=situation.model_dump_json())
            return SimpleNamespace(choices=[SimpleNamespace(message=msg, finish_reason="stop")],
                                   usage=SimpleNamespace(prompt_tokens=13, completion_tokens=5))

    rt = OpenAIRuntime(model="m", client=SimpleNamespace(chat=SimpleNamespace(completions=FakeCompletions())))
    res = rt.invoke_agent("situation_creator", SituationInput(brief=StoryBrief(premise="p")), StorySituation,
                          InvokeContext("r"))
    assert res.output.protagonist_goal == situation.protagonist_goal
    assert (res.usage.input_tokens, res.usage.output_tokens) == (13, 5)
    assert captured["response_format"] == {"type": "json_object"} and captured["model"] == "m"
    assert captured["messages"][0]["role"] == "system" and "Situation Creator" in captured["messages"][0]["content"]


def test_openai_runtime_errors_become_agent_errors():
    from harness.openai_runtime import OpenAIRuntime

    class Boom:
        def create(self, **kw):
            raise RuntimeError("429")

    class Truncated:
        def create(self, **kw):
            return SimpleNamespace(choices=[SimpleNamespace(message=SimpleNamespace(content="{"),
                                                            finish_reason="length")], usage=None)

    for comp in (Boom(), Truncated()):
        rt = OpenAIRuntime(model="m", client=SimpleNamespace(chat=SimpleNamespace(completions=comp)))
        with pytest.raises(AgentError):
            rt.invoke_agent("situation_creator", SituationInput(brief=StoryBrief()), StorySituation, InvokeContext("r"))


def test_openai_runtime_unavailable_without_key(monkeypatch):
    from harness.base import HarnessUnavailable
    from harness.openai_runtime import OpenAIRuntime
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    with pytest.raises(HarnessUnavailable):
        OpenAIRuntime()
