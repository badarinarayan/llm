"""Runs only where `tantra-harness` is installed (Python >= 3.13). Uses Tantra's own FakeProvider,
scripting the structured `submit_output` tool call it uses for `Agent.output_schema`."""
import pytest

tantra = pytest.importorskip("tantra")

from harness.base import AgentError, InvokeContext
from harness.stub import StubRuntime
from harness.tantra_adapter import TantraAdapter
from schemas import StoryBrief, StorySituation
from schemas.io import SituationInput
from tantra.providers.base import ToolCall
from tantra.providers.fake import FakeProvider, Sample

BRIEF = StoryBrief(premise="p", language="en")


def submit(model):
    return Sample(tool_calls=[ToolCall(id="t1", name="submit_output", args=model.model_dump_json())])


def test_adapter_returns_validated_typed_output():
    expected = StubRuntime()._SituationInput(SituationInput(brief=BRIEF))
    rt = TantraAdapter(provider=FakeProvider([submit(expected)]), model="fake/model")
    try:
        res = rt.invoke_agent("situation_creator", SituationInput(brief=BRIEF), StorySituation, InvokeContext("r"))
        assert res.output.protagonist_goal == expected.protagonist_goal
        assert len(res.output.story_beats) == len(expected.story_beats)
    finally:
        rt.close()


def test_adapter_maps_provider_failure_to_agent_error():
    rt = TantraAdapter(provider=FakeProvider([]), model="fake/model")      # no scripted sample -> ProviderError
    try:
        with pytest.raises(AgentError):
            rt.invoke_agent("situation_creator", SituationInput(brief=BRIEF), StorySituation, InvokeContext("r"))
    finally:
        rt.close()
