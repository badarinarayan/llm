"""Command-line entry point.

  story-creator run examples/sample_brief.yaml --harness stub
  story-creator run brief.yaml --stop-after plan      # pause for human review
  story-creator override RUN_ID cast edited_cast.json # a human replaces an artifact (new version)
  story-creator resume RUN_ID                         # draft from the (edited) plan
  story-creator show RUN_ID [KEY] / report RUN_ID / runs
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Optional

import yaml

from config import ROOT, load_defaults
from harness import HARNESSES, HarnessUnavailable, get_runtime
from memory.artifact_store import ArtifactStore
from memory.character_library import CharacterLibrary
from memory.story_bible import StoryBible
from orchestrator.events import RunObserver
from orchestrator.pipeline import PLAN_KEYS, StoryPipeline, render_story
from orchestrator.state import StoryState
from schemas.story import RunReport, StoryDraft


DEFAULT_HARNESS = "openai" if os.environ.get("OPENAI_API_KEY") else "stub"


def _load_brief(path: str) -> dict:
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    data = json.loads(text) if p.suffix == ".json" else yaml.safe_load(text)
    if not isinstance(data, dict):
        raise SystemExit(f"{path}: expected a mapping of brief fields")
    return data


def _build(args: argparse.Namespace, run_id_for_log: Optional[str] = None) -> tuple[StoryPipeline, ArtifactStore]:
    cfg = load_defaults()
    runs = Path(args.workdir or cfg["paths"]["runs_dir"])
    if not runs.is_absolute():
        runs = Path.cwd() / runs
    store = ArtifactStore(runs / "artifacts.db", mirror_dir=runs)
    runtime = get_runtime(getattr(args, "harness", DEFAULT_HARNESS))
    library = CharacterLibrary.load(args.library) if getattr(args, "library", None) else None
    bible = StoryBible(runs / cfg["paths"]["story_bible_dir"])
    observer = RunObserver(runs / "events.jsonl")
    return StoryPipeline(runtime, store, config=cfg, observer=observer, library=library, bible=bible), store


def _finish(state: StoryState, store: ArtifactStore, workdir: Optional[str]) -> int:
    print(f"run:    {state.run_id}")
    print(f"status: {state.status}")
    if state.draft and state.report:
        base = Path(workdir or load_defaults()["paths"]["runs_dir"])
        base = base if base.is_absolute() else Path.cwd() / base
        out = base / state.run_id / "story.md"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(render_story(state.draft), encoding="utf-8")
        print(f"story:  {out}  ({state.draft.actual_word_count} words)")
    for n in state.notes:
        print(f"note:   {n}")
    if state.report:
        warns = [i for r in state.report.stage_results for i in r.warnings]
        print(f"calls:  {state.report.agent_calls}   warnings: {len(warns)}   repairs: {len(state.report.repairs)}")
    return 0 if state.status in ("ok", "ok_with_warnings", "plan_ready") else 1


def main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser(prog="story-creator", description="Multi-Agent Story Creator")
    ap.add_argument("--workdir", help="where artifacts, events and stories are written (default: ./runs)")
    sub = ap.add_subparsers(dest="cmd", required=True)

    r = sub.add_parser("run", help="run the pipeline on a brief")
    r.add_argument("brief")
    r.add_argument("--harness", choices=HARNESSES, default=DEFAULT_HARNESS)
    r.add_argument("--stop-after", choices=["plan"], help="pause after the coherence gate for human review")
    r.add_argument("--library", help="YAML/JSON file of existing characters")

    rs = sub.add_parser("resume", help="draft from the latest (possibly human-edited) plan")
    rs.add_argument("run_id")
    rs.add_argument("--harness", choices=HARNESSES, default=DEFAULT_HARNESS)

    ov = sub.add_parser("override", help="replace a plan artifact with an edited JSON file (saved as a new version)")
    ov.add_argument("run_id")
    ov.add_argument("key", choices=sorted(PLAN_KEYS))
    ov.add_argument("file")

    sh = sub.add_parser("show", help="print an artifact (default: version history)")
    sh.add_argument("run_id")
    sh.add_argument("key", nargs="?")

    rp = sub.add_parser("report", help="print the run report")
    rp.add_argument("run_id")
    sub.add_parser("runs", help="list runs")

    args = ap.parse_args(argv)
    try:
        pipeline, store = _build(args)
    except HarnessUnavailable as exc:
        print(f"harness unavailable: {exc}", file=sys.stderr)
        return 2
    try:
        return _dispatch(args, pipeline, store)
    finally:
        pipeline.runtime.close()
        store.close()


def _dispatch(args: argparse.Namespace, pipeline: StoryPipeline, store: ArtifactStore) -> int:
    if args.cmd == "run":
        state = pipeline.run(_load_brief(args.brief), stop_after=args.stop_after)
        if args.stop_after == "plan":
            print("plan saved. Edit artifacts with `override`, then `resume`.")
        return _finish(state, store, args.workdir)
    if args.cmd == "resume":
        return _finish(pipeline.resume(args.run_id), store, args.workdir)
    if args.cmd == "override":
        model = PLAN_KEYS[args.key]
        art = model.model_validate_json(Path(args.file).read_text(encoding="utf-8"))  # contract check
        saved = store.save(args.run_id, args.key, art, "human",
                           {k: v for k, v in store.latest_versions(args.run_id).items() if k != args.key
                            and k in PLAN_KEYS})
        print(f"saved {args.key} v{saved.version} (created_by=human)")
        return 0
    if args.cmd == "show":
        if not args.key:
            for row in store.history(args.run_id):
                print(f"{row['key']:<28} v{row['version']:<3} {row['created_by']:<18} {row['created_at']}")
            return 0
        model = PLAN_KEYS.get(args.key) or {"draft": StoryDraft, "report": RunReport}.get(args.key)
        if model is None:
            print("unknown key; use brief|situation|cast|locations|draft|report", file=sys.stderr)
            return 2
        art = store.latest(args.run_id, args.key, model)
        print(art.model_dump_json(indent=2) if art else "not found")
        return 0 if art else 1
    if args.cmd == "report":
        rep = store.latest(args.run_id, "report", RunReport)
        print(rep.model_dump_json(indent=2) if rep else "not found")
        return 0 if rep else 1
    if args.cmd == "runs":
        for rid in store.list_runs():
            print(rid)
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
