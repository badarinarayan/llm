"""Numerology Expert.

Number *derivation* is deterministic code (below) and always records its method
and source. Trait *interpretation* is the agent's job and is seeded from
config/numerology.yaml. The two are deliberately separate (design section 8).
"""
from __future__ import annotations

import hashlib
import json
import unicodedata
from typing import Any, Optional

from orchestrator.policy import MissingNumberError
from schemas.brief import StoryBrief
from schemas.character import CastPlan, CharacterCard, DerivedNumber, NumerologyProfile
from schemas.io import NumerologyInput
from schemas.situation import StorySituation

from .base import AgentSpec, Invoker

SPEC = AgentSpec(
    name="numerology_expert",
    prompt_file="numerology_expert.md",
    purpose="Translate an explicit or configured number into a symbolic character profile for fiction.",
    must_not=("claim numerology describes real people", "invent user-supplied data", "make traits immutable destiny"),
)

MASTER = (11, 22, 33)


def reduce_number(n: int, keep_master: bool = True) -> int:
    while n > 9 and not (keep_master and n in MASTER):
        n = sum(int(d) for d in str(n))
    return n


def _latin_letters(name: str) -> list[str]:
    folded = unicodedata.normalize("NFKD", name)
    return [ch.upper() for ch in folded if ch.isascii() and ch.isalpha()]


def has_latin_letters(name: str) -> bool:
    return bool(_latin_letters(name))


def name_number(name: str, method: str, cfg: dict[str, Any]) -> Optional[int]:
    """Pythagorean (A=1..I=9 cycling) or Chaldean (config table). None if the name has no Latin letters."""
    letters = _latin_letters(name)
    if not letters:
        return None
    if method == "chaldean_name":
        table = cfg["chaldean"]
        total = sum(table[ch] for ch in letters)
    elif method == "pythagorean_name":
        total = sum((ord(ch) - 65) % 9 + 1 for ch in letters)
    else:
        raise ValueError(f"not a name method: {method}")
    return reduce_number(total, cfg["settings"].get("keep_master_numbers", True))


def birth_date_number(date_text: str, cfg: dict[str, Any]) -> Optional[int]:
    digits = [int(ch) for ch in date_text if ch.isdigit()]
    if not digits:
        return None
    return reduce_number(sum(digits), cfg["settings"].get("keep_master_numbers", True))


def assign_explicit_numbers(brief: StoryBrief, cast: CastPlan) -> dict[str, int]:
    """Map user-supplied base numbers onto characters in cast order.

    A character's own fixed_number (user/registry) wins and does not consume a slot.
    """
    pool = list(brief.explicit_base_numbers)
    out: dict[str, int] = {}
    for c in cast.characters:
        if c.fixed_number is not None:
            out[c.character_id] = c.fixed_number
        elif pool:
            out[c.character_id] = pool.pop(0)
    return out


def derive_number(character: CharacterCard, explicit: Optional[int], brief: StoryBrief,
                  cfg: dict[str, Any]) -> DerivedNumber:
    """Return the number plus method + provenance. Never fabricates user-supplied data."""
    if explicit is not None:
        return DerivedNumber(number=explicit, method="explicit_base_number", input_source="user_supplied",
                             input_value=str(explicit), note="supplied by the user or registry")
    method = brief.numerology_method
    if method in ("pythagorean_name", "chaldean_name"):
        n = name_number(character.name, method, cfg)
        if n is not None:
            return DerivedNumber(number=n, method=method, input_source="calculated_name", input_value=character.name)
    elif method == "birth_date" and character.birth_date:
        n = birth_date_number(character.birth_date, cfg)
        if n is not None:
            return DerivedNumber(number=n, method=method, input_source="calculated_birth_date",
                                 input_value=character.birth_date)
    # Required data is absent: ask, or suggest a clearly labelled fictional value.
    if brief.missing_number_policy == "ask":
        raise MissingNumberError(
            f"No number for '{character.name}' (method={method}). Supply a base number"
            f"{' or a birth date' if method == 'birth_date' else ''} for this character.")
    fallback = cfg["settings"].get("fallback_method", "pythagorean_name")
    n = name_number(character.name, fallback, cfg)
    note = f"suggested via {fallback}; fictional value, not user data"
    if n is None:  # e.g. a Kannada-script name: use a stable hash so replays are deterministic
        n = int(hashlib.sha256(character.name.encode("utf-8")).hexdigest(), 16) % 9 + 1
        note = "suggested via stable name hash (name not in Latin script); fictional value, not user data"
        fallback = "stable_hash"
    return DerivedNumber(number=n, method=fallback, input_source="suggested_fictional",
                         input_value=character.name, note=note)


def profile_fingerprint(character: CharacterCard, derived: DerivedNumber) -> str:
    """Changes only when the profile's inputs change, enabling selective recompute."""
    payload = json.dumps([character.name, character.story_role, character.dramatic_function, derived.number,
                          derived.method, derived.input_source], ensure_ascii=False)
    return hashlib.sha1(payload.encode("utf-8")).hexdigest()


class NumerologyExpert:
    spec = SPEC

    def __init__(self, invoke: Invoker, cfg: dict[str, Any]):
        self._invoke = invoke
        self.cfg = cfg

    def derive(self, character: CharacterCard, explicit: Optional[int], brief: StoryBrief) -> DerivedNumber:
        return derive_number(character, explicit, brief, self.cfg)

    def profile(self, brief: StoryBrief, situation: StorySituation, character: CharacterCard,
                derived: DerivedNumber) -> NumerologyProfile:
        seed = self.cfg["traits"].get(derived.number, {})
        out = self._invoke(SPEC.name, NumerologyInput(brief=brief, situation=situation, character=character,
                                                      derived=derived, interpretation_seed=seed), NumerologyProfile)
        # Provenance is owned by deterministic code, whatever the agent returned.
        return out.model_copy(update={"character_id": character.character_id, "number": derived.number,
                                      "method": derived.method, "input_source": derived.input_source,
                                      "input_value": derived.input_value})
