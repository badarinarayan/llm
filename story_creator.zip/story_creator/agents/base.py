from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable, TypeVar

from pydantic import BaseModel

T = TypeVar("T", bound=BaseModel)

#: (agent_name, typed_input, output_type) -> validated output.
#: Provided by the orchestrator: wraps the runtime with budgets, retries and events.
Invoker = Callable[[str, BaseModel, type[T]], T]

PROMPTS_DIR = Path(__file__).resolve().parent.parent / "prompts"


@dataclass(frozen=True)
class AgentSpec:
    name: str
    prompt_file: str
    purpose: str
    must_not: tuple[str, ...] = ()

    def load_prompt(self) -> str:
        return (PROMPTS_DIR / self.prompt_file).read_text(encoding="utf-8")


def all_specs() -> dict[str, AgentSpec]:
    from . import casting_agent, language_expert, location_finder, numerology_expert, situation_creator
    mods = (language_expert, numerology_expert, casting_agent, location_finder, situation_creator)
    return {m.SPEC.name: m.SPEC for m in mods}
