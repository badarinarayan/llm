from __future__ import annotations

from typing import Any

from schemas.brief import StoryBrief
from schemas.character import CastPlan
from schemas.io import DraftInput, EditInput, NormalizeBriefInput, ReviewInput
from schemas.location import LocationPlan
from schemas.situation import StorySituation
from schemas.story import EditorialReview, StoryDraft, ValidationIssue

from .base import AgentSpec, Invoker

SPEC = AgentSpec(
    name="language_expert",
    prompt_file="language_expert.md",
    purpose="Phase A: normalize the brief. Phase B: draft, review and edit the story in the requested language.",
    must_not=("redefine the numerology method", "replace locked characters/locations",
              "assert unverified real-world details", "override user content boundaries"),
)


class LanguageExpert:
    spec = SPEC

    def __init__(self, invoke: Invoker):
        self._invoke = invoke

    # Phase A
    def normalize_brief(self, raw: dict[str, Any], defaults: dict[str, Any],
                        repair_notes: list[str] | None = None) -> StoryBrief:
        return self._invoke(SPEC.name, NormalizeBriefInput(raw_brief=raw, defaults=defaults,
                                                           repair_notes=repair_notes or []), StoryBrief)

    # Phase B
    def draft_story(self, brief: StoryBrief, situation: StorySituation, cast: CastPlan,
                    locations: LocationPlan) -> StoryDraft:
        return self._invoke(SPEC.name, DraftInput(brief=brief, situation=situation, cast=cast, locations=locations),
                            StoryDraft)

    def review(self, brief: StoryBrief, draft: StoryDraft, cast: CastPlan, locations: LocationPlan) -> EditorialReview:
        return self._invoke(SPEC.name, ReviewInput(brief=brief, draft=draft, cast=cast, locations=locations),
                            EditorialReview)

    def edit(self, brief: StoryBrief, situation: StorySituation, cast: CastPlan, locations: LocationPlan,
             draft: StoryDraft, issues: list[ValidationIssue], instructions: list[str] | None = None) -> StoryDraft:
        return self._invoke(SPEC.name, EditInput(brief=brief, situation=situation, cast=cast, locations=locations,
                                                 draft=draft, issues=issues, instructions=instructions or []),
                            StoryDraft)
