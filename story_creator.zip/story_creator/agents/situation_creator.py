from __future__ import annotations

from schemas.brief import StoryBrief
from schemas.io import SituationInput
from schemas.situation import StorySituation

from .base import AgentSpec, Invoker

SPEC = AgentSpec(
    name="situation_creator",
    prompt_file="situation_creator.md",
    purpose="Turn the normalized brief into a dramatic engine: goal, conflict, stakes, beats.",
    must_not=("write the full story", "pick final cast or setting", "violate content boundaries"),
)


class SituationCreator:
    spec = SPEC

    def __init__(self, invoke: Invoker):
        self._invoke = invoke

    def create(self, brief: StoryBrief, repair_notes: list[str] | None = None) -> StorySituation:
        return self._invoke(SPEC.name, SituationInput(brief=brief, repair_notes=repair_notes or []), StorySituation)
