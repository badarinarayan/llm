from __future__ import annotations

from schemas.brief import StoryBrief
from schemas.io import LocationInput
from schemas.location import LocationPlan
from schemas.situation import StorySituation

from .base import AgentSpec, Invoker

SPEC = AgentSpec(
    name="location_finder",
    prompt_file="location_finder.md",
    purpose="Choose a primary (and optional secondary) setting that enables the action and mood.",
    must_not=("present invented details as fact", "fabricate citations", "replace a locked location"),
)


class LocationFinder:
    spec = SPEC

    def __init__(self, invoke: Invoker):
        self._invoke = invoke

    def find(self, brief: StoryBrief, situation: StorySituation, repair_notes: list[str] | None = None) -> LocationPlan:
        return self._invoke(SPEC.name, LocationInput(brief=brief, situation=situation,
                                                     repair_notes=repair_notes or []), LocationPlan)
