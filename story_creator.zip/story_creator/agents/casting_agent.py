from __future__ import annotations

from schemas.brief import StoryBrief
from schemas.character import CastPlan, CharacterCard
from schemas.io import CastingInput
from schemas.situation import StorySituation

from .base import AgentSpec, Invoker

SPEC = AgentSpec(
    name="casting_agent",
    prompt_file="casting_agent.md",
    purpose="Select/propose a compact cast that can create, escalate and resolve the situation.",
    must_not=("assign numerology traits", "write stereotypes", "add essential roles without a recorded reason"),
)


class CastingAgent:
    spec = SPEC

    def __init__(self, invoke: Invoker):
        self._invoke = invoke

    def cast(self, brief: StoryBrief, situation: StorySituation, library: list[CharacterCard] | None = None,
             repair_notes: list[str] | None = None) -> CastPlan:
        return self._invoke(
            SPEC.name,
            CastingInput(brief=brief, situation=situation, library=library or [], repair_notes=repair_notes or []),
            CastPlan,
        )
