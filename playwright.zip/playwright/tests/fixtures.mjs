// @ts-check
/**
 * Playwright Test fixtures for driving Samsung Magician via the native Electron
 * API (no manual CDP attach).
 *
 * Written as ESM (.mjs) on purpose: with Playwright 1.61 on Node 22.16 the CJS
 * transform throws "context.conditions?.includes is not a function" when a test
 * `require()`s a relative helper file. The ESM loader path is unaffected, so
 * keep these files as .mjs and use import/export.
 *
 * Exposed fixtures:
 *   electronApp -> the launched ElectronApplication
 *   window      -> the main renderer Page (already loaded)
 *   magician    -> small page-object with helpers (goto, dump)
 *
 * IMPORTANT — run elevated:
 *   Magician's main process checks `isAppElevationRequired()` and, when not
 *   already admin, relaunches itself via `powershell Start-Process` (UAC). That
 *   spawns a new elevated process WITHOUT Playwright's --inspect flags and quits
 *   the original, so Playwright loses the app ("Target page, context or browser
 *   has been closed"). Start the runner from a "Run as administrator" terminal;
 *   when already admin no relaunch happens and _electron.launch attaches.
 */
import { test as base, expect, _electron as electron } from '@playwright/test';
import { execSync } from 'node:child_process';
import path from 'node:path';
import fs from 'node:fs';

export const MAGICIAN_EXE =
  process.env.MAGICIAN_EXE ||
  'C:\\Program Files (x86)\\Samsung\\Samsung Magician\\SamsungMagician.exe';

/** Real feature/menu names pulled from Magician's own resource files. */
export const MENU = {
  dashboard: 'Drive Details',
  diskPartition: 'Disk Partition',
  benchmark: 'Performance Benchmark',
  diagnosticScan: 'Diagnostic Scan',
  overProvisioning: 'Over Provisioning',
  performanceOptimization: 'Performance Optimization',
  rapid: 'RAPID',
  securitySetting: 'Security Setting',
  ledSetting: 'LED Setting',
  secureErase: 'Secure Erase',
  psidRevert: 'PSID Revert',
};

/** True if the current Windows process is elevated (admin). */
export function isElevated() {
  if (process.platform !== 'win32') return true;
  try {
    execSync('net session', { stdio: 'ignore' });
    return true;
  } catch {
    return false;
  }
}

/**
 * Launch Magician for plain-node use (e.g. the authoring tool) and return the
 * app, the loaded main window, and a ready MagicianApp. Mirrors the test
 * fixtures' elevation/exe guards so behaviour matches between authoring & replay.
 * @param {{ settle?: number }} [opts]
 */
export async function launchMagician({ settle = 3000 } = {}) {
  if (!isElevated()) {
    throw new Error(
      'Samsung Magician requires an ELEVATED terminal. Re-run from a ' +
        '"Run as administrator" PowerShell/cmd.'
    );
  }
  if (!fs.existsSync(MAGICIAN_EXE)) {
    throw new Error(`SamsungMagician.exe not found at ${MAGICIAN_EXE}`);
  }
  const app = await electron.launch({
    executablePath: MAGICIAN_EXE,
    cwd: path.dirname(MAGICIAN_EXE),
  });
  const window = await app.firstWindow();
  await window.waitForLoadState('domcontentloaded');
  if (settle) await window.waitForTimeout(settle);
  return { app, window, magician: new MagicianApp(window) };
}

/** Minimal page-object so specs stay readable. */
export class MagicianApp {
  /**
   * Performance Benchmark selectors — literal, un-hashed class/id names taken
   * straight from Magician's renderer bundle (dist/renderer/app/*.bundle.js).
   */
  static PB = {
    startBtn: '#circularProgressBarView_Start_Button',
    percent: '.circularProgressBarView_InCircle_Percentage',
    // The Performance Benchmark widget lives on the landing (Drive Details)
    // view; metrics are labelled tiles. These labels are read off the live UI.
    metricLabels: [
      'Sequential Read',
      'Sequential Write',
      'Random Read',
      'Random Write',
    ],
    // Completion shows a shared toast (toastControl) in the frame's Toast_Area.
    // Targeting the component classes works regardless of which frame hosts it.
    toastText: '.toastControl_Text',
    toastClose: '.toastControl_Close_Btn',
  };

  /** @param {import('@playwright/test').Page} window */
  constructor(window) {
    this.window = window;
  }

  /**
   * Click a left-nav entry by its visible name. Tries the common roles
   * Magician's nav might use, then falls back to plain text, so it survives
   * DOM differences between versions.
   * @param {string} name
   */
  async goto(name) {
    const w = this.window;
    const candidates = [
      w.getByRole('button', { name, exact: false }),
      w.getByRole('link', { name, exact: false }),
      w.getByRole('menuitem', { name, exact: false }),
      w.getByRole('tab', { name, exact: false }),
      w.getByText(name, { exact: true }),
    ];
    for (const loc of candidates) {
      if (await loc.count()) {
        await loc.first().click();
        return;
      }
    }
    throw new Error(`Nav item not found: "${name}"`);
  }

  /**
   * Run the Performance Benchmark end-to-end and return the parsed metrics.
   * @param {number} timeout ms to wait for the benchmark to finish
   * @returns {Promise<Array<{metric:string,value:string,unit:string}>>}
   */
  async runBenchmark(timeout = 300_000) {
    const before = await this.startBenchmark();
    await this.waitForBenchmarkComplete(before, timeout);
    await this.dismissCompletionToast();
    return this.extractBenchmarkMetrics();
  }

  /**
   * Click Start on the Performance Benchmark widget (on the landing view — the
   * nav is icon-only, so there's nothing to navigate to). Returns the baseline
   * metric signature so completion can be detected as "values changed".
   */
  async startBenchmark(startSelector) {
    const start = startSelector
      ? this.window.locator(startSelector).filter({ visible: true }).first()
      : await this.#startButton();
    await start.scrollIntoViewIfNeeded();
    await start.waitFor({ state: 'visible', timeout: 30_000 });
    const baseline = JSON.stringify(await this.extractBenchmarkMetrics());
    await start.click();
    await this.#dismissConfirmIfPresent();
    return baseline;
  }

  /**
   * Wait until the benchmark finishes: the metric tiles change from their
   * baseline and at least one value is > 0 (a fresh result has populated).
   * @param {string} baselineSignature value returned by startBenchmark()
   * @param {number} timeout
   */
  async waitForBenchmarkComplete(baselineSignature, timeout = 300_000) {
    await expect
      .poll(
        async () => {
          const metrics = await this.extractBenchmarkMetrics();
          const changed = JSON.stringify(metrics) !== baselineSignature;
          const anyPositive = metrics.some((m) => this.#toNumber(m.value) > 0);
          return changed && anyPositive ? 'done' : 'running';
        },
        {
          timeout,
          intervals: [3000],
          message: 'Benchmark never produced a result (did the run start?)',
        }
      )
      .toBe('done');
  }

  /**
   * Handle the "benchmark complete" toast that Magician pops on completion:
   * wait briefly for it, capture its message, then close it via the X so it
   * doesn't overlap the result tiles or block later interactions. Safe to call
   * even if no toast appears (or it already auto-dismissed) — returns '' then.
   * @param {number} timeout how long to wait for the toast to appear
   * @returns {Promise<string>} the toast message (joined lines), or ''
   */
  async dismissCompletionToast(timeout = 20_000) {
    const toast = this.window.locator(MagicianApp.PB.toastText).first();
    try {
      await toast.waitFor({ state: 'visible', timeout });
    } catch {
      return ''; // no toast shown (or it vanished before we looked)
    }

    const message = ((await toast.innerText().catch(() => '')) ?? '')
      .replace(/\s+/g, ' ')
      .trim();

    const close = this.window.locator(MagicianApp.PB.toastClose).first();
    if (await close.count()) {
      await close.click({ timeout: 3000 }).catch(() => {});
      // Confirm it's gone so it can't interfere with the screenshot/next step.
      await toast.waitFor({ state: 'hidden', timeout: 5000 }).catch(() => {});
    }
    return message;
  }

  /** Read the live progress percentage (best-effort; '' when idle/finished). */
  async progressPercent() {
    const el = this.window.locator(MagicianApp.PB.percent).first();
    if (!(await el.count())) return '';
    return ((await el.textContent()) ?? '').trim();
  }

  /**
   * Parse the read/write metric tiles into structured rows by their labels.
   * Each tile renders "<label>" and a sibling "<value> <unit>" (e.g. "0 MB/s").
   */
  async extractBenchmarkMetrics() {
    const rows = [];
    for (const label of MagicianApp.PB.metricLabels) {
      // IMPORTANT: filter to visible — Magician keeps a HIDDEN duplicate of the
      // Sequential tiles (the "Setup Benchmark" preview) that shows 0 and comes
      // first in the DOM, so an unfiltered .first() would read the stale zero.
      const labelLoc = this.window
        .getByText(label, { exact: true })
        .filter({ visible: true })
        .first();
      if (!(await labelLoc.count())) continue;

      // The value is the sibling immediately after the label within the tile.
      let valueText = '';
      const sibling = labelLoc.locator('xpath=following-sibling::*[1]');
      if (await sibling.count()) {
        valueText = ((await sibling.innerText()) ?? '').trim(); // "1709 MB/s"
      } else {
        const tile = labelLoc.locator('xpath=..');
        valueText = ((await tile.innerText()) ?? '').replace(label, '').trim();
      }

      const m = valueText.match(/([\d.,]+)\s*(.*)$/);
      rows.push({
        metric: label,
        value: m ? m[1] : valueText,
        unit: m ? m[2].trim() : '',
      });
    }
    return rows;
  }

  /** Locate the Start control (id from the bundle, falling back to its label). */
  async #startButton() {
    const byId = this.window.locator(MagicianApp.PB.startBtn);
    if (await byId.count()) return byId.first();
    return this.window.getByText('Start', { exact: true }).first();
  }

  /** Some drives prompt a confirm before benchmarking — accept it if shown. */
  async #dismissConfirmIfPresent() {
    const confirm = this.window
      .getByText(/^(OK|Yes|Continue)$/i)
      .filter({ visible: true })
      .last();
    if (await confirm.count().catch(() => 0)) {
      await confirm.click({ timeout: 1500 }).catch(() => {});
    }
  }

  #toNumber(v) {
    return Number(String(v).replace(/[^\d.]/g, '')) || 0;
  }

  /** Dump the accessibility tree + a screenshot to ./artifacts for selector work. */
  async dump(label = 'state') {
    const dir = path.resolve('artifacts');
    fs.mkdirSync(dir, { recursive: true });
    await this.window.screenshot({
      path: path.join(dir, `${label}.png`),
      fullPage: true,
    });
    const snapshot = await this.window.accessibility.snapshot();
    fs.writeFileSync(
      path.join(dir, `${label}.a11y.json`),
      JSON.stringify(snapshot, null, 2)
    );
  }
}

export const test = base.extend({
  // One app per test file: isolated but cheap. Switch to { scope: 'worker' }
  // if you'd rather share one app across the whole run.
  electronApp: async ({}, use) => {
    if (!isElevated()) {
      throw new Error(
        'Samsung Magician requires an ELEVATED terminal. Re-run from a ' +
          '"Run as administrator" PowerShell/cmd, otherwise the app relaunches ' +
          'itself with UAC and Playwright cannot attach.'
      );
    }
    if (!fs.existsSync(MAGICIAN_EXE)) {
      throw new Error(`SamsungMagician.exe not found at ${MAGICIAN_EXE}`);
    }

    const app = await electron.launch({
      executablePath: MAGICIAN_EXE,
      cwd: path.dirname(MAGICIAN_EXE),
    });
    await use(app);
    await app.close();
  },

  window: async ({ electronApp }, use) => {
    const window = await electronApp.firstWindow();
    await window.waitForLoadState('domcontentloaded');
    // Let the SPA finish its initial drive scan / render.
    await window.waitForTimeout(3000);
    await use(window);
  },

  magician: async ({ window }, use) => {
    await use(new MagicianApp(window));
  },
});

export { expect };
