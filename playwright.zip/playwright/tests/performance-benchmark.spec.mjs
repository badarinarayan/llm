// @ts-check
/**
 * Performance Benchmark — plain Playwright script.
 *
 * GENERATED from input/performance-benchmark.enhanced.html (which enriches
 * input/performance-benchmark.txt with live DOM inspection). It is a
 * self-contained, ordinary Playwright test: element IDs come from
 * Elements_Config/, the flow is explicit below, and NO LLM or live inspection
 * is used at run time. Re-run any time with:
 *
 *   npx playwright test tests/performance-benchmark.spec.mjs
 *
 * (Must run from an elevated terminal — Magician self-elevates via UAC.)
 *
 * Step map (see the enhanced input):
 *   1 verify the benchmark widget is present   4 close completion toast (≤10s)
 *   2 start the benchmark                       5 read the four metrics
 *   3 wait for completion                       6 display + assert
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { test, expect } from './fixtures.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const cfgDir = path.resolve(__dirname, '../Elements_Config');
const common = JSON.parse(fs.readFileSync(path.join(cfgDir, 'common.json'), 'utf8'));
const pb = JSON.parse(fs.readFileSync(path.join(cfgDir, 'performance-benchmark.json'), 'utf8'));

const TOAST_WAIT_MS = 10_000; // enhanced input: "if it appears within 10 seconds"
const COMPLETION_TIMEOUT_MS = 330_000;

const toNumber = (v) => Number(String(v).replace(/[^\d.]/g, '')) || 0;

test('Performance Benchmark — run and capture metrics', async ({ window }, testInfo) => {
  testInfo.setTimeout(360_000); // benchmark writes to the SSD; allow minutes
  const el = pb.elements;

  // Reads the visible result tiles into [{ metric, value, unit }].
  const readMetrics = async () => {
    const rows = [];
    for (const label of pb.metricTiles.labels) {
      // Visible-only: a hidden "Setup Benchmark" preview duplicates these labels at 0.
      const labelLoc = window.getByText(label, { exact: true }).filter({ visible: true }).first();
      if (!(await labelLoc.count())) continue;
      const sibling = labelLoc.locator('xpath=following-sibling::*[1]');
      const valueText = (await sibling.count())
        ? ((await sibling.innerText()) ?? '').trim()
        : ((await labelLoc.locator('xpath=..').innerText()) ?? '').replace(label, '').trim();
      const m = valueText.match(/([\d.,]+)\s*(.*)$/);
      rows.push({ metric: label, value: m ? m[1] : valueText, unit: m ? m[2].trim() : '' });
    }
    return rows;
  };

  // ---- Step 1: verify the Performance Benchmark widget is on screen ----
  // The nav is icon-only and the widget is on the landing view, so there is no
  // text "navigate" target — confirming the Start control is present is enough.
  const start = window.locator(el.startButton).filter({ visible: true }).first();
  await start.scrollIntoViewIfNeeded();
  await expect(start, 'Performance Benchmark start control visible').toBeVisible({ timeout: 30_000 });

  // ---- Step 2: start the benchmark ----
  const baseline = JSON.stringify(await readMetrics()); // to detect a fresh result
  await start.click();

  // Accept a confirmation dialog if one appears.
  const confirm = window
    .getByText(new RegExp(`^(${common.confirm.acceptLabels})$`, 'i'))
    .filter({ visible: true })
    .last();
  if (await confirm.count().catch(() => 0)) {
    await confirm.click({ timeout: 1500 }).catch(() => {});
  }

  // ---- Step 3: wait for completion ----
  // Reliable signal = tiles change from baseline and at least one value > 0
  // (the progress dial resets after the run, so % is informational only).
  await expect
    .poll(
      async () => {
        const m = await readMetrics();
        const changed = JSON.stringify(m) !== baseline;
        const anyPositive = m.some((x) => toNumber(x.value) > 0);
        return changed && anyPositive ? 'done' : 'running';
      },
      { timeout: COMPLETION_TIMEOUT_MS, intervals: [3000], message: 'benchmark did not complete' }
    )
    .toBe('done');

  // ---- Step 4: close the "benchmark complete" pop-up if it appears within 10s ----
  const toast = window.locator(common.toast.text).first();
  const toastShown = await toast
    .waitFor({ state: 'visible', timeout: TOAST_WAIT_MS })
    .then(() => true)
    .catch(() => false);
  if (toastShown) {
    const notice = ((await toast.innerText().catch(() => '')) ?? '').replace(/\s+/g, ' ').trim();
    if (notice) {
      console.log('Completion notice:', notice);
      testInfo.annotations.push({ type: 'completion-notice', description: notice });
    }
    const close = window.locator(common.toast.close).first();
    if (await close.count()) {
      await close.click({ timeout: 3000 }).catch(() => {});
      await toast.waitFor({ state: 'hidden', timeout: 5000 }).catch(() => {});
    }
  }

  // ---- Step 5: read the four result metrics ----
  const metrics = await readMetrics();

  // ---- Step 6: display the metrics ----
  console.log('\n=== Samsung Magician — Performance Benchmark ===');
  console.table(metrics);
  console.log(metrics.map((m) => `${m.metric.padEnd(20)} ${m.value.padStart(8)} ${m.unit}`).join('\n'));

  await testInfo.attach('benchmark-metrics.json', {
    body: JSON.stringify(metrics, null, 2),
    contentType: 'application/json',
  });
  await testInfo.attach('benchmark-result.png', {
    body: await window.screenshot({ fullPage: true }),
    contentType: 'image/png',
  });

  // ---- Expected: each metric is a positive number ----
  expect(metrics.length, 'exactly the configured metric tiles').toBe(pb.metricTiles.labels.length);
  for (const m of metrics) {
    expect(toNumber(m.value), `metric "${m.metric}" should be > 0`).toBeGreaterThan(0);
  }
});
