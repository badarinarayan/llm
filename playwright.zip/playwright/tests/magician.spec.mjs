// @ts-check
import { test, expect, MENU } from './fixtures.mjs';

/**
 * Sample Samsung Magician tests using the native Electron fixtures.
 *
 * Run from an ELEVATED terminal:
 *   npx playwright test
 *
 * First run, do the smoke test alone, then open artifacts/dashboard.a11y.json
 * to confirm the exact roles/names and tighten the assertions below:
 *   npx playwright test -g smoke
 */

test('smoke: app launches and main window is shown', async ({ window, magician }) => {
  // Title comes from the Electron app (productName: "Samsung Magician").
  await expect.poll(() => window.title()).toContain('Magician');

  // Capture a baseline + a11y tree to drive future selector work.
  await magician.dump('dashboard');

  // The home view is "Drive Details" — assert its label is on screen.
  await expect(window.getByText(MENU.dashboard).first()).toBeVisible();
});

test('main feature menu items are present', async ({ window }) => {
  for (const name of [
    MENU.dashboard,
    MENU.benchmark,
    MENU.diagnosticScan,
    MENU.overProvisioning,
    MENU.securitySetting,
  ]) {
    await expect(
      window.getByText(name, { exact: true }).first(),
      `expected nav item "${name}"`
    ).toBeVisible();
  }
});

test('navigate to Performance Benchmark', async ({ window, magician }) => {
  await magician.goto(MENU.benchmark);

  // The benchmark view exposes a Start control — narrow this once you've seen
  // the a11y dump (button name may be "Start" / "Run" depending on version).
  const start = window.getByRole('button', { name: /start|run/i });
  await expect(start.first()).toBeVisible();

  await magician.dump('benchmark-view');

  // To actually run it (writes to the SSD — enable deliberately):
  // await start.first().click();
  // await expect(window.getByText(/MB\/s/).first()).toBeVisible({ timeout: 120_000 });
  // await magician.dump('benchmark-result');
});

test('read app + drive info from the Electron main process', async ({ electronApp }) => {
  // Reach the main process directly — useful for assertions that don't depend
  // on the rendered DOM.
  const info = await electronApp.evaluate(async ({ app }) => ({
    name: app.getName(),
    version: app.getVersion(),
    locale: app.getLocale(),
  }));
  expect(info.name).toBeTruthy();
  expect(info.version).toMatch(/^\d+\./);
  console.log('Magician app info:', info);
});
