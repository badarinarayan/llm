// @ts-check
/**
 * Disk Partition — plain Playwright script.
 *
 * GENERATED from input/partition.enhanced.html. Selectors come from
 * Elements_Config/partition.json + common.json. No LLM/inspection at run time.
 *
 * ┌───────────────────────────────────────────────────────────────────────┐
 * │  ⚠  DESTRUCTIVE — DATA LOSS                                            │
 * │  Creating a partition and formatting volumes ERASES the target disk.  │
 * │  All connected disks are assumed disposable test disks. DISABLED by    │
 * │  default; runs only with the explicit opt-in:                         │
 * │    set ALLOW_DESTRUCTIVE_PARTITION_TEST=yes                            │
 * │    npx playwright test tests/partition.spec.mjs   (elevated)           │
 * └───────────────────────────────────────────────────────────────────────┘
 *
 * Disk-selection logic (per request):
 *   For each disk: hover Disk Management → is Disk Partition offered
 *   (#titleView_DP present)? If yes, use it; if not, try the next disk.
 *
 * Several selectors are CANDIDATES pending live verification (drive switcher,
 * per-volume file-system dropdown, volume index base). The script fails fast with
 * named messages so mismatches point to Elements_Config/partition.json fields.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { test, expect } from './fixtures.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const cfgDir = path.resolve(__dirname, '../Elements_Config');
const common = JSON.parse(fs.readFileSync(path.join(cfgDir, 'common.json'), 'utf8'));
const dp = JSON.parse(fs.readFileSync(path.join(cfgDir, 'partition.json'), 'utf8'));

const el = dp.elements;
const dm = dp.diskManagement;
const volSel = (template, i) => template.replace('{i}', String(i));

// ---- SAFETY GUARD (collection time): the test only exists when opted in ----
const authorized = process.env[dp.guard.confirmEnv] === dp.guard.confirmValue;
const runOrSkip = authorized ? test : test.skip;

runOrSkip('Disk Partition — create 2 volumes (NTFS + exFAT)', async ({ window }, testInfo) => {
  testInfo.setTimeout(300_000);

  const acceptConfirm = async () => {
    const c = window
      .getByText(new RegExp(`^(${common.confirm.acceptLabels})$`, 'i'))
      .filter({ visible: true })
      .last();
    if (await c.count().catch(() => 0)) await c.click({ timeout: 2000 }).catch(() => {});
  };

  // ---- Steps 1–2: find a disk that offers Disk Partition (retry across disks) ----
  const found = await findPartitionCapableDisk(window, dp);
  expect(found, 'no disk offers Disk Partition (checked up to maxDisks)').toBeTruthy();

  // Log which disk we're operating on (informational — all test disks are disposable).
  const nameEl = window.locator(dm.driveNameDisplay).filter({ visible: true }).first();
  if (await nameEl.count()) {
    console.log(`Operating on disk: ${((await nameEl.innerText()) ?? '').trim()}`);
  }

  // Open the Disk Partition feature for the chosen disk.
  await openDiskPartition(window, dp);

  // ---- Step 3: create a new partition with two volumes ----
  const createBtn = window.getByText(el.createPartitionText, { exact: true }).filter({ visible: true }).first();
  const initBtn = window.locator(dm.initDiskBtn).filter({ visible: true }).first();
  if (await createBtn.count()) await createBtn.click();
  else if (await initBtn.count()) await initBtn.click(); // uninitialised disk path
  else throw new Error('Neither "Create Partition" nor #titleView_DP_initDiskBtn found — verify selectors');

  const initNext = window.locator(el.initDiskNext).filter({ visible: true }).first();
  if (await initNext.count()) {
    await initNext.click();
    await acceptConfirm();
  }

  const addVolume = window.locator(el.addVolume).filter({ visible: true }).first();
  await expect(addVolume, 'Add Volume button').toBeVisible({ timeout: 15_000 });
  await addVolume.click(); // wizard starts with volume 1; add volume 2

  // ---- Steps 4 & 5: set each volume's file system BEFORE applying ----
  const base = dp.volume.indexBase;
  await selectVolumeFileSystem(window, dp, base + 0, dp.fileSystems.volume1); // volume 1 → NTFS
  await selectVolumeFileSystem(window, dp, base + 1, dp.fileSystems.volume2); // volume 2 → exFAT

  // Apply / create.
  const apply = window.locator(el.apply).filter({ visible: true }).first();
  await expect(apply, 'Apply/Create button').toBeVisible({ timeout: 15_000 });
  await apply.click();
  await acceptConfirm();

  // ---- Wait for completion (toast), capture evidence ----
  const toast = window.locator(common.toast.text).first();
  const done = await toast.waitFor({ state: 'visible', timeout: 120_000 }).then(() => true).catch(() => false);
  if (done) {
    const notice = ((await toast.innerText().catch(() => '')) ?? '').replace(/\s+/g, ' ').trim();
    if (notice) {
      console.log('Completion notice:', notice);
      testInfo.annotations.push({ type: 'completion-notice', description: notice });
    }
    const close = window.locator(common.toast.close).first();
    if (await close.count()) await close.click({ timeout: 3000 }).catch(() => {});
  }

  await testInfo.attach('partition-result.png', {
    body: await window.screenshot({ fullPage: true }),
    contentType: 'image/png',
  });
  expect(done, 'partition/format completion toast should appear').toBeTruthy();
});

/**
 * Iterate disks: select each, hover its Disk Management, and check whether Disk
 * Partition is offered (#titleView_DP present). Returns true and leaves that disk
 * selected on success; false if no disk (up to maxDisks) supports it.
 */
async function findPartitionCapableDisk(window, dp) {
  const max = dp.driveSelection.maxDisks ?? 1;
  for (let i = 0; i < max; i++) {
    if (!(await selectDisk(window, dp, i))) break; // no more disks to try

    // Hover Disk Management to reveal the feature set for this disk.
    const dmArea = window.locator(dp.diskManagement.dmTooltipArea).filter({ visible: true }).first();
    if (await dmArea.count()) await dmArea.hover().catch(() => {});

    // Disk Partition is available iff its section renders for this disk.
    const dpSection = window.locator(dp.diskManagement.dpSection).filter({ visible: true });
    if (await dpSection.count()) {
      console.log(`Disk #${i + 1}: Disk Partition available.`);
      return true;
    }
    console.log(`Disk #${i + 1}: Disk Partition NOT available — trying next disk.`);
  }
  return false;
}

/**
 * Select the i-th disk. CANDIDATE: the drive switcher isn't resolved statically.
 * With driveSelection.item configured, clicks the i-th visible item; otherwise
 * only the currently-selected disk (i===0) is reachable — resolve the selector
 * via tools/inspect.mjs --find to enable true multi-disk retry.
 */
async function selectDisk(window, dp, i) {
  const sel = dp.driveSelection.item;
  if (!sel) return i === 0;
  const items = window.locator(sel).filter({ visible: true });
  if (i >= (await items.count())) return false;
  await items.nth(i).click();
  await window.waitForTimeout(800);
  return true;
}

/** Open the Disk Partition feature/frame for the currently-selected disk. */
async function openDiskPartition(window, dp) {
  const dpSection = window.locator(dp.diskManagement.dpSection).filter({ visible: true }).first();
  if (await dpSection.count()) await dpSection.click().catch(() => {});
  const navByText = window.getByText(dp.navText, { exact: true }).filter({ visible: true }).first();
  if (await navByText.count()) await navByText.click().catch(() => {});

  const frame = window.locator(dp.elements.frame).first();
  await expect(frame, 'Disk Partition frame (#dpFrameView)').toBeVisible({ timeout: 15_000 });
  const unsupported = window.locator(dp.elements.unsupported).filter({ visible: true });
  expect(await unsupported.count(), 'disk reports unsupported on the partition screen').toBe(0);
}

/**
 * Set the file system for volume `i`. CANDIDATE interaction — opens the volume
 * row's dropdown then selects the option by visible text. Verify against live UI.
 */
async function selectVolumeFileSystem(window, dp, i, fileSystem) {
  const row = window.locator(volSel(dp.volume.rowOuter, i)).filter({ visible: true }).first();
  await expect(row, `volume ${i} config row`).toBeVisible({ timeout: 15_000 });
  await row.click(); // open the dropdown(s) for this volume

  const option = window.getByText(fileSystem, { exact: true }).filter({ visible: true }).first();
  await expect(option, `file-system option "${fileSystem}" for volume ${i}`).toBeVisible({ timeout: 5_000 });
  await option.click();
}
