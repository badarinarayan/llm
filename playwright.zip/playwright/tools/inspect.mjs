// @ts-check
/**
 * Live DOM inspection harness — phase 2 of the generation pipeline.
 *
 * Launches Samsung Magician, inspects the REAL rendered DOM, and emits an
 * LLM-friendly "element catalog" plus resolved selectors for named targets.
 * This is the only step that uses live inspection; its output feeds the
 * (one-time) authoring of Elements_Config/ and the plain test scripts.
 *
 * Run ELEVATED (Magician self-elevates via UAC):
 *   node tools/inspect.mjs                                   # catalog of current screen
 *   node tools/inspect.mjs --find "Start" "Sequential Read"  # resolve NL step targets
 *   node tools/inspect.mjs --settle 5000 --out benchmark.json
 *
 * Outputs (under Elements_Config/_inspection/):
 *   <out>.json   structured element catalog
 *   screen.png   full-page screenshot
 *   a11y.json    accessibility tree
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { launchMagician } from '../tests/fixtures.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');

const args = process.argv.slice(2);
const opt = (name, def) => {
  const i = args.indexOf(name);
  return i >= 0 && args[i + 1] ? args[i + 1] : def;
};
const findIdx = args.indexOf('--find');
const findTerms = findIdx >= 0 ? args.slice(findIdx + 1).filter((a) => !a.startsWith('--')) : [];
const settle = Number(opt('--settle', '3000'));
const outName = opt('--out', 'catalog.json');
const outDir = path.join(ROOT, 'Elements_Config', '_inspection');

(async () => {
  console.log('Launching Magician for live inspection (elevated)...');
  const { app, window } = await launchMagician({ settle });

  try {
    const catalog = await window.evaluate(extractCatalog);

    fs.mkdirSync(outDir, { recursive: true });
    const outPath = path.join(outDir, outName);
    fs.writeFileSync(outPath, JSON.stringify(catalog, null, 2));
    await window.screenshot({ path: path.join(outDir, 'screen.png'), fullPage: true });
    fs.writeFileSync(
      path.join(outDir, 'a11y.json'),
      JSON.stringify(await window.accessibility.snapshot(), null, 2)
    );

    console.log(
      `\nCatalog: ${catalog.elements.length} elements ` +
        `(${catalog.withId} with id, ${catalog.clickable} clickable)`
    );
    console.log(`Wrote ${path.relative(ROOT, outPath)} (+ screen.png, a11y.json)`);

    if (findTerms.length) {
      console.log('\n=== Resolved targets (best stable selector first) ===');
      for (const term of findTerms) {
        const hits = resolveTerm(catalog.elements, term);
        console.log(`\n"${term}":`);
        if (!hits.length) {
          console.log('  (no visible match)');
          continue;
        }
        for (const h of hits.slice(0, 5)) {
          const flag = h.unique === false ? '  ⚠ not unique' : '';
          console.log(`  ${h.suggestedSelector.padEnd(46)} [${h.kind}] "${h.text}"${flag}`);
        }
      }
    } else {
      const stable = catalog.elements.filter((e) => e.id || e.clickable).slice(0, 60);
      console.log('\n=== Stable elements (id / clickable) ===');
      for (const e of stable) {
        console.log(`  ${e.suggestedSelector.padEnd(46)} [${e.kind}] "${(e.text || '').slice(0, 40)}"`);
      }
    }
  } finally {
    await app.close();
  }
})().catch((e) => {
  console.error('\nInspection failed:', e.message);
  process.exit(1);
});

/** Rank catalog elements that match a natural-language target term. */
function resolveTerm(elements, term) {
  const t = term.toLowerCase();
  const slug = t.replace(/\s+/g, '');
  const visible = elements.filter((e) => e.visible);
  const score = (e) => {
    const text = (e.text || '').toLowerCase();
    const meta = `${e.id || ''} ${e.classes || ''}`.toLowerCase();
    let s = 0;
    if (text === t) s += 100;
    else if (text.includes(t)) s += 40;
    if (meta.includes(slug)) s += 30;
    if (e.id) s += 15; // ids are the most stable
    if (e.unique) s += 10;
    return s;
  };
  return visible
    .map((e) => ({ ...e, _s: score(e) }))
    .filter((e) => e._s > 0)
    .sort((a, b) => b._s - a._s);
}

/* ----- runs inside the page (must be self-contained) ----- */
function extractCatalog() {
  const isVisible = (el) => {
    if (!el.getClientRects().length) return false;
    const s = getComputedStyle(el);
    return s.visibility !== 'hidden' && s.display !== 'none' && Number(s.opacity) !== 0;
  };
  const clickableTags = new Set(['button', 'a', 'input', 'select', 'textarea']);
  const isClickable = (el) =>
    clickableTags.has(el.tagName.toLowerCase()) ||
    el.getAttribute('role') === 'button' ||
    el.hasAttribute('onclick') ||
    getComputedStyle(el).cursor === 'pointer';
  const shortText = (el) =>
    (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 60);
  const cssId = (id) => '#' + id.replace(/([^\w-])/g, '\\$1');

  const out = [];
  let withId = 0,
    clickable = 0;
  for (const el of Array.from(document.querySelectorAll('*'))) {
    const tag = el.tagName.toLowerCase();
    if (tag === 'script' || tag === 'style') continue;

    const id = el.id || '';
    const classes = typeof el.className === 'string' ? el.className.trim() : '';
    const click = isClickable(el);
    const text = shortText(el);
    const isLeaf = el.children.length === 0;
    if (!id && !click && !(isLeaf && text)) continue;

    let sel, kind;
    if (id) {
      sel = cssId(id);
      kind = 'id';
    } else if (classes) {
      sel = '.' + classes.split(/\s+/)[0];
      kind = click ? 'clickable' : 'class';
    } else if (text) {
      sel = `text=${text}`;
      kind = click ? 'clickable' : 'text';
    } else continue;

    let unique = null,
      visibleMatches = null;
    if (sel[0] === '#' || sel[0] === '.') {
      try {
        const matches = Array.from(document.querySelectorAll(sel));
        unique = matches.length === 1;
        visibleMatches = matches.filter(isVisible).length;
      } catch {
        /* invalid selector — leave null */
      }
    }

    if (id) withId++;
    if (click) clickable++;
    out.push({
      tag,
      id: id || null,
      classes: classes ? classes.slice(0, 80) : null,
      role: el.getAttribute('role'),
      aria: el.getAttribute('aria-label'),
      text,
      visible: isVisible(el),
      clickable: click,
      kind,
      suggestedSelector: sel,
      unique,
      visibleMatches,
    });
    if (out.length >= 1500) break;
  }
  return {
    url: location.href,
    title: document.title,
    count: out.length,
    withId,
    clickable,
    elements: out,
  };
}
