// @ts-check
const { defineConfig } = require('@playwright/test');

/**
 * Samsung Magician is a single-instance Electron desktop app, so tests must run
 * serially in one worker — never in parallel.
 */
module.exports = defineConfig({
  testDir: './tests',
  fullyParallel: false,
  workers: 1,
  retries: 0,
  timeout: 180_000, // benchmarks/scans are slow
  expect: { timeout: 30_000 },
  reporter: [['list'], ['html', { open: 'never' }]],
  use: {
    screenshot: 'only-on-failure',
    trace: 'retain-on-failure',
  },
});
