Create comprehensive Samsung Magician test framework
NLP user input text file from input directory to generate playwrite javascript tests in tests directory.
Do not use CDP, use live DOM inspection instead.  
Enhance the steps so that LLM can better understand the input text file based oon live DOM inspection
Update configurration files holding Element IDs (common, feature specific etc) etc in Elements_Config
Generate Playwright javascript tests
