# Generating Magician test scripts

A natural-language description becomes a **plain, standalone Playwright script**.
The LLM and live DOM inspection are used **once, at generation time**. The
generated script in `tests/` then runs on its own — no LLM, no inspection.

```
input/<feature>.txt  ──►  tools/inspect.mjs (live DOM)  ──►  Elements_Config/<feature>.json  ──►  tests/<feature>.spec.mjs
   (you write)              (resolve element IDs)               (LLM updates)                        (LLM generates → just runs)
```

## Layout

| Path | Role | Maintained by |
|------|------|---------------|
| `input/*.txt` | natural-language test descriptions | you |
| `tools/inspect.mjs` | live DOM inspection → element catalog + resolved targets | — |
| `Elements_Config/common.json` | element IDs shared across features | generator |
| `Elements_Config/<feature>.json` | feature-specific element IDs | generator |
| `tests/<feature>.spec.mjs` | the generated plain Playwright script | generator |
| `tests/fixtures.mjs` | shared launch + elevation guard (the only runtime dependency) | — |

## Steps

1. **Describe the test** — write `input/<feature>.txt` in plain English
   (see `input/performance-benchmark.txt`).

2. **Inspect the live app** (run ELEVATED — Magician self-elevates via UAC):
   ```powershell
   node tools/inspect.mjs --find "Start" "Sequential Read" "Random Write"
   ```
   This launches Magician, dumps an element catalog to
   `Elements_Config/_inspection/`, and prints the most stable selector for each
   named target (preferring `#id` > unique `.class` > visible text), flagging
   non-unique matches.

3. **Update Elements_Config** — record the resolved selectors in
   `Elements_Config/common.json` (shared) and `Elements_Config/<feature>.json`
   (feature-specific). This is the "enhance steps with live inspection" step:
   the catalog turns vague NL targets into concrete, verified element IDs.

4. **Generate the plain script** — write `tests/<feature>.spec.mjs` following the
   `performance-benchmark.spec.mjs` template: load IDs from `Elements_Config`,
   express the steps with ordinary Playwright calls, assert outcomes. No engine,
   no config interpreter — just readable Playwright.

5. **Validate** (elevated):
   ```powershell
   npx playwright test tests/<feature>.spec.mjs
   ```
   Once green, the script is the deliverable: repeatable and unattended.

## Conventions for resilient scripts

- Prefer `#id`, then a unique class, then visible text.
- Always `.filter({ visible: true })` — Magician renders hidden duplicate tiles.
- Wait on real state (value changes, element visible/hidden), never fixed sleeps.
- Source every selector from `Elements_Config` so a Magician UI change is a
  one-file edit, not a script rewrite.
