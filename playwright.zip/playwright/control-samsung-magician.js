/**
 * Control Samsung Magician with Playwright (native Electron API — no manual CDP).
 *
 * Samsung Magician 8.x is a packaged Electron app:
 *   "C:\Program Files (x86)\Samsung\Samsung Magician\SamsungMagician.exe"
 *
 * Playwright's `_electron.launch()` starts that binary and gives you the
 * renderer window back as an ordinary Playwright `Page`, so you can use the
 * usual locators / clicks / screenshots. You do NOT need to start the app with
 * --remote-debugging-port and connect over CDP yourself.
 *
 * Run:
 *   npm init -y
 *   npm i -D playwright
 *   node control-samsung-magician.js
 *
 * NOTE: Samsung Magician normally needs admin rights and its background
 * service (SamsungMagicianSVC.exe) to read SSD data. Launch your terminal
 * "as Administrator" so the automated instance behaves the same as a normal
 * double-click launch.
 */

const { _electron: electron } = require('playwright');
const path = require('path');

const MAGICIAN_EXE =
  'C:\\Program Files (x86)\\Samsung\\Samsung Magician\\SamsungMagician.exe';

(async () => {
  // 1. Launch the packaged Electron app.
  const app = await electron.launch({
    executablePath: MAGICIAN_EXE,
    // Helps when the app is launched outside its install dir.
    cwd: path.dirname(MAGICIAN_EXE),
  });

  try {
    // 2. Grab the first renderer window (the main UI).
    const window = await app.firstWindow();
    await window.waitForLoadState('domcontentloaded');

    console.log('Window title:', await window.title());

    // Give the SPA a moment to render its dashboard.
    await window.waitForTimeout(3000);

    // 3. Snapshot what we're looking at so you can build real selectors.
    await window.screenshot({ path: 'magician-start.png', fullPage: true });
    console.log('Saved screenshot -> magician-start.png');

    // 4. Inspect the DOM to discover stable selectors. Magician's UI text is
    //    localized, so prefer roles / test-ids over hard-coded English text.
    const buttons = await window.getByRole('button').allInnerTexts();
    console.log('Buttons on screen:', buttons);

    // 5. Example interaction — adjust the names to what step 4 prints.
    //    e.g. navigate to the "Performance Benchmark" view and run it:
    //
    // await window.getByRole('button', { name: /performance/i }).click();
    // await window.getByRole('button', { name: /start/i }).click();
    // await window.getByText(/MB\/s/).first().waitFor({ timeout: 120000 });
    // await window.screenshot({ path: 'benchmark-result.png' });

    // 6. You can also reach into the Electron main process if needed, e.g.
    //    read the app version straight from the main process:
    const appVersion = await app.evaluate(async ({ app }) => app.getVersion());
    console.log('Electron app version:', appVersion);
  } finally {
    // 7. Close the app.
    await app.close();
  }
})().catch((err) => {
  console.error('Automation failed:', err);
  process.exit(1);
});
