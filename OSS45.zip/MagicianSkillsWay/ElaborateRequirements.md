# Elaborated Requirements — Samsung Magician Test Automation Framework

## 1. Goal

Build a repeatable, self-contained test automation framework for **Samsung Magician** (an Electron/Chromium desktop app) that:

- Uses **agent-browser** (vercel-labs) to *discover* UI elements on each screen and persist them as JSON configs.
- Uses **Playwright** (accessibility-tree API) to *interact* with those elements in test scripts.
- Starts and stops the application as part of every test run — no manual pre-launch required.

---

## 2. Architecture Overview

```
MagicianSkills/
├── Elements_Config/          ← agent-browser discovery output (one JSON per screen)
│   ├── home_dashboard.json
│   ├── diagnosis_information.json
│   ├── performance_management.json
│   ├── firmware_update.json
│   └── ...
├── tests/
│   ├── helpers/
│   │   ├── magician.js       ← app lifecycle (start / stop / waitForUiReady)
│   │   ├── ab.js             ← agent-browser CLI wrapper (snapshot, click, fill…)
│   │   └── elements.js       ← loads Elements_Config JSONs for use in tests
│   ├── smoke.test.js         ← sanity: app launches, tabs, drive visible
│   ├── home_dashboard.test.js
│   ├── diagnosis.test.js
│   ├── performance.test.js
│   └── ...
├── playwright.config.js
└── scripts/
    └── discover.js           ← run once to regenerate Elements_Config via agent-browser
```

---

## 3. Two-Phase Workflow

### Phase A — Discovery (agent-browser)

A one-shot script (`scripts/discover.js`) navigates each Samsung Magician screen and uses `agent-browser snapshot --json` to extract the full accessibility tree. The output is written to `Elements_Config/<screen>.json`.

Each config file captures:

| Field | Description |
|---|---|
| `screen` | Screen name (e.g. `home_dashboard`) |
| `url` | Electron renderer URL for this view |
| `elements` | Array of discovered elements (see below) |
| `capturedAt` | ISO timestamp of discovery run |

Each element entry:

```json
{
  "ref": "e11",
  "label": "Home Dashboard",
  "role": "generic",
  "clickable": true,
  "type": "nav-link",
  "selector": "text=Home Dashboard"
}
```

Element types to capture exhaustively per screen:
- **Navigation links** — sidebar / top-bar items that route to other screens
- **Buttons** — action triggers (Run, Apply, Update, Erase, Enable…)
- **Dropdowns / selects** — mode selectors, partition selectors
- **Toggles / checkboxes** — RAPID mode, Over Provisioning on/off
- **Text / data fields** — drive health %, temperature, firmware version
- **Alerts / notices** — UpdateNotice banners, warning dialogs

### Phase B — Testing (Playwright)

Test scripts import the relevant config from `Elements_Config/` via a helper (`tests/helpers/elements.js`) and use Playwright's accessibility tree selectors to locate and interact with elements.

```js
const { getElement } = require('./helpers/elements');

const navHome = getElement('home_dashboard', 'Home Dashboard');
await page.locator(navHome.selector).click();
```

This decouples selectors from test logic — when the UI changes, only the config needs regeneration, not every test.

---

## 4. Samsung Magician Screens (known from snapshot)

Based on the first agent-browser snapshot, the following screens are confirmed in the navigation:

| Screen | Nav Label | Notes |
|---|---|---|
| Home Dashboard | "Home Dashboard" | Landing page, shows connected drive(s) |
| Diagnosis & Information | "Diagnosis & Information" | Drive health, S.M.A.R.T data |
| Performance Management | "Performance Management" | Benchmark, RAPID mode |
| Firmware Update | (inferred from UpdateNotice) | Update check, firmware flash |
| Over Provisioning | (inferred) | Partition resize for OP |
| Secure Erase | (inferred) | Full drive erase |
| Settings | (inferred) | App preferences |

The connected device observed: `SAMSUNG MZVLQ512HALU-00000--` (NVMe, PM991 series).

---

## 5. Test Script Requirements

### 5.1 Structure

- One test file per screen.
- Each file uses `test.beforeAll` / `test.afterAll` to start and stop Samsung Magician.
- Tests within a file are ordered: navigate → verify static content → interact → verify result.

### 5.2 App Lifecycle (inside each test file)

```
beforeAll:
  1. taskkill SamsungMagician.exe    (ignore if not running)
  2. taskkill SamsungMagicianSVC.exe (ignore if not running)
  3. spawn SamsungMagician.exe --remote-debugging-port=9222
  4. poll /json/version until CDP responds
  5. agent-browser connect 9222
  6. poll snapshot until "Home Dashboard" appears (UI renderer ready)

afterAll:
  7. agent-browser disconnect
  8. taskkill SamsungMagician.exe
```

### 5.3 Logging

Every test must log:
- Screen name and test name at start
- agent-browser snapshot excerpt (first 500 chars) on navigation
- Element ref and label before every click/fill
- Pass/fail result with relevant value (e.g. health %, firmware version read)

### 5.4 Element Selection Strategy

Use Playwright accessibility-tree selectors in this priority order:

1. `text=<label>` — for uniquely labelled elements
2. `role=<role>[name="<label>"]` — when role + name is unambiguous
3. `[ref=eN]` — agent-browser ref as a last resort (refs can change between launches)

---

## 6. Elements_Config Schema

```json
{
  "screen": "home_dashboard",
  "url": "file:///C:/Program%20Files%20(x86)/Samsung/Samsung%20Magician/resources/app/dist/main/app/main/main.html",
  "capturedAt": "2026-06-09T00:00:00.000Z",
  "elements": [
    {
      "ref": "e11",
      "label": "Home Dashboard",
      "role": "generic",
      "type": "nav-link",
      "clickable": true,
      "selector": "text=Home Dashboard"
    },
    {
      "ref": "e8",
      "label": "SAMSUNG MZVLQ512HALU-00000--",
      "role": "generic",
      "type": "drive-selector",
      "clickable": true,
      "selector": "text=SAMSUNG MZVLQ512HALU"
    }
  ]
}
```

---

## 7. Discovery Script (`scripts/discover.js`)

Responsibilities:
1. Start Samsung Magician (via `startMagician()`).
2. For each known screen: navigate to it, call `agent-browser snapshot --json`, parse the output, classify elements by type, write to `Elements_Config/<screen>.json`.
3. Stop Samsung Magician.
4. Print a summary of elements found per screen.

Run with:
```powershell
node scripts/discover.js
```

Re-run after any Samsung Magician UI update to refresh configs.

---

## 8. How agent-browser and Elements_Config Work Together

| Stage | Tool | Role |
|---|---|---|
| Discovery | agent-browser | Navigates the live app, reads the accessibility tree, exports JSON |
| Config | Elements_Config JSON | Stable snapshot of selectors and element metadata |
| Test execution | Playwright | Reads configs, drives app via accessibility selectors, asserts outcomes |
| Re-discovery | agent-browser | Re-run `discover.js` when UI changes; tests stay unchanged |

agent-browser is **not** used at test runtime — only Playwright drives interactions during tests. agent-browser's role is config generation only.

---

## 9. Open Questions / Decisions Needed

1. **Admin elevation**: Samsung Magician requires admin. Tests must be run from an elevated terminal. Should this be enforced programmatically (detect and error early)?
2. **Drive-dependent tests**: Some tests (Benchmark, Firmware Update, Secure Erase) are destructive or depend on a specific drive being connected. These need a guard/skip mechanism.
3. **Firmware Update**: Should this be tested end-to-end (actual flash) or only up to the confirmation dialog?
4. **Secure Erase**: Almost certainly should remain stub-only — never execute the erase in CI.
5. **Config refresh cadence**: Trigger `discover.js` automatically on test failure due to missing element, or keep it purely manual?
