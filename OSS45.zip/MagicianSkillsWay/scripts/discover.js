'use strict';

/**
 * discover.js
 *
 * Navigates every Samsung Magician screen, uses agent-browser to snapshot
 * the accessibility tree, classifies each element, and writes a JSON config
 * to Elements_Config/<screen_name>.json.
 *
 * Run from an elevated terminal:
 *   node scripts/discover.js
 *
 * Re-run whenever the Samsung Magician UI changes.
 */

const path = require('path');
const fs   = require('fs');
const { startMagician, stopMagician } = require('../tests/helpers/magician');
const ab = require('../tests/helpers/ab');

const OUTPUT_DIR = path.resolve(__dirname, '..', 'Elements_Config');
const sleep = ms => new Promise(r => setTimeout(r, ms));

// ─── Screen manifest ────────────────────────────────────────────────────────
// navLabel: the exact text shown in the sidebar/nav.
// null means it is the landing screen (no click needed).
const SCREENS = [
  { name: 'home_dashboard',         navLabel: null },
  { name: 'diagnosis_information',  navLabel: 'Diagnosis & Information' },
  { name: 'performance_management', navLabel: 'Performance Management' },
  { name: 'firmware_update',        navLabel: 'Firmware Update' },
  { name: 'over_provisioning',      navLabel: 'Over Provisioning' },
  { name: 'secure_erase',           navLabel: 'Secure Erase' },
  { name: 'settings',               navLabel: 'Settings' },
];

// ─── Element classification ──────────────────────────────────────────────────
const NAV_LABELS_RE   = /dashboard|information|management|update|provisioning|erase|settings|mode|boost|benchmark|notification/i;
const BUTTON_WORDS_RE = /^(run|start|stop|apply|enable|disable|install|scan|fix|optimize|refresh|cancel|confirm|next|back|ok|yes|no)$/i;
const DRIVE_RE        = /samsung|ssd|nvme|mzvl|drive|disk|pm\d{3}|860|870|980|990/i;
const TIME_FILTER_RE  = /^Last \d+ (Month|Months|Year|Years|Week|Weeks|Day|Days)$/i;

function classifyElement(el) {
  const name = (el.name || el.label || '').trim();
  const role = (el.role || '').toLowerCase();

  if (['combobox', 'listbox', 'option', 'menuitem'].includes(role)) return 'dropdown';
  if (['checkbox', 'switch', 'radio'].includes(role))               return 'toggle';
  if (role === 'button')                                             return 'button';
  if (['textbox', 'searchbox', 'spinbutton'].includes(role))        return 'input';
  if (role === 'link')                                               return 'nav-link';

  // Heuristics for Electron's generic/div-heavy DOMs
  if (/notice|alert|warning|banner/i.test(name))                    return 'alert';
  if (TIME_FILTER_RE.test(name) && el.clickable)                    return 'dropdown';
  if (DRIVE_RE.test(name) && el.clickable)                          return 'drive-selector';
  if (NAV_LABELS_RE.test(name) && el.clickable)                     return 'nav-link';
  if (BUTTON_WORDS_RE.test(name.split(' ')[0]) && el.clickable)     return 'button';
  if (el.clickable)                                                  return 'clickable';
  return 'data-field';
}

function buildSelector(el) {
  const name = (el.name || el.label || '').trim();
  const role = (el.role || '').toLowerCase();
  if (name && role && role !== 'generic') return `role=${role}[name="${name}"]`;
  if (name)                               return `text=${name}`;
  return `[ref=${el.ref}]`; // last resort — ref can change between launches
}

// ─── Flatten nested element tree ─────────────────────────────────────────────
function flatten(nodes, out = []) {
  if (!Array.isArray(nodes)) return out;
  for (const n of nodes) {
    out.push(n);
    if (n.children) flatten(n.children, out);
  }
  return out;
}

// ─── Parse text snapshot as fallback ─────────────────────────────────────────
function parseTextSnapshot(text) {
  const elements = [];
  for (const line of text.split('\n')) {
    const refMatch   = line.match(/\[ref=(e\d+)\]/);
    const labelMatch = line.match(/"([^"]+)"/);
    const clickable  = line.includes('clickable');
    if (!refMatch && !labelMatch) continue;

    const el = {
      ref:      refMatch   ? refMatch[1]   : '',
      name:     labelMatch ? labelMatch[1] : '',
      role:     'generic',
      clickable,
    };
    elements.push(el);
  }
  return elements;
}

// ─── Current tab URL ──────────────────────────────────────────────────────────
function getTabUrl() {
  try {
    const tabs = ab.tab();
    const m = tabs.match(/file:\/\/[^\s\]]+/);
    return m ? decodeURIComponent(m[0]) : '';
  } catch { return ''; }
}

// ─── Discover one screen ──────────────────────────────────────────────────────
async function discoverScreen(screen) {
  console.log(`\n${'─'.repeat(60)}`);
  console.log(`[discover] Screen: ${screen.name}`);

  // Navigate if needed
  if (screen.navLabel) {
    console.log(`[discover] Clicking nav: "${screen.navLabel}"`);
    try {
      ab.clickLabel(screen.navLabel);
    } catch (err) {
      console.warn(`[discover] Nav click failed: ${err.message}`);
      console.warn('[discover] Skipping this screen.');
      return null;
    }
    await sleep(2000); // wait for React re-render
  }

  // Screenshot for human reference
  const imgPath = path.join(OUTPUT_DIR, `${screen.name}.png`);
  try {
    ab.screenshot(imgPath);
    console.log(`[discover] Screenshot → ${imgPath}`);
  } catch { /* non-fatal */ }

  // Text snapshot for logging
  const textSnap = ab.snapshot();
  console.log(`[discover] Text snapshot (first 500 chars):\n${textSnap.slice(0, 500)}`);

  // JSON snapshot (structured)
  let rawNodes = [];
  try {
    const json = ab.snapshotJson();
    // agent-browser may return array or { nodes: [...] } or { tree: [...] }
    if (Array.isArray(json))         rawNodes = json;
    else if (Array.isArray(json.nodes))    rawNodes = json.nodes;
    else if (Array.isArray(json.elements)) rawNodes = json.elements;
    else if (Array.isArray(json.tree))     rawNodes = json.tree;
    else {
      console.warn('[discover] Unknown JSON shape — keys:', Object.keys(json));
      console.warn('[discover] Falling back to text parser.');
      rawNodes = parseTextSnapshot(textSnap);
    }
  } catch (err) {
    console.warn(`[discover] JSON snapshot failed (${err.message}), using text parser.`);
    rawNodes = parseTextSnapshot(textSnap);
  }

  const flat = flatten(rawNodes);
  console.log(`[discover] Total nodes in tree: ${flat.length}`);

  // Build element configs
  const seen = new Set();
  const elements = flat
    .filter(el => (el.name || el.label || '').trim() || el.clickable)
    .map(el => {
      const label    = (el.name || el.label || '').trim();
      const role     = (el.role || 'generic').toLowerCase();
      const type     = classifyElement({ ...el, name: label, role });
      const selector = buildSelector({ ...el, name: label, role });
      return { ref: el.ref || '', label, role, type, clickable: !!el.clickable, selector };
    })
    .filter(el => {
      // deduplicate by label+role
      const key = `${el.label}::${el.role}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });

  console.log(`[discover] Classified ${elements.length} unique elements`);

  // Log by type
  const byType = {};
  for (const el of elements) {
    byType[el.type] = (byType[el.type] || 0) + 1;
  }
  console.log('[discover] Element types:', byType);

  return {
    screen:    screen.name,
    navLabel:  screen.navLabel,
    url:       getTabUrl(),
    capturedAt: new Date().toISOString(),
    elementCount: elements.length,
    elements,
  };
}

// ─── Main ─────────────────────────────────────────────────────────────────────
async function main() {
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });

  console.log('[discover] Starting Samsung Magician...');
  await startMagician();
  console.log('[discover] App ready. Starting discovery.\n');

  const summary = [];

  for (const screen of SCREENS) {
    const config = await discoverScreen(screen);

    if (!config) {
      summary.push({ screen: screen.name, status: 'skipped', count: 0 });
      continue;
    }

    const outPath = path.join(OUTPUT_DIR, `${screen.name}.json`);
    fs.writeFileSync(outPath, JSON.stringify(config, null, 2));
    console.log(`[discover] Written → ${outPath}`);
    summary.push({ screen: screen.name, status: 'ok', count: config.elementCount });
  }

  console.log('\n[discover] Stopping Samsung Magician...');
  stopMagician();

  console.log('\n' + '═'.repeat(60));
  console.log('[discover] SUMMARY');
  console.log('═'.repeat(60));
  for (const s of summary) {
    const tag = s.status === 'ok' ? `✓  ${s.count} elements` : '✗  skipped';
    console.log(`  ${s.screen.padEnd(32)} ${tag}`);
  }
  console.log('═'.repeat(60));
}

main().catch(err => {
  console.error('\n[discover] Fatal:', err.message);
  try { stopMagician(); } catch {}
  process.exit(1);
});
