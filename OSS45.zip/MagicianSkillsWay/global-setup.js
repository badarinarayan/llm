const { startMagician } = require('./tests/helpers/magician');

module.exports = async function globalSetup() {
  await startMagician();
};
