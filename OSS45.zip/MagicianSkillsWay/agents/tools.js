// Tool definitions (LangChain StructuredTool objects) + implementations.
// Each export is a ready-to-use tool: pass to model.bindTools() and call .invoke().

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const { tool } = require('@langchain/core/tools');
const { z } = require('zod');

const ROOT = path.resolve(__dirname, '..');
const ELEMENTS_CONFIG_DIR = path.join(ROOT, 'Elements_Config');
const WORKSPACE_DIR = path.join(ROOT, 'workspace');
const TESTS_DIR = path.join(ROOT, 'tests');
const CDP_PORT = 9222;

const SCREEN_NAMES = [
  'home_dashboard', 'diagnosis_information', 'performance_benchmark',
  'performance_management', 'disk_partition', 'data_management',
  'over_provisioning', 'settings',
];

function resolvePath(p) {
  return path.isAbsolute(p) ? p : path.join(ROOT, p);
}

// ─── Tool objects ─────────────────────────────────────────────────────────────

const readFileTool = tool(
  async ({ path: filePath }) => {
    const abs = resolvePath(filePath);
    if (!fs.existsSync(abs)) return `ERROR: File not found: ${abs}`;
    return fs.readFileSync(abs, 'utf8');
  },
  {
    name: 'read_file',
    description: 'Read any file from the project. Use for input files, existing tests, workspace intermediates, or Elements_Config.',
    schema: z.object({
      path: z.string().describe('File path — absolute, or relative to project root'),
    }),
  }
);

const writeFileTool = tool(
  async ({ path: filePath, content }) => {
    const abs = resolvePath(filePath);
    fs.mkdirSync(path.dirname(abs), { recursive: true });
    fs.writeFileSync(abs, content, 'utf8');
    return `Written ${abs} (${content.length} bytes)`;
  },
  {
    name: 'write_file',
    description: 'Write content to a file. Creates parent directories automatically.',
    schema: z.object({
      path: z.string().describe('File path — absolute, or relative to project root'),
      content: z.string().describe('Content to write'),
    }),
  }
);

const listElementsConfigsTool = tool(
  async () => {
    return SCREEN_NAMES.map(s => {
      const cfgPath = path.join(ELEMENTS_CONFIG_DIR, `${s}.json`);
      if (!fs.existsSync(cfgPath)) return `${s}: (not found)`;
      const cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
      return `${s}: navLabel="${cfg.navLabel}", ${cfg.elements.length} elements, signals=[${(cfg.page_signals || []).join(', ')}]`;
    }).join('\n');
  },
  {
    name: 'list_elements_configs',
    description: 'List all Elements_Config screens with navLabel, element count, and page signals.',
    schema: z.object({}),
  }
);

const readElementsConfigTool = tool(
  async ({ screen }) => {
    const cfgPath = path.join(ELEMENTS_CONFIG_DIR, `${screen}.json`);
    if (!fs.existsSync(cfgPath)) return `ERROR: No config for screen "${screen}"`;
    return fs.readFileSync(cfgPath, 'utf8');
  },
  {
    name: 'read_elements_config',
    description: 'Read the Elements_Config JSON for a Magician screen. Contains exact element labels, types, clickable status, and action_hints.',
    schema: z.object({
      screen: z.enum(SCREEN_NAMES).describe('Screen name'),
    }),
  }
);

const updateElementsConfigTool = tool(
  async ({ screen, new_elements }) => {
    const cfgPath = path.join(ELEMENTS_CONFIG_DIR, `${screen}.json`);
    if (!fs.existsSync(cfgPath)) return `ERROR: No config for screen "${screen}"`;
    const cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
    let updated = 0, added = 0;
    for (const el of new_elements) {
      const idx = cfg.elements.findIndex(e => e.label === el.label);
      if (idx >= 0) { cfg.elements[idx] = { ...cfg.elements[idx], ...el }; updated++; }
      else { cfg.elements.push({ ref: 'unknown', ...el }); added++; }
    }
    cfg.capturedAt = new Date().toISOString();
    fs.writeFileSync(cfgPath, JSON.stringify(cfg, null, 2), 'utf8');
    return `Updated ${screen}: ${updated} modified, ${added} added`;
  },
  {
    name: 'update_elements_config',
    description: "Add or update elements in a screen's Elements_Config. Use when live snapshot reveals elements not yet in config.",
    schema: z.object({
      screen: z.enum(SCREEN_NAMES).describe('Screen name'),
      new_elements: z.array(z.object({
        label: z.string(),
        type: z.string().optional().describe('e.g., button, nav-link, dropdown, toggle'),
        clickable: z.boolean().optional(),
        aliases: z.array(z.string()).optional(),
        action_hints: z.string().optional(),
      })).describe('Elements to add or update (matched by label)'),
    }),
  }
);

const snapshotUiTool = tool(
  async ({ full = false } = {}) => {
    try {
      const cmd = full
        ? `agent-browser --cdp ${CDP_PORT} snapshot`
        : `agent-browser --cdp ${CDP_PORT} snapshot -i`;
      return execSync(cmd, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });
    } catch (err) {
      return `ERROR: snapshot failed — ${err.message.split('\n')[0]}. Is Magician running with --remote-debugging-port=${CDP_PORT}?`;
    }
  },
  {
    name: 'snapshot_ui',
    description: 'Take a live UI snapshot of Samsung Magician via CDP. Returns the accessibility tree. Requires Magician running on port 9222.',
    schema: z.object({
      full: z.boolean().optional().describe('true = all nodes including static text; false = interactive elements only (default)'),
    }),
  }
);

const listTestFilesTool = tool(
  async () => {
    if (!fs.existsSync(TESTS_DIR)) return '(tests/ directory not found)';
    return fs.readdirSync(TESTS_DIR, { withFileTypes: true })
      .filter(f => f.isFile() && (f.name.endsWith('.js') || f.name.endsWith('.ts')))
      .map(f => `tests/${f.name}`)
      .join('\n') || '(no test files)';
  },
  {
    name: 'list_test_files',
    description: 'List existing .spec.js test files in tests/ (useful as code style reference).',
    schema: z.object({}),
  }
);

const runTestTool = tool(
  async ({ test_file }) => {
    const abs = resolvePath(test_file);
    if (!fs.existsSync(abs)) return `ERROR: Test file not found: ${abs}`;
    try {
      const absForward = abs.replace(/\\/g, '/');
      const output = execSync(
        `npx playwright test "${absForward}" --reporter=list`,
        { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], cwd: ROOT, timeout: 300000 }
      );
      fs.mkdirSync(WORKSPACE_DIR, { recursive: true });
      fs.writeFileSync(path.join(WORKSPACE_DIR, 'test_result.json'),
        JSON.stringify({ status: 'PASS', output }, null, 2));
      return `PASS\n${output}`;
    } catch (err) {
      const output = [err.stdout, err.stderr, err.message].filter(Boolean).join('\n');
      fs.mkdirSync(WORKSPACE_DIR, { recursive: true });
      fs.writeFileSync(path.join(WORKSPACE_DIR, 'test_result.json'),
        JSON.stringify({ status: 'FAIL', output }, null, 2));
      return `FAIL\n${output}`;
    }
  },
  {
    name: 'run_test',
    description: 'Run a Playwright test file and return output. Saves result to workspace/test_result.json.',
    schema: z.object({
      test_file: z.string().describe('Path relative to project root, e.g. tests/generated_benchmark.spec.js'),
    }),
  }
);

const terminateMagicianTool = tool(
  async () => {
    try {
      execSync('taskkill /F /IM SamsungMagician.exe', { stdio: 'pipe' });
      return 'Samsung Magician terminated.';
    } catch {
      return 'Samsung Magician was not running (already terminated).';
    }
  },
  {
    name: 'terminate_magician',
    description: 'Kill the Samsung Magician process. Call this after a test passes.',
    schema: z.object({}),
  }
);

module.exports = {
  readFileTool,
  writeFileTool,
  listElementsConfigsTool,
  readElementsConfigTool,
  updateElementsConfigTool,
  snapshotUiTool,
  listTestFilesTool,
  runTestTool,
  terminateMagicianTool,
  WORKSPACE_DIR,
  ROOT,
};
