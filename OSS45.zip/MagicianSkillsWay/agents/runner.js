// Shared tool-use loop for all agents.
// Replaces the manual Anthropic SDK loop — uses ChatOpenAI + LangChain message types.

const { ChatOpenAI } = require('@langchain/openai');
const { SystemMessage, HumanMessage, ToolMessage } = require('@langchain/core/messages');

const model = new ChatOpenAI({ model: 'gpt-4o', temperature: 0 });

// Runs a self-contained tool-use loop:
//   1. Sends systemPrompt + userPrompt to the model (with tools bound)
//   2. Executes any tool_calls returned
//   3. Feeds results back until the model stops calling tools
//   4. Returns the final text response
async function runToolLoop(systemPrompt, userPrompt, tools) {
  const toolMap = Object.fromEntries(tools.map(t => [t.name, t]));
  const boundModel = model.bindTools(tools);

  const messages = [
    new SystemMessage(systemPrompt),
    new HumanMessage(userPrompt),
  ];

  while (true) {
    const response = await boundModel.invoke(messages);
    messages.push(response);

    const calls = response.tool_calls ?? [];
    if (!calls.length) {
      return typeof response.content === 'string'
        ? response.content
        : (Array.isArray(response.content)
            ? response.content.map(b => b.text ?? '').join('')
            : String(response.content));
    }

    for (const tc of calls) {
      console.log(`\n[tool] → ${tc.name}(${JSON.stringify(tc.args)})`);
      let result;
      try {
        const t = toolMap[tc.name];
        if (!t) throw new Error(`Unknown tool: ${tc.name}`);
        result = String(await t.invoke(tc.args));
      } catch (err) {
        result = `ERROR: ${err.message}`;
      }
      console.log(`[tool] ← ${result.slice(0, 400)}`);
      messages.push(new ToolMessage({ content: result, tool_call_id: tc.id, name: tc.name }));
    }
  }
}

module.exports = { runToolLoop, model };
