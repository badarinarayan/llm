// Agent 4 — Fixer (LangGraph node)
// Reads the failing test + error output, edits the test file directly, and re-runs it.
// Escalates to the Enhancer only when it cannot resolve the failure itself.
//
// Input:  workspace/test_result.json, workspace/generated_test_path.txt
// Output: overwrites the test file with fixes, re-runs it
// Returns: { verdict, feedback, fixerCount: +1 }

const fs = require('fs');
const path = require('path');
const { runToolLoop } = require('./runner');
const {
  readFileTool, writeFileTool,
  listElementsConfigsTool, readElementsConfigTool,
  snapshotUiTool, runTestTool, WORKSPACE_DIR,
} = require('./tools');

const TOOLS = [
  readFileTool, writeFileTool,
  listElementsConfigsTool, readElementsConfigTool,
  snapshotUiTool, runTestTool,
];

const SYSTEM = `
You are a Test Script Fixer for Samsung Magician automated tests.

Goal: Read the failing test file and its error output, fix the code directly, re-run it.
Edit only what is broken — do not restructure the test or change working logic.

## Failure types and how to fix each

WRONG_LABEL — ab.clickLabel('[label]') threw "No element found"
  → read_elements_config for that screen, find the correct exact label
  → update the clickLabel call in the test file

TIMING — operation still running when assertion ran, or "Stop" still visible
  → increase the polling deadline (e.g., 120000 → 180000)
  → increase ab.wait() between poll cycles
  → add an extra ab.wait(2000) before the assertion block

WRONG_ASSERT — expect(snap).toContain('X') failed
  → snapshot_ui({full: true}) to see the actual text on screen
  → update the assertion string to match what is really there

WRONG_NAV — landed on wrong screen, expected page signal not found
  → read_elements_config to verify navLabel sequence
  → fix clickLabel nav calls and/or add missing ab.wait() between them

DRIVE_ISSUE — wrong drive selected, or drive panel did not close
  → verify the ab.selectDrive hint ('internal'|'external'|'nvme'|'sata')
  → ensure await magician.switchDrive() is used if drive must be confirmed closed

## Process
1. read_file workspace/test_result.json        — understand the error
2. read_file workspace/generated_test_path.txt — get the test file path
3. read_file [test file path]                  — read current test code
4. snapshot_ui({full: false})                  — ALWAYS inspect live UI state via agent-browser
                                                 to see exactly what is on screen right now
5. snapshot_ui({full: true})                   — if you need to read actual text values or metric labels
6. read_elements_config [screen]               — verify correct element labels against the config
7. (optional) read_file [enhancedFile]         — consult enhanced spec for original intent
8. write_file [test file path]                 — write the complete fixed file
9. run_test [test file path]                   — re-run it
10. If PASS: respond "PASS: [one-line summary]"
    If FAIL: respond "FAIL: [what you tried] — [remaining problem]"

Write the full fixed file, not a patch. Keep all imports and test structure intact.
The live snapshot from agent-browser is the ground truth — trust it over the config when they differ.
`.trim();

async function fixerNode(state) {
  console.log('\n[Fixer] Running...');

  const result = await runToolLoop(
    SYSTEM,
    `Read the failing test and fix it. Re-run after fixing.\nEnhanced spec (for intent reference): ${state.enhancedFile}`,
    TOOLS
  );

  console.log('[Fixer] Done.');

  const verdict = result.trimStart().startsWith('PASS') ? 'PASS' : 'FAIL';

  let feedback = '';
  if (verdict === 'FAIL') {
    feedback = result;
    // Persist fixer's findings so the Enhancer has full context on escalation
    fs.mkdirSync(WORKSPACE_DIR, { recursive: true });
    fs.writeFileSync(
      path.join(WORKSPACE_DIR, 'feedback.md'),
      `# Fixer could not resolve\n\n${result}\n`,
      'utf8'
    );
  }

  return {
    verdict,
    feedback,
    fixerCount: state.fixerCount + 1,
  };
}

module.exports = { fixerNode };
