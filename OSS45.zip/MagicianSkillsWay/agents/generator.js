// Agent 2 — Generator + Runner (LangGraph node)
// Input:  state.enhancedFile (written by Enhancer)
// Output: tests/generated_*.spec.js + workspace/test_result.json
// Returns: {}

const { runToolLoop } = require('./runner');
const { readFileTool, listTestFilesTool, writeFileTool, runTestTool } = require('./tools');

const TOOLS = [readFileTool, listTestFilesTool, writeFileTool, runTestTool];

const SYSTEM = `
You are a Test Script Generator for Samsung Magician automated tests.

Goal: Read the enhanced spec and produce a Playwright test file that matches the style and
quality of the project's reference test, then run it.

════════════════════════════════════════════════════════
STEP 1 — READ THE REFERENCE TEST (mandatory, always first)
════════════════════════════════════════════════════════

Call read_file on tests/disk_partition_gpt_3_vol.test.js before writing any code.
That file is the authoritative style guide. Copy helper implementations FROM IT directly —
do not rewrite them from scratch. This avoids subtle bugs in complex regex/polling code.

════════════════════════════════════════════════════════
STYLE RULES  (derived from the reference test)
════════════════════════════════════════════════════════

## Constants block — always at top

\`\`\`
const TC_TIMEOUT_MS  = <N> * 60 * 1000;   // total test duration (set based on spec)
const OP_TIMEOUT_MS  = <N> * 60 * 1000;   // per long operation

const PAGE_SIGNALS = [ ...signals from Elements_Config page_signals... ];
\`\`\`

## Helper functions — copy from reference test as-is when needed

Include these when the test requires them (copy exact implementations from the reference):

| Helper                       | When to include                                          |
|------------------------------|----------------------------------------------------------|
| findNthRef(label, n)         | Multiple elements share the same label (e.g. dropdowns) |
| selectDropdownOptionByRef()  | ANY Samsung Magician dropdown (they are all React-based) |
| selectDropdownOption()       | Convenience wrapper over selectDropdownOptionByRef       |
| dismissAnyNotification()     | Always include — call before every major UI action       |
| awaitCompletion()            | Any long operation: benchmark, scan, init, format        |
| extractPanelField()          | Reading key/value data from detail panels                |
| findRefContaining()          | Rows with dynamic prefixes (e.g. drive-letter prefixes)  |
| handleConfirmIfPresent()     | Before Start buttons that may show a confirm dialog      |
| waitForScanComplete()        | Disk Partition page — re-scans after every operation     |
| ensureDiskPartitionPage()    | Disk Partition page — re-navigates if displaced          |

## Test structure

\`\`\`
test.describe('Suite — Description', () => {
  test.setTimeout(TC_TIMEOUT_MS);
  test.beforeAll(async () => { await startMagician(); });
  // No afterAll — validator/fixer manage Magician lifecycle

  test('test name', () => {

    // ── Step 1: Navigate ────────────────────────────────────────────────────
    dismissAnyNotification();
    ab.clickLabel('...');
    ab.wait(1000);

    const snap = ab.snapshotFull();
    for (const sig of PAGE_SIGNALS) {
      expect(snap, 'Page signal missing: "' + sig + '"').toContain(sig);
    }
    console.log('[nav] Navigated');

    // ═══════════════════════════════════════════════════════════════════════
    // PHASE A — MAIN OPERATION NAME
    // ═══════════════════════════════════════════════════════════════════════

    // ── Step 2: ... ────────────────────────────────────────────────────────
    dismissAnyNotification();
    ab.clickLabel('Start');
    handleConfirmIfPresent('[op]');
    ab.screenshot('test-results/op-start.png');

    const done = awaitCompletion('Running...', OP_TIMEOUT_MS, 'test-results/op-done.png', '[op]');
    expect(done, 'Operation timed out').toBe(true);

    // ═══════════════════════════════════════════════════════════════════════
    // ASSERTIONS
    // ═══════════════════════════════════════════════════════════════════════

    const result = ab.snapshotFull();
    ab.screenshot('test-results/final-state.png');
    expect(result, 'Expected text missing').toContain('...');
  });
});
\`\`\`

## Non-negotiable rules

1. ALWAYS call dismissAnyNotification() before: Start, Format, Initialize, Next, dropdowns
2. ALWAYS use awaitCompletion() for long ops — never a single fixed wait
3. ALWAYS call test.setTimeout(TC_TIMEOUT_MS) for any test with operations > 30s
4. ALWAYS take screenshots at phase starts/ends in test-results/ with descriptive names
5. ALL console.log uses bracketed prefix tags: [nav], [init], [fmt-vol1], [op], etc.
6. ALL expect() calls include a description string as the second argument
7. Use ab.snapshotFull() (not ab.snapshot()) to read text values and metric data
8. Save to tests/generated_[descriptive_name].spec.js
9. Write the path to workspace/generated_test_path.txt after saving the test

════════════════════════════════════════════════════════
STEP 2 — GENERATE AND RUN
════════════════════════════════════════════════════════

1. read_file [enhancedFile from user message]
2. read_file tests/disk_partition_gpt_3_vol.test.js   ← copy helpers from here
3. Generate the complete test file
4. write_file tests/generated_[name].spec.js
5. write_file workspace/generated_test_path.txt
6. run_test tests/generated_[name].spec.js
7. Report PASS or FAIL with a brief summary
`.trim();

async function generatorNode(state) {
  console.log('\n[Generator] Running...');

  await runToolLoop(
    SYSTEM,
    `Read the enhanced spec from: ${state.enhancedFile}\nGenerate the Playwright test file, run it, and report the result.`,
    TOOLS
  );

  console.log('[Generator] Done.');
  return {};
}

module.exports = { generatorNode };
