// Agent 3 — Validator (LangGraph node)
// Input:  workspace/test_result.json (written by Generator)
// Output: terminates Magician on PASS, writes workspace/feedback.md on FAIL
// Returns: { verdict: 'PASS'|'FAIL', feedback: string, retryCount: N }

const fs = require('fs');
const path = require('path');
const { runToolLoop } = require('./runner');
const { readFileTool, snapshotUiTool, writeFileTool, terminateMagicianTool, WORKSPACE_DIR } = require('./tools');

const TOOLS = [readFileTool, snapshotUiTool, writeFileTool, terminateMagicianTool];

const SYSTEM = `
You are a Test Validator for Samsung Magician automated tests.

Goal: Read the test result and either declare success or produce actionable corrective feedback.

## Decision rules

If PASS:
  1. Call terminate_magician
  2. Respond with exactly: "PASS: [one-line summary of what passed]"

If FAIL:
  1. Read the full error output
  2. ALWAYS call snapshot_ui({full: false}) via agent-browser to see the current live UI state —
     this is the ground truth for what is actually on screen regardless of what the test expected
  3. Call snapshot_ui({full: true}) if you need to read exact text values or metric labels
  4. Classify the root cause:
       WRONG_LABEL   — element label in test doesn't match UI
       WRONG_NAV     — wrong screen or navigation sequence
       TIMING        — operation not finished when checked
       WRONG_ASSERT  — assertion text not present in snapshot
       DRIVE_ISSUE   — wrong drive selected or switch didn't complete
       CRASH         — app crashed or CDP lost
  4. Write workspace/feedback.md with this structure:

\`\`\`markdown
# Test Failure Feedback

## Error
[exact error from test output]

## Root Cause
[classification + explanation]

## Current UI State
[relevant snapshot lines, or "not checked"]

## Required Corrections
1. [specific fix — include step number from spec]
2. [another fix if needed]

## Do NOT change
- [things that were correct]
\`\`\`

  5. Respond with exactly: "FAIL: [RootCauseClass] — [one-line description]"

Be specific: tell the Enhancer exactly which step to fix and how.
`.trim();

async function validatorNode(state) {
  console.log('\n[Validator] Running...');

  const result = await runToolLoop(
    SYSTEM,
    'Read workspace/test_result.json. If PASS: terminate Magician and respond "PASS: ...". If FAIL: analyze, snapshot if needed, write workspace/feedback.md, respond "FAIL: ...".',
    TOOLS
  );

  console.log('[Validator] Done.');

  const verdict = result.trimStart().startsWith('PASS') ? 'PASS' : 'FAIL';

  let feedback = '';
  if (verdict === 'FAIL') {
    const fbPath = path.join(WORKSPACE_DIR, 'feedback.md');
    feedback = fs.existsSync(fbPath) ? fs.readFileSync(fbPath, 'utf8') : result;
  }

  return { verdict, feedback };
}

module.exports = { validatorNode };
