#!/usr/bin/env node
// Orchestrator — builds the LangGraph StateGraph and runs the 4-agent pipeline.
// Usage: node agents/orchestrator.js <input-file> [--retries N] [--fixes N]
//
// Graph:
//   START → enhancer → generator → validator ──PASS──→ END
//                                      │
//                                    FAIL
//                                      ↓
//                                    fixer (edits test file directly, re-runs)
//                                      │
//                           PASS ──────┤──→ END
//                           FAIL ──────┤
//                     fixerCount < maxFixes ──→ fixer (retry)
//                     fixerCount >= maxFixes ──→ enhancer (escalate with feedback)
//                     retryCount >= maxRetries ──→ END (give up)

const { StateGraph, Annotation, START, END } = require('@langchain/langgraph');
const { enhancerNode } = require('./enhancer');
const { generatorNode } = require('./generator');
const { validatorNode } = require('./validator');
const { fixerNode } = require('./fixer');
const fs = require('fs');
const path = require('path');

const DEFAULT_MAX_RETRIES = 2; // full enhancer→generator cycles after fixer gives up
const DEFAULT_MAX_FIXES   = 2; // fixer attempts per generated test

// ─── State ────────────────────────────────────────────────────────────────────

const AgentState = Annotation.Root({
  inputFile:    Annotation({ default: () => '' }),
  enhancedFile: Annotation({ default: () => '' }), // inputs/test_steps/[name]_enhanced[ext]
  feedback:     Annotation({ default: () => '' }),
  verdict:      Annotation({ default: () => '' }),
  retryCount:   Annotation({ reducer: (_, b) => b, default: () => 0 }),
  fixerCount:   Annotation({ reducer: (_, b) => b, default: () => 0 }),
  maxRetries:   Annotation({ default: () => DEFAULT_MAX_RETRIES }),
  maxFixes:     Annotation({ default: () => DEFAULT_MAX_FIXES }),
});

// ─── Routing ──────────────────────────────────────────────────────────────────

// After validator: PASS → end, FAIL → fixer
function afterValidator(state) {
  return state.verdict === 'PASS' ? 'end' : 'fix';
}

// After fixer: PASS → end, FAIL → retry fixer or escalate to enhancer or give up
function afterFixer(state) {
  if (state.verdict === 'PASS') return 'end';
  if (state.fixerCount < state.maxFixes) return 'fix';
  if (state.retryCount < state.maxRetries) return 'enhance';
  return 'end';
}

// ─── Graph ────────────────────────────────────────────────────────────────────

const graph = new StateGraph(AgentState)
  .addNode('enhancer',  enhancerNode)
  .addNode('generator', generatorNode)
  .addNode('validator', validatorNode)
  .addNode('fixer',     fixerNode)
  .addEdge(START, 'enhancer')
  .addEdge('enhancer', 'generator')
  .addEdge('generator', 'validator')
  .addConditionalEdges('validator', afterValidator, { fix: 'fixer', end: END })
  .addConditionalEdges('fixer', afterFixer, { fix: 'fixer', enhance: 'enhancer', end: END })
  .compile();

// ─── Entry point ──────────────────────────────────────────────────────────────

function parseArgs() {
  const args = process.argv.slice(2);
  let inputFile = null;
  let maxRetries = DEFAULT_MAX_RETRIES;
  let maxFixes   = DEFAULT_MAX_FIXES;
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--retries' && args[i + 1]) { maxRetries = parseInt(args[++i], 10); }
    else if (args[i] === '--fixes' && args[i + 1]) { maxFixes = parseInt(args[++i], 10); }
    else if (!args[i].startsWith('--')) { inputFile = args[i]; }
  }
  return { inputFile, maxRetries, maxFixes };
}

function resolveInput(inputFile) {
  for (const candidate of [
    inputFile,
    path.resolve(process.cwd(), inputFile),
    path.resolve(__dirname, '..', inputFile),
  ]) {
    if (candidate && fs.existsSync(candidate)) return candidate;
  }
  return null;
}

// Derives the enhanced file path from the input file:
//   inputs/test_steps/disk_partition_gpt_3_vol.txt
//   → inputs/test_steps/disk_partition_gpt_3_vol_enhanced.txt
function deriveEnhancedPath(inputFile) {
  const dir  = path.dirname(inputFile);
  const ext  = path.extname(inputFile);
  const base = path.basename(inputFile, ext);
  return path.join(dir, `${base}_enhanced${ext}`);
}

async function main() {
  if (!process.env.OPENAI_API_KEY) {
    console.error('ERROR: OPENAI_API_KEY environment variable not set');
    process.exit(1);
  }

  const { inputFile, maxRetries, maxFixes } = parseArgs();
  if (!inputFile) {
    console.error('Usage: node agents/orchestrator.js <input-file> [--retries N] [--fixes N]');
    console.error('Example: node agents/orchestrator.js inputs/example_benchmark.md');
    process.exit(1);
  }

  const resolvedInput = resolveInput(inputFile);
  if (!resolvedInput) {
    console.error(`Input file not found: ${inputFile}`);
    process.exit(1);
  }

  const enhancedFile = deriveEnhancedPath(resolvedInput);

  fs.mkdirSync(path.resolve(__dirname, '..', 'workspace'), { recursive: true });

  console.log('\n' + '═'.repeat(60));
  console.log('Samsung Magician — Agentic Test Generator (LangGraph + GPT-4o)');
  console.log(`Input:    ${resolvedInput}`);
  console.log(`Enhanced: ${enhancedFile}`);
  console.log(`Retries: up to ${maxRetries} full cycles | Fixes: up to ${maxFixes} per test`);
  console.log('═'.repeat(60));

  const finalState = await graph.invoke({
    inputFile: resolvedInput,
    enhancedFile,
    maxRetries,
    maxFixes,
  });

  console.log('\n' + '═'.repeat(60));
  if (finalState.verdict === 'PASS') {
    console.log('RESULT: PASS');
  } else {
    console.log(`RESULT: FAIL  (${finalState.retryCount} full cycle(s), ${finalState.fixerCount} fix attempt(s))`);
    console.log('Check workspace/ for intermediate files and feedback.');
  }
  console.log('═'.repeat(60) + '\n');

  process.exit(finalState.verdict === 'PASS' ? 0 : 1);
}

main().catch(err => {
  console.error('\n[Orchestrator] Fatal error:', err.message || err);
  process.exit(1);
});
