# Samsung Magician Test Automation Framework
Use playwright, agent-browser skills to automate electron framework built app: SamsungMagician.

## Samsung Magician installation path
"C:\Program Files (x86)\Samsung\Samsung Magician"\SamsungMagician.exe

## Develop framework to extract elements from Samsung Magician 
- Create Elements_Config folder and dump the configs
- Create test scripts in tests folder
- Test script can be in javascript based on PLaywright API
- Stick to Playwright API for element selection and interaction using Playwright accessibility tree
- Have sufficient logging
- Each screen will have link for other screens, drop down boxes etc identify them and have exhaustive element configuration

## NOTE
Since  we are using agent-browser mechanism, create elements config for each screen using agent-browser mechanism.
You need to decide  how you will use  agent-browser as well as elements config.
