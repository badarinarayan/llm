# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: generated_disk_partition_gpt_2_vol_enhanced.spec.js >> Disk Partition with GPT and 2 Volumes >> Partition external drive with GPT and 2 volumes
- Location: tests\generated_disk_partition_gpt_2_vol_enhanced.spec.js:11:3

# Error details

```
Error: [ab] No drive matching "Samsung Portable SSD T7USB NVMeS7MLNS0YA33966R FXG44P2QGood34℃". Selectable: SAMSUNG MZVLQ512HALU-00000NVMeS4Y4NF1MB27576      FXV7000Q--
```

# Test source

```ts
  43  |   type(text)            { return run(`keyboard type "${text}"`); },
  44  |   tab(index)            { return run(index !== undefined ? `tab ${index}` : 'tab'); },
  45  |   wait(ms)              { return run(`wait ${ms}`); },
  46  |   scroll(dir, px)       { return run(`scroll ${dir} ${px}`); },
  47  |   get(attr, ref)        { return run(`get ${attr} ${ref}`); },
  48  |   snapshotJson()        { return JSON.parse(run('snapshot --json')); },
  49  | 
  50  |   findRef(label) {
  51  |     const text = run('snapshot -i');
  52  |     const escaped = label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  53  |     const match = text.match(new RegExp(`"${escaped}"[^\\[]*\\[ref=(e\\d+)\\]`));
  54  |     if (!match) throw new Error(`[ab] No element found with label "${label}"`);
  55  |     return match[1];
  56  |   },
  57  | 
  58  |   // Returns { ref, label } for the first drive found in the live snapshot.
  59  |   // Use this instead of a stored label — drive model strings are machine-specific.
  60  |   findDrive() {
  61  |     const text = run('snapshot -i');
  62  |     for (const line of text.split('\n')) {
  63  |       const labelMatch = line.match(/"([^"]+)"/);
  64  |       const refMatch   = line.match(/\[ref=(e\d+)\]/);
  65  |       if (labelMatch && refMatch && DRIVE_RE.test(labelMatch[1])) {
  66  |         return { ref: refMatch[1], label: labelMatch[1] };
  67  |       }
  68  |     }
  69  |     throw new Error('[ab] No drive element found in snapshot');
  70  |   },
  71  | 
  72  |   clickLabel(label) {
  73  |     const ref = ab.findRef(label);
  74  |     return run(`click ${ref}`);
  75  |   },
  76  | 
  77  |   // Opens the drive selection panel by clicking the drive selector in the sidebar.
  78  |   // The panel replaces the sidebar nav links with a "Drive (N)" list of SSDs.
  79  |   // No-op if the panel is already open.
  80  |   openDrivePanel() {
  81  |     const snap = run('snapshot -i');
  82  |     if (!snap.includes('Home Dashboard')) return; // panel already open
  83  |     for (const line of snap.split('\n')) {
  84  |       const labelMatch = line.match(/"([^"]+)"/);
  85  |       const refMatch   = line.match(/\[ref=(e\d+)\]/);
  86  |       if (labelMatch && refMatch && DRIVE_RE.test(labelMatch[1])) {
  87  |         run(`click ${refMatch[1]}`);
  88  |         run('wait 600');
  89  |         return;
  90  |       }
  91  |     }
  92  |     throw new Error('[ab] Drive selector not found in sidebar');
  93  |   },
  94  | 
  95  |   // Switches the active drive. Accepts:
  96  |   //   Semantic keywords  — 'internal', 'external', 'portable', 'os', 'usb', 'nvme', 'sata'
  97  |   //   Model substrings   — 'T7', 'MZVLQ', '980 PRO' (case-insensitive, machine-specific)
  98  |   //
  99  |   // Semantic keywords classify by interface type embedded in the panel label:
  100 |   //   internal / os  → drive whose label does NOT contain 'usb' (NVMe or SATA)
  101 |   //   external / portable / usb → drive whose label contains 'usb'
  102 |   //   nvme           → internal NVMe only
  103 |   //   sata           → SATA only
  104 |   //
  105 |   // Returns silently if the target drive is already active.
  106 |   // The drive panel closes automatically after selection — no extra step needed.
  107 |   selectDrive(hint) {
  108 |     const h = hint.toLowerCase().trim();
  109 |     const predicate = DRIVE_SEMANTIC[h] ?? (l => l.toLowerCase().includes(h));
  110 | 
  111 |     // Early exit: when the panel is closed, the first DRIVE_RE match in the snapshot
  112 |     // is the active drive selector. Check it before opening the panel.
  113 |     const snapBefore = run('snapshot -i');
  114 |     if (snapBefore.includes('Home Dashboard')) {
  115 |       for (const line of snapBefore.split('\n')) {
  116 |         const lm = line.match(/"([^"]+)"/);
  117 |         const rm = line.match(/\[ref=(e\d+)\]/);
  118 |         if (lm && rm && DRIVE_RE.test(lm[1])) {
  119 |           if (predicate(lm[1])) return; // already active
  120 |           break;
  121 |         }
  122 |       }
  123 |     }
  124 | 
  125 |     ab.openDrivePanel();
  126 | 
  127 |     // In the open panel, selectable (non-active) drives have BOTH cursor:pointer and onclick.
  128 |     // The currently active drive has only onclick (no cursor:pointer) and is excluded.
  129 |     const panelSnap = run('snapshot -i');
  130 |     const candidates = [];
  131 |     for (const line of panelSnap.split('\n')) {
  132 |       const lm = line.match(/"([^"]+)"/);
  133 |       const rm = line.match(/\[ref=(e\d+)\]/);
  134 |       if (lm && rm && DRIVE_RE.test(lm[1])
  135 |           && line.includes('cursor:pointer') && line.includes('onclick')) {
  136 |         candidates.push({ ref: rm[1], label: lm[1] });
  137 |       }
  138 |     }
  139 | 
  140 |     const match = candidates.find(d => predicate(d.label));
  141 |     if (!match) {
  142 |       const names = candidates.map(d => d.label).join(' | ') || '(none — target may already be active)';
> 143 |       throw new Error(`[ab] No drive matching "${hint}". Selectable: ${names}`);
      |             ^ Error: [ab] No drive matching "Samsung Portable SSD T7USB NVMeS7MLNS0YA33966R FXG44P2QGood34℃". Selectable: SAMSUNG MZVLQ512HALU-00000NVMeS4Y4NF1MB27576      FXV7000Q--
  144 |     }
  145 | 
  146 |     run(`click ${match.ref}`);
  147 |     run('wait 800');
  148 | 
  149 |     // After selecting a drive the panel sometimes leaves the sidebar in a stuck state —
  150 |     // nav items (Home Dashboard, Disk Management, etc.) are hidden behind the drive panel.
  151 |     // Collapse the sidebar with "<" then re-expand it to force the nav to restore.
  152 |     const postSnap = run('snapshot -i');
  153 |     if (!postSnap.includes('Home Dashboard')) {
  154 |       ab.clickSidebarToggle(); // hide the stuck panel
  155 |       run('wait 600');
  156 |       ab.clickSidebarToggle(); // re-expand the sidebar
  157 |       run('wait 800');
  158 |     }
  159 |   },
  160 | 
  161 |   // Clicks the "<" / ">" sidebar collapse-expand toggle.
  162 |   // The button carries no text label, so it is identified as the first clickable
  163 |   // element whose label is empty or a single arrow character.
  164 |   clickSidebarToggle() {
  165 |     const snap = run('snapshot -i');
  166 |     for (const line of snap.split('\n')) {
  167 |       if (!line.includes('[ref=') || !line.includes('clickable')) continue;
  168 |       const labelM = line.match(/"([^"]*)"/);
  169 |       const label  = labelM ? labelM[1] : '';
  170 |       if (label === '' || label === '<' || label === '>') {
  171 |         const m = line.match(/\[ref=(e\d+)\]/);
  172 |         if (m) { run(`click ${m[1]}`); return true; }
  173 |       }
  174 |     }
  175 |     return false;
  176 |   },
  177 | };
  178 | 
  179 | module.exports = ab;
  180 | 
```