# Enhanced Test Spec: Disk Partition with GPT and Two Volumes

## Drive
- Target: external

## Steps

### Step 1: Select External SSD
- Screen: home_dashboard
- Navigation:
  1. ab.selectDrive('external')
  2. ab.wait(1000)
- Page signal: snapshot includes 'Samsung Portable SSD T7'
- Action: None
- Wait: 1000 ms
- Expected: Drive is selected and displayed as 'Samsung Portable SSD T7'

### Step 2: Navigate to Disk Partition
- Screen: disk_partition
- Navigation:
  1. ab.clickLabel('Data Management')
  2. ab.wait(1500)
  3. ab.clickLabel('Disk Partition')
  4. ab.wait(3000)
- Page signal: snapshot includes 'Disk Partition'
- Action: None
- Wait: 3000 ms
- Expected: Disk Partition screen is displayed

### Step 3: Initialize the Disk
- Screen: disk_partition
- Navigation: None
- Page signal: snapshot includes 'Initialize Disk'
- Action: ab.clickLabel('Initialize Disk')
- Wait: poll for 'Initialize Disk' step 1/2 timeout 5000 ms
- Expected: Initialize Disk wizard step 1 is displayed

### Step 4: Set Partition Table to GPT
- Screen: initialize_disk_wizard
- Navigation: None
- Page signal: snapshot includes '1/2'
- Action: ab.clickLabel('GPT')
- Wait: 500 ms
- Expected: GPT is selected as the partition table format

### Step 5: Proceed to Step 2 of Initialization
- Screen: initialize_disk_wizard
- Navigation: None
- Page signal: snapshot includes 'Next'
- Action: ab.clickLabel('Next')
- Wait: poll for '2/2' timeout 5000 ms
- Expected: Initialize Disk wizard step 2 is displayed

### Step 6: Create Two Partitions
- Screen: initialize_disk_wizard
- Navigation: None
- Page signal: snapshot includes 'Add Partition'
- Action:
  1. ab.clickLabel('Add Partition')
  2. ab.wait(1000)
  3. ab.clickLabel('Volume 1')
  4. ab.type('Volume 1')
  5. ab.clickLabel('NTFS')
  6. ab.clickLabel('Add Partition')
  7. ab.wait(1000)
  8. ab.clickLabel('Volume 2')
  9. ab.type('Volume 2')
  10. ab.clickLabel('exFAT')
- Wait: 1000 ms
- Expected: Two partitions are created with labels 'Volume 1' and 'Volume 2'

### Step 7: Start Initialization
- Screen: initialize_disk_wizard
- Navigation: None
- Page signal: snapshot includes 'Start'
- Action: ab.clickLabel('Start')
- Wait: poll for 'Initializing the disk...' timeout 10000 ms
- Expected: Disk initialization starts

### Step 8: Confirm Initialization Completion
- Screen: disk_partition
- Navigation: None
- Page signal: snapshot includes 'Initialize Disk has been completed successfully.'
- Action: ab.clickLabel('OK')
- Wait: poll for 'Scanning for drive information' timeout 5000 ms
- Expected: Disk initialization is completed and confirmed

## Assertions
- 'Samsung Portable SSD T7' must appear in snapshotFull() output
- 'Disk Partition' must appear in snapshotFull() output
- 'Initialize Disk has been completed successfully.' must appear in snapshotFull() output

## Imports
const { test, expect } = require('@playwright/test');
const magician = require('./helpers/magician');
const ab = require('./helpers/ab');
