Electron uses Chromium's **multi-process architecture** — 8 `chrome.exe` instances is completely normal.

Each process has a dedicated role:

| Process | Purpose |
|---|---|
| **Main process** | Node.js/Electron host, manages app lifecycle |
| **Renderer process** | The actual UI window (`main.html`) |
| **GPU process** | Hardware-accelerated rendering |
| **Network service** | HTTP/network stack |
| **Storage service** | IndexedDB, localStorage |
| **Audio service** | Audio rendering |
| **Utility/crash handler** | Crash reporting |
| **Plugin/webview** | Embedded frames or extensions |

This isolation is intentional — a crash in one process (e.g. the GPU process) doesn't take down the whole app.

Your CDP port `9222` only talks to the **renderer process** — the one hosting `main.html`. That's why `getMainTargetWs()` in `magician.js` filters the `/json` target list for `main.html` specifically; the other 7 processes either expose no CDP target or expose targets irrelevant to UI automation.