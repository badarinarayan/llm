const { stopMagician } = require('./tests/helpers/magician');

module.exports = async function globalTeardown() {
  stopMagician();
};
