# Launches Samsung Magician with CDP enabled so Playwright can attach.
# Run this BEFORE starting any test or agentic session.
# Samsung Magician requires elevation (Admin) — this script re-launches itself
# elevated via UAC if not already running as Administrator.
#
# Usage:
#   .\launch-magician.ps1
#   .\launch-magician.ps1 -Port 9223   # alternate port if 9222 is taken

param(
    [int]$Port = 9222
)

# Re-launch elevated if not already admin
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $isAdmin) {
    Write-Host "Not running as Administrator — requesting elevation via UAC..."
    $scriptPath = $MyInvocation.MyCommand.Path
    Start-Process powershell -Verb RunAs -ArgumentList "-ExecutionPolicy Bypass -File `"$scriptPath`" -Port $Port" -Wait
    exit
}

Write-Host "[Elevated] Running as Administrator."

$exe = "C:\Program Files (x86)\Samsung\Samsung Magician\SamsungMagician.exe"

if (-not (Test-Path $exe)) {
    Write-Error "Samsung Magician not found at: $exe"
    exit 1
}

# Kill any running instance first so we get a clean CDP session
$running = Get-Process -Name "SamsungMagician" -ErrorAction SilentlyContinue
if ($running) {
    Write-Host "Stopping existing Samsung Magician process..."
    $running | Stop-Process -Force
    Start-Sleep -Milliseconds 1500
}

Write-Host "Starting Samsung Magician on CDP port $Port ..."
Start-Process -FilePath $exe -ArgumentList "--remote-debugging-port=$Port", "--remote-debugging-address=127.0.0.1"

# Wait until CDP endpoint is reachable
$deadline = (Get-Date).AddSeconds(20)
$ready = $false
while ((Get-Date) -lt $deadline) {
    try {
        $response = Invoke-WebRequest -Uri "http://127.0.0.1:$Port/json/version" -UseBasicParsing -ErrorAction Stop
        $ready = $true
        break
    } catch {
        Start-Sleep -Milliseconds 500
    }
}

if ($ready) {
    Write-Host "CDP ready at http://127.0.0.1:$Port"
    Write-Host "Run tests with: npx playwright test"
} else {
    Write-Warning "CDP did not become ready within 20 s. The app may have launched but CDP is blocked."
    Write-Warning "Check that no firewall rule is blocking 127.0.0.1:$Port"
}
