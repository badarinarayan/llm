const { test, expect } = require('@playwright/test');
const magician = require('./helpers/magician');
const ab = require('./helpers/ab');

test.describe('Disk Partition Initialization with 2 Volumes', () => {
  test.beforeAll(async () => { await magician.startMagician(); });
  test.afterAll(() => { magician.stopMagician(); });

  test('Initialize disk with two partitions', async () => {
    // Select drive
    ab.selectDrive('external');

    // Step 1: Navigate to Disk Partition
    ab.clickLabel('Data Management');
    ab.wait(500);
    ab.clickLabel('Disk Partition');
    ab.wait(3000);

    // Verify page loaded
    let snap = ab.snapshotFull();
    expect(snap).toContain('Disk Partition');
    expect(snap).toContain('Disk Information');
    expect(snap).toContain('Partition Management');

    // Step 2: Initialize Disk
    ab.clickLabel('Initialize Disk');
    let deadline = Date.now() + 5000;
    let step1Visible = false;
    while (Date.now() < deadline) {
      ab.wait(500);
      snap = ab.snapshotFull();
      if (snap.includes('Next')) { step1Visible = true; break; }
    }
    expect(step1Visible, 'Wizard step 1/2 not visible').toBe(true);

    // Step 3: Select GPT and Proceed
    ab.clickLabel('GPT');
    ab.clickLabel('Next');
    deadline = Date.now() + 5000;
    let step2Visible = false;
    while (Date.now() < deadline) {
      ab.wait(500);
      snap = ab.snapshotFull();
      if (snap.includes('Add Partition')) { step2Visible = true; break; }
    }
    expect(step2Visible, 'Wizard step 2/2 not visible').toBe(true);

    // Step 4: Create Two Partitions
    ab.clickLabel('Add Partition');
    ab.clickLabel('Volume 1');
    ab.type('[ref=e3]', 'Volume 1');
    ab.clickLabel('NTFS');
    ab.clickLabel('Add Partition');
    ab.clickLabel('Volume 2');
    ab.type('[ref=e3]', 'Volume 2');
    ab.clickLabel('exFAT');

    // Verify partitions
    snap = ab.snapshotFull();
    expect(snap).toContain('Volume 1');
    expect(snap).toContain('NTFS');
    expect(snap).toContain('Volume 2');
    expect(snap).toContain('exFAT');

    // Step 5: Start Initialization
    ab.clickLabel('Start');
    deadline = Date.now() + 10000;
    let initializingVisible = false;
    while (Date.now() < deadline) {
      ab.wait(500);
      snap = ab.snapshotFull();
      if (snap.includes('Initializing the disk...')) { initializingVisible = true; break; }
    }
    expect(initializingVisible, 'Initialization progress not visible').toBe(true);

    // Step 6: Confirm Completion
    deadline = Date.now() + 10000;
    let completionVisible = false;
    while (Date.now() < deadline) {
      ab.wait(500);
      snap = ab.snapshotFull();
      if (snap.includes('Initialize Disk has been completed successfully.')) { completionVisible = true; break; }
    }
    expect(completionVisible, 'Initialization completion message not visible').toBe(true);
    ab.clickLabel('OK');

    // Verify new partition layout
    snap = ab.snapshotFull();
    expect(snap).toContain('Volume 1');
    expect(snap).toContain('NTFS');
    expect(snap).toContain('Volume 2');
    expect(snap).toContain('exFAT');
  });
});
