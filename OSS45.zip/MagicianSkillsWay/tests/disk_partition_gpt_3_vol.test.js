const { test, expect } = require('@playwright/test');
const { startMagician, killExisting } = require('./helpers/magician');
const ab = require('./helpers/ab');

// Init partitions 3×310 GB (includes quick-format per volume) can take 3+ min.
// Format per volume: up to 90s. Navigation overhead: ~60s. Total: ~15 min worst case.
const TC_TIMEOUT_MS     = 15 * 60 * 1000;
const INIT_TIMEOUT_MS   =  4 * 60 * 1000;
const FORMAT_TIMEOUT_MS = 90 * 1000;

const PAGE_SIGNALS = [
  'Disk Partition', 'Disk Information', 'Partition Management', 'Initialize Disk',
];

// Three volumes in the order they are created and formatted
const VOLUMES = [
  { label: 'Volume 1', fileSystem: 'NTFS'  },
  { label: 'Volume 2', fileSystem: 'exFAT' },
  { label: 'Volume 3', fileSystem: 'NTFS'  },
];

// ─── helpers ─────────────────────────────────────────────────────────────────

// Find the Nth interactive element with a given label (1-based).
// Refs in the Initialize Disk wizard shift when partition cards are added, so
// label-based discovery is used instead of hardcoded refs.
function findNthRef(label, n) {
  const text = ab.snapshot();
  const escaped = label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const re = new RegExp(`"${escaped}"[^\\[]*\\[ref=(e\\d+)\\]`, 'g');
  let match;
  let count = 0;
  while ((match = re.exec(text)) !== null) {
    if (++count === n) return match[1];
  }
  throw new Error(`findNthRef: no ${n}th element with label "${label}"`);
}

// Open a custom dropdown by ref and select an option by label.
// Samsung Magician uses React-based custom dropdowns. Options may render as
// interactive refs (best case) or as StaticText only (no ref). This helper:
//   1. Clicks the dropdown to open it and waits up to 1500ms for an interactive ref
//   2. If a ref appears, clicks it directly
//   3. Otherwise falls back to ArrowDown + Enter keyboard navigation
function selectDropdownOptionByRef(dropdownRef, targetLabel) {
  const escaped = targetLabel.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const optionRe = new RegExp(`"${escaped}"[^\\[]*\\[ref=(e\\d+)\\]`);

  for (let attempt = 0; attempt < 3; attempt++) {
    if (attempt > 0) {
      // Dismiss any notification, then wait for it to clear before reopening
      dismissAnyNotification();
      ab.wait(400);
    }

    // Open (or reopen) the dropdown
    ab.click(dropdownRef);

    // Poll up to 2000ms for the option as an interactive ref
    const deadline = Date.now() + 2000;
    while (Date.now() < deadline) {
      ab.wait(200);
      const m = ab.snapshot().match(optionRe);
      if (m) { ab.click(m[1]); ab.wait(300); return; }
    }

    // Check what's currently visible
    const fullSnap = ab.snapshotFull();
    const hasNotification = fullSnap.includes('Update your firmware') ||
                            fullSnap.includes("Don't show again");

    if (!hasNotification && fullSnap.includes(targetLabel)) {
      // Dropdown is open, option visible as StaticText only — keyboard nav
      ab.press('ArrowDown'); ab.wait(200); ab.press('Enter'); ab.wait(300);
      return;
    }

    console.log(`[dropdown] Attempt ${attempt + 1}: option "${targetLabel}" not found. notification=${hasNotification}. Retrying…`);
  }

  try { ab.screenshot('test-results/dropdown-failure.png'); } catch (_) {}
  throw new Error(`selectDropdownOptionByRef: option "${targetLabel}" not visible after opening dropdown`);
}

// Convenience wrapper: open by current label (for single dropdowns).
function selectDropdownOption(currentLabel, targetLabel) {
  selectDropdownOptionByRef(ab.findRef(currentLabel), targetLabel);
}

// Detect any Samsung Magician notification popup or unexpected modal, log its
// content, and dismiss it. Returns true if something was found and dismissed.
// Samsung Magician shows update banners (UpdateNotice) and may display
// informational popups at any time. This function is safe to call at any point
// in the test flow — it identifies and skips over expected dialogs (wizard,
// format dialog, progress states) and only acts on unexpected notifications.
function dismissAnyNotification() {
  const full = ab.snapshotFull();
  const snap = ab.snapshot();

  // ── Samsung Magician firmware update notification popup ──────────────────
  // Structure (live-confirmed): modal with X button (no label, e1) + two cards,
  // each with text "Update your firmware…" and a "Don't show again" button.
  // When active the popup covers everything — snap shows only e1-e5.
  const hasFirmwarePopup = full.includes('Update your firmware') ||
                           full.includes("Don't show again");
  if (hasFirmwarePopup) {
    const textLines = full.split('\n')
      .map(l => l.match(/StaticText "([^"]{3,})"/)?.[1])
      .filter(Boolean);
    console.log('[notification] Firmware popup detected:', textLines.slice(0, 4).join(' | '));
    try { ab.screenshot('test-results/notification-detected.png'); } catch (_) {}

    // Click "Don't show again" for each notification card (up to 4 cards).
    // This permanently suppresses the popup for future appearances.
    for (let i = 0; i < 4; i++) {
      const s = ab.snapshot();
      if (!s.includes("Don't show again")) break;
      const esc = "Don't show again".replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const m = s.match(new RegExp(`"${esc}"[^\\[]*\\[ref=(e\\d+)\\]`));
      if (!m) break;
      console.log(`[notification] Clicked "Don't show again" (${m[1]})`);
      ab.click(m[1]);
      ab.wait(400);
    }

    // Always try X button to close the popup container.
    // Clicking "Don't show again" removes the per-card buttons but the popup
    // modal stays open until the X button is explicitly clicked.
    // The X button has NO quoted label: - generic [ref=eN] clickable [cursor:pointer, onclick]
    const s2 = ab.snapshot();
    const xMatch = s2.match(/^\s*-\s+generic\s+\[ref=(e\d+)\]\s+clickable/m);
    if (xMatch) {
      console.log(`[notification] Closed via X button (${xMatch[1]})`);
      ab.click(xMatch[1]);
      ab.wait(500);
    } else {
      // X button not found in interactive snapshot — popup may already be gone,
      // or it's using a different structure. Log for diagnosis.
      console.log('[notification] X button not found in interactive snapshot after "Don\'t show again"');
    }
    return true;
  }

  // ── Samsung Magician "task delayed/failed" error popup ──────────────────
  // Shown when an operation (Init/Format) hits a background error.
  // Has an X button and a "Restart Magician" link — dismiss via X only.
  const hasTaskError = full.includes('may be delayed') ||
                       full.includes('Restart Magician');
  if (hasTaskError) {
    const textLines = full.split('\n')
      .map(l => l.match(/StaticText "([^"]{3,})"/)?.[1])
      .filter(Boolean);
    console.warn('[notification] Task error popup:', textLines.slice(0, 3).join(' | '));
    try { ab.screenshot('test-results/task-error-popup.png'); } catch (_) {}
    const s = ab.snapshot();
    const xMatch = s.match(/^\s*-\s+generic\s+\[ref=(e\d+)\]\s+clickable/m);
    if (xMatch) { ab.click(xMatch[1]); ab.wait(500); }
    return true;
  }

  // ── Generic unexpected popup (OK/Close button outside expected dialogs) ──
  // Recognise expected dialogs so we don't accidentally dismiss them
  const inWizardStep2  = snap.includes('"Add Partition"');
  const inFormatDialog = full.includes('Allocation unit') && snap.includes('"Start"');
  const inWizardStep1  = snap.includes('"Next"') && !inWizardStep2 && !inFormatDialog;
  const inProgress     = full.includes('Initializing the disk') || full.includes('Formatting the partition');
  const inExpected     = inWizardStep1 || inWizardStep2 || inFormatDialog || inProgress;

  const hasUnexpectedModal = !inExpected && (
    /"OK"[^\[]*\[ref=(e\d+)\]/.test(snap) ||
    /"Close"[^\[]*\[ref=(e\d+)\]/.test(snap)
  );
  if (!hasUnexpectedModal) return false;

  // Read: log popup content
  const textLines = full.split('\n')
    .map(l => l.match(/StaticText "([^"]{3,})"/)?.[1])
    .filter(Boolean);
  console.log('[notification] Unexpected popup:', textLines.join(' | '));
  try { ab.screenshot('test-results/notification-detected.png'); } catch (_) {}

  // Close via labeled dismiss button
  for (const label of ['OK', 'Close', 'Dismiss', 'Cancel', 'Later']) {
    const escaped = label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const m = snap.match(new RegExp(`"${escaped}"[^\\[]*\\[ref=(e\\d+)\\]`));
    if (m) {
      console.log(`[notification] Dismissed via "${label}" (${m[1]})`);
      ab.click(m[1]);
      ab.wait(500);
      return true;
    }
  }
  // Fallback: unlabeled X button
  const xMatch = snap.match(/^\s*-\s+generic\s+\[ref=(e\d+)\]\s+clickable/m);
  if (xMatch) {
    console.log(`[notification] Dismissed via X button (${xMatch[1]})`);
    ab.click(xMatch[1]);
    ab.wait(500);
    return true;
  }
  console.warn('[notification] Could not find dismiss button');
  return false;
}

// Find the first interactive element whose label contains the given substring.
// Used to select partition rows by volume label post-initialization, when rows
// are prefixed with drive letters (e.g. "D: Volume 1 310.50 GB").
function findRefContaining(substr) {
  for (const line of ab.snapshot().split('\n')) {
    if (!line.includes(substr)) continue;
    const m = line.match(/\[ref=(e\d+)\]/);
    if (m) return m[1];
  }
  return null;
}

// Block until "Scanning for drive information" clears (max 10 s).
// Disk Partition triggers a re-scan on navigation and after every operation.
function waitForScanComplete() {
  const deadline = Date.now() + 10_000;
  while (Date.now() < deadline) {
    if (!ab.snapshotFull().includes('Scanning for drive information')) return;
    ab.wait(500);
  }
  console.warn('[disk] Disk scan did not clear within 10 s');
}

// Ensure we are on the Disk Partition page with scan complete.
// Re-navigates via sidebar if we have been sent elsewhere by a popup dismiss.
function ensureDiskPartitionPage() {
  dismissAnyNotification();

  // If an init or format operation overlay is still running, wait for it to clear.
  // awaitCompletion may have timed out while the operation was still in progress.
  const opDeadline = Date.now() + 4 * 60_000;
  while (Date.now() < opDeadline) {
    const f = ab.snapshotFull();
    if (!f.includes('Initializing the disk') && !f.includes('Formatting the partition')) break;
    console.log('[disk] Operation still running — waiting…');
    dismissAnyNotification();
    ab.wait(2000);
  }

  const snap = ab.snapshotFull();
  const onPage = snap.includes('Disk Partition') && snap.includes('Disk Information');
  const scanning = snap.includes('Scanning for drive information');
  if (!onPage && !scanning) {
    console.log('[disk] Re-navigating to Disk Partition');
    ab.clickLabel('Data Management');
    ab.wait(1000);
    ab.clickLabel('Disk Partition');
    ab.wait(500);
  }
  waitForScanComplete();
}

// After clicking Start, check once for a pre-execution confirmation dialog.
// Looks for common confirm labels; clicks the first one found.
// Returns true if a confirmation was handled.
// NOTE: Exact text/button label is TBD (not triggered live during discovery).
function handleConfirmIfPresent(prefix) {
  ab.wait(500);
  const snap = ab.snapshot();
  for (const label of ['OK', 'Yes', 'Confirm']) {
    const escaped = label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const m = snap.match(new RegExp(`"${escaped}"[^\\[]*\\[ref=(e\\d+)\\]`));
    if (m) {
      console.log(`${prefix} Confirmation dialog — clicking "${label}"`);
      ab.click(m[1]);
      ab.wait(300);
      return true;
    }
  }
  console.log(`${prefix} No confirmation dialog detected`);
  return false;
}

// Poll until an operation completes (up to timeoutMs).
// Completion is detected by:
//   a) "completed successfully" / "has been completed" text  →  dismiss OK
//   b) After minWait: progressText gone + "Partition Management" back
// Returns true on success, false on timeout.
function awaitCompletion(progressText, timeoutMs, screenshotPath, prefix) {
  const deadline = Date.now() + timeoutMs;
  // Give the operation at least 3 s before considering "progress gone = done",
  // to avoid the pre-operation page state being mistaken for completion.
  const minWait  = Date.now() + 3_000;

  while (Date.now() < deadline) {
    ab.wait(1500);
    const full = ab.snapshotFull();

    // Explicit completion popup
    if (full.includes('completed successfully') || full.includes('has been completed')) {
      console.log(`${prefix} Completion popup detected`);
      if (screenshotPath) ab.screenshot(screenshotPath);
      const m = ab.snapshot().match(/"OK"[^\[]*\[ref=(e\d+)\]/);
      if (m) {
        ab.click(m[1]);
      } else {
        try { ab.clickLabel('Close'); } catch (_) {}
      }
      ab.wait(1500);
      waitForScanComplete();
      return true;
    }

    // Implicit completion: no progress indicator, normal page visible
    if (Date.now() > minWait
        && !full.includes(progressText)
        && !full.includes('Scanning for drive information')
        && full.includes('Partition Management')) {
      console.log(`${prefix} Page returned to normal — assuming operation complete`);
      return true;
    }

    // Dismiss any notification that may have appeared during the operation
    dismissAnyNotification();
  }

  console.warn(`${prefix} WARNING: completion not detected within ${timeoutMs} ms`);
  if (screenshotPath) ab.screenshot(screenshotPath.replace('.png', '-timeout.png'));
  return false;
}

// Extract a named field value from the Partition Management panel via snapshotFull().
// e.g. extractPanelField(snap, 'File system') → 'NTFS'
// Looks for a StaticText with the exact field name and returns the next StaticText.
function extractPanelField(snapshot, fieldName) {
  const lines = snapshot.split('\n');
  for (let i = 0; i < lines.length; i++) {
    // Match line that contains exactly "fieldName" as a quoted StaticText value
    if (!lines[i].includes(`"${fieldName}"`)) continue;
    // Skip lines where the match is a substring of a longer label (e.g. "Free Space (%)")
    if (lines[i].includes(`"${fieldName} `)) continue;
    for (let j = i + 1; j < Math.min(i + 5, lines.length); j++) {
      const m = lines[j].match(/StaticText "([^"]+)"/);
      if (m && m[1] !== fieldName) return m[1];
    }
  }
  return null;
}

// Click a partition row by volume label (partial match) and return snapshotFull.
// Works for both pre-init ("Partition 1…") and post-init ("D: Volume 1…") labels.
function selectVolume(volumeLabel) {
  const ref = findRefContaining(volumeLabel);
  if (!ref) throw new Error(`No interactive element found containing "${volumeLabel}"`);
  ab.click(ref);
  ab.wait(500);
  return ab.snapshotFull();
}

// ─── test ────────────────────────────────────────────────────────────────────

test.describe('Disk Partition — GPT, 3 Volumes, Format Each', () => {
  test.setTimeout(TC_TIMEOUT_MS);

  test.beforeAll(async () => { await startMagician(); });
  test.afterAll(async ()  => { await killExisting(); });

  test('initialize disk GPT with 3 volumes and format each', () => {

    // ── Step 1: Navigate to Disk Partition ──────────────────────────────────

    ab.clickLabel('Data Management');
    ab.wait(1500);
    ab.clickLabel('Disk Partition');
    ab.wait(500);
    waitForScanComplete();

    let snap = ab.snapshotFull();
    for (const signal of PAGE_SIGNALS) {
      expect(snap, `Page signal missing: "${signal}"`).toContain(signal);
    }
    console.log('[disk] Navigated — page signals confirmed');

    // ═══════════════════════════════════════════════════════════════════════
    // PHASE A — INITIALIZE DISK
    // ═══════════════════════════════════════════════════════════════════════

    // ── Step 2: Open wizard ─────────────────────────────────────────────────

    ab.clickLabel('Initialize Disk');
    ab.wait(1000);

    expect(ab.snapshotFull(), 'Initialize Disk wizard did not open').toContain('Initialize Disk');
    console.log('[init] Wizard opened — step 1/2');

    // ── Step 3: Select GPT, advance to step 2 ───────────────────────────────

    // Open the partition table format dropdown (current value = MBR) and select GPT
    dismissAnyNotification();
    selectDropdownOption('MBR', 'GPT');
    console.log('[init] Partition table format: GPT');

    dismissAnyNotification();
    ab.clickLabel('Next');
    ab.wait(500);

    expect(ab.snapshotFull(), 'Wizard step 2 not reached').toContain('Add Partition');
    console.log('[init] Step 2/2 — partition configuration panel open');

    // ── Step 4: Configure 3 partitions ──────────────────────────────────────

    // Add card 2 first, then change its file system while it's still in view.
    // Each Add Partition scrolls the list to the newest card. Changing the file
    // system immediately after adding avoids the card being scrolled out of
    // viewport — off-screen dropdowns open outside the visible area and their
    // options don't appear in the accessibility tree.
    dismissAnyNotification();
    ab.clickLabel('Add Partition');
    ab.wait(400);

    // Card 2 is now the last (visible) card — change its file system to exFAT
    dismissAnyNotification();
    const vol2FsRef = findNthRef('NTFS', 2);
    selectDropdownOptionByRef(vol2FsRef, 'exFAT');
    console.log('[init] Volume 2 file system set to exFAT');

    // Add card 3 (NTFS by default — no change needed)
    dismissAnyNotification();
    ab.clickLabel('Add Partition');
    ab.wait(400);

    const wizSnap = ab.snapshotFull();
    // Counter line: "The number of total partition: 3/4(Maximum)"
    expect(wizSnap, 'Partition counter should show 3').toContain('3');
    console.log('[init] 3 partition cards configured (Vol1=NTFS, Vol2=exFAT, Vol3=NTFS)');

    ab.screenshot('test-results/disk-partition-init-before-start.png');

    // ── Step 5: Execute initialization ──────────────────────────────────────

    // Start ref shifts between single-partition and multi-partition states.
    // With 3 cards the Start label is still unique — clickLabel is safe.
    ab.clickLabel('Start');

    // Handle the pre-execution confirmation dialog (TBD — may or may not appear)
    handleConfirmIfPresent('[init]');

    ab.wait(2000);
    ab.screenshot('test-results/disk-partition-init-progress.png');

    const initDone = awaitCompletion(
      'Initializing the disk',
      INIT_TIMEOUT_MS,
      'test-results/disk-partition-init-complete.png',
      '[init]',
    );
    if (!initDone) {
      console.warn('[init] Proceeding to post-init assertions despite completion timeout');
    }

    // ═══════════════════════════════════════════════════════════════════════
    // VERIFY POST-INITIALIZATION STATE
    // ═══════════════════════════════════════════════════════════════════════

    // ── Step 6: Assert 3 volumes on the disk ────────────────────────────────

    ensureDiskPartitionPage();

    snap = ab.snapshotFull();
    ab.screenshot('test-results/disk-partition-post-init.png');

    for (const vol of VOLUMES) {
      expect(snap, `Post-init: "${vol.label}" not found`).toContain(vol.label);
    }
    console.log('[disk] All 3 volume labels present');

    // Count distinct partition blocks in the disk visualization.
    // Pattern matches "Volume N  NNN.NN GB" in the snapshotFull text.
    const partMatches = snap.match(/Volume\s+\d+\s+[\d.]+\s*GB/g) ?? [];
    expect(partMatches.length, 'Expected exactly 3 partitions in disk visualization').toBe(3);
    console.log(`[disk] ${partMatches.length} partitions confirmed`);

    // ═══════════════════════════════════════════════════════════════════════
    // PHASE B — FORMAT EACH VOLUME
    // ═══════════════════════════════════════════════════════════════════════

    // Shared format + verify routine used for all 3 volumes.
    // After each format the page re-scans; ensureDiskPartitionPage() waits for it.
    function formatAndVerify(volumeLabel, fileSystem, screenshotPath, prefix) {
      ensureDiskPartitionPage();
      dismissAnyNotification();  // clear any popup before opening the Format dialog

      // Select the partition row by volume label (partial match handles drive-letter prefix)
      selectVolume(volumeLabel);
      console.log(`${prefix} Selected ${volumeLabel}`);

      // Open Format dialog
      ab.clickLabel('Format');
      ab.wait(600);

      // The Format dialog defaults to NTFS. Change only when exFAT is needed.
      if (fileSystem !== 'NTFS') {
        selectDropdownOption('NTFS', fileSystem);
        console.log(`${prefix} File system set to ${fileSystem}`);
      }

      ab.screenshot(screenshotPath);

      // Click Start and handle optional pre-execution confirmation
      ab.clickLabel('Start');
      handleConfirmIfPresent(prefix);
      ab.wait(1500);

      awaitCompletion(
        'Formatting the partition',
        FORMAT_TIMEOUT_MS,
        null,
        prefix,
      );

      // Verify Partition Management panel after format
      ensureDiskPartitionPage();
      const panelSnap = selectVolume(volumeLabel);

      const fs     = extractPanelField(panelSnap, 'File system');
      const status = extractPanelField(panelSnap, 'Status');
      const free   = extractPanelField(panelSnap, 'Free Space');

      console.log(`${prefix} File system=${fs} | Status=${status} | Free Space=${free}`);

      expect(fs,     `${volumeLabel}: file system mismatch`).toBe(fileSystem);
      expect(status, `${volumeLabel}: unexpected status`).toBe('Healthy (Primary Partition)');
      expect(free,   `${volumeLabel}: Free Space should not be N/A after format`).not.toBe('N/A');
    }

    // ── Step 7: Format Volume 1 (NTFS) ──────────────────────────────────────
    formatAndVerify('Volume 1', 'NTFS',  'test-results/disk-partition-format-vol1.png',       '[fmt-vol1]');

    // ── Step 8: Format Volume 2 (exFAT) ─────────────────────────────────────
    formatAndVerify('Volume 2', 'exFAT', 'test-results/disk-partition-format-vol2-exfat.png', '[fmt-vol2]');

    // ── Step 9: Format Volume 3 (NTFS) ──────────────────────────────────────
    formatAndVerify('Volume 3', 'NTFS',  'test-results/disk-partition-format-vol3.png',       '[fmt-vol3]');

    // ═══════════════════════════════════════════════════════════════════════
    // FINAL ASSERTIONS
    // ═══════════════════════════════════════════════════════════════════════

    // ── Step 10: Final state verification ───────────────────────────────────

    ensureDiskPartitionPage();
    snap = ab.snapshotFull();
    ab.screenshot('test-results/disk-partition-final-state.png');

    // 10c — exactly 3 partitions
    const finalParts = snap.match(/Volume\s+\d+\s+[\d.]+\s*GB/g) ?? [];
    expect(finalParts.length, 'Final: expected 3 partitions').toBe(3);

    // 10d — all volume labels present
    for (const vol of VOLUMES) {
      expect(snap, `Final: "${vol.label}" missing`).toContain(vol.label);
    }

    // 10h — "Create Partition" is non-interactive (no unallocated space)
    // With 3 partitions fully consuming the disk, it renders as a plain StaticText.
    const createRef = findRefContaining('Create Partition');
    expect(
      createRef,
      '"Create Partition" should have no ref (disk fully allocated)',
    ).toBeNull();

    console.log('[disk] All final assertions passed');
  });
});
