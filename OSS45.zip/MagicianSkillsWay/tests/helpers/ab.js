const { execSync } = require('child_process');

let _cdpPort = null;

// Matches any label that represents a drive entry in the sidebar/panel.
const DRIVE_RE = /samsung|ssd|nvme|mzvl|drive|disk|pm\d{3}|860|870|980|990/i;

// Semantic keywords for drive selection. The drive panel label concatenates
// model + interface type (e.g. "USB NVMe", "NVMe", "SATA") so interface-based
// substring checks are reliable classifiers across machines.
const DRIVE_SEMANTIC = {
  internal: l => !l.toLowerCase().includes('usb'),
  external: l =>  l.toLowerCase().includes('usb'),
  portable: l =>  l.toLowerCase().includes('usb'),
  os:       l => !l.toLowerCase().includes('usb'), // OS drive is always internal
  usb:      l =>  l.toLowerCase().includes('usb'),
  nvme:     l =>  l.toLowerCase().includes('nvme') && !l.toLowerCase().includes('usb'),
  sata:     l =>  l.toLowerCase().includes('sata'),
};

function setTarget(wsUrl) {
  const m = wsUrl.match(/:(\d+)\//);
  _cdpPort = m ? m[1] : '9222';
  console.log(`[ab] Target set via CDP port ${_cdpPort} (${wsUrl})`);
}

function run(cmd) {
  if (!_cdpPort) throw new Error('[ab] No target set — call ab.setTarget(wsUrl) before using ab');
  return execSync(`agent-browser --cdp ${_cdpPort} ${cmd}`, {
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
  });
}

const ab = {
  setTarget,
  snapshot()            { return run('snapshot -i'); },
  snapshotFull()        { return run('snapshot'); },
  screenshot(file)      { return run(`screenshot "${file}"`); },
  click(ref)            { return run(`click ${ref}`); },
  fill(ref, text)       { return run(`fill ${ref} "${text}"`); },
  press(key)            { return run(`press ${key}`); },
  type(text)            { return run(`keyboard type "${text}"`); },
  tab(index)            { return run(index !== undefined ? `tab ${index}` : 'tab'); },
  wait(ms)              { return run(`wait ${ms}`); },
  scroll(dir, px)       { return run(`scroll ${dir} ${px}`); },
  get(attr, ref)        { return run(`get ${attr} ${ref}`); },
  snapshotJson()        { return JSON.parse(run('snapshot --json')); },

  findRef(label) {
    const text = run('snapshot -i');
    const escaped = label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const match = text.match(new RegExp(`"${escaped}"[^\\[]*\\[ref=(e\\d+)\\]`));
    if (!match) throw new Error(`[ab] No element found with label "${label}"`);
    return match[1];
  },

  // Returns { ref, label } for the first drive found in the live snapshot.
  // Use this instead of a stored label — drive model strings are machine-specific.
  findDrive() {
    const text = run('snapshot -i');
    for (const line of text.split('\n')) {
      const labelMatch = line.match(/"([^"]+)"/);
      const refMatch   = line.match(/\[ref=(e\d+)\]/);
      if (labelMatch && refMatch && DRIVE_RE.test(labelMatch[1])) {
        return { ref: refMatch[1], label: labelMatch[1] };
      }
    }
    throw new Error('[ab] No drive element found in snapshot');
  },

  clickLabel(label) {
    const ref = ab.findRef(label);
    return run(`click ${ref}`);
  },

  // Opens the drive selection panel by clicking the drive selector in the sidebar.
  // The panel replaces the sidebar nav links with a "Drive (N)" list of SSDs.
  // No-op if the panel is already open.
  openDrivePanel() {
    const snap = run('snapshot -i');
    if (!snap.includes('Home Dashboard')) return; // panel already open
    for (const line of snap.split('\n')) {
      const labelMatch = line.match(/"([^"]+)"/);
      const refMatch   = line.match(/\[ref=(e\d+)\]/);
      if (labelMatch && refMatch && DRIVE_RE.test(labelMatch[1])) {
        run(`click ${refMatch[1]}`);
        run('wait 600');
        return;
      }
    }
    throw new Error('[ab] Drive selector not found in sidebar');
  },

  // Switches the active drive. Accepts:
  //   Semantic keywords  — 'internal', 'external', 'portable', 'os', 'usb', 'nvme', 'sata'
  //   Model substrings   — 'T7', 'MZVLQ', '980 PRO' (case-insensitive, machine-specific)
  //
  // Semantic keywords classify by interface type embedded in the panel label:
  //   internal / os  → drive whose label does NOT contain 'usb' (NVMe or SATA)
  //   external / portable / usb → drive whose label contains 'usb'
  //   nvme           → internal NVMe only
  //   sata           → SATA only
  //
  // Returns silently if the target drive is already active.
  // The drive panel closes automatically after selection — no extra step needed.
  selectDrive(hint) {
    const h = hint.toLowerCase().trim();
    const predicate = DRIVE_SEMANTIC[h] ?? (l => l.toLowerCase().includes(h));

    // Early exit: when the panel is closed, the first DRIVE_RE match in the snapshot
    // is the active drive selector. Check it before opening the panel.
    const snapBefore = run('snapshot -i');
    if (snapBefore.includes('Home Dashboard')) {
      for (const line of snapBefore.split('\n')) {
        const lm = line.match(/"([^"]+)"/);
        const rm = line.match(/\[ref=(e\d+)\]/);
        if (lm && rm && DRIVE_RE.test(lm[1])) {
          if (predicate(lm[1])) return; // already active
          break;
        }
      }
    }

    ab.openDrivePanel();

    // In the open panel, selectable (non-active) drives have BOTH cursor:pointer and onclick.
    // The currently active drive has only onclick (no cursor:pointer) and is excluded.
    const panelSnap = run('snapshot -i');
    const candidates = [];
    for (const line of panelSnap.split('\n')) {
      const lm = line.match(/"([^"]+)"/);
      const rm = line.match(/\[ref=(e\d+)\]/);
      if (lm && rm && DRIVE_RE.test(lm[1])
          && line.includes('cursor:pointer') && line.includes('onclick')) {
        candidates.push({ ref: rm[1], label: lm[1] });
      }
    }

    const match = candidates.find(d => predicate(d.label));
    if (!match) {
      const names = candidates.map(d => d.label).join(' | ') || '(none — target may already be active)';
      throw new Error(`[ab] No drive matching "${hint}". Selectable: ${names}`);
    }

    run(`click ${match.ref}`);
    run('wait 800');

    // After selecting a drive the panel sometimes leaves the sidebar in a stuck state —
    // nav items (Home Dashboard, Disk Management, etc.) are hidden behind the drive panel.
    // Collapse the sidebar with "<" then re-expand it to force the nav to restore.
    const postSnap = run('snapshot -i');
    if (!postSnap.includes('Home Dashboard')) {
      ab.clickSidebarToggle(); // hide the stuck panel
      run('wait 600');
      ab.clickSidebarToggle(); // re-expand the sidebar
      run('wait 800');
    }
  },

  // Clicks the "<" / ">" sidebar collapse-expand toggle.
  // The button carries no text label, so it is identified as the first clickable
  // element whose label is empty or a single arrow character.
  clickSidebarToggle() {
    const snap = run('snapshot -i');
    for (const line of snap.split('\n')) {
      if (!line.includes('[ref=') || !line.includes('clickable')) continue;
      const labelM = line.match(/"([^"]*)"/);
      const label  = labelM ? labelM[1] : '';
      if (label === '' || label === '<' || label === '>') {
        const m = line.match(/\[ref=(e\d+)\]/);
        if (m) { run(`click ${m[1]}`); return true; }
      }
    }
    return false;
  },
};

module.exports = ab;
