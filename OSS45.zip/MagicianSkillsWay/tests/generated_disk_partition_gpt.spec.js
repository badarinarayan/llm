const { test, expect } = require('@playwright/test');
const magician = require('./helpers/magician');
const ab = require('./helpers/ab');

test.describe('Disk Partition with GPT and Two Volumes', () => {
  test.beforeAll(async () => { await magician.startMagician(); });

  test('Partition external drive with GPT and two volumes', async () => {
    // Step 1: Select NVMe SSD
    ab.selectDrive('nvme');
    ab.wait(1000);
    let snap = ab.snapshot();
    expect(snap).toContain('SAMSUNG MZVLQ512HALU-00000--');

    // Step 2: Navigate to Disk Partition
    ab.clickLabel('Data Management');
    ab.wait(1500);
    ab.clickLabel('Disk Partition');
    ab.wait(3000);
    snap = ab.snapshot();
    expect(snap).toContain('Disk Partition');

    // Step 3: Initialize the Disk
    snap = ab.snapshot();
    expect(snap).toContain('Initialize Disk');
    ab.clickLabel('Initialize Disk');
    const deadline1 = Date.now() + 5000;
    let step1 = false;
    while (Date.now() < deadline1) {
      ab.wait(500);
      snap = ab.snapshot();
      if (snap.includes('1/2')) { step1 = true; break; }
    }
    expect(step1, 'Initialize Disk step 1 timed out').toBe(true);

    // Step 4: Set Partition Table to GPT
    ab.clickLabel('GPT');
    ab.wait(500);

    // Step 5: Proceed to Step 2 of Initialization
    ab.clickLabel('Next');
    const deadline2 = Date.now() + 5000;
    let step2 = false;
    while (Date.now() < deadline2) {
      ab.wait(500);
      snap = ab.snapshot();
      if (snap.includes('2/2')) { step2 = true; break; }
    }
    expect(step2, 'Initialize Disk step 2 timed out').toBe(true);

    // Step 6: Create Two Partitions
    ab.clickLabel('Add Partition');
    ab.wait(1000);
    ab.clickLabel('Volume 1');
    ab.type('Volume 1');
    ab.clickLabel('NTFS');
    ab.clickLabel('Add Partition');
    ab.wait(1000);
    ab.clickLabel('Volume 2');
    ab.type('Volume 2');
    ab.clickLabel('exFAT');
    ab.wait(1000);

    // Step 7: Start Initialization
    ab.clickLabel('Start');
    const deadline3 = Date.now() + 10000;
    let initializing = false;
    while (Date.now() < deadline3) {
      ab.wait(500);
      snap = ab.snapshot();
      if (snap.includes('Initializing the disk...')) { initializing = true; break; }
    }
    expect(initializing, 'Disk initialization timed out').toBe(true);

    // Step 8: Confirm Initialization Completion
    const deadline4 = Date.now() + 5000;
    let completed = false;
    while (Date.now() < deadline4) {
      ab.wait(500);
      snap = ab.snapshot();
      if (snap.includes('Initialize Disk has been completed successfully.')) { completed = true; break; }
    }
    expect(completed, 'Disk initialization completion timed out').toBe(true);
    ab.clickLabel('OK');

    // Assertions
    const full = ab.snapshotFull();
    expect(full).toContain('SAMSUNG MZVLQ512HALU-00000--');
    expect(full).toContain('Disk Partition');
    expect(full).toContain('Initialize Disk has been completed successfully.');
  });
});
