const { test, expect } = require('@playwright/test');
const magician = require('./helpers/magician');
const ab = require('./helpers/ab');

test.describe('Disk Partition with GPT and 2 Volumes', () => {
  test.beforeAll(async () => { await magician.startMagician(); });
  test.afterAll(() => { magician.stopMagician(); });

  test('Partition internal drive with GPT and 2 volumes', async () => {
    // Step 1: Select Drive
    ab.clickLabel('Data Management');
    ab.wait(1500);
    ab.clickLabel('Disk Partition');
    ab.wait(3000);
    let snap = ab.snapshotFull();
    expect(snap).toContain('Disk Partition');
    ab.selectDrive('internal');
    const deadline1 = Date.now() + 5000;
    let done1 = false;
    while (Date.now() < deadline1) {
      ab.wait(500);
      snap = ab.snapshotFull();
      if (snap.includes('Disk Information')) { done1 = true; break; }
    }
    expect(done1).toBe(true);
    expect(snap).toContain('Samsung Portable SSD T7');

    // Step 2: Initialize Disk
    ab.clickLabel('Initialize Disk');
    const deadline2 = Date.now() + 5000;
    let done2 = false;
    while (Date.now() < deadline2) {
      ab.wait(500);
      snap = ab.snapshotFull();
      if (snap.includes('1/2')) { done2 = true; break; }
    }
    expect(done2).toBe(true);

    // Step 3: Set Partition Table Format
    ab.clickLabel('GPT');
    ab.wait(500);
    snap = ab.snapshotFull();
    expect(snap).toContain('GPT');

    // Step 4: Proceed to Step 2
    ab.clickLabel('Next');
    const deadline3 = Date.now() + 5000;
    let done3 = false;
    while (Date.now() < deadline3) {
      ab.wait(500);
      snap = ab.snapshotFull();
      if (snap.includes('2/2')) { done3 = true; break; }
    }
    expect(done3).toBe(true);
    expect(snap).toContain('Add Partition');

    // Step 5: Create Partitions
    ab.clickLabel('Add Partition');
    ab.wait(500);
    ab.clickLabel('Add Partition');
    ab.wait(500);
    ab.clickLabel('Volume 1');
    ab.type('Volume 1');
    ab.clickLabel('NTFS');
    ab.clickLabel('Volume 2');
    ab.type('Volume 2');
    ab.clickLabel('exFAT');
    ab.wait(1000);
    snap = ab.snapshotFull();
    expect(snap).toContain('Volume 1');
    expect(snap).toContain('Volume 2');

    // Step 6: Start Initialization
    ab.clickLabel('Start');
    const deadline4 = Date.now() + 10000;
    let done4 = false;
    while (Date.now() < deadline4) {
      ab.wait(500);
      snap = ab.snapshotFull();
      if (snap.includes('Initialize Disk has been completed successfully.')) { done4 = true; break; }
    }
    expect(done4).toBe(true);

    // Step 7: Confirm Completion
    ab.clickLabel('OK');
    const deadline5 = Date.now() + 5000;
    let done5 = false;
    while (Date.now() < deadline5) {
      ab.wait(500);
      snap = ab.snapshotFull();
      if (snap.includes('Disk Information')) { done5 = true; break; }
    }
    expect(done5).toBe(true);
    expect(snap).toContain('Partition 1');
    expect(snap).toContain('Partition 2');
  });
});
