const { test, expect } = require('@playwright/test');
const magician = require('./helpers/magician');
const ab = require('./helpers/ab');

test.describe('Disk Partition Initialization with 2 Volumes', () => {
  test.beforeAll(async () => { await magician.startMagician(); });
  test.afterAll(() => { magician.stopMagician(); });

  test('initialize disk with 2 volumes', async () => {
    // Select drive
    ab.selectDrive('external');

    // Step 1: Navigate to Disk Partition
    ab.clickLabel('Data Management');
    ab.wait(1500);
    ab.clickLabel('Disk Partition');
    ab.wait(3000);

    // Verify page loaded
    let snap = ab.snapshotFull();
    expect(snap).toContain('Disk Partition');
    expect(snap).toContain('Disk Information');
    expect(snap).toContain('Partition Management');

    // Step 2: Initialize Disk
    ab.clickLabel('Initialize Disk');
    const deadlineStep1 = Date.now() + 5000;
    let step1Done = false;
    while (Date.now() < deadlineStep1) {
      ab.wait(500);
      snap = ab.snapshotFull();
      if (snap.includes('Next') && snap.includes('partition table format')) {
        step1Done = true;
        break;
      }
    }
    expect(step1Done, 'Initialize Disk step 1/2 timed out').toBe(true);

    // Step 3: Select GPT and Proceed
    ab.clickLabel('GPT');
    ab.clickLabel('Next');
    const deadlineStep2 = Date.now() + 5000;
    let step2Done = false;
    while (Date.now() < deadlineStep2) {
      ab.wait(500);
      snap = ab.snapshotFull();
      if (snap.includes('Add Partition')) {
        step2Done = true;
        break;
      }
    }
    expect(step2Done, 'Initialize Disk step 2/2 timed out').toBe(true);

    // Step 4: Create Two Partitions
    ab.clickLabel('Add Partition');
    ab.clickLabel('Volume 1');
    ab.clickLabel('NTFS');
    ab.clickLabel('Add Partition');
    ab.clickLabel('Volume 2');
    ab.clickLabel('exFAT');

    snap = ab.snapshotFull();
    expect(snap).toContain('Volume 1');
    expect(snap).toContain('Volume 2');

    // Step 5: Start Initialization
    ab.clickLabel('Start');
    const deadlineInit = Date.now() + 10000;
    let initDone = false;
    while (Date.now() < deadlineInit) {
      ab.wait(500);
      snap = ab.snapshotFull();
      if (snap.includes('Initialize Disk has been completed successfully.')) {
        initDone = true;
        break;
      }
    }
    expect(initDone, 'Disk initialization timed out').toBe(true);

    // Step 6: Confirm Completion
    ab.clickLabel('OK');
    const deadlineConfirm = Date.now() + 5000;
    let confirmDone = false;
    while (Date.now() < deadlineConfirm) {
      ab.wait(500);
      snap = ab.snapshotFull();
      if (!snap.includes('Initializing the disk...')) {
        confirmDone = true;
        break;
      }
    }
    expect(confirmDone, 'Confirmation timed out').toBe(true);

    // Final Assertions
    expect(snap).toContain('Volume 1');
    expect(snap).toContain('NTFS');
    expect(snap).toContain('Volume 2');
    expect(snap).toContain('exFAT');
  });
});