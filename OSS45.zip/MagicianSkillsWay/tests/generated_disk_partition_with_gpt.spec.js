const { test, expect } = require('@playwright/test');
const magician = require('./helpers/magician');
const ab = require('./helpers/ab');

test.describe('Disk Partition with GPT and Two Volumes', () => {
  test.beforeAll(async () => { await magician.startMagician(); });
  test.afterAll(() => { magician.stopMagician(); });

  test('Partition external SSD with GPT and two volumes', async () => {
    // Step 1: Select NVMe SSD
    ab.selectDrive('nvme');
    ab.wait(1000);
    let snap = ab.snapshotFull();
    expect(snap).toContain('SAMSUNG MZVLQ512HALU-00000NVMeS4Y4NF1MB27576');

    // Step 2: Navigate to Disk Partition
    ab.clickLabel('Data Management');
    ab.wait(1500);
    ab.clickLabel('Disk Partition');
    ab.wait(3000);
    snap = ab.snapshotFull();
    expect(snap).toContain('Disk Partition');

    // Step 3: Initialize the Disk
    snap = ab.snapshotFull();
    expect(snap).toContain('Initialize Disk');
    ab.clickLabel('Initialize Disk');
    const initDeadline = Date.now() + 10000;
    let initDone = false;
    while (Date.now() < initDeadline) {
      ab.wait(1000);
      snap = ab.snapshotFull();
      if (snap.includes('Initialize Disk step 2/2')) { initDone = true; break; }
    }
    expect(initDone, 'Initialize Disk step 2/2 timed out').toBe(true);

    // Step 4: Create 2 Partitions
    snap = ab.snapshotFull();
    expect(snap).toContain('Add Partition');
    ab.clickLabel('Add Partition');
    ab.wait(1000);
    ab.clickLabel('Volume 1');
    ab.type('[Volume 1 textbox]', 'Volume 1');
    ab.clickLabel('NTFS');
    ab.clickLabel('Add Partition');
    ab.wait(1000);
    ab.clickLabel('Volume 2');
    ab.type('[Volume 2 textbox]', 'Volume 2');
    ab.clickLabel('exFAT');
    ab.wait(1000);

    // Step 5: Start Initialization
    snap = ab.snapshotFull();
    expect(snap).toContain('Start');
    ab.clickLabel('Start');
    const startDeadline = Date.now() + 20000;
    let startDone = false;
    while (Date.now() < startDeadline) {
      ab.wait(1000);
      snap = ab.snapshotFull();
      if (snap.includes('Initializing the disk...')) { startDone = true; break; }
    }
    expect(startDone, 'Disk initialization timed out').toBe(true);

    // Step 6: Confirm Initialization Completion
    snap = ab.snapshotFull();
    expect(snap).toContain('Initialize Disk has been completed successfully.');
    ab.clickLabel('OK');
    ab.wait(3000);

    // Assertions
    snap = ab.snapshotFull();
    expect(snap).toContain('Disk Partition');
    expect(snap).toContain('Volume 1');
    expect(snap).toContain('Volume 2');
    expect(snap).toContain('NTFS');
    expect(snap).toContain('exFAT');
  });
});
