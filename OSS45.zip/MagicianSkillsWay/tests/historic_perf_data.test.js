const { test, expect } = require('@playwright/test');
const { startMagician, killExisting } = require('./helpers/magician');
const ab = require('./helpers/ab');

// No live benchmark run — navigation + scroll-read only
const HISTORY_TIMEOUT_MS = 90 * 1000; // extra headroom for scroll iterations
const MAX_SCROLL_ATTEMPTS = 20;        // safety cap; stops early when no new rows appear

const PAGE_SIGNALS   = ['Benchmark Test', 'History', 'Sequential Read', 'Sequential Write'];
const COLUMN_HEADERS = ['Date/Info', 'Sequential Read', 'Sequential Write', 'Random Read', 'Random Write'];

// Timestamp anchors each row: M/D/YYYY HH:MM:SS
const DATE_RE   = /(\d{1,2}\/\d{1,2}\/\d{4}\s+\d{2}:\d{2}:\d{2})/;
const MBS_RE    = /(\d+(?:\.\d+)?)\s*MB\/s/i;
const IOPS_RE   = /(\d+(?:\.\d+)?)\s*IOPS/i;
const DRIVE_RE  = /\(([^)]+)\)/;
const CONFIG_RE = /(\d+\s*(?:GB|MB))\s*[|]\s*(\d+\s*Times)/i;

// Parse the full snapshot text and return one object per history row.
// Anchors on each timestamp line; scans the following 20 lines for
// drive label, test config, and the four metric values.
// Column order in the DOM: Seq Read (1st MB/s), Seq Write (2nd MB/s),
//                          Rnd Read (1st IOPS), Rnd Write (2nd IOPS).
//
// Each row in the full snapshot has extra structural lines (generic containers
// and progress-bar ref nodes) between the date anchor and the actual metric
// values. A 20-line window safely covers all 4 metrics even when all are
// non-zero (worst case ~15 lines due to container nodes per metric).
//
// The Result section (above the History panel) also renders a timestamp when
// a benchmark has been run. Scanning starts only from the "History" heading
// line so that timestamp is never treated as a row anchor.
function extractHistoryRows(snapshot) {
  const lines = snapshot.split('\n');
  const rows  = [];

  // In the full snapshot the heading appears as:  - StaticText "History"
  // (NOT as bare "History" on its own line).
  const historyIdx = lines.findIndex(l => /StaticText\s+"History"/.test(l));
  if (historyIdx < 0) {
    console.warn('[history] Could not locate "History" heading — scanning full snapshot (result-section timestamp may produce a false row)');
  }
  const startIdx = historyIdx >= 0 ? historyIdx : 0;

  for (let i = startIdx; i < lines.length; i++) {
    const dateMatch = lines[i].match(DATE_RE);
    if (!dateMatch) continue;

    const date    = dateMatch[1];
    const window  = lines.slice(i + 1, i + 21);

    let driveLabel = null;
    let testConfig = null;
    const mbsValues  = [];
    const iopsValues = [];

    for (const line of window) {
      if (!driveLabel) {
        const m = line.match(DRIVE_RE);
        if (m) driveLabel = m[1].trim();
      }
      if (!testConfig) {
        const m = line.match(CONFIG_RE);
        if (m) testConfig = `${m[1].trim()} | ${m[2].trim()}`;
      }
      const mbsM  = line.match(MBS_RE);
      if (mbsM)  mbsValues.push(parseFloat(mbsM[1]));
      const iopsM = line.match(IOPS_RE);
      if (iopsM) iopsValues.push(parseFloat(iopsM[1]));
    }

    rows.push({
      date,
      driveLabel: driveLabel  ?? null,
      testConfig: testConfig  ?? null,
      seqRead:    mbsValues[0]  ?? null,
      seqWrite:   mbsValues[1]  ?? null,
      rndRead:    iopsValues[0] ?? null,
      rndWrite:   iopsValues[1] ?? null,
    });
  }

  return rows;
}

test.describe('Performance Benchmark — History Panel', () => {
  test.setTimeout(HISTORY_TIMEOUT_MS);

  test.beforeAll(async () => {
    await startMagician();
  });

  test.afterAll(async () => {
    await killExisting();
  });

  // Step 1: Navigate to Performance Benchmark
  // Step 2: Verify History panel present (page signals + column headers)
  // Step 3: Extract all history rows via full snapshot
  // Step 4: Assert date format, unit consistency, and non-zero metric values
  test('verify history panel and extract historical performance data', () => {
    // Step 1 — Navigate
    ab.clickLabel('Performance Management');
    ab.wait(1000);
    ab.clickLabel('Performance Benchmark');
    ab.wait(1500);

    // Step 2 — Read full DOM.
    // snapshotFull() captures StaticText nodes that are invisible to snapshot -i,
    // including all history rows regardless of whether the panel is scrolled into view.
    let snapshot = ab.snapshotFull();

    if (!snapshot.includes('History')) {
      console.log('[history] History panel not yet visible — waiting 1s and re-reading');
      ab.wait(1000);
      snapshot = ab.snapshotFull();
    }

    for (const signal of PAGE_SIGNALS) {
      expect(snapshot, `Page signal missing: "${signal}"`).toContain(signal);
    }
    console.log('[history] Page signals confirmed');

    for (const header of COLUMN_HEADERS) {
      expect(snapshot, `History column header missing: "${header}"`).toContain(header);
    }
    console.log('[history] Column headers confirmed');

    // Step 3 — Scroll through the History panel to collect every row.
    // The panel has its own scrollbar; rows below the visible area may not be
    // in the DOM snapshot until scrolled into view. A Map keyed by date
    // deduplicates rows that appear in multiple scroll positions.
    const allRowsMap = new Map();

    function collect(snap) {
      let added = 0;
      for (const row of extractHistoryRows(snap)) {
        if (!allRowsMap.has(row.date)) { allRowsMap.set(row.date, row); added++; }
      }
      return added;
    }

    collect(snapshot);
    console.log(`[history] Initial snapshot: ${allRowsMap.size} row(s)`);

    let noNewCount = 0;
    for (let i = 0; i < MAX_SCROLL_ATTEMPTS; i++) {
      ab.scroll('down', 300);
      ab.wait(500);
      const added = collect(ab.snapshotFull());
      console.log(`[history] Scroll ${i + 1}: +${added} new, ${allRowsMap.size} total`);
      if (added === 0) {
        if (++noNewCount >= 2) break; // two consecutive scrolls with nothing new = bottom reached
      } else {
        noNewCount = 0;
      }
    }

    ab.screenshot('test-results/history-panel.png');

    const rows = Array.from(allRowsMap.values());
    console.log(`[history] Collected ${rows.length} total row(s)`);

    // No rows = no prior runs within the active time-range filter ("Last 1 Month" default).
    // Not a hard failure: warn and skip metric assertions.
    if (rows.length === 0) {
      console.warn('[history] WARNING: No history rows found. Ensure at least one benchmark run exists within the selected time range.');
      return;
    }

    // Step 4 — Assert every row
    for (const row of rows) {
      console.log(
        `[history] ${row.date} | config=${row.testConfig}` +
        ` | SeqR=${row.seqRead} MB/s | SeqW=${row.seqWrite} MB/s` +
        ` | RndR=${row.rndRead} IOPS | RndW=${row.rndWrite} IOPS`
      );

      // 4a — Valid date
      expect(DATE_RE.test(row.date), `Invalid date format: "${row.date}"`).toBe(true);

      // 4b — All four metrics present
      expect(row.seqRead,  `Sequential Read missing in row ${row.date}`).not.toBeNull();
      expect(row.seqWrite, `Sequential Write missing in row ${row.date}`).not.toBeNull();
      expect(row.rndRead,  `Random Read missing in row ${row.date}`).not.toBeNull();
      expect(row.rndWrite, `Random Write missing in row ${row.date}`).not.toBeNull();

      // 4c — Floor checks: catch corrupt / partially-recorded entries.
      // Only applied to standard 1GB benchmark runs; smaller configs (e.g. 50MB | 1 Times)
      // produce legitimately lower values and are excluded from floor assertions.
      // MBS_RE and IOPS_RE are independent patterns so unit cross-contamination
      // (an IOPS value landing in seqRead) cannot happen structurally.
      const isLargeBenchmark = row.testConfig && /\d+\s*GB/i.test(row.testConfig);
      if (isLargeBenchmark) {
        expect(row.seqRead,  `Sequential Read below floor in row ${row.date}`).toBeGreaterThan(100);
        expect(row.seqWrite, `Sequential Write below floor in row ${row.date}`).toBeGreaterThan(50);
        expect(row.rndRead,  `Random Read below floor in row ${row.date}`).toBeGreaterThan(1000);
        expect(row.rndWrite, `Random Write below floor in row ${row.date}`).toBeGreaterThan(500);
      }
    }

    // 4d — Warn if rows are not newest-first (not a hard failure; flags potential UI regression)
    if (rows.length > 1) {
      const timestamps   = rows.map(r => new Date(r.date).getTime());
      const isDescending = timestamps.every((t, i) => i === 0 || t <= timestamps[i - 1]);
      if (!isDescending) {
        console.warn('[history] WARNING: History rows not in descending date order — possible UI regression.');
      }
    }
  });
});
