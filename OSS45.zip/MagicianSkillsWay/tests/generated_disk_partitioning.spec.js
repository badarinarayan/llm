const { test, expect } = require('@playwright/test');
const magician = require('./helpers/magician');
const ab = require('./helpers/ab');

test.describe('Disk Partitioning with GPT and Two Volumes', () => {
  test.beforeAll(async () => { await magician.startMagician(); });
  test.afterAll(() => { magician.stopMagician(); });

  test('Partition external drive with GPT and two volumes', async () => {
    // Step 1: Select NVMe SSD
    ab.selectDrive('nvme');
    ab.wait(1000);
    let snap = ab.snapshotFull();
    expect(snap).toContain('SAMSUNG MZVLQ512HALU-00000');
    expect(snap).toContain('S4Y4NF1MB27576');
    expect(snap).toContain('FXV7000Q');

    // Step 2: Navigate to Disk Partition
    ab.clickLabel('Data Management');
    ab.wait(500);
    ab.clickLabel('Disk Partition');
    ab.wait(3000);
    snap = ab.snapshotFull();
    expect(snap).toContain('Disk Partition');

    // Step 3: Initialize Disk
    ab.clickLabel('Initialize Disk');
    ab.wait(1000);
    snap = ab.snapshotFull();
    expect(snap).toContain('1/2');

    // Step 4: Set Partition Table to GPT
    ab.clickLabel('GPT');
    ab.wait(500);
    ab.clickLabel('Next');
    ab.wait(1000);
    snap = ab.snapshotFull();
    expect(snap).toContain('2/2');

    // Step 5: Create Two Partitions
    ab.clickLabel('Add Partition');
    ab.wait(500);
    snap = ab.snapshotFull();
    expect(snap).toContain('New Partition 2');

    // Step 6: Configure Partition 1 as NTFS
    ab.clickLabel('Volume 1');
    ab.type('[Volume 1]', 'Volume 1');
    ab.clickLabel('NTFS');
    ab.wait(500);
    snap = ab.snapshotFull();
    expect(snap).toContain('Volume 1');

    // Step 7: Configure Partition 2 as exFAT
    ab.clickLabel('Volume 2');
    ab.type('[Volume 2]', 'Volume 2');
    ab.clickLabel('exFAT');
    ab.wait(500);
    snap = ab.snapshotFull();
    expect(snap).toContain('Volume 2');

    // Step 8: Start Initialization
    ab.clickLabel('Start');
    ab.wait(1000);
    snap = ab.snapshotFull();
    expect(snap).toContain('Initializing the disk...');

    // Step 9: Confirm Initialization Completion
    const deadline = Date.now() + 10000;
    let done = false;
    while (Date.now() < deadline) {
      ab.wait(3000);
      snap = ab.snapshotFull();
      if (snap.includes('Initialize Disk has been completed successfully.')) { done = true; break; }
    }
    expect(done, 'initialization timed out').toBe(true);

    // Step 10: Close Completion Popup
    ab.clickLabel('OK');
    ab.wait(1000);
    snap = ab.snapshotFull();
    expect(snap).toContain('Disk Partition');
  });
});
