const { test, expect } = require('@playwright/test');
const { startMagician, killExisting } = require('./helpers/magician');
const ab = require('./helpers/ab');
const fs = require('fs');

test.describe('Samsung Magician — smoke', () => {
  test.beforeAll(async () => {
    await startMagician();
  });

  test.afterAll(async () => {
    await killExisting();
  });

  test('main window renders UI elements', () => {
    const snapshot = ab.snapshot();
    expect(snapshot.length).toBeGreaterThan(0);
    console.log('[snapshot]\n', snapshot.slice(0, 800));
  });

  test('screenshot main window', () => {
    fs.mkdirSync('test-results', { recursive: true });
    ab.screenshot('test-results/smoke-launch.png');
    expect(fs.existsSync('test-results/smoke-launch.png')).toBe(true);
  });

  test('list available tabs and webviews', () => {
    const tabs = ab.tab();
    console.log('[tabs]\n', tabs);
    expect(tabs.length).toBeGreaterThan(0);
  });

  test('snapshot contains drive or SSD content', () => {
    const snapshot = ab.snapshot().toLowerCase();
    const hasDriveContent =
      snapshot.includes('samsung') ||
      snapshot.includes('drive')   ||
      snapshot.includes('ssd')     ||
      snapshot.includes('nvme')    ||
      snapshot.includes('disk')    ||
      snapshot.includes('mzvl')    ||
      snapshot.includes('dashboard');
    expect(hasDriveContent).toBe(true);
  });
});
