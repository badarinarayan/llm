const { test, expect } = require('@playwright/test');
const magician = require('./helpers/magician');
const ab = require('./helpers/ab');

test.describe('Disk Partition with GPT and 2 Volumes', () => {
  test.beforeAll(async () => { 
    test.setTimeout(120000); // Set timeout for beforeAll hook
    await magician.startMagician(); 
  });

  test('Partition external drive with GPT and 2 volumes', async () => {
    // Step 1: Select External SSD
    ab.selectDrive('Samsung Portable SSD T7USB NVMeS7MLNS0YA33966R FXG44P2QGood34℃');
    ab.wait(1000);
    let snap = ab.snapshotFull();
    expect(snap).toContain('Samsung Portable SSD T7USB NVMeS7MLNS0YA33966R FXG44P2QGood34℃');
    ab.clickLabel('Samsung Portable SSD T7USB NVMeS7MLNS0YA33966R FXG44P2QGood34℃');
    const deadline1 = Date.now() + 5000;
    let done1 = false;
    while (Date.now() < deadline1) {
      ab.wait(500);
      snap = ab.snapshotFull();
      if (snap.includes('Samsung Portable SSD T7USB NVMeS7MLNS0YA33966R FXG44P2QGood34℃')) { done1 = true; break; }
    }
    expect(done1).toBe(true);

    // Step 2: Collapse Sidebar
    ab.clickLabel('Data Management');
    ab.wait(500);
    ab.clickLabel('Disk Partition');
    ab.wait(3000);
    snap = ab.snapshotFull();
    expect(snap).toContain('Disk Partition');
    ab.clickLabel('sidebar toggle');
    ab.wait(500);

    // Step 3: Navigate to Disk Partition
    ab.clickLabel('Data Management');
    ab.wait(500);
    ab.clickLabel('Disk Partition');
    ab.wait(3000);
    snap = ab.snapshotFull();
    expect(snap).toContain('Disk Partition');
    const deadline2 = Date.now() + 5000;
    let done2 = false;
    while (Date.now() < deadline2) {
      ab.wait(500);
      snap = ab.snapshotFull();
      if (snap.includes('Disk Information')) { done2 = true; break; }
    }
    expect(done2).toBe(true);

    // Step 4: Initialize the Disk
    ab.clickLabel('Initialize Disk');
    const deadline3 = Date.now() + 5000;
    let done3 = false;
    while (Date.now() < deadline3) {
      ab.wait(500);
      snap = ab.snapshotFull();
      if (snap.includes('Initialize Disk')) { done3 = true; break; }
    }
    expect(done3).toBe(true);

    // Step 5: Create 2 Partitions
    ab.clickLabel('Next');
    ab.wait(1000);
    ab.clickLabel('Add Partition');
    ab.wait(500);
    ab.fill('Volume 1', 'Volume 1');
    ab.selectOption('NTFS');
    ab.clickLabel('Add Partition');
    ab.wait(500);
    ab.fill('Volume 2', 'Volume 2');
    ab.selectOption('exFAT');
    const deadline4 = Date.now() + 5000;
    let done4 = false;
    while (Date.now() < deadline4) {
      ab.wait(500);
      snap = ab.snapshotFull();
      if (snap.includes('2/2')) { done4 = true; break; }
    }
    expect(done4).toBe(true);

    // Step 6: Start Initialization
    ab.clickLabel('Start');
    const deadline5 = Date.now() + 10000;
    let done5 = false;
    while (Date.now() < deadline5) {
      ab.wait(500);
      snap = ab.snapshotFull();
      if (snap.includes('Initializing the disk...')) { done5 = true; break; }
    }
    expect(done5).toBe(true);

    // Step 7: Confirm Initialization Completion
    const deadline6 = Date.now() + 5000;
    let done6 = false;
    while (Date.now() < deadline6) {
      ab.wait(500);
      snap = ab.snapshotFull();
      if (snap.includes('Initialize Disk has been completed successfully.')) { done6 = true; break; }
    }
    expect(done6).toBe(true);
    ab.clickLabel('OK');
    ab.wait(3000);

    // Assertions
    snap = ab.snapshotFull();
    expect(snap).toContain('Volume 1');
    expect(snap).toContain('NTFS');
    expect(snap).toContain('Volume 2');
    expect(snap).toContain('exFAT');
  });
});
