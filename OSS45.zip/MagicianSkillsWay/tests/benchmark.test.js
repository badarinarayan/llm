const { test, expect } = require('@playwright/test');
const { startMagician, killExisting } = require('./helpers/magician');
const ab = require('./helpers/ab');

// Benchmark can take several minutes on slower drives
const BENCHMARK_TIMEOUT_MS = 5 * 60 * 1000;

const METRICS = [
  'Sequential Read',
  'Sequential Write',
  'Random Read',
  'Random Write',
];

// Find the first "value unit" pair on or after the line containing metricName.
// Returns { value: number, unit: string } or null if not found within 6 lines.
function extractMetric(snapshot, metricName) {
  const lines = snapshot.split('\n');
  const nameRe = new RegExp(metricName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
  const valueRe = /\b(\d+(?:\.\d+)?)\s*(MB\/s|GB\/s|IOPS)\b/i;
  for (let i = 0; i < lines.length; i++) {
    if (!nameRe.test(lines[i])) continue;
    for (let j = i; j < Math.min(i + 6, lines.length); j++) {
      const m = lines[j].match(valueRe);
      if (m) return { value: parseFloat(m[1]), unit: m[2].toUpperCase() };
    }
  }
  return null;
}

// Poll the interactive snapshot for the completion popup.
// Returns true when "Go To Magician" is present (benchmark finished).
function isPopupVisible() {
  try {
    const snap = ab.snapshot();
    return snap.includes('Go To Magician');
  } catch {
    return false;
  }
}

test.describe('Performance Benchmark', () => {
  test.setTimeout(BENCHMARK_TIMEOUT_MS + 60_000);

  test.beforeAll(async () => {
    await startMagician();
  });

  test.afterAll(async () => {
    await killExisting();
  });

  // Step 1: Navigate to Performance Benchmark
  // Step 2: Click Start
  // Step 3: Wait for completion popup, then dismiss it
  // Steps 4-7: Verify Sequential Read/Write and Random Read/Write values
  test('run benchmark and verify read/write results', () => {
    // Navigate: top-level nav → sub-nav
    ab.clickLabel('Performance Management');
    ab.wait(1000);
    ab.clickLabel('Performance Benchmark');
    ab.wait(1500);

    // Start the benchmark
    ab.clickLabel('Start');
    console.log('[benchmark] Benchmark started, waiting for completion popup...');

    // Step 3: Poll every 5 s for the "...completed successfully" popup
    const deadline = Date.now() + BENCHMARK_TIMEOUT_MS;
    let popupSeen = false;
    while (Date.now() < deadline) {
      ab.wait(5000);
      if (isPopupVisible()) { popupSeen = true; break; }
    }

    if (popupSeen) {
      console.log('[benchmark] Popup detected. Dismissing...');
      ab.clickLabel('Go To Magician');
      ab.wait(1000);
    } else {
      console.warn('[benchmark] WARNING: Completion popup did not appear within timeout — continuing to fetch results.');
    }

    // Navigate to Performance Benchmark to read the Result section
    // (explicit navigation works whether popup dismissed us elsewhere or not)
    ab.clickLabel('Performance Management');
    ab.wait(1000);
    ab.clickLabel('Performance Benchmark');
    ab.wait(1500);

    // Read metrics from the full snapshot (StaticText nodes not in interactive snapshot)
    const snapshot = ab.snapshotFull();
    ab.screenshot('test-results/benchmark-results.png');

    // Steps 4-7: Verify each metric has a value above the baseline and the expected unit
    const EXPECTED_UNIT = {
      'Sequential Read':  'MB/S',
      'Sequential Write': 'MB/S',
      'Random Read':      'IOPS',
      'Random Write':     'IOPS',
    };
    // Baselines derived from observed run (6/10/2026): 1967 MB/s, 205 MB/s, 114013 IOPS, 30029 IOPS
    // Thresholds set at ~75% of observed to accommodate run-to-run variance.
    const MIN_THRESHOLD = {
      'Sequential Read':  1500,
      'Sequential Write': 150,
      'Random Read':      80000,
      'Random Write':     20000,
    };
    for (const metric of METRICS) {
      const result = extractMetric(snapshot, metric);
      console.log(`[benchmark] ${metric}: ${result ? `${result.value} ${result.unit}` : 'NOT FOUND'}`);
      expect(result, `${metric} not found in snapshot`).not.toBeNull();
      expect(result.value, `${metric} value should be >= ${MIN_THRESHOLD[metric]}`).toBeGreaterThanOrEqual(MIN_THRESHOLD[metric]);
      expect(result.unit, `${metric} unit mismatch`).toBe(EXPECTED_UNIT[metric]);
    }
  });
});
