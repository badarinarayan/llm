# Test: Performance Benchmark on Internal SSD

## Description
Verify the Performance Benchmark feature works correctly on the internal NVMe SSD.

## Steps
1. Launch Samsung Magician
2. Select the internal drive (not the USB external drive)
3. Navigate to Performance Benchmark
4. Start a benchmark run
5. Wait for the benchmark to finish
6. Confirm Sequential Read and Sequential Write results are displayed
