"""
agentic/state.py

LangGraph state schema for the Samsung Magician test agent.

Design notes:
  - Fields marked Annotated[List[...], operator.add] ACCUMULATE across nodes
    (each node returns only new items; LangGraph concatenates them).
  - All other list fields are REPLACED by each node that updates them.
  - Nodes that don't touch a field should omit it from their return dict.
"""

import operator
from typing import Annotated, List, Optional, TypedDict


# ── Top-level agent state ─────────────────────────────────────────────────────

class AgentState(TypedDict, total=False):
    # ── Input ─────────────────────────────────────────────────────────────────
    test_file_path: str
    raw_steps: List[str]

    # ── Parsed ────────────────────────────────────────────────────────────────
    parsed_steps: List[dict]

    # ── Execution (replaced each run cycle) ───────────────────────────────────
    step_results: List[dict]
    current_run_output: Optional[dict]

    # ── Failures & AI context (replaced each diagnosis cycle) ─────────────────
    failures: List[dict]
    qdrant_context: List[dict]

    # ── Reinspection artifacts (accumulated across all retries) ───────────────
    dom_captures: Annotated[List[dict], operator.add]
    config_patches: Annotated[List[dict], operator.add]

    # ── Control flow ──────────────────────────────────────────────────────────
    retry_count: int
    max_retries: int
    # parsing | executing | diagnosing | reinspecting | updating | success | failed
    status: str

    # ── Output ────────────────────────────────────────────────────────────────
    report: Optional[dict]

    # ── Streaming log (accumulated — nodes return only NEW lines) ─────────────
    log_messages: Annotated[List[str], operator.add]
