"""
agentic/agent.py

LangGraph StateGraph definition for the Samsung Magician test agent.

Graph topology:
  parse_steps
      │
  execute_steps ──────────────────────────────────────────┐
      │                                                    │ (retry loop)
  check_results_router                                ┌───┴───┐
   ├── "success"   → report_success → END             │ retry │
   ├── "diagnose"  → diagnose_failure                 └───────┘
   │                    │                                  ▲
   │               diagnose_router                         │
   │                ├── "reinspect"  → reinspect ──▶ update_config ─┘
   │                └── "update_config" ────────────▶ update_config ─┘
   └── "give_up"   → report_failure → END
"""

from langgraph.graph import END, StateGraph

from agentic.state import AgentState
from agentic.nodes.diagnose import diagnose_failure_node
from agentic.nodes.execute_steps import execute_steps_node
from agentic.nodes.parse_steps import parse_steps_node
from agentic.nodes.reinspect import reinspect_node
from agentic.nodes.report import report_failure_node, report_success_node
from agentic.nodes.update_config import update_config_node


# ── Router functions ──────────────────────────────────────────────────────────

def check_results_router(state: dict) -> str:
    """
    Route after execute_steps.
    - success   → report and stop
    - give_up   → max retries exhausted; report failure
    - diagnose  → still have retries left; enter failure-analysis loop
    """
    failures = [
        f for f in state.get('failures', [])
        if f.get('category') != 'cannot_automate'
    ]
    if not failures:
        return 'success'
    if state.get('retry_count', 0) >= state.get('max_retries', 3):
        return 'give_up'
    return 'diagnose'


def diagnose_router(state: dict) -> str:
    """
    Route after diagnose_failure.
    - reinspect     → at least one failure needs live DOM capture
    - update_config → all failures can be addressed without launching app
    """
    for failure in state.get('failures', []):
        if failure.get('needs_reinspect', True):
            return 'reinspect'
    return 'update_config'


# ── Retry node ────────────────────────────────────────────────────────────────

def retry_node(state: dict) -> dict:
    count = state.get('retry_count', 0) + 1
    return {
        'retry_count':  count,
        'status':       'executing',
        'log_messages': [f'\n  ── Retry {count} ──────────────────────────────────────────────\n'],
    }


# ── Build and compile the graph ───────────────────────────────────────────────

def build_agent():
    graph = StateGraph(AgentState)

    graph.add_node('parse_steps',      parse_steps_node)
    graph.add_node('execute_steps',    execute_steps_node)
    graph.add_node('diagnose_failure', diagnose_failure_node)
    graph.add_node('reinspect',        reinspect_node)
    graph.add_node('update_config',    update_config_node)
    graph.add_node('retry',            retry_node)
    graph.add_node('report_success',   report_success_node)
    graph.add_node('report_failure',   report_failure_node)

    graph.set_entry_point('parse_steps')
    graph.add_edge('parse_steps', 'execute_steps')

    graph.add_conditional_edges(
        'execute_steps',
        check_results_router,
        {
            'success':  'report_success',
            'diagnose': 'diagnose_failure',
            'give_up':  'report_failure',
        },
    )

    graph.add_conditional_edges(
        'diagnose_failure',
        diagnose_router,
        {
            'reinspect':     'reinspect',
            'update_config': 'update_config',
        },
    )

    graph.add_edge('reinspect',    'update_config')
    graph.add_edge('update_config', 'retry')
    graph.add_edge('retry',         'execute_steps')

    graph.add_edge('report_success', END)
    graph.add_edge('report_failure', END)

    return graph.compile()


# Singleton compiled agent — import this from UI / CLI
agent = build_agent()


# ── Default initial state factory ─────────────────────────────────────────────

def make_initial_state(
    raw_steps: list[str],
    test_file_path: str = '',
    max_retries: int = 3,
) -> dict:
    return {
        'test_file_path':    test_file_path,
        'raw_steps':         raw_steps,
        'parsed_steps':      [],
        'step_results':      [],
        'current_run_output': None,
        'failures':          [],
        'qdrant_context':    [],
        'dom_captures':      [],
        'config_patches':    [],
        'retry_count':       0,
        'max_retries':       max_retries,
        'status':            'starting',
        'report':            None,
        'log_messages':      [f'  Samsung Magician Test Agent\n  File: {test_file_path}\n'],
    }
