"""
agentic/ui/app.py

Streamlit dashboard for the Samsung Magician Agentic Test Agent.

Run from Administrator PowerShell (admin required — agent launches Magician):
  streamlit run agentic/ui/app.py

Layout:
  Left  (wide)   — dynamic output: live log, progress, results (empty until Create TC is clicked)
  Right (narrow) — inputs: upload test steps → sample syntax → Create TC button
"""

import json
import os
import sys
import time
from pathlib import Path

import streamlit as st

# ── Bootstrap Python path ─────────────────────────────────────────────────────
_ROOT = Path(__file__).parent.parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

# Load .env if present
try:
    from dotenv import load_dotenv
    load_dotenv(_ROOT / '.env')
except ImportError:
    pass

# ── Page config ───────────────────────────────────────────────────────────────

st.set_page_config(
    page_title='Magician Test Agent',
    page_icon='🧙',
    layout='wide',
    initial_sidebar_state='expanded',
)

# ── Session state defaults ────────────────────────────────────────────────────

if 'run_history' not in st.session_state:
    st.session_state.run_history = []
if 'last_log' not in st.session_state:
    st.session_state.last_log = []

# ── Sidebar ───────────────────────────────────────────────────────────────────

with st.sidebar:
    st.image('https://img.shields.io/badge/Samsung%20Magician-Test%20Agent-blue', use_container_width=True)
    st.title('⚙️ Configuration')

    st.subheader('🔑 API Keys')
    openai_key = st.text_input(
        'OpenAI API Key',
        type='password',
        value=os.getenv('OPENAI_API_KEY', ''),
        help='Required for GPT-4o failure diagnosis and element embeddings',
    )
    if openai_key:
        os.environ['OPENAI_API_KEY'] = openai_key

    st.subheader('🔁 Agent Settings')
    max_retries = st.slider('Max self-heal retries', min_value=1, max_value=5, value=3)

    st.divider()

    st.subheader('📚 Knowledge Base')
    st.caption('Seed ChromaDB with all Elements_Config selectors so the agent\n'
               'gets better first-pass search results.')
    if st.button('🌱 Seed Knowledge Base', use_container_width=True):
        with st.spinner('Embedding elements and uploading to ChromaDB…'):
            try:
                from agentic.tools.element_store import seed_from_configs
                count = seed_from_configs(str(_ROOT / 'Elements_Config'))
                st.success(f'✓ Seeded {count} elements')
            except Exception as exc:
                st.error(f'✗ Seed failed: {exc}')

    st.divider()
    st.caption('⚠️ Must run as **Administrator** — the agent stops the Samsung Magician service.')
    st.caption('v1.0  ·  LangGraph + ChromaDB + GPT-4o')

# ── Page header ───────────────────────────────────────────────────────────────

st.title('🧙 Samsung Magician Test Agent')
st.caption(
    'Upload a natural-language test steps file → the agent executes it, '
    'diagnoses failures, reinspects the live UI, patches element configs, and retries automatically.'
)

# ── Two-column layout: output (left) | inputs (right) ─────────────────────────
#
#   col_output  — dynamic: live log, progress bar, results tabs (fills when run starts)
#   col_inputs  — static:  upload → sample syntax → Create TC button

col_output, col_inputs = st.columns([3, 2])

# ── RIGHT column: inputs ──────────────────────────────────────────────────────

with col_inputs:
    st.subheader('📄 Upload Test Steps')
    uploaded = st.file_uploader(
        'Choose a .txt file',
        type=['txt'],
        help='One step per line.  Lines starting with # are comments.',
        label_visibility='collapsed',
    )

    content = None
    if uploaded:
        content = uploaded.read().decode('utf-8')
        st.code(content, language='text', line_numbers=True)

    st.divider()

    st.subheader('📋 Supported Step Syntax')
    st.code(
        '# Comments start with #\n'
        'navigate to performance benchmark screen\n'
        'click on Setup Benchmark\n'
        'select 512MB\n'
        'click Apply\n'
        'verify Sequential Read\n'
        'verify Random Write\n'
        'scroll down 500\n'
        'wait 2000\n',
        language='text',
    )
    st.caption(
        '**Actions:** navigate · click · verify · verify_absent · '
        'select · scroll · wait'
    )

    st.divider()

    run_disabled = content is None
    run_clicked = st.button(
        '▶  Create TC',
        type='primary',
        use_container_width=True,
        disabled=run_disabled,
        help='Upload a test steps file to enable',
    )

# ── LEFT column: dynamic output ───────────────────────────────────────────────

with col_output:

    if not uploaded:
        st.info('⬆️  Upload a test steps file on the right to get started.')

    elif not run_clicked:
        st.info('📋  File loaded. Click **Create TC** to execute.')

    else:
        # ── Run the agent ──────────────────────────────────────────────────────
        if not openai_key:
            st.warning('⚠️  No OpenAI API key — AI diagnosis will use heuristics.')

        from agentic.agent import agent, make_initial_state

        initial_state = make_initial_state(
            raw_steps=content.splitlines(),
            test_file_path=uploaded.name,
            max_retries=max_retries,
        )

        st.subheader('🔄 Live Execution')
        progress_bar  = st.progress(0, text='Starting…')
        log_container = st.empty()

        PHASE_ORDER = ['parsing', 'executing', 'diagnosing', 'reinspecting', 'updating']
        PHASE_ICON  = {
            'parsing':      '📝',
            'executing':    '▶️',
            'diagnosing':   '🔍',
            'reinspecting': '🔎',
            'updating':     '✏️',
            'success':      '✅',
            'failed':       '❌',
        }

        final_state = None
        try:
            for event in agent.stream(initial_state, stream_mode='values'):
                final_state = event
                status = event.get('status', 'starting')

                # Progress bar
                try:
                    pct = (PHASE_ORDER.index(status) + 1) / (len(PHASE_ORDER) + 1)
                except ValueError:
                    pct = 1.0
                icon = PHASE_ICON.get(status, '⏳')
                progress_bar.progress(pct, text=f'{icon}  {status.capitalize()}…')

                # Streaming log (last 60 lines)
                msgs = event.get('log_messages', [])
                log_container.code('\n'.join(msgs[-60:]), language='text')

        except Exception as run_exc:
            st.error(f'Agent error: {run_exc}')

        # ── Final results ──────────────────────────────────────────────────────
        if final_state:
            report = final_state.get('report') or {}
            status = final_state.get('status', 'unknown')

            if status == 'success':
                progress_bar.progress(1.0, text='✅  All steps passed!')
                st.success(
                    f"✅  **{report.get('passed', 0)}/{report.get('total_steps', 0)} steps passed**"
                    f"  ·  {report.get('retry_count', 0)} retrie(s)"
                    f"  ·  {report.get('config_patches', 0)} config patch(es)"
                )
            else:
                progress_bar.progress(1.0, text='❌  Completed with failures')
                p = report.get('passed', 0)
                t = report.get('total_steps', 0)
                st.error(
                    f"❌  **{t - p}/{t} steps failed**"
                    f"  ·  {report.get('retry_count', 0)} retrie(s)"
                    f"  ·  {report.get('config_patches', 0)} config patch(es)"
                )

            # Metrics row
            m1, m2, m3, m4, m5 = st.columns(5)
            m1.metric('Total Steps',    report.get('total_steps', 0))
            m2.metric('Passed',         report.get('passed', 0))
            m3.metric('Failed',         report.get('failed', 0))
            m4.metric('Retries',        report.get('retry_count', 0))
            m5.metric('Config Patches', report.get('config_patches', 0))

            # Tabs: step details | patches | full log
            tab_steps, tab_patches, tab_log = st.tabs(['📋 Step Details', '🔧 Config Patches', '📜 Full Log'])

            with tab_steps:
                step_results = final_state.get('step_results', [])
                if step_results:
                    for i, result in enumerate(step_results):
                        step   = result.get('step', {})
                        ok     = result.get('success', False)
                        action = step.get('action', '?')
                        label  = step.get('text') or step.get('to') or step.get('raw', '')
                        dur    = result.get('duration_ms', 0)
                        ico    = '✅' if ok else '❌'

                        with st.expander(f'{ico}  Step {i + 1}:  [{action}]  {label!r}  ({dur} ms)'):
                            if not ok:
                                st.error(result.get('error', 'Unknown error'))
                                snapshot = result.get('dom_snapshot')
                                if snapshot:
                                    st.caption('DOM snapshot at point of failure (first 30 nodes):')
                                    nodes = snapshot.get('text_nodes', [])[:30]
                                    rows = [
                                        f'{n["text"]!r:40s}  <{n["tag"]}>'
                                        + (f'  .{n["class"]}' if n.get('class') else '')
                                        for n in nodes
                                    ]
                                    st.code('\n'.join(rows), language='text')
                            else:
                                st.success('Step passed')
                else:
                    st.info('No step results available.')

            with tab_patches:
                patches = final_state.get('config_patches', [])
                if patches:
                    st.caption(
                        'These elements were discovered by the agent and written to '
                        'Elements_Config/*.json under the `_discovered_by_agent` group. '
                        'Review and move them to the correct named groups.'
                    )
                    for patch in patches:
                        with st.expander(f"**{patch['screen']}** → `{patch['element_key']}`"):
                            st.json(patch['element_data'])
                else:
                    st.info('No config patches were applied in this run.')

            with tab_log:
                all_msgs = final_state.get('log_messages', [])
                st.code('\n'.join(all_msgs), language='text')
                st.download_button(
                    '⬇️ Download Log',
                    data='\n'.join(all_msgs),
                    file_name=f'agent_log_{time.strftime("%Y%m%dT%H%M%S")}.txt',
                    mime='text/plain',
                )

            # Save to session history
            st.session_state.run_history.append({
                'file':   uploaded.name,
                'time':   time.strftime('%H:%M:%S'),
                'status': status,
                'report': report,
            })
            st.session_state.last_log = final_state.get('log_messages', [])

# ── Run history (full width, below both columns) ──────────────────────────────

if st.session_state.run_history:
    st.divider()
    st.subheader('📚 Session Run History')
    for run in reversed(st.session_state.run_history[-8:]):
        ico = '✅' if run['status'] == 'success' else '❌'
        r = run['report']
        st.caption(
            f'{ico}  {run["time"]}  —  **{run["file"]}**  —  '
            f'{r.get("passed", 0)}/{r.get("total_steps", 0)} passed  '
            f'({r.get("retry_count", 0)} retries, {r.get("config_patches", 0)} patches)'
        )
