"""
agentic/run.py

CLI entry point for the Samsung Magician test agent.

Usage (from Administrator PowerShell):
  python -m agentic.run inputs/test_steps/example_benchmark.txt
  python -m agentic.run inputs/test_steps/example_benchmark.txt --max-retries 5
  python -m agentic.run inputs/test_steps/example_benchmark.txt --seed-qdrant
"""

import argparse
import os
import sys
from pathlib import Path

# Load .env if present
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass


def main() -> None:
    parser = argparse.ArgumentParser(
        description='Samsung Magician Agentic Test Runner',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python -m agentic.run inputs/test_steps/example_benchmark.txt
  python -m agentic.run inputs/test_steps/my_test.txt --max-retries 5
  python -m agentic.run inputs/test_steps/my_test.txt --seed-qdrant
        """,
    )
    parser.add_argument('test_file', help='Path to the test steps .txt file')
    parser.add_argument('--max-retries', type=int, default=3,
                        help='Maximum self-heal retry attempts (default: 3)')
    parser.add_argument('--seed-qdrant', action='store_true',
                        help='Seed Qdrant from Elements_Config/ before running')
    args = parser.parse_args()

    test_path = Path(args.test_file)
    if not test_path.exists():
        print(f'\n  ERROR: Test file not found: {test_path}')
        sys.exit(1)

    raw_steps = test_path.read_text(encoding='utf-8').splitlines()

    # Optional Qdrant seeding
    if args.seed_qdrant:
        from agentic.tools.element_store import seed_from_configs
        config_dir = Path(__file__).parent.parent / 'Elements_Config'
        print(f'\n  Seeding Qdrant from {config_dir} …')
        count = seed_from_configs(str(config_dir))
        print(f'  Seeded {count} elements.\n')

    # Build initial state and run
    from agentic.agent import agent, make_initial_state

    state = make_initial_state(
        raw_steps=raw_steps,
        test_file_path=str(test_path),
        max_retries=args.max_retries,
    )

    print(f'\n  Running: {test_path.name}  (max_retries={args.max_retries})')
    print('  ─' * 40)

    final_state = None
    try:
        for event in agent.stream(state, stream_mode='values'):
            final_state = event
            # Print new log messages as they arrive
            new_msgs = event.get('log_messages', [])
            if new_msgs:
                # LangGraph streams full accumulated list; print only new tail
                # (For CLI we just reprint the last chunk — Streamlit handles this better)
                pass

    except KeyboardInterrupt:
        print('\n\n  Interrupted by user.')
        sys.exit(130)

    if final_state:
        # Print the full log
        for line in final_state.get('log_messages', []):
            print(line)

        report = final_state.get('report', {})
        status = report.get('status', 'unknown')
        passed = report.get('passed', 0)
        total  = report.get('total_steps', 0)
        patches = report.get('config_patches', 0)
        retries = report.get('retry_count', 0)

        print('  ─' * 40)
        if status == 'success':
            print(f'\n  ✅  PASSED  {passed}/{total} steps  (retries: {retries}, patches: {patches})\n')
            sys.exit(0)
        else:
            print(f'\n  ❌  FAILED  {passed}/{total} steps  (retries: {retries}, patches: {patches})\n')
            sys.exit(1)
    else:
        print('\n  ERROR: Agent produced no output.')
        sys.exit(1)


if __name__ == '__main__':
    main()
