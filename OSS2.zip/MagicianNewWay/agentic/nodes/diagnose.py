"""
agentic/nodes/diagnose.py

LangGraph node: use OpenAI GPT-4o + Qdrant to analyse failures, categorise
them, and decide whether each needs a live UI reinspection.

Falls back gracefully if:
  - OPENAI_API_KEY is not set (uses heuristic-only diagnosis)
  - Qdrant is unavailable (skips vector search, uses empty context)
"""

import json
import os

from agentic.tools.element_store import search_similar_elements


def _heuristic_diagnosis(failure: dict) -> dict:
    """Rule-based fallback when OpenAI is unavailable."""
    category = failure.get('category', 'unknown')
    step = failure.get('step', {})
    text = step.get('text') or step.get('to') or step.get('raw', '')

    if category == 'element_not_found':
        return {
            'root_cause': f'Element "{text}" was not found in the DOM.',
            'needs_reinspect': True,
            'elements_to_find': [text],
            'suggested_fix': f'Reinspect the screen/popup and confirm the visible label for "{text}".',
        }
    if category == 'page_closed':
        return {
            'root_cause': 'Samsung Magician self-quit — SVC race condition or named-pipe conflict.',
            'needs_reinspect': False,
            'elements_to_find': [],
            'suggested_fix': 'Re-run the test; the launcher will retry automatically (MAX_RETRIES=3).',
        }
    if category == 'navigation_failed':
        return {
            'root_cause': f'Sidebar label for "{text}" was not found.',
            'needs_reinspect': True,
            'elements_to_find': [text, 'Performance Management', 'System Details'],
            'suggested_fix': 'Check navigator.py SIDEBAR_LABELS mapping.',
        }
    return {
        'root_cause': f'Unexpected error: {failure.get("error", "unknown")}',
        'needs_reinspect': True,
        'elements_to_find': [text] if text else [],
        'suggested_fix': None,
    }


def _openai_diagnosis(failure: dict, similar_elements: list) -> dict:
    """Call GPT-4o to analyse a single step failure."""
    try:
        from openai import OpenAI
        client = OpenAI()
    except Exception:
        return _heuristic_diagnosis(failure)

    prompt = f"""
You are debugging a UI automation test for Samsung Magician (an Electron app on Windows).
The test uses Playwright via CDP and finds elements by visible text (no ARIA roles).

## Failed Step
{json.dumps(failure.get('step', {}), indent=2)}

## Error
{failure.get('error', 'Unknown')}

## Category (pre-classified)
{failure.get('category', 'unknown')}

## Screen where it failed
{failure.get('screen', 'unknown')}

## DOM snapshot at failure (first 30 nodes, may be empty)
{json.dumps((failure.get('dom_snapshot') or {}).get('text_nodes', [])[:30], indent=2)}

## Similar known elements from the knowledge base
{json.dumps(similar_elements[:5], indent=2)}

## Your task
Analyse this failure and return JSON with these exact keys:
- root_cause (string, 1 sentence)
- needs_reinspect (boolean — true if we should launch the app and capture the DOM)
- elements_to_find (list of strings — text labels to search for in the live UI)
- suggested_fix (string or null — corrected step text or instruction)

Important: Samsung Magician has NO native <select> elements and NO ARIA roles.
All dropdowns are custom React — clicking the visible text works for selection.
"""
    try:
        response = client.chat.completions.create(
            model='gpt-4o',
            messages=[{'role': 'user', 'content': prompt}],
            response_format={'type': 'json_object'},
            temperature=0,
        )
        return json.loads(response.choices[0].message.content)
    except Exception as exc:
        return {**_heuristic_diagnosis(failure), 'root_cause': f'OpenAI error ({exc}): ' + _heuristic_diagnosis(failure)['root_cause']}


# ── LangGraph node ────────────────────────────────────────────────────────────

def diagnose_failure_node(state: dict) -> dict:
    failures: list = state.get('failures', [])
    new_logs = ['\n  ── Diagnosing failures ──────────────────────────────────']

    has_openai = bool(os.getenv('OPENAI_API_KEY'))
    if not has_openai:
        new_logs.append('  ⚠  OPENAI_API_KEY not set — using heuristic-only diagnosis')

    all_similar: list = []
    enhanced: list = []

    for failure in failures:
        step = failure.get('step', {})
        search_text = step.get('text') or step.get('to') or step.get('raw', '')
        screen = failure.get('screen', 'unknown')

        # Qdrant search
        similar = []
        try:
            similar = search_similar_elements(search_text, screen=screen, limit=5)
            all_similar.extend(similar)
        except Exception as exc:
            new_logs.append(f'  ⚠  Qdrant unavailable ({exc}) — skipping vector search')

        # AI or heuristic analysis
        if has_openai:
            analysis = _openai_diagnosis(failure, similar)
        else:
            analysis = _heuristic_diagnosis(failure)

        enhanced_failure = {
            **failure,
            'root_cause':      analysis.get('root_cause', 'Unknown'),
            'needs_reinspect': analysis.get('needs_reinspect', True),
            'elements_to_find': analysis.get('elements_to_find', [search_text]),
            'suggested_fix':   analysis.get('suggested_fix'),
        }
        enhanced.append(enhanced_failure)

        icon = '🔎' if enhanced_failure['needs_reinspect'] else '💡'
        new_logs.append(f'  {icon}  [{failure["category"]}]  {enhanced_failure["root_cause"]}')
        if enhanced_failure.get('suggested_fix'):
            new_logs.append(f'       Fix: {enhanced_failure["suggested_fix"]}')

    new_logs.append('')

    return {
        'failures': enhanced,
        'qdrant_context': all_similar,
        'status': 'diagnosing',
        'log_messages': new_logs,
    }
