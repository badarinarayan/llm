"""
agentic/nodes/reinspect.py

LangGraph node: launch Samsung Magician, navigate to the failing screen,
optionally perform pre-actions (e.g. open a popup), and capture a DOM
snapshot for analysis.

Calls agentic_scripts/capture_dom.js as a subprocess.
Results are stored in state['dom_captures'] (accumulated) and indexed
into Qdrant so future runs benefit immediately.
"""

import json
import subprocess
from pathlib import Path

from agentic.tools.element_store import upsert_element

_CAPTURE_DOM = Path(__file__).parent.parent.parent / 'agentic_scripts' / 'capture_dom.js'


def _pre_actions_for_failure(failure: dict) -> list:
    """
    Build the pre_actions list needed to expose the DOM state where the step
    failed.  If the failing step was a click on something that would open a
    popup (e.g. "Setup Benchmark"), include a click action so the popup is
    visible in the capture.
    """
    step = failure.get('step', {})
    actions = []
    if step.get('action') == 'click':
        # Include the click so the popup / dropdown is open during capture
        actions.append({'action': 'click', 'text': step['text']})
    return actions


def reinspect_node(state: dict) -> dict:
    failures: list = state.get('failures', [])
    new_logs = ['\n  ── Reinspecting Samsung Magician UI ──────────────────────']
    new_dom_captures: list = []

    # Group failures that require reinspection by screen
    screens_to_inspect: dict = {}
    for f in failures:
        if not f.get('needs_reinspect', True):
            continue
        screen = f.get('screen', 'unknown')
        if screen not in screens_to_inspect:
            screens_to_inspect[screen] = []
        screens_to_inspect[screen].append(f)

    if not screens_to_inspect:
        new_logs.append('  No screens require reinspection.')
        return {
            'dom_captures': new_dom_captures,
            'status': 'reinspecting',
            'log_messages': new_logs,
        }

    for screen, screen_failures in screens_to_inspect.items():
        new_logs.append(f'  Inspecting screen: {screen}')

        # Collect unique pre-actions (deduplicate by text)
        seen_texts: set = set()
        pre_actions = []
        for failure in screen_failures:
            for action in _pre_actions_for_failure(failure):
                if action.get('text') not in seen_texts:
                    pre_actions.append(action)
                    seen_texts.add(action.get('text', ''))

        capture_config = {
            'screen': screen,
            'pre_actions': pre_actions,
            'popup_wait_ms': 5000,
        }

        try:
            new_logs.append(f'    Running capture_dom.js (pre_actions={len(pre_actions)})…')
            proc = subprocess.run(
                ['node', str(_CAPTURE_DOM), json.dumps(capture_config)],
                capture_output=True,
                text=True,
                timeout=180,   # 3-minute cap for launch + navigate + capture
            )

            if proc.returncode == 0 and proc.stdout.strip():
                capture_data = json.loads(proc.stdout)
                text_count = len(capture_data.get('text_nodes', []))
                ax_count   = len(capture_data.get('ax_nodes', []))
                new_logs.append(f'    ✓ Captured {text_count} text nodes, {ax_count} AX nodes')
                new_dom_captures.append({'screen': screen, 'data': capture_data})

                # Index into Qdrant for future runs
                _index_capture(capture_data, screen, new_logs)
            else:
                stderr = (proc.stderr or '')[:400]
                new_logs.append(f'    ✗ capture_dom.js failed (exit {proc.returncode}): {stderr}')

        except subprocess.TimeoutExpired:
            new_logs.append(f'    ✗ Reinspect timed out after 3 minutes for screen "{screen}"')
        except json.JSONDecodeError as exc:
            new_logs.append(f'    ✗ Invalid JSON from capture_dom.js: {exc}')
        except Exception as exc:
            new_logs.append(f'    ✗ Reinspect error: {exc}')

    new_logs.append('')
    return {
        'dom_captures': new_dom_captures,  # goes through operator.add reducer
        'status': 'reinspecting',
        'log_messages': new_logs,
    }


def _index_capture(capture_data: dict, screen: str, logs: list) -> None:
    """Upsert discovered text nodes into Qdrant."""
    text_nodes = capture_data.get('text_nodes', [])
    indexed = 0
    errors = 0

    for node in text_nodes:
        text = node.get('text', '').strip()
        if len(text) < 2:
            continue
        try:
            upsert_element({
                'screen':    screen,
                'text':      text,
                'tag':       node.get('tag', ''),
                'css_class': node.get('class', ''),
                'source':    'reinspect',
                'type':      'unknown',
            })
            indexed += 1
        except Exception:
            errors += 1

    if indexed or errors:
        msg = f'    Qdrant: indexed {indexed} nodes'
        if errors:
            msg += f', {errors} error(s)'
        logs.append(msg)
