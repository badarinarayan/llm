"""
agentic/nodes/update_config.py

LangGraph node: map each failure to a DOM element found during reinspection,
then patch the corresponding Elements_Config JSON file.

Strategy:
  1. For each failure, check the DOM captures for the screen where it failed.
  2. Use OpenAI to match the step's intent to a specific text node.
  3. Write the new element into Elements_Config/<screen>.json under the
     '_discovered_by_agent' group for human review.
  4. Falls back to Qdrant context if no DOM capture is available.
"""

import json
import os
from pathlib import Path

_CONFIG_DIR = Path(__file__).parent.parent.parent / 'Elements_Config'


def _find_dom_capture(dom_captures: list, screen: str) -> dict | None:
    for cap in reversed(dom_captures):  # most-recent first
        if cap.get('screen') == screen:
            return cap.get('data')
    return None


def _openai_match(failure: dict, text_nodes: list) -> dict | None:
    """Ask GPT-4o to match the failed step to a text node."""
    if not os.getenv('OPENAI_API_KEY'):
        return _heuristic_match(failure, text_nodes)
    try:
        from openai import OpenAI
        client = OpenAI()
    except Exception:
        return _heuristic_match(failure, text_nodes)

    step = failure.get('step', {})
    prompt = f"""
You are helping fix a UI test for Samsung Magician.

## Failed step
{json.dumps(step, indent=2)}

## Available text nodes in the live UI (first 60)
{json.dumps(text_nodes[:60], indent=2)}

Task: identify which text node the step was trying to interact with.
If found, return JSON:
{{
  "element_key": "<snake_case_name>",
  "selector_text": "<exact visible text>",
  "css_class": "<first css class if available>",
  "description": "<1-sentence description>",
  "type": "action | label | info | dropdown"
}}
If no suitable node found, return: {{"element_key": null}}
"""
    try:
        response = client.chat.completions.create(
            model='gpt-4o',
            messages=[{'role': 'user', 'content': prompt}],
            response_format={'type': 'json_object'},
            temperature=0,
        )
        return json.loads(response.choices[0].message.content)
    except Exception:
        return _heuristic_match(failure, text_nodes)


def _heuristic_match(failure: dict, text_nodes: list) -> dict | None:
    """
    Simple heuristic: look for the exact step text in the text_nodes list.
    Returns a minimal match if found.
    """
    step = failure.get('step', {})
    target = (step.get('text') or step.get('to') or '').strip().lower()
    if not target:
        return None

    for node in text_nodes:
        node_text = node.get('text', '').strip()
        if node_text.lower() == target:
            key = target.replace(' ', '_').replace('(', '').replace(')', '')
            return {
                'element_key':   key,
                'selector_text': node_text,
                'css_class':     node.get('class', ''),
                'description':   f'Auto-discovered: "{node_text}" on {failure.get("screen", "?")} screen',
                'type':          'action' if step.get('action') in ('click', 'select') else 'label',
            }

    # Partial match fallback
    for node in text_nodes:
        if target in node.get('text', '').lower():
            key = node['text'].strip().lower().replace(' ', '_')[:30]
            return {
                'element_key':   key,
                'selector_text': node['text'].strip(),
                'css_class':     node.get('class', ''),
                'description':   f'Auto-discovered (partial match): "{node["text"]}"',
                'type':          'unknown',
            }
    return None


def _patch_config(screen: str, element_key: str, element_data: dict, logs: list) -> bool:
    """Write the element into Elements_Config/<screen>.json."""
    config_path = _CONFIG_DIR / f'{screen}.json'
    if not config_path.exists():
        logs.append(f'  ✗  Config not found: {config_path.name} — cannot patch')
        return False

    with open(config_path, encoding='utf-8') as f:
        config = json.load(f)

    group_key = '_discovered_by_agent'
    if group_key not in config:
        config[group_key] = {
            '_note': 'Elements discovered by the AI agent. Review and move to correct groups.'
        }

    config[group_key][element_key] = element_data

    with open(config_path, 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=2)

    logs.append(f'  ✓  Patched {config_path.name}  →  {group_key}.{element_key}')
    return True


# ── LangGraph node ────────────────────────────────────────────────────────────

def update_config_node(state: dict) -> dict:
    failures: list  = state.get('failures', [])
    dom_captures: list = state.get('dom_captures', [])
    qdrant_context: list = state.get('qdrant_context', [])
    new_logs = ['\n  ── Updating element configs ─────────────────────────────────']
    new_patches: list = []

    if not failures:
        new_logs.append('  No failures to address.')
        return {'config_patches': new_patches, 'status': 'updating', 'log_messages': new_logs}

    for failure in failures:
        screen = failure.get('screen', 'unknown')
        step   = failure.get('step', {})
        label  = step.get('text') or step.get('to') or step.get('raw', 'unknown')
        new_logs.append(f'  Processing failure: [{step.get("action")}] "{label}" on {screen}')

        # Try DOM capture first
        capture = _find_dom_capture(dom_captures, screen)
        text_nodes = (capture or {}).get('text_nodes', [])

        if not text_nodes:
            # Fall back to Qdrant context
            new_logs.append('    No DOM capture — using Qdrant context')
            text_nodes = [
                {'text': e.get('text', ''), 'class': e.get('css_class', '')}
                for e in qdrant_context
            ]

        if not text_nodes:
            new_logs.append('    ✗  No element data available — cannot patch config')
            continue

        match = _openai_match(failure, text_nodes)
        if not match or not match.get('element_key'):
            new_logs.append(f'    ✗  Could not match "{label}" to any DOM element')
            continue

        element_data = {
            'selector':    {
                'type':  'text',
                'text':  match['selector_text'],
                'exact': True,
            },
            'description': match['description'],
            'type':        match.get('type', 'unknown'),
            'cssClass':    match.get('css_class', ''),
            '_status':     '[REVIEW] — discovered by agent, confirm before promoting',
        }

        patched = _patch_config(screen, match['element_key'], element_data, new_logs)
        if patched:
            new_patches.append({
                'screen':       screen,
                'element_key':  match['element_key'],
                'element_data': element_data,
            })

    new_logs.append(f'\n  Config patches this cycle: {len(new_patches)}\n')
    return {
        'config_patches': new_patches,   # goes through operator.add reducer
        'status': 'updating',
        'log_messages': new_logs,
    }
