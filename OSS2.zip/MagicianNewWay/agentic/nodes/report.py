"""
agentic/nodes/report.py

LangGraph nodes: build the final success/failure report.
"""

import time


def report_success_node(state: dict) -> dict:
    step_results = state.get('step_results', [])
    total   = len(step_results)
    passed  = sum(1 for r in step_results if r.get('success'))
    retries = state.get('retry_count', 0)
    patches = len(state.get('config_patches', []))

    new_logs = [
        '\n  ── Test Run Complete ─────────────────────────────────────────',
        f'  ✅  All {passed}/{total} steps PASSED',
        f'  Retries needed: {retries}',
        f'  Config patches applied: {patches}',
        '',
    ]

    report = {
        'status':          'success',
        'total_steps':     total,
        'passed':          passed,
        'failed':          0,
        'retry_count':     retries,
        'config_patches':  patches,
        'completed_at':    time.strftime('%Y-%m-%dT%H:%M:%S'),
    }

    return {
        'report':       report,
        'status':       'success',
        'log_messages': new_logs,
    }


def report_failure_node(state: dict) -> dict:
    step_results = state.get('step_results', [])
    failures     = state.get('failures', [])
    total   = len(step_results)
    passed  = sum(1 for r in step_results if r.get('success'))
    failed  = total - passed
    retries = state.get('retry_count', 0)
    patches = len(state.get('config_patches', []))

    new_logs = [
        '\n  ── Test Run Complete (with failures) ────────────────────────',
        f'  ❌  {failed}/{total} steps FAILED after {retries} retry attempt(s)',
        f'  Config patches applied: {patches}',
    ]

    for f in failures:
        step = f.get('step', {})
        label = step.get('text') or step.get('to') or step.get('raw', '?')
        new_logs.append(f'  • [{f.get("category", "?")}]  "{label}" — {f.get("root_cause") or f.get("error", "?")}')

    new_logs.append('')
    if patches:
        new_logs.append(f'  Config was updated with {patches} new element(s).')
        new_logs.append('  Re-run the test — the agent may succeed now.')
    else:
        new_logs.append('  No new elements were discovered.')
        new_logs.append('  Consider running "npm run spike:popup" manually and reviewing the output.')
    new_logs.append('')

    report = {
        'status':         'failed',
        'total_steps':    total,
        'passed':         passed,
        'failed':         failed,
        'retry_count':    retries,
        'config_patches': patches,
        'unresolved':     [
            {'step': f.get('step', {}), 'error': f.get('error'), 'category': f.get('category')}
            for f in failures
        ],
        'completed_at':   time.strftime('%Y-%m-%dT%H:%M:%S'),
    }

    return {
        'report':       report,
        'status':       'failed',
        'log_messages': new_logs,
    }
