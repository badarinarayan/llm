"""
agentic/nodes/execute_steps.py

LangGraph node: execute parsed steps via the Node.js bridge (run_steps.js).

Calls run_steps.js as a subprocess, reads its JSON output, and builds the
`failures` list from any step that did not succeed.
"""

import json
import os
import subprocess
import tempfile
from pathlib import Path

# Path to the Node.js bridge script
_BRIDGE = Path(__file__).parent.parent.parent / 'agentic_scripts' / 'run_steps.js'


def _categorise(error: str) -> str:
    e = error.lower()
    if 'not found' in e or 'could not find' in e or 'option not found' in e:
        return 'element_not_found'
    if 'page closed' in e or 'browser has been closed' in e or 'target page' in e:
        return 'page_closed'
    if 'navigation' in e or 'sidebar label' in e:
        return 'navigation_failed'
    if 'timeout' in e or 'timed out' in e:
        return 'timeout'
    return 'unknown'


def _infer_screen(steps: list, failed_index: int) -> str:
    """Walk backwards to find the most recent navigate step."""
    for i in range(failed_index - 1, -1, -1):
        if steps[i].get('action') == 'navigate':
            return steps[i].get('to', 'unknown')
    return 'unknown'


def execute_steps_node(state: dict) -> dict:
    parsed_steps: list = state.get('parsed_steps', [])
    retry_count: int = state.get('retry_count', 0)
    new_logs = [f'\n  ── Executing steps (attempt {retry_count + 1}) ────────────────────']

    # Filter out cannot_automate steps before sending to Node.js
    runnable = [s for s in parsed_steps if s.get('action') != 'cannot_automate']

    if not runnable:
        new_logs.append('  No automatable steps — skipping execution.')
        return {
            'step_results': [],
            'current_run_output': None,
            'failures': [],
            'status': 'executing',
            'log_messages': new_logs,
        }

    # Write steps to a temp file
    with tempfile.NamedTemporaryFile(
        mode='w', suffix='_steps.json', delete=False, encoding='utf-8'
    ) as f:
        json.dump({'steps': runnable}, f)
        steps_file = f.name

    output_file = steps_file.replace('_steps.json', '_output.json')

    try:
        new_logs.append(f'  Calling run_steps.js with {len(runnable)} step(s)…')
        proc = subprocess.run(
            ['node', str(_BRIDGE), steps_file, output_file],
            capture_output=True,
            text=True,
            timeout=360,     # 6-minute hard cap (launch + all steps)
        )

        if os.path.exists(output_file):
            with open(output_file, encoding='utf-8') as f:
                run_output = json.load(f)
        else:
            stderr_snippet = (proc.stderr or '')[:400]
            run_output = {
                'success': False,
                'steps': [],
                'error': f'run_steps.js produced no output file.\nstderr: {stderr_snippet}',
            }

    except subprocess.TimeoutExpired:
        run_output = {
            'success': False,
            'steps': [],
            'error': 'Execution timed out after 6 minutes',
        }
    except Exception as exc:
        run_output = {
            'success': False,
            'steps': [],
            'error': str(exc),
        }
    finally:
        for path in [steps_file, output_file]:
            try:
                os.unlink(path)
            except OSError:
                pass

    # Build step results + failures
    step_results = run_output.get('steps', [])
    failures = []

    for idx, result in enumerate(step_results):
        step = result.get('step', runnable[idx] if idx < len(runnable) else {})
        success = result.get('success', False)
        icon = '  ✓' if success else '  ✗'
        action = step.get('action', '?')
        label = step.get('text') or step.get('to') or step.get('raw', '')
        dur = result.get('duration_ms', 0)
        new_logs.append(f'{icon}  [{action}] {label!r}  ({dur} ms)')

        if not success:
            error = result.get('error', 'Unknown error')
            new_logs.append(f'       Error: {error}')
            failures.append({
                'step': step,
                'error': error,
                'category': _categorise(error),
                'screen': _infer_screen(runnable, idx),
                'needs_reinspect': None,     # set by diagnose_failure node
                'elements_to_find': [step.get('text') or step.get('to', '')],
                'suggested_fix': None,
                'root_cause': None,
                'dom_snapshot': result.get('dom_snapshot'),
            })

    # Handle launch-level error (no steps ran)
    if not step_results and run_output.get('error'):
        err = run_output['error']
        new_logs.append(f'  ✗  Launch-level error: {err}')
        failures.append({
            'step': {'action': 'launch', 'raw': 'launch samsung magician'},
            'error': err,
            'category': _categorise(err),
            'screen': 'unknown',
            'needs_reinspect': True,
            'elements_to_find': [],
            'suggested_fix': None,
            'root_cause': None,
        })

    passed = sum(1 for r in step_results if r.get('success'))
    new_logs.append(f'\n  Result: {passed}/{len(step_results)} steps passed, {len(failures)} failure(s)\n')

    return {
        'step_results': step_results,
        'current_run_output': run_output,
        'failures': failures,
        'status': 'executing',
        'log_messages': new_logs,
    }
