"""
agentic/nodes/parse_steps.py

LangGraph node: parse raw text lines → structured step dicts.

Supported actions:
  navigate to <screen> [screen]
  click [on|the] <text>          — quoted text preferred; sidebar labels auto-converted to navigate
  verify [not|absent] <text>     — quoted text preferred; noise phrases stripped
  wait <N> [ms|s]
  scroll <up|down|left|right> [N]
  select <text> [from <source>]

Robustness rules applied to every click/verify step:
  1. If the step contains quoted text ("…" or '…'), extract the quoted string as the target.
  2. Otherwise strip common preamble ("the", "that", "on") and suffix noise
     ("button", "section", "is displayed", "speed value", "(4K)", …).
  3. For click steps: if the extracted text matches a known sidebar label, emit
     a navigate action instead — sidebar items require navigateTo(), not clickText().
"""

import re
from typing import List


# ── Sidebar label → screen key map ────────────────────────────────────────────
# Checked after extracting the click target; matched text → navigate action.

_SIDEBAR_TO_SCREEN = {
    'home dashboard':         'dashboard',
    'system details':         'system_details',
    'performance management': 'performance_benchmark',
    'performance benchmark':  'performance_benchmark',
    'performance optimization': 'performance_optimization',
    'over provisioning':      'over_provisioning',
    'data migration':         'data_migration',
    'newsroom':               'newsroom',
    'help center':            'help_center',
    'chatbot':                'chatbot',
    'settings':               'settings',
}


# ── Text-extraction helpers ────────────────────────────────────────────────────

def _extract_quoted(s: str) -> str | None:
    """Return the content of the first double- or single-quoted string, or None."""
    m = re.search(r'["“”]([^"“”]+)["“”]', s)
    if m:
        return m.group(1).strip()
    m = re.search(r"'([^']+)'", s)
    if m:
        return m.group(1).strip()
    return None


def _clean_click_text(raw: str) -> str:
    """
    Given everything after 'click [on|the]', return the actual DOM text target.

    Priority:
      1. Quoted string (single or double) inside the step.
      2. Strip trailing context phrases ("button", "section", "in the sidebar", …).
    """
    quoted = _extract_quoted(raw)
    if quoted:
        return quoted

    text = raw.strip().rstrip('.')
    # Strip trailing location context: "in the left sidebar", "in the sidebar"
    text = re.sub(r'\s+in\s+(?:the\s+)?(?:left\s+|right\s+)?sidebar$', '', text, flags=re.I)
    # Strip trailing UI-type words: "button", "section", "link", "tab", "menu", "icon", "item"
    text = re.sub(r'\s+(?:button|section|link|tab|menu|icon|item|option|field|control)$', '', text, flags=re.I)
    # Strip leading article noise if it's left
    text = re.sub(r'^(?:the|a|an)\s+', '', text, flags=re.I)
    return text.strip()


def _clean_verify_text(raw: str) -> str:
    """
    Given everything after 'verify', return the actual DOM text to assert.

    Strips:
      - Leading "that", "the", "a", "an"
      - Trailing state phrases: "is displayed", "is shown", "is visible", "is present", …
      - Trailing descriptor words: "(4K)", "speed value", "value", "metric", "result", …
    """
    quoted = _extract_quoted(raw)
    if quoted:
        return quoted

    text = raw.strip().rstrip('.')

    # Strip leading preamble words
    text = re.sub(r'^(?:that|the|a|an)\s+', '', text, flags=re.I)

    # Strip trailing state phrase: "is displayed / shown / visible / present / correct / available"
    text = re.sub(
        r'\s+is\s+(?:now\s+)?(?:displayed|shown|visible|present|correct|available|enabled|disabled|active)\.?$',
        '', text, flags=re.I,
    )

    # Strip trailing parenthetical + descriptor:  "(4K) speed value"  or  "speed value"  or  "value"
    text = re.sub(
        r'\s+(?:\([^)]+\)\s+)?(?:speed\s+|performance\s+|current\s+)?'
        r'(?:value|metric|result|data|reading|count|rate|speed)$',
        '', text, flags=re.I,
    )

    # Strip any remaining trailing parenthetical: "(4K)"
    text = re.sub(r'\s+\([^)]+\)$', '', text)

    # Strip trailing single noise words that might remain
    text = re.sub(r'\s+(?:speed|performance|data|reading)$', '', text, flags=re.I)

    return text.strip()


# ── Single-line parser ────────────────────────────────────────────────────────

def _parse_one(line: str) -> dict:
    s = line.strip()

    # ── Navigate — "navigate to <screen> [screen]" ────────────────────────────
    m = re.match(r'^navigate\s+to\s+(.+?)(?:\s+screen)?$', s, re.I)
    if m:
        to = m.group(1).strip().lower().replace(' ', '_')
        return {'action': 'navigate', 'to': to, 'raw': s}

    # ── Verify absent (must precede plain verify) ─────────────────────────────
    m = re.match(
        r'^verify\s+(?:not\s+|absent\s+)?(.+?)\s+(?:is\s+)?(?:not\s+(?:present|found)|absent|gone)$',
        s, re.I,
    )
    if m:
        return {'action': 'verify_absent', 'text': _clean_verify_text(m.group(1)), 'raw': s}

    # ── Verify ────────────────────────────────────────────────────────────────
    m = re.match(r'^verify\s+(.+)$', s, re.I)
    if m:
        text = _clean_verify_text(m.group(1))
        return {'action': 'verify', 'text': text, 'raw': s}

    # ── Click — "click [on|the] <target>" ────────────────────────────────────
    m = re.match(r'^click\s+(?:(?:the|on)\s+)?(.+)$', s, re.I)
    if m:
        text = _clean_click_text(m.group(1))

        # Auto-convert to navigate when text matches a known sidebar label
        screen = _SIDEBAR_TO_SCREEN.get(text.lower())
        if screen:
            return {'action': 'navigate', 'to': screen, 'raw': s, '_converted_from': 'click'}

        return {'action': 'click', 'text': text, 'raw': s}

    # ── Wait — "wait 500 [ms|s|…]" ────────────────────────────────────────────
    m = re.match(r'^wait\s+(\d+)\s*(?:ms|milliseconds?|s|seconds?)?$', s, re.I)
    if m:
        raw_n = int(m.group(1))
        # Heuristic: values ≤ 60 with 's' unit → seconds; else treat as ms
        ms = raw_n * 1000 if raw_n <= 60 and 's' in s.lower() else raw_n
        return {'action': 'wait', 'timeout': ms, 'raw': s}

    # ── Scroll — "scroll up|down|left|right [N]" ─────────────────────────────
    m = re.match(r'^scroll\s+(up|down|left|right)(?:\s+(\d+))?$', s, re.I)
    if m:
        return {
            'action':    'scroll',
            'direction': m.group(1).lower(),
            'amount':    int(m.group(2) or 300),
            'raw':       s,
        }

    # ── Select — "select <text> [from <dropdown>]" ────────────────────────────
    m = re.match(r'^select\s+(.+?)(?:\s+from\s+.+)?$', s, re.I)
    if m:
        return {'action': 'select', 'text': m.group(1).strip(), 'raw': s}

    return {'action': 'cannot_automate', 'raw': s}


# ── LangGraph node ────────────────────────────────────────────────────────────

def parse_steps_node(state: dict) -> dict:
    raw_steps: List[str] = state.get('raw_steps', [])
    new_logs = ['\n  ── Parsing test steps ─────────────────────────────']

    parsed = []
    for line in raw_steps:
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        step = _parse_one(line)
        parsed.append(step)

        icon = '✓' if step['action'] != 'cannot_automate' else '✗'
        # Show extracted text/target alongside the raw line for transparency
        detail = ''
        if step['action'] in ('click', 'verify', 'verify_absent', 'select'):
            detail = f'  →  text="{step["text"]}"'
        elif step['action'] == 'navigate':
            conv = '  [sidebar→navigate]' if step.get('_converted_from') == 'click' else ''
            detail = f'  →  screen="{step["to"]}"{conv}'
        new_logs.append(f'  {icon}  [{step["action"]:20s}]  {line}{detail}')

    cannot = [s for s in parsed if s['action'] == 'cannot_automate']
    if cannot:
        new_logs.append(f'\n  ⚠  {len(cannot)} step(s) cannot be automated and will be skipped')

    automatable = [s for s in parsed if s['action'] != 'cannot_automate']
    new_logs.append(f'  Total automatable steps: {len(automatable)}/{len(parsed)}\n')

    return {
        'parsed_steps': parsed,
        'status': 'parsing',
        'log_messages': new_logs,
    }
