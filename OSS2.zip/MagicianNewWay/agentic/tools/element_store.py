"""
agentic/tools/element_store.py

ChromaDB vector store for Samsung Magician UI elements.

ChromaDB runs in-process and persists to a local folder (chroma_db/ in the
project root) — no server, no Docker, no config required.

Embeddings:
  - If OPENAI_API_KEY is set: uses text-embedding-3-small via ChromaDB's
    OpenAI embedding function (best quality, same model as the GPT-4o calls).
  - Otherwise: falls back to ChromaDB's built-in default embedding function
    (all-MiniLM-L6-v2 via onnxruntime — no API key needed, runs locally).

Collection: magician_elements
  document  = "<visible text> <description> <css_class>"  (what gets embedded)
  metadata  = { screen, element_key, text, description, css_class,
                selector_type, type, source }
  id        = deterministic string so re-seeding doesn't duplicate config entries
"""

import json
import os
from pathlib import Path
from typing import Optional

COLLECTION   = 'magician_elements'
_DB_PATH     = str(Path(__file__).parent.parent.parent / 'chroma_db')

_client     = None
_collection = None


def _get_collection():
    global _client, _collection
    if _collection is not None:
        return _collection

    import chromadb

    # Choose embedding function
    if os.getenv('OPENAI_API_KEY'):
        from chromadb.utils.embedding_functions import OpenAIEmbeddingFunction
        emb_fn = OpenAIEmbeddingFunction(
            api_key=os.getenv('OPENAI_API_KEY'),
            model_name='text-embedding-3-small',
        )
    else:
        # Built-in: small ONNX model, no API key, ~80 MB download on first use
        from chromadb.utils.embedding_functions import DefaultEmbeddingFunction
        emb_fn = DefaultEmbeddingFunction()

    _client     = chromadb.PersistentClient(path=_DB_PATH)
    _collection = _client.get_or_create_collection(
        name=COLLECTION,
        embedding_function=emb_fn,
        metadata={'hnsw:space': 'cosine'},
    )
    return _collection


def _make_document(element: dict) -> str:
    """Concatenate the fields that should be embedded."""
    return ' '.join(filter(None, [
        element.get('text', ''),
        element.get('description', ''),
        element.get('css_class', ''),
    ]))


def _make_id(element: dict) -> str:
    """
    Deterministic ID so re-seeding config elements doesn't create duplicates.
    Config elements: screen + element_key
    Reinspect discoveries: screen + text + source
    """
    screen = element.get('screen', 'unknown')
    if element.get('element_key'):
        return f"{screen}__{element['element_key']}"
    text = element.get('text', '').strip().lower().replace(' ', '_')[:40]
    source = element.get('source', 'unknown')
    return f"{screen}__{source}__{text}"


# ── Public API ────────────────────────────────────────────────────────────────

def upsert_element(element: dict) -> bool:
    """
    Store or update a UI element in ChromaDB.

    element keys (all optional except 'text'):
      screen, element_key, text, description, css_class,
      selector_type, type, source
    """
    try:
        col = _get_collection()
        doc = _make_document(element)
        if not doc.strip():
            return False

        col.upsert(
            ids=[_make_id(element)],
            documents=[doc],
            metadatas=[{k: str(v) for k, v in element.items() if v is not None}],
        )
        return True
    except Exception as exc:
        print(f'[element_store] upsert error: {exc}')
        return False


def search_similar_elements(query: str, screen: Optional[str] = None, limit: int = 5) -> list:
    """
    Return up to `limit` elements whose embeddings are closest to `query`.
    Optionally filter by screen.
    Returns [] on any error.
    """
    if not query.strip():
        return []
    try:
        col = _get_collection()

        where = {'screen': screen} if screen else None

        results = col.query(
            query_texts=[query],
            n_results=min(limit, col.count() or 1),
            where=where,
        )

        out = []
        for i, doc_id in enumerate(results['ids'][0]):
            meta  = (results['metadatas'][0][i] or {})
            dist  = results['distances'][0][i]          # cosine distance (0=identical)
            score = round(1 - dist, 4)                  # convert to similarity
            out.append({'score': score, **meta})
        return out

    except Exception as exc:
        print(f'[element_store] search error: {exc}')
        return []


def seed_from_configs(config_dir: str) -> int:
    """
    Seed ChromaDB from all Elements_Config/*.json files.

    Uses deterministic IDs so this is safe to call multiple times —
    existing config entries are updated in place (upsert), not duplicated.
    Returns the number of elements processed.
    """
    total = 0
    config_path = Path(config_dir)

    for json_file in sorted(config_path.glob('*.json')):
        screen = json_file.stem
        try:
            with open(json_file, encoding='utf-8') as f:
                config = json.load(f)
        except Exception as exc:
            print(f'[element_store] Could not read {json_file.name}: {exc}')
            continue

        for group_name, group in config.items():
            if not isinstance(group, dict) or group_name.startswith('_'):
                continue
            for element_key, element in group.items():
                if not isinstance(element, dict) or element_key.startswith('_'):
                    continue
                selector = element.get('selector', {})
                ok = upsert_element({
                    'screen':        screen,
                    'element_key':   element_key,
                    'text':          selector.get('text', ''),
                    'description':   element.get('description', ''),
                    'css_class':     element.get('cssClass', ''),
                    'selector_type': selector.get('type', ''),
                    'type':          element.get('type', ''),
                    'source':        'config',
                })
                if ok:
                    total += 1

    print(f'[element_store] Seeded {total} elements into ChromaDB at {_DB_PATH}')
    return total
