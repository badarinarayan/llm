'Samsung Magician Agentic Test Automation'
