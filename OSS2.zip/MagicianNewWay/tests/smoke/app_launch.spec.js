'use strict';

/**
 * app_launch.spec.js
 *
 * Smoke tests — verify Samsung Magician launches correctly and the dashboard
 * is stable. Fastest sanity check that the framework and app both work.
 *
 * Requires: Administrator PowerShell (for net stop SamsungMagicianSVC).
 *
 * All tests share one browser instance (beforeAll launch, afterAll close).
 * Serial mode ensures order and prevents parallel multi-launch conflicts.
 */

const { test, expect } = require('@playwright/test');
const { launchMagician, closeMagician } = require('../helpers/appLauncher');
const { loadScreen }                    = require('../helpers/elementLoader');
const { buildLocator }                  = require('../helpers/navigator');

test.describe.configure({ mode: 'serial' });

test.describe('Smoke — App Launch', () => {
  /** @type {{ close: Function }} */
  let app;
  /** @type {import('@playwright/test').Page} */
  let page;

  test.beforeAll(async () => {
    ({ app, page } = await launchMagician());
  }, 90_000);   // launch: stop SVC + kill + 3s sleep + spawn + CDP connect ≈ 20-30s

  test.afterAll(async () => {
    await closeMagician(app);
  }, 30_000);

  // ── 1. Dashboard loads ───────────────────────────────────────────────────────
  test('dashboard loads after launch', async () => {
    test.setTimeout(30_000);
    // 'Home Dashboard' appears in both the sidebar nav label and the page heading area.
    // Using toBeAttached (not toBeVisible) because sidebar items are CSS visibility:hidden.
    await page.getByText('Home Dashboard', { exact: true })
              .first()
              .waitFor({ state: 'attached', timeout: 15_000 });
  });

  // ── 2. All four dashboard widget headings are present ────────────────────────
  test('all four dashboard widgets are present', async () => {
    const config = loadScreen('dashboard');
    const widgetHeadings = [
      config.widget_drive_health.heading,
      config.widget_performance_benchmark.heading,
      config.widget_diagnostic_scan.heading,
      config.widget_perf_optimization.heading,
    ];
    for (const elem of widgetHeadings) {
      await expect(buildLocator(page, elem.selector).first()).toBeAttached();
    }
  });

  // ── 3. All five sidebar navigation labels are present in the DOM ─────────────
  test('all sidebar navigation labels are present in DOM', async () => {
    // Sidebar divs are CSS visibility:hidden — use count() not toBeVisible().
    const sidebarLabels = [
      'Home Dashboard',
      'System Details',
      'Newsroom',
      'Help Center',
      'Settings',
    ];
    for (const label of sidebarLabels) {
      const count = await page.getByText(label, { exact: true }).count();
      expect(count, `sidebar label "${label}" not found in DOM`).toBeGreaterThan(0);
    }
  });

  // ── 4. App is stable after 5s idle ──────────────────────────────────────────
  test('app is stable after 5s idle', async () => {
    test.setTimeout(20_000);
    await page.waitForTimeout(5_000);
    // Dashboard heading still present — no crash, no unintended navigation
    await expect(
      page.getByText('Home Dashboard', { exact: true }).first()
    ).toBeAttached();
  });
});
