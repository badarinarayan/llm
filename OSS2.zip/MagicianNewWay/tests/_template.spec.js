'use strict';

/**
 * _template.spec.js
 *
 * Copy this file → tests/my_test.spec.js and fill in your steps.
 *
 * Step syntax quick-ref (full reference: tests/user_defined/STEP_REFERENCE.md):
 *
 *   'navigate to <screen>'          screen: dashboard | system_details |
 *                                           newsroom | help_center | settings
 *   'click <text>'                  click any visible text / button
 *   'click tab <name>'              tab buttons on System Details screen only
 *   'verify <text>'                 assert text is in DOM
 *   'verify <text> is not visible'  assert text is absent
 *   'wait <ms>'                     pause N milliseconds
 *
 * Object form (for exact control):
 *   { action: 'navigate',      to: 'settings' }
 *   { action: 'click',         text: 'Export' }
 *   { action: 'click_tab',     name: 'System Details' }
 *   { action: 'verify',        text: 'BIOS', exact: true }
 *   { action: 'verify_absent', text: 'Error' }
 *   { action: 'wait',          ms: 2000 }
 *
 * If any step cannot be automated the test exits immediately with:
 *   CANNOT AUTOMATE — test steps do not cover 100%
 *
 * Run this file:
 *   npx playwright test tests/my_test.spec.js
 */

const { defineTest } = require('./helpers/testBuilder');

defineTest('TODO — replace with your test name', [
  // Replace with your actual steps
  'navigate to dashboard',
  'verify Home Dashboard',
]);
