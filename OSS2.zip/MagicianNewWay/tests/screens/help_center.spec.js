'use strict';

/**
 * help_center.spec.js
 *
 * Per-screen tests for the Help Center screen.
 *
 * The Help Center screen is structurally identical to Newsroom — both screens
 * reuse the same React component (accessible name: "Newsroom Feature") and render
 * an external Samsung support site inside an <iframe>. The AX tree only exposes
 * the shell; iframe content is not accessible.
 *
 * What CAN be tested:
 *   - The <iframe> element is present in the DOM after navigation
 *   - The iframe still carries the title "Newsroom Feature" (shared component)
 *   - The global header badges and sidebar nav labels are present
 *
 * Requires: Administrator PowerShell.
 */

const { test, expect } = require('@playwright/test');
const { launchMagician, closeMagician } = require('../helpers/appLauncher');
const { loadScreen }                    = require('../helpers/elementLoader');
const { navigateTo, buildLocator }      = require('../helpers/navigator');

test.describe.configure({ mode: 'serial' });

test.describe('Screen — Help Center', () => {
  /** @type {{ close: Function }} */
  let app;
  /** @type {import('@playwright/test').Page} */
  let page;
  /** @type {object} */
  let config;

  test.beforeAll(async () => {
    ({ app, page } = await launchMagician());
    config = loadScreen('help_center');
    await navigateTo(page, 'help_center', { verify: false });
  }, 90_000);

  test.afterAll(async () => {
    await closeMagician(app);
  }, 30_000);

  // ── Iframe presence ───────────────────────────────────────────────────────────

  test('Help Center iframe is present in DOM', async () => {
    const iframeCount = await page.locator('iframe').count();
    expect(iframeCount, 'expected at least one <iframe> on Help Center screen').toBeGreaterThan(0);
  });

  test('Help Center iframe has accessible name "Newsroom Feature" (shared component)', async () => {
    // Both Newsroom and Help Center reuse the same React component — the iframe
    // title is "Newsroom Feature" on both screens. This is expected/by-design.
    const iframe = page.locator('iframe[title="Newsroom Feature"]');
    const count = await iframe.count();
    expect(count, 'expected iframe with title="Newsroom Feature"').toBeGreaterThan(0);
  });

  // ── Global header ─────────────────────────────────────────────────────────────

  test('header Update badge is present', async () => {
    await expect(
      buildLocator(page, config.header.badge_update.selector).first()
    ).toBeAttached();
  });

  test('header Notice badge is present', async () => {
    await expect(
      buildLocator(page, config.header.badge_notice.selector).first()
    ).toBeAttached();
  });

  // ── Sidebar labels ────────────────────────────────────────────────────────────

  test('all sidebar navigation labels are in DOM', async () => {
    const labels = ['Home Dashboard', 'System Details', 'Newsroom', 'Help Center', 'Settings'];
    for (const label of labels) {
      const count = await page.getByText(label, { exact: true }).count();
      expect(count, `sidebar label "${label}" not found`).toBeGreaterThan(0);
    }
  });

  // ── Stability ─────────────────────────────────────────────────────────────────

  test('app is stable on Help Center screen after 3s idle', async () => {
    test.setTimeout(15_000);
    await page.waitForTimeout(3_000);
    const iframeCount = await page.locator('iframe').count();
    expect(iframeCount).toBeGreaterThan(0);
  });
});
