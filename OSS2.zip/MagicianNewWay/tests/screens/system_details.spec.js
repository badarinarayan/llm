'use strict';

/**
 * system_details.spec.js
 *
 * Per-screen tests for the System Details screen.
 *
 * This is the only screen in Samsung Magician with real ARIA button roles.
 * The three tabs (System Summary | System Details | Drive Details) use
 * page.getByRole('button', { name }) — handled by buildLocator type=role.
 *
 * Tab content strategy:
 *   - The spike captured content with "System Details" tab active.
 *   - beforeAll explicitly clicks the "System Details" tab to guarantee
 *     the correct tab is active before the content-label tests run.
 *   - Tab-switching tests (Summary, Drive Details) only assert no crash;
 *     we have no confirmed selectors for those tab content areas.
 *   - Field LABELS are asserted (stable across machines).
 *     Field VALUES are NOT asserted (machine-specific).
 *
 * Requires: Administrator PowerShell.
 */

const { test, expect } = require('@playwright/test');
const { launchMagician, closeMagician } = require('../helpers/appLauncher');
const { loadScreen }                    = require('../helpers/elementLoader');
const { navigateTo, buildLocator }      = require('../helpers/navigator');

test.describe.configure({ mode: 'serial' });

test.describe('Screen — System Details', () => {
  /** @type {{ close: Function }} */
  let app;
  /** @type {import('@playwright/test').Page} */
  let page;
  /** @type {object} */
  let config;

  // Track whether the "System Details" tab content actually loaded.
  // Motherboard/BIOS appear in BOTH System Summary and System Details tabs,
  // so we need a System-Details-only marker ('Memory Information') to know the
  // tab switch truly worked.  Tests that rely on tab-specific content check
  // this flag and skip gracefully if the tab didn't switch.
  let systemDetailsTabActive = false;

  test.beforeAll(async () => {
    ({ app, page } = await launchMagician());
    config = loadScreen('system_details');
    await navigateTo(page, 'system_details');

    // The default landing tab is System Summary (first tab).
    // Click "System Details" tab explicitly and wait for its unique content.
    await buildLocator(page, config.tabs.tab_system_details.selector).click();

    // 'Memory Information' only appears in the System Details tab — not in
    // System Summary.  Wait up to 5 s; if it doesn't appear the click may
    // have had no effect (timing) or this machine has no removable RAM slots.
    try {
      await page.getByText('Memory Information', { exact: false })
                .first()
                .waitFor({ state: 'attached', timeout: 5_000 });
      systemDetailsTabActive = true;
      logger.info({ action: 'beforeAll', detail: 'System Details tab confirmed active' });
    } catch {
      // Retry once — click again and wait
      logger.warn({ action: 'beforeAll', detail: 'Memory Information not found after first tab click — retrying' });
      await buildLocator(page, config.tabs.tab_system_details.selector).click();
      await page.waitForTimeout(2_000);
      const count = await page.getByText('Memory Information', { exact: false }).count();
      systemDetailsTabActive = count > 0;
      logger.info({ action: 'beforeAll', detail: `System Details tab after retry: active=${systemDetailsTabActive}` });
    }
  }, 90_000);

  test.afterAll(async () => {
    await closeMagician(app);
  }, 30_000);

  // ── Page structure ────────────────────────────────────────────────────────────

  test('page heading "System Details" is present', async () => {
    await expect(
      buildLocator(page, config.page_structure.page_heading.selector).first()
    ).toBeAttached();
  });

  test('Export button is present', async () => {
    // Presence only — do NOT click (generates a file export dialog)
    await expect(
      buildLocator(page, config.page_structure.btn_export.selector).first()
    ).toBeAttached();
  });

  // ── Tab buttons (real ARIA role="button") ─────────────────────────────────────

  test('System Summary tab button is present and enabled', async () => {
    const tab = buildLocator(page, config.tabs.tab_system_summary.selector);
    await expect(tab.first()).toBeAttached();
    await expect(tab.first()).toBeEnabled();
  });

  test('System Details tab button is present and enabled', async () => {
    const tab = buildLocator(page, config.tabs.tab_system_details.selector);
    await expect(tab.first()).toBeAttached();
    await expect(tab.first()).toBeEnabled();
  });

  test('Drive Details tab button is present and enabled', async () => {
    const tab = buildLocator(page, config.tabs.tab_drive_details.selector);
    await expect(tab.first()).toBeAttached();
    await expect(tab.first()).toBeEnabled();
  });

  // ── System Details tab content — section headings ─────────────────────────────

  test('System Details tab: Motherboard section heading present', async () => {
    await expect(
      buildLocator(page, config.system_details_tab_content.section_motherboard.selector).first()
    ).toBeAttached();
  });

  test('System Details tab: BIOS section heading present', async () => {
    await expect(
      buildLocator(page, config.system_details_tab_content.section_bios.selector).first()
    ).toBeAttached();
  });

  test('System Details tab: Memory Information section heading present', async () => {
    // Skip if the tab didn't activate — avoids false failure vs. a real bug.
    // The selector now uses exact:false and text:"Memory Information" (no slot count)
    // so it matches "Memory Information (1/1)", "(2/2)", etc. on any machine.
    test.skip(!systemDetailsTabActive, 'System Details tab did not activate — Memory Information not reachable');
    await expect(
      buildLocator(page, config.system_details_tab_content.section_memory.selector).first()
    ).toBeAttached();
  });

  test('System Details tab: PCI Information section heading present', async () => {
    test.skip(!systemDetailsTabActive, 'System Details tab did not activate — PCI Information not reachable');
    // Selector uses exact:false — matches "PCI Information (n)" or similar
    await expect(
      buildLocator(page, config.system_details_tab_content.section_pci.selector).first()
    ).toBeAttached();
  });

  // ── System Details tab content — field labels ─────────────────────────────────

  test('System Details tab: Motherboard field labels present', async () => {
    const labels = [
      config.system_details_tab_content.label_manufacturer,
      config.system_details_tab_content.label_name,
    ];
    for (const elem of labels) {
      await expect(buildLocator(page, elem.selector).first()).toBeAttached();
    }
  });

  test('System Details tab: BIOS field labels present', async () => {
    const labels = [
      config.system_details_tab_content.label_vendor,
      config.system_details_tab_content.label_version,
    ];
    for (const elem of labels) {
      await expect(buildLocator(page, elem.selector).first()).toBeAttached();
    }
  });

  test('System Details tab: Memory field labels present', async () => {
    test.skip(!systemDetailsTabActive, 'System Details tab did not activate — memory field labels not reachable');
    const labels = [
      config.system_details_tab_content.label_status,
      config.system_details_tab_content.label_size,
      config.system_details_tab_content.label_form_factor,
      config.system_details_tab_content.label_mem_drive_type,
      config.system_details_tab_content.label_serial_number,
    ];
    for (const elem of labels) {
      await expect(buildLocator(page, elem.selector).first()).toBeAttached();
    }
  });

  test('System Details tab: PCI field labels present', async () => {
    test.skip(!systemDetailsTabActive, 'System Details tab did not activate — PCI field labels not reachable');
    const labels = [
      config.system_details_tab_content.label_slot_type,
      config.system_details_tab_content.label_connected_drive,
    ];
    for (const elem of labels) {
      await expect(buildLocator(page, elem.selector).first()).toBeAttached();
    }
  });

  // ── Tab interaction — non-destructive switching ───────────────────────────────

  test('clicking System Summary tab does not crash', async () => {
    test.setTimeout(20_000);
    await buildLocator(page, config.tabs.tab_system_summary.selector).click();
    await page.waitForTimeout(1_500);
    // Page is still alive — page heading still in DOM
    await expect(
      buildLocator(page, config.page_structure.page_heading.selector).first()
    ).toBeAttached();
  });

  test('clicking Drive Details tab does not crash', async () => {
    test.setTimeout(20_000);
    await buildLocator(page, config.tabs.tab_drive_details.selector).click();
    await page.waitForTimeout(1_500);
    await expect(
      buildLocator(page, config.page_structure.page_heading.selector).first()
    ).toBeAttached();
  });

  test('return to System Details tab — Motherboard section still visible', async () => {
    test.setTimeout(20_000);
    await buildLocator(page, config.tabs.tab_system_details.selector).click();
    await page.waitForTimeout(1_500);
    // Motherboard appears in both tabs — confirms the page is still responsive
    await expect(
      buildLocator(page, config.system_details_tab_content.section_motherboard.selector).first()
    ).toBeAttached();
  });
});
