'use strict';

/**
 * dashboard.spec.js
 *
 * Per-screen tests for the Home Dashboard.
 *
 * The dashboard is the launch landing screen — no navigation needed in beforeAll.
 * It contains 4 embedded widgets (NOT separate navigable screens):
 *   Drive Health | Performance Benchmark | Diagnostic Scan | Performance Optimization
 *
 * Test strategy:
 *   - Assert element PRESENCE (toBeAttached) — not toBeVisible, sidebar items are
 *     CSS visibility:hidden and getByText can still find them.
 *   - Dynamic values (health_status, temperatures, benchmark results) are NOT asserted
 *     for specific values — they change per machine and drive state.
 *   - No destructive interactions: Start benchmark and Delete buttons are not clicked.
 *
 * Requires: Administrator PowerShell.
 */

const { test, expect } = require('@playwright/test');
const { launchMagician, closeMagician } = require('../helpers/appLauncher');
const { loadScreen }                    = require('../helpers/elementLoader');
const { buildLocator }                  = require('../helpers/navigator');

test.describe.configure({ mode: 'serial' });

test.describe('Screen — Dashboard', () => {
  /** @type {{ close: Function }} */
  let app;
  /** @type {import('@playwright/test').Page} */
  let page;
  /** @type {object} */
  let config;

  test.beforeAll(async () => {
    ({ app, page } = await launchMagician());
    config = loadScreen('dashboard');
    // Dashboard is the default landing screen — no navigation needed.
    // Wait for the page heading to confirm load.
    await page.getByText('Home Dashboard', { exact: true })
              .first()
              .waitFor({ state: 'attached', timeout: 15_000 });
  }, 90_000);

  test.afterAll(async () => {
    await closeMagician(app);
  }, 30_000);

  // ── Widget headings ──────────────────────────────────────────────────────────

  test('Drive Health widget heading is present', async () => {
    await expect(
      buildLocator(page, config.widget_drive_health.heading.selector).first()
    ).toBeAttached();
  });

  test('Performance Benchmark widget heading is present', async () => {
    await expect(
      buildLocator(page, config.widget_performance_benchmark.heading.selector).first()
    ).toBeAttached();
  });

  test('Diagnostic Scan widget heading is present', async () => {
    await expect(
      buildLocator(page, config.widget_diagnostic_scan.heading.selector).first()
    ).toBeAttached();
  });

  test('Performance Optimization widget heading is present', async () => {
    await expect(
      buildLocator(page, config.widget_perf_optimization.heading.selector).first()
    ).toBeAttached();
  });

  // ── Drive Health widget — static labels ─────────────────────────────────────

  test('Drive Health: S.M.A.R.T. label present', async () => {
    await expect(
      buildLocator(page, config.widget_drive_health.label_smart.selector).first()
    ).toBeAttached();
  });

  test('Drive Health: temperature section labels present', async () => {
    const labels = [
      config.widget_drive_health.label_temperature,
      config.widget_drive_health.label_current_temp,
      config.widget_drive_health.label_highest_temp,
      config.widget_drive_health.label_average_temp,
    ];
    for (const elem of labels) {
      await expect(buildLocator(page, elem.selector).first()).toBeAttached();
    }
  });

  test('Drive Health: temperature scale markers (0°, 50°, 100°) present', async () => {
    const scaleLabels = [
      config.widget_drive_health.temp_scale_0,
      config.widget_drive_health.temp_scale_50,
      config.widget_drive_health.temp_scale_100,
    ];
    for (const elem of scaleLabels) {
      await expect(buildLocator(page, elem.selector).first()).toBeAttached();
    }
  });

  test('Drive Health: Written / TB labels present', async () => {
    await expect(buildLocator(page, config.widget_drive_health.label_written.selector).first()).toBeAttached();
    await expect(buildLocator(page, config.widget_drive_health.label_tb.selector).first()).toBeAttached();
  });

  test('Drive Health: Performance label present', async () => {
    await expect(
      buildLocator(page, config.widget_drive_health.label_performance.selector).first()
    ).toBeAttached();
  });

  // ── Performance Benchmark widget — static labels ─────────────────────────────

  test('Performance Benchmark: Setup Benchmark label present', async () => {
    await expect(
      buildLocator(page, config.widget_performance_benchmark.label_setup.selector).first()
    ).toBeAttached();
  });

  test('Performance Benchmark: Result section label present', async () => {
    await expect(
      buildLocator(page, config.widget_performance_benchmark.label_result.selector).first()
    ).toBeAttached();
  });

  test('Performance Benchmark: read/write result labels present', async () => {
    const labels = [
      config.widget_performance_benchmark.label_seq_read,
      config.widget_performance_benchmark.label_seq_write,
      config.widget_performance_benchmark.label_rand_read,
      config.widget_performance_benchmark.label_rand_write,
    ];
    for (const elem of labels) {
      await expect(buildLocator(page, elem.selector).first()).toBeAttached();
    }
  });

  test('Performance Benchmark: MB/s and IOPS unit labels present', async () => {
    // These labels appear multiple times (one per result row) — first() is sufficient
    await expect(buildLocator(page, config.widget_performance_benchmark.unit_mbs.selector).first()).toBeAttached();
    await expect(buildLocator(page, config.widget_performance_benchmark.unit_iops.selector).first()).toBeAttached();
  });

  test('Performance Benchmark: Start button present', async () => {
    // Presence check only — do NOT click (would start a benchmark run)
    await expect(
      buildLocator(page, config.widget_performance_benchmark.btn_start.selector).first()
    ).toBeAttached();
  });

  // ── Diagnostic Scan & Performance Optimization — unsupported state ───────────

  test('Diagnostic Scan: shows unsupported-drive message', async () => {
    await expect(
      buildLocator(page, config.widget_diagnostic_scan.unsupported_msg.selector).first()
    ).toBeAttached();
  });

  test('Performance Optimization: shows unsupported-drive message', async () => {
    await expect(
      buildLocator(page, config.widget_perf_optimization.unsupported_msg.selector).first()
    ).toBeAttached();
  });

  // ── Drive info card — action buttons ─────────────────────────────────────────

  test('drive info card: See All Widgets button present', async () => {
    await expect(
      buildLocator(page, config.drive_info_card.btn_see_all_widgets.selector).first()
    ).toBeAttached();
  });

  test('drive info card: Edit button present', async () => {
    await expect(
      buildLocator(page, config.drive_info_card.btn_edit.selector).first()
    ).toBeAttached();
  });

  // ── Header ────────────────────────────────────────────────────────────────────

  test('header: Update and Notice badges present', async () => {
    await expect(buildLocator(page, config.header.badge_update.selector).first()).toBeAttached();
    await expect(buildLocator(page, config.header.badge_notice.selector).first()).toBeAttached();
  });
});
