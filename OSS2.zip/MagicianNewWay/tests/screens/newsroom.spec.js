'use strict';

/**
 * newsroom.spec.js
 *
 * Per-screen tests for the Newsroom screen.
 *
 * The Newsroom screen is entirely iframe-based. The Samsung Magician shell renders
 * a single <iframe> loading an external Samsung Newsroom website. The accessibility
 * tree shows only the shell; iframe content is not accessible via getFullAXTree.
 *
 * What CAN be tested:
 *   - The <iframe> element is present in the DOM after navigation
 *   - The global header badges (Update, Notice) are attached
 *   - The sidebar navigation labels are present (they persist across all screens)
 *   - Navigation to this screen does not crash the app
 *
 * What CANNOT be tested:
 *   - Content inside the iframe (Samsung Newsroom website — external, not in AX tree)
 *   - Any text headings specific to Newsroom (none exist outside the iframe)
 *
 * Requires: Administrator PowerShell.
 */

const { test, expect } = require('@playwright/test');
const { launchMagician, closeMagician } = require('../helpers/appLauncher');
const { loadScreen }                    = require('../helpers/elementLoader');
const { navigateTo, buildLocator }      = require('../helpers/navigator');

test.describe.configure({ mode: 'serial' });

test.describe('Screen — Newsroom', () => {
  /** @type {{ close: Function }} */
  let app;
  /** @type {import('@playwright/test').Page} */
  let page;
  /** @type {object} */
  let config;

  test.beforeAll(async () => {
    ({ app, page } = await launchMagician());
    config = loadScreen('newsroom');
    // { verify: false } — the screen marker ('Newsroom Feature') is an iframe
    // accessible name (title attribute), not a text node; getByText can't find it.
    await navigateTo(page, 'newsroom', { verify: false });
  }, 90_000);

  test.afterAll(async () => {
    await closeMagician(app);
  }, 30_000);

  // ── Iframe presence ───────────────────────────────────────────────────────────

  test('Newsroom iframe is present in DOM', async () => {
    const iframeCount = await page.locator('iframe').count();
    expect(iframeCount, 'expected at least one <iframe> on Newsroom screen').toBeGreaterThan(0);
  });

  test('Newsroom iframe has accessible name "Newsroom Feature"', async () => {
    // Verify the iframe's title attribute matches the expected accessible name.
    // This is the only Newsroom-specific content we can assert on.
    const iframe = page.locator('iframe[title="Newsroom Feature"]');
    const count = await iframe.count();
    expect(count, 'expected iframe with title="Newsroom Feature"').toBeGreaterThan(0);
  });

  // ── Global header (present on every screen) ──────────────────────────────────

  test('header Update badge is present', async () => {
    await expect(
      buildLocator(page, config.header.badge_update.selector).first()
    ).toBeAttached();
  });

  test('header Notice badge is present', async () => {
    await expect(
      buildLocator(page, config.header.badge_notice.selector).first()
    ).toBeAttached();
  });

  // ── Sidebar labels (present on every screen, visibility:hidden in CSS) ────────

  test('all sidebar navigation labels are in DOM', async () => {
    const labels = ['Home Dashboard', 'System Details', 'Newsroom', 'Help Center', 'Settings'];
    for (const label of labels) {
      const count = await page.getByText(label, { exact: true }).count();
      expect(count, `sidebar label "${label}" not found`).toBeGreaterThan(0);
    }
  });

  // ── Stability ─────────────────────────────────────────────────────────────────

  test('app is stable on Newsroom screen after 3s idle', async () => {
    test.setTimeout(15_000);
    await page.waitForTimeout(3_000);
    // Iframe is still present — no crash or unload
    const iframeCount = await page.locator('iframe').count();
    expect(iframeCount).toBeGreaterThan(0);
  });
});
