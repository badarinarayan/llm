# User-Defined Test — Step Reference

## Quick start

Copy `_template.spec.js` → `my_test.spec.js`, then fill in your steps and run:
```powershell
# Administrator PowerShell
npx playwright test tests/user_defined/my_test.spec.js
```

---

## Step formats

Steps can be **plain strings** (parsed automatically) or **objects** (explicit, preferred when text is ambiguous).

### navigate

Go to a screen by clicking the sidebar label.

```js
'navigate to dashboard'
'navigate to system_details'
'navigate to newsroom'
'navigate to help_center'
'navigate to settings'

// Object form:
{ action: 'navigate', to: 'system_details' }
```

Valid screen names: `dashboard` | `system_details` | `newsroom` | `help_center` | `settings`

---

### click

Click any visible text element (buttons, labels, links).

```js
'click Export'
'click See All Widgets'
'click the Export'           // 'the' is ignored

// Object form:
{ action: 'click', text: 'Export' }
```

---

### click tab

Click a tab button. Tab buttons are the **only** real ARIA `role="button"` elements in Samsung Magician — they only exist on the System Details screen.

```js
'click tab System Details'
'click tab System Summary'
'click tab Drive Details'
'click System Details tab'   // word order doesn't matter

// Object form:
{ action: 'click_tab', name: 'System Details' }
```

---

### verify

Assert that text is present in the page (attached to the DOM).

```js
'verify Memory Information'
'verify text BIOS'
'verify Memory Information is visible'
'verify Memory Information is present'

// Object form — exact:false by default:
{ action: 'verify', text: 'Memory Information', exact: false }
{ action: 'verify', text: 'Export',             exact: true  }
```

---

### verify absent

Assert that text is **not** present in the page.

```js
'verify absent Error'
'verify Error is not present'
'verify Error is not visible'

// Object form:
{ action: 'verify_absent', text: 'Error' }
```

---

### wait

Pause for N milliseconds (capped at 30 000 ms).

```js
'wait 2000'
'wait 500 ms'

// Object form:
{ action: 'wait', ms: 2000 }
```

---

### cannot_automate (explicit)

Mark a step as not automatable. The test will exit immediately with a "CANNOT AUTOMATE" message and will NOT be marked as passing.

```js
{ action: 'cannot_automate', reason: 'requires physical drive insertion' }
```

You do not need to add this manually — the runner detects common non-automatable patterns automatically (see below).

---

## Automatically detected non-automatable patterns

The step runner scans every step and exits immediately if any of these are detected:

| Pattern | Reason |
|---------|--------|
| save file / save as file | OS file-save dialog (outside Electron renderer) |
| open file dialog / browse for file | OS file-open dialog |
| download | External download; no DOM control |
| plug in / unplug | Physical hardware interaction |
| physically | Physical action |
| remove/insert/connect/disconnect drive | Physical hardware |
| power off / power cycle | OS-level action |
| reboot / restart windows / restart computer | OS-level action |
| shutdown / log out | OS-level action |
| secure erase / format drive / erase drive | Destructive — never automated |

---

## "Cannot automate" exit

If the test hits a non-automatable step it exits immediately with:

```
╔══════════════════════════════════════════════════════════════╗
║  CANNOT AUTOMATE — test steps do not cover 100%             ║
╠══════════════════════════════════════════════════════════════╣
║  Step   : click Export and save the file                    ║
║  Reason : matches non-automatable pattern (save\s+...)      ║
╚══════════════════════════════════════════════════════════════╝
```

The test is marked **failed** (not skipped) so the gap is visible in the report.

---

## Full example

```js
'use strict';
const { defineTest } = require('../helpers/testBuilder');

defineTest('Check System Details memory labels', [
  'navigate to system_details',
  'click tab System Details',
  'verify Memory Information',
  'verify Status',
  'verify Size',
  'verify Form Factor',
]);
```
