'use strict';

/**
 * performance_benchmark.spec.js
 *
 * User-defined test — Performance Benchmark
 *
 * Steps:
 *   1. Navigate to Performance Benchmark via sidebar
 *   2. Click "Start" to begin the benchmark
 *   3. Wait for the test to complete (Stop button disappears → Start returns)
 *      with polling fallback (up to 10 minutes)
 *   4. Extract Sequential Read/Write (MB/s) and Random Read/Write (IOPS)
 *   5. Print results to terminal (console) and structured log
 *
 * Non-automatable check:
 *   All steps are automatable via CDP DOM access.
 *   File-save, hardware insertion, OS dialogs → none involved here.
 *
 * Requires: Administrator PowerShell.
 */

const { test } = require('@playwright/test');
const { launchMagician, closeMagician } = require('./helpers/appLauncher');
const { navigateTo, clickText }         = require('./helpers/navigator');
const logger                            = require('./helpers/logger');

// ── Timing constants ──────────────────────────────────────────────────────────

/** Minimum time after clicking Start before we begin polling for results. */
const INIT_WAIT_MS      = 15_000;

/** How often to check for completion. */
const POLL_INTERVAL_MS  = 10_000;

/** Maximum time the benchmark is allowed to run before we give up. */
const BENCHMARK_MAX_MS  = 600_000;   // 10 minutes

/** Total test timeout (benchmark + launch overhead + extraction). */
const TEST_TIMEOUT_MS   = BENCHMARK_MAX_MS + 180_000;

// ── Test suite ────────────────────────────────────────────────────────────────

test.describe.configure({ mode: 'serial' });

test.describe('[User] Performance Benchmark', () => {
  let app, page;

  test.beforeAll(async () => {
    ({ app, page } = await launchMagician());
    // Navigate to the dedicated Performance Benchmark screen via the sidebar.
    await navigateTo(page, 'performance_benchmark');
  }, 90_000);

  test.afterAll(async () => {
    await closeMagician(app);
  }, 30_000);

  // ── Main test ────────────────────────────────────────────────────────────────

  test('run benchmark and extract metrics', async () => {
    test.setTimeout(TEST_TIMEOUT_MS);

    // ── Step 1: Confirm the Performance Benchmark screen has loaded ────────────
    await page
      .getByText('Performance Benchmark', { exact: true })
      .first()
      .waitFor({ state: 'attached', timeout: 15_000 });

    // Also confirm the Start button is present — if it's missing the drive may
    // not support benchmarking.
    const startCount = await page.getByText('Start', { exact: true }).count();
    if (startCount === 0) {
      throw new Error(
        'Performance Benchmark screen loaded but "Start" button not found.\n' +
        'The connected drive may not support performance benchmarking.'
      );
    }

    logger.info({ action: 'benchmark', step: 1, status: 'screen confirmed, Start button present' });

    // ── Step 2: Record pre-run state ────────────────────────────────────────────
    // Needed to detect when a NEW run completes (result values may already exist
    // from a previous session).
    const preRun = await extractMetrics(page);
    const hadNoResult = await page.getByText('No Result', { exact: true }).count() > 0;

    logger.info({ action: 'benchmark', step: 2, status: 'pre-run state captured', hadNoResult, preRun });
    console.log(`\nPre-run state: ${hadNoResult ? '"No Result" displayed (no previous run)' : 'previous results present'}`);
    if (!hadNoResult && preRun.sequentialRead) {
      console.log(`  Previous Sequential Read  : ${preRun.sequentialRead} MB/s`);
      console.log(`  Previous Sequential Write : ${preRun.sequentialWrite} MB/s`);
      console.log(`  Previous Random Read      : ${preRun.randomRead} IOPS`);
      console.log(`  Previous Random Write     : ${preRun.randomWrite} IOPS`);
    }

    // ── Step 3: Click Start ─────────────────────────────────────────────────────
    const clicked = await clickText(page, 'Start');
    if (!clicked) {
      throw new Error(
        'Could not click the "Start" button.\n' +
        'Possible reasons:\n' +
        '  • The benchmark is already running (click Stop first)\n' +
        '  • The widget is not visible on this machine\n' +
        '  • The drive does not support the benchmark'
      );
    }

    logger.info({ action: 'benchmark', step: 3, status: 'Start clicked' });
    console.log('\n▶  Benchmark started — waiting for results...');
    console.log(`   (polling every ${POLL_INTERVAL_MS / 1000}s, timeout ${BENCHMARK_MAX_MS / 60_000} min)\n`);

    // ── Step 4: Wait for benchmark to complete ──────────────────────────────────
    // Primary signal: when running, "Start" changes to "Stop".
    //   Wait for "Stop" to appear  → benchmark is running.
    //   Wait for "Stop" to go away → benchmark is complete.
    // Fallback: if "Stop" never appears (UI behaves differently), fall back to
    //   the polling loop that watches for result values to change.
    const metrics = await waitForBenchmarkResults(page, preRun, hadNoResult);

    // ── Step 5a: Print to terminal ──────────────────────────────────────────────
    const report = formatReport(metrics);
    console.log(report);

    // ── Step 5b: Write to structured log ────────────────────────────────────────
    logger.info({
      action:  'benchmark-results',
      step:    5,
      status:  'complete',
      metrics: {
        sequentialRead:  { value: metrics.sequentialRead,  unit: 'MB/s' },
        sequentialWrite: { value: metrics.sequentialWrite, unit: 'MB/s' },
        randomRead:      { value: metrics.randomRead,      unit: 'IOPS' },
        randomWrite:     { value: metrics.randomWrite,     unit: 'IOPS' },
      },
    });
  });
});

// ── Completion detection ──────────────────────────────────────────────────────

/**
 * Wait for the benchmark to finish and return the extracted metrics.
 *
 * Strategy (two-phase):
 *
 *   Phase A — Button signal (preferred):
 *     When "Start" is clicked the button text changes to "Stop".
 *     We wait for "Stop" to appear (confirms run started), then wait for
 *     "Stop" to disappear (confirms run ended).  This is instantaneous compared
 *     to polling and works regardless of how long the benchmark takes.
 *
 *   Phase B — Polling fallback:
 *     If "Stop" never appears within INIT_WAIT_MS (UI may differ between
 *     Magician versions), fall through to polling result values directly.
 *     Poll every POLL_INTERVAL_MS until "No Result" is gone AND the values
 *     are non-zero and differ from the pre-click state.
 *
 * @param {import('@playwright/test').Page} page
 * @param {{ sequentialRead, sequentialWrite, randomRead, randomWrite }} preRun
 * @param {boolean} hadNoResult  True if "No Result" was shown before clicking Start
 * @returns {Promise<object>}    Resolved metrics
 */
async function waitForBenchmarkResults(page, preRun, hadNoResult) {
  const runStart = Date.now();

  // ── Phase A: Stop button signal ─────────────────────────────────────────────
  console.log('  Watching for "Stop" button (confirms run started)…');

  const stopAppeared = await page
    .getByText('Stop', { exact: true })
    .first()
    .waitFor({ state: 'attached', timeout: INIT_WAIT_MS })
    .then(() => true)
    .catch(() => false);

  if (stopAppeared) {
    logger.info({ action: 'benchmark', status: 'running-confirmed', signal: 'stop-button-appeared' });
    console.log('  "Stop" button visible — benchmark is running…');

    // Now wait for Stop to disappear — that is the completion signal.
    await page
      .getByText('Stop', { exact: true })
      .first()
      .waitFor({ state: 'detached', timeout: BENCHMARK_MAX_MS });

    const elapsed = Date.now() - runStart;
    logger.info({ action: 'benchmark', status: 'complete', signal: 'stop-button-gone', elapsedMs: elapsed });
    console.log(`\n✔  Benchmark complete (Stop→Start) after ~${Math.round(elapsed / 1000)}s\n`);

    // Brief settle pause to let the DOM update with final values.
    await page.waitForTimeout(1_500);
    return extractMetrics(page);
  }

  // ── Phase B: Polling fallback ────────────────────────────────────────────────
  logger.warn({ action: 'benchmark', status: 'stop-button-not-seen', fallback: 'polling' });
  console.log('  "Stop" button not detected — switching to polling mode…');

  const deadline  = Date.now() + BENCHMARK_MAX_MS;
  let   pollCount = 0;

  while (Date.now() < deadline) {
    pollCount++;
    await page.waitForTimeout(POLL_INTERVAL_MS);

    const elapsed    = Date.now() - runStart;
    const noResult   = await page.getByText('No Result', { exact: true }).count();
    const current    = await extractMetrics(page);
    const hasValues  = current.sequentialRead !== null;
    const isNonZero  = hasValues && parseFloat(current.sequentialRead.replace(/,/g, '')) > 0;
    const isFresh    = hadNoResult
      || current.sequentialRead  !== preRun.sequentialRead
      || current.sequentialWrite !== preRun.sequentialWrite;

    logger.info({
      action: 'benchmark-poll', poll: pollCount,
      elapsedMs: elapsed, noResult: noResult > 0,
      hasValues, isNonZero, isFresh, current,
    });

    console.log(
      `  [${Math.round(elapsed / 1000)}s]  ` +
      (noResult > 0
        ? 'running…'
        : hasValues && isNonZero
          ? `Seq Read ${current.sequentialRead} MB/s — verifying freshness…`
          : 'waiting for results…')
    );

    if (noResult === 0 && hasValues && isNonZero && isFresh) {
      logger.info({ action: 'benchmark', status: 'complete', signal: 'poll', elapsedMs: elapsed });
      console.log(`\n✔  Benchmark complete (poll) after ~${Math.round(elapsed / 1000)}s\n`);
      return current;
    }
  }

  // Timed out
  const lastAttempt = await extractMetrics(page);
  logger.error({ action: 'benchmark', status: 'timeout', lastAttempt });
  throw new Error(
    `Benchmark did not complete within ${BENCHMARK_MAX_MS / 60_000} minutes.\n` +
    `Last extracted values: ${JSON.stringify(lastAttempt)}`
  );
}

// ── DOM metric extractor ──────────────────────────────────────────────────────

/**
 * Extract benchmark result values from the live page via DOM text node walk.
 *
 * Samsung Magician renders results as plain StaticText nodes — no ARIA roles
 * or data attributes on the value elements.  We find the label ("Sequential Read"),
 * then scan forward for a numeric token that sits before the unit ("MB/s" / "IOPS").
 *
 * Handles values like "3,500", "1,234.56", "450,000".
 *
 * @param {import('@playwright/test').Page} page
 * @returns {Promise<{ sequentialRead, sequentialWrite, randomRead, randomWrite }>}
 */
async function extractMetrics(page) {
  return page.evaluate(() => {
    // Collect all non-empty text node contents in DOM order.
    const texts = [];
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      const t = node.textContent.trim();
      if (t) texts.push(t);
    }

    /**
     * Find the value for a (label, unit) pair.
     * Scans a window of WINDOW tokens after the label; returns the last
     * numeric token that appears before the unit.
     */
    function findValue(label, unit, window = 8) {
      for (let i = 0; i < texts.length; i++) {
        if (texts[i] !== label) continue;
        const slice   = texts.slice(i + 1, i + 1 + window);
        const unitIdx = slice.indexOf(unit);
        if (unitIdx === -1) continue;
        // Walk backwards from the unit to find a numeric token
        for (let k = unitIdx - 1; k >= 0; k--) {
          if (/^[\d,\.]+$/.test(slice[k])) return slice[k];
        }
      }
      return null;
    }

    return {
      sequentialRead:  findValue('Sequential Read',  'MB/s'),
      sequentialWrite: findValue('Sequential Write', 'MB/s'),
      randomRead:      findValue('Random Read',      'IOPS'),
      randomWrite:     findValue('Random Write',     'IOPS'),
    };
  });
}

// ── Console report formatter ──────────────────────────────────────────────────

/**
 * Format extracted metrics into a human-readable terminal box.
 */
function formatReport(m) {
  const na  = 'N/A';
  const fmt = (val, unit) => (val ? `${val} ${unit}` : na).padEnd(24);

  return [
    '',
    '╔══════════════════════════════════════════════╗',
    '║     PERFORMANCE BENCHMARK RESULTS            ║',
    '╠══════════════════════════════════════════════╣',
    `║  Sequential Read  :  ${fmt(m.sequentialRead,  'MB/s')} ║`,
    `║  Sequential Write :  ${fmt(m.sequentialWrite, 'MB/s')} ║`,
    `║  Random Read      :  ${fmt(m.randomRead,      'IOPS')} ║`,
    `║  Random Write     :  ${fmt(m.randomWrite,     'IOPS')} ║`,
    '╚══════════════════════════════════════════════╝',
    '',
  ].join('\n');
}
