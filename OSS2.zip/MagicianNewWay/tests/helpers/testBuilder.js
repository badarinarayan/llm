'use strict';

/**
 * testBuilder.js
 *
 * Wraps a user-provided step list into a full Playwright test.
 * Handles launch, teardown, and graceful exit on non-automatable steps.
 *
 * Usage:
 *
 *   const { defineTest } = require('../helpers/testBuilder');
 *
 *   defineTest('Verify System Details screen', [
 *     'navigate to system_details',
 *     'click tab System Details',
 *     'verify Memory Information',
 *     'verify BIOS',
 *   ]);
 *
 * Steps can be plain strings (parsed automatically) or structured objects —
 * see tests/helpers/stepRunner.js for the full step reference.
 *
 * If ANY step cannot be automated the test exits immediately with:
 *   CANNOT AUTOMATE — test steps do not cover 100%
 *
 * Known screens (for 'navigate to'):
 *   dashboard | system_details | newsroom | help_center | settings
 *
 * Known tab names (for 'click tab'):
 *   System Summary | System Details | Drive Details
 */

const { test }                   = require('@playwright/test');
const { launchMagician,
        closeMagician }          = require('./appLauncher');
const { runSteps,
        CannotAutomateError }    = require('./stepRunner');
const logger                     = require('./logger');

/**
 * Define a user-provided test.
 *
 * @param {string}       testName  Human-readable name shown in the test report
 * @param {Array}        steps     Ordered list of step strings or step objects
 * @param {object}       [opts]
 * @param {number}       [opts.timeout=120000]  Total step-execution timeout (ms)
 * @param {string}       [opts.startScreen]     Navigate here immediately after launch
 *                                              (e.g. 'dashboard'). Skipped if omitted.
 */
function defineTest(testName, steps, opts = {}) {
  const { timeout = 120_000, startScreen } = opts;

  test.describe.configure({ mode: 'serial' });

  test.describe(`[User] ${testName}`, () => {
    let app, page;

    test.beforeAll(async () => {
      ({ app, page } = await launchMagician());
      if (startScreen) {
        const { navigateTo } = require('./navigator');
        await navigateTo(page, startScreen);
      }
    }, 90_000);

    test.afterAll(async () => {
      await closeMagician(app);
    }, 30_000);

    test(testName, async () => {
      test.setTimeout(timeout);

      try {
        await runSteps(page, steps);
        logger.info({ action: 'test-complete', name: testName, status: 'pass' });
      } catch (err) {
        if (err instanceof CannotAutomateError) {
          // Surface the "cannot automate" message as the test failure reason.
          // Using test.fail() marks it differently from a genuine assertion error.
          logger.error({ action: 'cannot-automate', name: testName, detail: err.message });
          throw err;   // Playwright will show the full message in the report
        }
        throw err;
      }
    });
  });
}

module.exports = { defineTest };
