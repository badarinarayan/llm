'use strict';

/**
 * elementLoader.js
 *
 * Loads Elements_Config/<screenName>.json and returns the parsed object.
 * Caches each file so it's only read from disk once per process.
 *
 * Usage:
 *   const { loadScreen } = require('./elementLoader');
 *   const config = loadScreen('dashboard');
 *   // config.elements.widget_drive_health.heading.selector.text === 'Drive Health'
 */

const fs   = require('fs');
const path = require('path');

const CONFIG_DIR = path.join(__dirname, '..', '..', 'Elements_Config');
const cache      = new Map();

/**
 * Load and cache a screen config.
 * @param {string} screenName - e.g. 'dashboard', 'system_details'
 * @returns {object} Parsed JSON config
 * @throws If the file does not exist or is malformed
 */
function loadScreen(screenName) {
  if (cache.has(screenName)) return cache.get(screenName);

  const filePath = path.join(CONFIG_DIR, `${screenName}.json`);
  if (!fs.existsSync(filePath)) {
    throw new Error(`Elements_Config not found: ${filePath}`);
  }

  const raw    = fs.readFileSync(filePath, 'utf8');
  const config = JSON.parse(raw);
  cache.set(screenName, config);
  return config;
}

/**
 * Return a flat map of all elements across every group in a screen config.
 * Skips keys that start with '_' (they are notes/comments).
 *
 * @param {object} config - Result of loadScreen()
 * @returns {object} { logicalName: elementDescriptor, … }
 */
function flattenElements(config) {
  const result = {};
  for (const [groupKey, groupVal] of Object.entries(config)) {
    if (groupKey.startsWith('_') || typeof groupVal !== 'object' || groupVal === null) continue;
    if (groupKey === 'screen' || groupKey === 'sidebarLabel' || groupKey === 'description') continue;

    // A leaf element has a 'selector' property; a group is a plain object without it
    if (groupVal.selector) {
      result[groupKey] = groupVal;
    } else {
      for (const [elemKey, elemVal] of Object.entries(groupVal)) {
        if (elemKey.startsWith('_') || typeof elemVal !== 'object' || !elemVal.selector) continue;
        result[elemKey] = elemVal;
      }
    }
  }
  return result;
}

/**
 * Clear the in-memory cache (useful between test suites if app state changes).
 */
function clearCache() {
  cache.clear();
}

module.exports = { loadScreen, flattenElements, clearCache };
