'use strict';

/**
 * stepRunner.js
 *
 * Executes an ordered list of user-provided test steps against a live
 * Samsung Magician page.  Steps can be plain strings or structured objects.
 *
 * ── STEP FORMATS ─────────────────────────────────────────────────────────────
 *
 * String (natural language — parsed automatically):
 *   'navigate to dashboard'
 *   'navigate to system_details'
 *   'navigate to system details'        ← spaces auto-converted to underscores
 *   'navigate to performance benchmark screen'  ← trailing "screen" stripped
 *   'click Export'
 *   'click on Export'                   ← "on" is optional
 *   'click tab System Details'          ← tab buttons (real ARIA role=button)
 *   'verify Memory Information'
 *   'verify text Memory Information'    ← same
 *   'verify absent Error'               ← assert text is NOT present
 *   'wait 2000'                         ← wait N ms
 *   'scroll down'                       ← scroll the viewport (up|down|left|right)
 *   'scroll down 500'                   ← scroll by explicit pixel amount
 *   'select 512MiB'                     ← click an option by its visible label text
 *   'select 512MiB from Test Range'     ← "from X" clause is stripped; clicks "512MiB"
 *
 * Object (explicit — preferred when the string form is ambiguous):
 *   { action: 'navigate',       to: 'system_details' }
 *   { action: 'click',          text: 'Export' }
 *   { action: 'click_tab',      name: 'System Details' }
 *   { action: 'verify',         text: 'Memory Information', exact: false }
 *   { action: 'verify_absent',  text: 'Error' }
 *   { action: 'wait',           ms: 2000 }
 *   { action: 'scroll',         direction: 'down', amount: 300 }
 *   { action: 'select',         text: '512MiB' }
 *   { action: 'cannot_automate', reason: 'requires physical drive removal' }
 *
 * ── NON-AUTOMATABLE STEPS ─────────────────────────────────────────────────────
 *
 * If ANY step cannot be automated the runner throws CannotAutomateError and the
 * test exits immediately with a clear message — it does NOT silently skip.
 *
 * Steps are flagged as non-automatable when:
 *   - action === 'cannot_automate'  (explicit)
 *   - the step text matches a CANNOT_AUTOMATE_PATTERNS entry
 *   - the step string could not be parsed into a known action
 *
 * ── KNOWN SCREENS (for the 'navigate' action) ─────────────────────────────────
 *   dashboard | system_details | performance_benchmark | newsroom | help_center | settings
 *   Multi-word names are normalised: spaces → underscores, trailing "screen" stripped.
 */

const { navigateTo, clickText } = require('./navigator');
const logger                    = require('./logger');

// ── Non-automatable pattern list ──────────────────────────────────────────────

const CANNOT_AUTOMATE_PATTERNS = [
  // File system dialogs (OS-native, not inside the Electron renderer)
  /save\s+(as\s+)?file/i,
  /open\s+file\s+dialog/i,
  /browse\s+for\s+file/i,
  /download/i,

  // Physical hardware interaction
  /plug\s*(in|out)/i,
  /unplug/i,
  /physically/i,
  /remove\s+drive/i,
  /insert\s+drive/i,
  /connect\s+(the\s+)?drive/i,
  /disconnect\s+(the\s+)?drive/i,
  /power\s+(off|cycle)/i,

  // OS-level actions outside the app
  /reboot/i,
  /restart\s+windows/i,
  /restart\s+(the\s+)?computer/i,
  /shutdown/i,
  /log\s*out/i,

  // Destructive drive operations — never automate without explicit opt-in
  /secure\s+erase/i,
  /format\s+drive/i,
  /erase\s+drive/i,
  /over\s*provisioning\s+set/i,   // changes drive-level config
];

// ── Error type ────────────────────────────────────────────────────────────────

class CannotAutomateError extends Error {
  /**
   * @param {string} stepDescription  Human-readable description of the step
   * @param {string} reason           Why it cannot be automated
   */
  constructor(stepDescription, reason) {
    super(
      `\n` +
      `╔══════════════════════════════════════════════════════════════╗\n` +
      `║  CANNOT AUTOMATE — test steps do not cover 100%             ║\n` +
      `╠══════════════════════════════════════════════════════════════╣\n` +
      `║  Step   : ${stepDescription.slice(0, 50).padEnd(50)} ║\n` +
      `║  Reason : ${reason.slice(0, 50).padEnd(50)} ║\n` +
      `╚══════════════════════════════════════════════════════════════╝\n`
    );
    this.name            = 'CannotAutomateError';
    this.stepDescription = stepDescription;
    this.reason          = reason;
  }
}

// ── String parser ─────────────────────────────────────────────────────────────

/**
 * Convert a natural-language step string into a structured step object.
 * Returns { action: 'cannot_automate', reason } if the string is not recognised.
 */
function parseStringStep(raw) {
  const s = raw.trim();

  // navigate to <screen>  — multi-word names OK; trailing "screen" stripped
  //   "navigate to performance_benchmark"       → performance_benchmark
  //   "navigate to performance benchmark"       → performance_benchmark
  //   "navigate to performance benchmark screen"→ performance_benchmark
  const navMatch = s.match(/^navigate\s+to\s+(.+?)(?:\s+screen)?$/i);
  if (navMatch) {
    const to = navMatch[1].trim().toLowerCase().replace(/\s+/g, '_');
    return { action: 'navigate', to };
  }

  // click tab <name>  OR  click <name> tab
  const tabMatch = s.match(/^click\s+(?:the\s+)?(?:tab\s+(.+)|(.+?)\s+tab)$/i);
  if (tabMatch) {
    const name = (tabMatch[1] || tabMatch[2]).trim();
    return { action: 'click_tab', name };
  }

  // click [the|on] <text>
  //   "click Start"          → text: "Start"
  //   "click the Start"      → text: "Start"
  //   "click on Start"       → text: "Start"
  const clickMatch = s.match(/^click\s+(?:(?:the|on)\s+)?(.+)$/i);
  if (clickMatch) return { action: 'click', text: clickMatch[1].trim() };

  // verify absent <text>  /  verify <text> is not present/visible
  const absentMatch = s.match(/^verify\s+(?:absent\s+(.+)|(.+?)\s+is\s+(?:not\s+(?:present|visible|shown)|absent))$/i);
  if (absentMatch) {
    const text = (absentMatch[1] || absentMatch[2]).trim();
    return { action: 'verify_absent', text };
  }

  // verify [text] <text> [is visible/present/shown]
  const verifyMatch = s.match(/^verify\s+(?:text\s+)?(.+?)(?:\s+is\s+(?:visible|present|shown))?$/i);
  if (verifyMatch) return { action: 'verify', text: verifyMatch[1].trim(), exact: false };

  // wait <ms>
  const waitMatch = s.match(/^wait\s+(\d+)(?:\s*ms)?$/i);
  if (waitMatch) return { action: 'wait', ms: parseInt(waitMatch[1], 10) };

  // scroll up|down|left|right [<pixels>]
  //   "scroll down"      → direction: down, amount: 300
  //   "scroll up 500"    → direction: up,   amount: 500
  const scrollMatch = s.match(/^scroll\s+(up|down|left|right)(?:\s+(\d+))?$/i);
  if (scrollMatch) {
    return {
      action:    'scroll',
      direction: scrollMatch[1].toLowerCase(),
      amount:    parseInt(scrollMatch[2] || '300', 10),
    };
  }

  // select <option> [from <field>]
  //   "select 512MiB"                  → text: "512MiB"
  //   "select 512MiB from Test Range"  → text: "512MiB"  (from-clause stripped)
  //   "select Sequential"              → text: "Sequential"
  // Clicks the option text via the DOM walker — works for radio buttons, dropdowns,
  // and any list item whose label is visible as a text node.
  const selectMatch = s.match(/^select\s+(.+?)(?:\s+from\s+.+)?$/i);
  if (selectMatch) return { action: 'select', text: selectMatch[1].trim() };

  // Unrecognised
  return { action: 'cannot_automate', reason: `step not recognised: "${s}"` };
}

// ── Step executor ─────────────────────────────────────────────────────────────

async function executeStep(page, step) {
  switch (step.action) {

    case 'navigate': {
      // navigateTo() handles sidebar poll + clickText + screen-marker verification
      const verifyMap = { newsroom: false, help_center: false };
      await navigateTo(page, step.to, { verify: !(step.to in verifyMap) ? true : verifyMap[step.to] });
      break;
    }

    case 'click': {
      const ok = await clickText(page, step.text);
      if (!ok) throw new Error(`Step failed — could not find clickable text: "${step.text}"`);
      await page.waitForTimeout(500);
      break;
    }

    case 'click_tab': {
      // Tab buttons are the ONLY real ARIA role="button" elements in Samsung Magician.
      // All tabs live on the System Details screen.
      const tab = page.getByRole('button', { name: step.name });
      const cnt = await tab.count();
      if (cnt === 0) throw new Error(`Step failed — tab button not found: "${step.name}"`);
      await tab.first().click();
      await page.waitForTimeout(1_000);
      break;
    }

    case 'verify': {
      const exact  = step.exact ?? false;
      const loc    = page.getByText(step.text, { exact });
      await loc.first().waitFor({ state: 'attached', timeout: 10_000 });
      logger.info({ action: 'step-verify', text: step.text, result: 'present' });
      break;
    }

    case 'verify_absent': {
      const cnt = await page.getByText(step.text, { exact: false }).count();
      if (cnt > 0) {
        throw new Error(`Step failed — text should be absent but was found: "${step.text}"`);
      }
      logger.info({ action: 'step-verify-absent', text: step.text, result: 'absent-confirmed' });
      break;
    }

    case 'wait': {
      const ms = Math.min(step.ms, 30_000);   // cap at 30 s to avoid runaway waits
      await page.waitForTimeout(ms);
      break;
    }

    case 'scroll': {
      // Use mouse.wheel for CDP-connected pages (page.evaluate + scrollBy also works).
      const dx = step.direction === 'left'  ? -step.amount
               : step.direction === 'right' ?  step.amount : 0;
      const dy = step.direction === 'up'    ? -step.amount
               : step.direction === 'down'  ?  step.amount : 0;
      await page.mouse.wheel(dx, dy);
      await page.waitForTimeout(300);   // let the scroll settle
      break;
    }

    case 'select': {
      // Click the option whose visible text matches step.text.
      // Works for radio buttons, dropdown list items, and any clickable label
      // rendered as a DOM text node (Samsung Magician uses no ARIA list roles).
      const ok = await clickText(page, step.text);
      if (!ok) {
        throw new Error(
          `Step failed — could not find selectable option: "${step.text}"\n` +
          `  Run the spike while the popup is open to see available option labels:\n` +
          `  npm run spike`
        );
      }
      await page.waitForTimeout(500);
      logger.info({ action: 'step-select', text: step.text, result: 'selected' });
      break;
    }

    default:
      throw new CannotAutomateError(JSON.stringify(step), `unknown action type: "${step.action}"`);
  }
}

// ── Public API ────────────────────────────────────────────────────────────────

/**
 * Execute an ordered list of steps against a live page.
 * Throws CannotAutomateError immediately if any step cannot be automated.
 *
 * @param {import('@playwright/test').Page} page
 * @param {Array<string|object>} steps
 */
async function runSteps(page, steps) {
  for (let i = 0; i < steps.length; i++) {
    const raw  = steps[i];
    const step = typeof raw === 'string' ? parseStringStep(raw) : raw;

    logger.info({ action: 'run-step', index: i + 1, total: steps.length, step });

    // ── Non-automatable: explicit marker ──────────────────────────────────────
    if (step.action === 'cannot_automate') {
      throw new CannotAutomateError(String(raw), step.reason || 'marked as cannot_automate');
    }

    // ── Non-automatable: natural-language pattern match ───────────────────────
    const rawStr = String(raw);
    for (const pattern of CANNOT_AUTOMATE_PATTERNS) {
      if (pattern.test(rawStr)) {
        throw new CannotAutomateError(rawStr, `matches non-automatable pattern (${pattern.source})`);
      }
    }

    // ── Execute ───────────────────────────────────────────────────────────────
    await executeStep(page, step);
    logger.info({ action: 'run-step', index: i + 1, status: 'done' });
  }
}

module.exports = { runSteps, CannotAutomateError, parseStringStep };
