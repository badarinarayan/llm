'use strict';

const LEVELS = { debug: 0, info: 1, warn: 2, error: 3 };
const MIN_LEVEL = process.env.LOG_LEVEL ? LEVELS[process.env.LOG_LEVEL] ?? 1 : 1;

function log(level, fields) {
  if ((LEVELS[level] ?? 1) < MIN_LEVEL) return;
  const line = {
    timestamp: new Date().toISOString(),
    level,
    ...fields,
  };
  console.log(JSON.stringify(line));
}

module.exports = {
  debug: (fields) => log('debug', fields),
  info:  (fields) => log('info',  fields),
  warn:  (fields) => log('warn',  fields),
  error: (fields) => log('error', fields),
};
