'use strict';

const { execSync, spawn }    = require('child_process');
const { chromium }           = require('playwright');
const logger                 = require('./logger');

const EXE_PATH    = 'C:\\Program Files (x86)\\Samsung\\Samsung Magician\\SamsungMagician.exe';
const SVC_NAME    = 'SamsungMagicianSVC';
const CDP_PORT    = 9222;
const LAUNCH_WAIT = 12_000;   // ms to wait after spawn before expecting UI
const MAX_RETRIES = 3;

// ── Service helpers ───────────────────────────────────────────────────────────

function runCmd(cmd) {
  try { execSync(cmd, { stdio: 'pipe' }); return true; }
  catch (_) { return false; }
}

function stopService() {
  logger.info({ action: 'service-stop', service: SVC_NAME, status: 'starting' });
  const ok = runCmd(`net stop "${SVC_NAME}" /y`);
  logger.info({ action: 'service-stop', service: SVC_NAME, status: ok ? 'stopped' : 'failed-or-not-running' });
  if (!ok) {
    logger.warn({ action: 'service-stop', detail: 'Admin rights may be required. Run terminal as Administrator.' });
  }
  return ok;
}

function startService() {
  logger.info({ action: 'service-start', service: SVC_NAME, status: 'starting' });
  const ok = runCmd(`net start "${SVC_NAME}"`);
  logger.info({ action: 'service-start', service: SVC_NAME, status: ok ? 'started' : 'failed' });
}

function killExistingInstances() {
  const okUi  = runCmd('taskkill /F /IM SamsungMagician.exe');
  const okSvc = runCmd('taskkill /F /IM SamsungMagicianSVC.exe');
  logger.info({ action: 'kill-existing', ui: okUi ? 'killed' : 'none-or-denied', svc: okSvc ? 'killed' : 'none-or-denied' });
}

// ── Spawn + wait for DevTools URL ─────────────────────────────────────────────

function spawnAndWaitForDevTools(timeoutMs = 15_000) {
  return new Promise((resolve, reject) => {
    const proc = spawn(EXE_PATH, [
      `--remote-debugging-port=${CDP_PORT}`,
    ], {
      stdio: ['ignore', 'pipe', 'pipe'],
    });

    proc.stdout.on('data', d =>
      logger.debug({ action: 'spawn-stdout', detail: d.toString().trim() })
    );

    let wsUrl = null;
    proc.stderr.on('data', d => {
      const text = d.toString();
      logger.debug({ action: 'spawn-stderr', detail: text.trim() });
      if (!wsUrl) {
        const m = text.match(/DevTools listening on (ws:\/\/[^\s]+)/);
        if (m) {
          wsUrl = m[1];
          logger.info({ action: 'devtools-url', url: wsUrl });
          resolve({ proc, wsUrl });
        }
      }
    });

    proc.on('exit', code => {
      logger.info({ action: 'spawn-exit', code });
      if (!wsUrl) reject(new Error(`Process exited (code ${code}) before DevTools URL`));
    });

    proc.on('error', err => reject(new Error(`Spawn error: ${err.message}`)));

    setTimeout(() => {
      if (!wsUrl) {
        proc.kill();
        reject(new Error(`Timeout: DevTools URL not seen within ${timeoutMs}ms`));
      }
    }, timeoutMs);
  });
}

// ── Public API ────────────────────────────────────────────────────────────────

/**
 * Launch Samsung Magician with CDP and return { app: { close }, page }.
 *
 * Requires Administrator privileges to stop SamsungMagicianSVC.
 */
async function launchMagician() {
  let lastErr;

  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    try {
      logger.info({ action: 'launch', status: 'starting', attempt });

      // Stop service → release named-pipe lock → kill UI processes
      stopService();
      killExistingInstances();

      // Give OS time to release mutex and pipe handles.
      // 5 s covers the case where the previous spec's afterAll just restarted
      // SamsungMagicianSVC and the service is still initialising when we call
      // stopService() — a too-short gap leaves the service half-alive and it
      // will kill our freshly-spawned app via the named-pipe conflict check.
      await new Promise(r => setTimeout(r, 5_000));

      // Second stop — catches Windows SCM crash-recovery auto-restarts.
      // When taskkill /F kills SamsungMagicianSVC.exe the SCM treats it as a
      // crash and may restart the service within a few seconds.  A second
      // net stop after the sleep ensures the pipe is released before we spawn.
      stopService();
      await new Promise(r => setTimeout(r, 1_000));

      // Spawn the app and wait for DevTools URL
      const { proc, wsUrl } = await spawnAndWaitForDevTools(15_000);

      // Connect via CDP immediately (app may exit in ~60ms if service is still up)
      logger.info({ action: 'cdp-connect', url: wsUrl });
      const browser = await chromium.connectOverCDP(wsUrl, { timeout: 15_000 });

      // Find the main BrowserWindow page
      let page = null;
      const start = Date.now();
      while (!page && Date.now() - start < LAUNCH_WAIT) {
        for (const ctx of browser.contexts()) {
          const pages = ctx.pages();
          if (pages.length > 0) { page = pages[0]; break; }
        }
        if (!page) await new Promise(r => setTimeout(r, 500));
      }

      if (!page) throw new Error('No page found in CDP contexts after timeout');

      // Register listeners before the load wait so we capture early close events.
      page.on('close', () =>
        logger.warn({ action: 'page-closed', detail: 'Renderer page closed unexpectedly — possible SVC restart conflict' })
      );
      page.on('console', msg =>
        logger.debug({ action: 'renderer-console', type: msg.type(), detail: msg.text() })
      );
      page.on('pageerror', err =>
        logger.error({ action: 'renderer-error', detail: err.message })
      );

      await page.waitForLoadState('domcontentloaded');
      await new Promise(r => setTimeout(r, 2_000));   // let UI begin rendering

      // Guard: if the app self-terminated (e.g. SVC restarted and won the
      // named-pipe race), throw so the retry loop can try again.
      if (page.isClosed()) {
        throw new Error('Page closed after launch — SamsungMagicianSVC likely restarted and killed the app');
      }

      // ── Sidebar readiness gate ────────────────────────────────────────────
      // The React app can take 10–30 s to fully hydrate after domcontentloaded.
      // Don't return until 'Home Dashboard' is confirmed in the DOM — that text
      // only appears once the entire sidebar has rendered.  All navigateTo()
      // calls can then proceed immediately without polling.
      const SIDEBAR_READY_MS  = 40_000;
      const SIDEBAR_READY_INT = 500;
      const sidebarDeadline = Date.now() + SIDEBAR_READY_MS;
      let sidebarReady = false;
      logger.info({ action: 'launch', status: 'waiting-for-sidebar' });
      while (!sidebarReady && Date.now() < sidebarDeadline) {
        if (page.isClosed()) {
          throw new Error('Page closed during sidebar readiness wait — SVC race condition');
        }
        sidebarReady = await page.evaluate(() => {
          const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
          let node;
          while ((node = walker.nextNode())) {
            if (node.textContent.trim() === 'Home Dashboard') return true;
          }
          return false;
        }).catch(() => false);
        if (!sidebarReady) await new Promise(r => setTimeout(r, SIDEBAR_READY_INT));
      }
      if (!sidebarReady) {
        throw new Error(`Sidebar did not appear within ${SIDEBAR_READY_MS}ms — app may be stuck on loading screen`);
      }
      logger.info({ action: 'launch', status: 'sidebar-ready', elapsed_ms: SIDEBAR_READY_MS - (sidebarDeadline - Date.now()) });

      logger.info({ action: 'launch', status: 'success', url: page.url() });

      // Return a handle that matches the teardown contract
      return {
        app: {
          close: async () => {
            try { await browser.close(); } catch (_) {}
            try { proc.kill('SIGTERM'); } catch (_) {}
            startService();
          },
        },
        page,
      };
    } catch (err) {
      lastErr = err;
      logger.warn({ action: 'launch', status: 'failed', attempt, detail: err.message });
    }
  }

  throw lastErr;
}

async function closeMagician(app) {
  try {
    await app.close();
    logger.info({ action: 'close', status: 'success' });
  } catch (err) {
    logger.warn({ action: 'close', status: 'error', detail: err.message });
  }
}

module.exports = { launchMagician, closeMagician };
