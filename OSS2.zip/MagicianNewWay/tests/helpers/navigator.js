'use strict';

/**
 * navigator.js
 *
 * Screen navigation helper for Samsung Magician.
 *
 * KEY CONSTRAINT: Samsung Magician v8 has no ARIA roles on sidebar nav items.
 * All sidebar divs have CSS `visibility: hidden` — Playwright's click() fails
 * even with { force: true }. The only working approach is a JS dispatchEvent
 * via page.evaluate() (the "JS DOM walker").
 *
 * HOVER-REVEALED ITEMS (discovered 2026-05-24, spike/output/sidebar_hover_*):
 * Some sidebar items are NOT in the DOM at rest — they are dynamically injected
 * when a parent group receives a mouseover/mouseenter event.
 *   • "Over Provisioning" appears after dispatching mouseover on "Performance Management"
 *   • "Data Migration"   appears after sweeping the mouse across the sidebar
 * These are in HOVER_REVEAL below.  navigateTo() handles them automatically.
 *
 * Usage:
 *   const { navigateTo, clickText, buildLocator } = require('./navigator');
 *   await navigateTo(page, 'system_details');          // sidebar click
 *   await navigateTo(page, 'over_provisioning');       // hover-reveal + click
 *   await clickText(page, 'Export');                   // any text click
 *   const loc = buildLocator(page, element.selector); // from Elements_Config
 */

const logger = require('./logger');

const SETTLE_MS = 2_000;   // ms to wait after a navigation click for content to settle

// ── Sidebar navigation map ────────────────────────────────────────────────────
// Maps screen name → exact label text to click in the sidebar DOM.
const SIDEBAR_LABELS = {
  dashboard:             'Home Dashboard',
  system_details:        'System Details',
  // "Performance Benchmark" also appears as a dashboard widget title — clicking it
  // lands on the widget instead.  "Performance Management" is the correct target.
  performance_benchmark: 'Performance Management',
  // Hover-revealed sub-items (not in DOM until parent is hovered — see HOVER_REVEAL)
  over_provisioning:     'Over Provisioning',
  data_migration:        'Data Migration',
  newsroom:              'Newsroom',
  help_center:           'Help Center',
  // Chatbot — global sidebar item (like Newsroom / Help Center); confirmed 2026-05-24
  chatbot:               'Chatbot',
  settings:              'Settings',
};

// ── Hover-reveal map ──────────────────────────────────────────────────────────
// Screens whose sidebar labels are dynamically injected on hover.
// Value = parent group label to dispatch mouseover on before clicking.
// null  = no specific parent known; fall back to full sidebar mouse sweep.
const HOVER_REVEAL = {
  over_provisioning: 'Performance Management',
  data_migration:    null,   // TBD — parent group not yet confirmed; sweep used
};

// ── Sidebar poll overrides ────────────────────────────────────────────────────
// For hover-revealed items, the target label is not in the DOM until after hover,
// so the sidebar readiness poll uses the parent label (or a stable fallback) instead.
const POLL_LABEL_OVERRIDE = {
  over_provisioning: 'Performance Management',
  data_migration:    'Home Dashboard',   // always present; just waits for sidebar hydration
};

// ── Screen markers ────────────────────────────────────────────────────────────
// Text that proves navigation succeeded.  Checked after the sidebar click.
const SCREEN_MARKERS = {
  dashboard:             'Home Dashboard',        // heading / active nav label
  system_details:        'System Details',        // page heading or tab button
  performance_benchmark: 'Performance Benchmark', // page heading on dedicated screen (pbTitleView_TitleName)
  over_provisioning:     'Over Provisioning',     // confirmed 2026-05-24: lnbMenuView_menuListArea_item_selected
  data_migration:        'Data Migration',        // TODO: confirm — screen not yet captured
  newsroom:              'Newsroom Feature',      // iframe accessible name
  help_center:           'Help Center',           // sidebar label (iframe screen)
  chatbot:               'Chatbot',              // TODO: confirm — screen not yet captured
  settings:              'Settings',              // page heading
};

// ── Hover-reveal helper ───────────────────────────────────────────────────────

/**
 * Reveal a hover-triggered sidebar item by dispatching mouseover on its parent
 * group (or sweeping the real mouse across the sidebar if parent is unknown).
 *
 * @param {import('@playwright/test').Page} page
 * @param {string|null} parentLabel  Parent group text to hover, or null for sweep
 */
async function _revealSidebarItem(page, parentLabel) {
  if (parentLabel) {
    // Dispatch JS mouseover + mouseenter on the parent group element.
    // This is the mechanism that Samsung Magician's React sidebar listens to.
    await page.evaluate((text) => {
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      let node;
      while ((node = walker.nextNode())) {
        if (node.textContent.trim() === text) {
          const el = node.parentElement;
          if (el) {
            el.dispatchEvent(new MouseEvent('mouseover',  { bubbles: true,  cancelable: true }));
            el.dispatchEvent(new MouseEvent('mouseenter', { bubbles: false, cancelable: true }));
          }
          return;
        }
      }
    }, parentLabel);
    logger.debug({ action: 'reveal-sidebar', parentLabel, strategy: 'js-mouseover' });
  } else {
    // Unknown parent — sweep the real mouse cursor down the sidebar column.
    // CSS :hover on the sidebar container reveals items dynamically.
    // Sidebar occupies x≈47, y≈420–940 (from bounding-box inspection 2026-05-24).
    logger.debug({ action: 'reveal-sidebar', parentLabel: null, strategy: 'mouse-sweep' });
    for (let y = 420; y <= 920; y += 40) {
      await page.mouse.move(47, y);
    }
  }
  // Allow React state update and DOM insertion to complete
  await page.waitForTimeout(600);
}

// ── Core helpers ──────────────────────────────────────────────────────────────

/**
 * Click any visible text in the page content (not sidebar).
 * Uses Playwright getByText with force:true, then falls back to JS dispatchEvent.
 *
 * @param {import('@playwright/test').Page} page
 * @param {string} text  Exact visible text to click
 * @returns {Promise<boolean>} true if clicked, false if not found
 */
async function clickText(page, text) {
  // Strategy 1 & 2: Playwright with force (works for main content area)
  for (const exact of [true, false]) {
    try {
      const loc = page.getByText(text, { exact });
      const cnt = await loc.count();
      if (cnt > 0) {
        await loc.first().click({ force: true });
        logger.debug({ action: 'clickText', text, strategy: `playwright-exact-${exact}` });
        return true;
      }
    } catch (e) {
      logger.debug({ action: 'clickText', text, strategy: `playwright-exact-${exact}`, error: e.message.split('\n')[0] });
    }
  }

  // Strategy 3: JS DOM walker — required for sidebar nav items (visibility:hidden)
  try {
    const clicked = await page.evaluate((searchText) => {
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      let node;
      while ((node = walker.nextNode())) {
        if (node.textContent.trim() === searchText) {
          const el = node.parentElement;
          if (el) {
            el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
            return true;
          }
        }
      }
      return false;
    }, text);

    if (clicked) {
      logger.debug({ action: 'clickText', text, strategy: 'js-dom-walker' });
      return true;
    }
  } catch (e) {
    logger.debug({ action: 'clickText', text, strategy: 'js-dom-walker', error: e.message });
  }

  logger.warn({ action: 'clickText', text, result: 'not-found' });
  return false;
}

/**
 * Navigate to a screen by clicking its sidebar label.
 * Handles both always-present labels and hover-revealed sub-items automatically.
 *
 * @param {import('@playwright/test').Page} page
 * @param {string} screenName  Key from SIDEBAR_LABELS (e.g. 'system_details')
 * @param {object} [opts]
 * @param {boolean} [opts.verify=true]  Assert the screen marker becomes visible
 * @returns {Promise<void>}
 * @throws If sidebar label not found or screen marker not visible
 */
async function navigateTo(page, screenName, opts = {}) {
  const { verify = true } = opts;

  const sidebarLabel = SIDEBAR_LABELS[screenName];
  if (!sidebarLabel) {
    throw new Error(`navigator: unknown screen "${screenName}". Known: ${Object.keys(SIDEBAR_LABELS).join(', ')}`);
  }

  const needsHover  = screenName in HOVER_REVEAL;
  const hoverParent = HOVER_REVEAL[screenName];     // may be null
  // For hover-revealed items, the target label is not in DOM yet — poll a stable label
  const pollLabel   = POLL_LABEL_OVERRIDE[screenName] || sidebarLabel;

  logger.info({ action: 'navigate', screen: screenName, sidebarLabel, needsHover, status: 'starting' });

  // ── Sidebar readiness poll ────────────────────────────────────────────────
  // Wait for the sidebar React component to hydrate before clicking.
  // For hover-revealed items we poll the parent/fallback label instead.
  const SIDEBAR_POLL_MS  = 20_000;  // extended: launchMagician now gates on sidebar readiness, but keep margin for mid-session navigations
  const SIDEBAR_POLL_INT = 400;
  const pollDeadline = Date.now() + SIDEBAR_POLL_MS;
  let sidebarReady = false;
  while (!sidebarReady && Date.now() < pollDeadline) {
    sidebarReady = await page.evaluate((text) => {
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      let node;
      while ((node = walker.nextNode())) {
        if (node.textContent.trim() === text) return true;
      }
      return false;
    }, pollLabel).catch(() => false);
    if (!sidebarReady) await page.waitForTimeout(SIDEBAR_POLL_INT);
  }
  if (!sidebarReady) {
    logger.warn({ action: 'navigate', screen: screenName, pollLabel, status: 'sidebar-poll-timeout' });
  }

  // ── Hover-reveal step (only for sub-items not present in DOM at rest) ─────
  if (needsHover) {
    logger.info({ action: 'navigate', screen: screenName, status: 'revealing-hover-item', hoverParent });
    await _revealSidebarItem(page, hoverParent);
  }

  // ── Click the sidebar label ───────────────────────────────────────────────
  const ok = await clickText(page, sidebarLabel);
  if (!ok) {
    throw new Error(`navigator: sidebar label "${sidebarLabel}" not found on page`);
  }

  // Let the SPA route/render
  await page.waitForTimeout(SETTLE_MS);

  // ── Screen marker verification ────────────────────────────────────────────
  if (verify) {
    const marker = SCREEN_MARKERS[screenName];
    if (marker) {
      await page.getByText(marker, { exact: false }).first().waitFor({ state: 'attached', timeout: 10_000 });
      logger.info({ action: 'navigate', screen: screenName, status: 'verified', marker });
    }
  }

  logger.info({ action: 'navigate', screen: screenName, status: 'success' });
}

/**
 * Build a Playwright Locator from an Elements_Config selector descriptor.
 *
 * Selector types:
 *   text      → page.getByText(text, { exact })
 *   role      → page.getByRole(role, { name })
 *   domClick  → page.getByText(text, { exact: true })  (use clickText() for clicking)
 *   iframe    → page.getByRole(role, { name })
 *
 * @param {import('@playwright/test').Page} page
 * @param {object} selector   Element selector descriptor from Elements_Config
 * @returns {import('@playwright/test').Locator}
 */
function buildLocator(page, selector) {
  const { type, text, role, name, exact = true } = selector;

  switch (type) {
    case 'text':
    case 'domClick':
      return page.getByText(text, { exact });

    case 'role':
    case 'iframe':
      return page.getByRole(role, { name });

    default:
      throw new Error(`navigator.buildLocator: unknown selector type "${type}"`);
  }
}

module.exports = { navigateTo, clickText, buildLocator, SIDEBAR_LABELS, SCREEN_MARKERS };
