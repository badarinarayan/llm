'use strict';

/**
 * sidebar_navigation.spec.js
 *
 * Navigation tests — verify all 5 sidebar items click successfully and the
 * correct screen content loads after each navigation.
 *
 * Key constraints documented here for future readers:
 *   - Sidebar items are CSS visibility:hidden — navigateTo() uses JS dispatchEvent
 *   - Newsroom & Help Center are iframe-only screens. Their accessible name
 *     ('Newsroom Feature') is not a text node, so getByText() cannot find it.
 *     We skip navigateTo's built-in marker check ({ verify: false }) and instead
 *     assert that at least one <iframe> element is present in the page DOM.
 *   - Each navigateTo() waits SETTLE_MS (2 000 ms) after clicking before verifying.
 *   - Tests run serially in one shared app instance to avoid multi-launch conflicts.
 *
 * Requires: Administrator PowerShell (for net stop SamsungMagicianSVC).
 */

const { test, expect } = require('@playwright/test');
const { launchMagician, closeMagician } = require('../helpers/appLauncher');
const { loadScreen }                    = require('../helpers/elementLoader');
const { navigateTo, buildLocator }      = require('../helpers/navigator');

test.describe.configure({ mode: 'serial' });

test.describe('Navigation — Sidebar', () => {
  /** @type {{ close: Function }} */
  let app;
  /** @type {import('@playwright/test').Page} */
  let page;

  test.beforeAll(async () => {
    ({ app, page } = await launchMagician());
  }, 90_000);

  test.afterAll(async () => {
    await closeMagician(app);
  }, 30_000);

  // ── 1. Navigate → System Details ────────────────────────────────────────────
  test('navigate to System Details', async () => {
    test.setTimeout(30_000);
    await navigateTo(page, 'system_details');

    const config = loadScreen('system_details');
    const heading = buildLocator(page, config.page_structure.page_heading.selector);
    await expect(heading.first()).toBeAttached();
  });

  // ── 2. Navigate → Newsroom ──────────────────────────────────────────────────
  test('navigate to Newsroom (iframe screen)', async () => {
    test.setTimeout(30_000);
    // { verify: false } — skip text-marker check; the screen's accessible name
    // ('Newsroom Feature') is not findable via getByText (it's an iframe title).
    await navigateTo(page, 'newsroom', { verify: false });

    const iframeCount = await page.locator('iframe').count();
    expect(iframeCount, 'expected at least one <iframe> on Newsroom screen').toBeGreaterThan(0);
  });

  // ── 3. Navigate → Help Center ───────────────────────────────────────────────
  test('navigate to Help Center (iframe screen)', async () => {
    test.setTimeout(30_000);
    await navigateTo(page, 'help_center', { verify: false });

    const iframeCount = await page.locator('iframe').count();
    expect(iframeCount, 'expected at least one <iframe> on Help Center screen').toBeGreaterThan(0);
  });

  // ── 4. Navigate → Settings ──────────────────────────────────────────────────
  test('navigate to Settings', async () => {
    test.setTimeout(30_000);
    await navigateTo(page, 'settings');

    const config = loadScreen('settings');
    const heading = buildLocator(page, config.page_structure.page_heading.selector);
    await expect(heading.first()).toBeAttached();
  });

  // ── 5. Navigate back → Home Dashboard ──────────────────────────────────────
  test('navigate back to Home Dashboard', async () => {
    test.setTimeout(30_000);
    await navigateTo(page, 'dashboard');
    await expect(
      page.getByText('Home Dashboard', { exact: true }).first()
    ).toBeAttached();
  });

  // ── 6. Back-navigation: Dashboard → Settings → Dashboard ───────────────────
  test('back navigation: dashboard → settings → dashboard', async () => {
    test.setTimeout(60_000);

    // Go to Settings
    await navigateTo(page, 'settings');
    const settingsConfig = loadScreen('settings');
    await expect(
      buildLocator(page, settingsConfig.page_structure.page_heading.selector).first()
    ).toBeAttached();

    // Return to Dashboard
    await navigateTo(page, 'dashboard');
    await expect(
      page.getByText('Home Dashboard', { exact: true }).first()
    ).toBeAttached();
  });

  // ── 7. Full round-trip: all 5 screens in sequence ──────────────────────────
  test('full round-trip through all 5 screens', async () => {
    test.setTimeout(120_000);  // 5 screens × ~20s each + 20s buffer

    // ① Dashboard
    await navigateTo(page, 'dashboard');
    await expect(
      page.getByText('Home Dashboard', { exact: true }).first()
    ).toBeAttached();

    // ② System Details
    await navigateTo(page, 'system_details');
    const sdConfig = loadScreen('system_details');
    await expect(
      buildLocator(page, sdConfig.page_structure.page_heading.selector).first()
    ).toBeAttached();

    // ③ Newsroom (iframe)
    await navigateTo(page, 'newsroom', { verify: false });
    expect(
      await page.locator('iframe').count(),
      'Newsroom: expected <iframe> in DOM'
    ).toBeGreaterThan(0);

    // ④ Help Center (iframe)
    await navigateTo(page, 'help_center', { verify: false });
    expect(
      await page.locator('iframe').count(),
      'Help Center: expected <iframe> in DOM'
    ).toBeGreaterThan(0);

    // ⑤ Settings
    await navigateTo(page, 'settings');
    const sConfig = loadScreen('settings');
    await expect(
      buildLocator(page, sConfig.page_structure.page_heading.selector).first()
    ).toBeAttached();
  });
});
