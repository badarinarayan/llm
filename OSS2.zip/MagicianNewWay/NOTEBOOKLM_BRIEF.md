# Samsung Magician Test Automation Framework
## NotebookLM Source Brief — Infographics & Slide Deck

---

## OVERVIEW: What This Project Is

**Samsung Magician** is a Windows desktop application used to manage Samsung SSDs — running benchmarks, checking drive health, updating firmware, and configuring storage. It is an Electron app (Chromium-based renderer) backed by a Windows service called `SamsungMagicianSVC`.

This project builds **two things on top of Samsung Magician**:

1. **A Playwright test automation framework** — automated tests that drive the app through CDP (Chrome DevTools Protocol), navigate screens, and assert UI state using text-based selectors.

2. **An AI self-healing agent** — a Python/LangGraph agent that accepts natural-language test steps, executes them, diagnoses failures using GPT-4o, re-inspects the live UI, patches element configs, and retries — all automatically.

**Core challenge:** Samsung Magician was not designed to be automated. It has three single-instance security locks, no ARIA roles, CSS-hidden sidebar elements, and hover-revealed sub-menus. Every standard automation technique fails — all approaches had to be discovered from scratch.

---

## THE PROBLEM IN NUMBERS

| Challenge | Impact |
|-----------|--------|
| 3 single-instance lock layers | App quits within 60 ms of launch unless all 3 are bypassed |
| 0 ARIA roles on interactive elements | `page.getByRole()` returns nothing useful |
| CSS `visibility: hidden` on sidebar | Playwright `.click({ force: true })` silently fails |
| 10–30 seconds for sidebar to hydrate | First navigation fails if attempted too early |
| 9 confirmed screens | 2 require hover to even appear in the DOM |
| 1 Windows service (`SamsungMagicianSVC`) | Must be stopped AND both EXEs killed before each test |

---

## ARCHITECTURE: THREE LAYERS

```
LAYER 1 — ELEMENT CONFIGS (JSON)
  Elements_Config/*.json
  One file per screen · Stores text selectors · Source of truth
  Updated manually or auto-patched by the AI agent

LAYER 2 — PLAYWRIGHT TEST FRAMEWORK (Node.js)
  appLauncher.js  →  navigator.js  →  elementLoader.js
  CDP connection · JS DOM walker clicks · Three-strategy cascade
  9 screens · 66 tests · workers:1 (single-instance constraint)

LAYER 3 — AI SELF-HEALING AGENT (Python)
  parse_steps.py → execute_steps.py → diagnose.py
  → reinspect.py → update_config.py → retry
  LangGraph · GPT-4o · ChromaDB · Streamlit UI
```

---

## THE SINGLE BIGGEST DISCOVERY: HOW TO LAUNCH THE APP

Standard approach (using `_electron.launch()`): **FAILS** — app detects `--inspect` flag and calls `app.quit()`.

**The actual working launch sequence (8 steps, 50+ seconds):**

```
Step 1  →  net stop SamsungMagicianSVC        (releases named-pipe lock)
Step 2  →  taskkill SamsungMagician.exe        (kill UI process)
           taskkill SamsungMagicianSVC.exe     (kill service EXE — BOTH required)
Step 3  →  Sleep 5 seconds                    (OS releases mutex + pipe handles)
Step 4  →  net stop SamsungMagicianSVC (again) (catches Windows SCM auto-restart)
Step 5  →  Sleep 1 second
Step 6  →  Spawn with --remote-debugging-port=9222
Step 7  →  Capture DevTools URL from stderr → connectOverCDP()
Step 8  →  Poll DOM for "Home Dashboard" text  (up to 40 seconds)
           ↓ Only return AFTER sidebar is fully rendered
```

**Why step 4 exists:** Windows Service Control Manager treats `taskkill` as a crash and auto-restarts the service within seconds. A second `net stop` catches this race.

**Why step 8 exists:** The React sidebar takes 10–30 seconds to hydrate after `domcontentloaded`. If navigation is attempted before "Home Dashboard" appears in the DOM, all sidebar clicks fail silently.

---

## THE NAVIGATION PROBLEM: THREE STRATEGIES

Samsung Magician sidebar items have CSS `visibility: hidden`. This breaks every standard Playwright click approach.

**Strategy Cascade in `clickText(page, text)`:**

```
Strategy 1: page.getByText(exact=true).click({ force: true })
            ✓ Works for main content area buttons
            ✗ Fails for sidebar (visibility:hidden)

Strategy 2: page.getByText(exact=false).click({ force: true })
            ✓ Works for fuzzy content matches
            ✗ Still fails for sidebar

Strategy 3: JS DOM Walker via page.evaluate()
            document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT)
            → find exact textContent.trim() match
            → el.dispatchEvent(new MouseEvent('click', { bubbles: true }))
            ✓ WORKS for sidebar (bypasses CSS visibility check entirely)
            ← This is the key discovery
```

**The insight:** The React event system processes `dispatchEvent` regardless of CSS visibility. Playwright's click goes through the rendering engine and respects `visibility: hidden`. Direct DOM event dispatch does not.

---

## THE HOVER PROBLEM: ITEMS NOT IN THE DOM

Two sidebar items don't exist in the HTML at all until a parent group is hovered:

| Sub-screen | Trigger | Parent Group |
|------------|---------|-------------|
| Over Provisioning | JS `dispatchEvent(mouseover + mouseenter)` on parent | Performance Management |
| Data Migration | Real mouse sweep across sidebar column (x≈47) | Likely Data Management |

**Why these two are different:**
- `Over Provisioning` responds to JavaScript synthetic events — fast, reliable
- `Data Migration` requires a real mouse cursor movement — React's CSS `:hover` state is only triggered by genuine pointer input, not synthetic events

**Fix:** `navigateTo()` in navigator.js auto-detects hover-required screens via `HOVER_REVEAL` map and calls `_revealSidebarItem()` before clicking. Callers never need to think about this.

---

## FULL SIDEBAR STRUCTURE (CONFIRMED 2026-05-24)

```
Samsung Magician Sidebar
│
├── Home Dashboard                    [direct click]
│
├── Diagnosis & Information  [group]  [hover to reveal sub-items — TBD]
│
├── Performance Management   [group]  [hover to reveal]
│   ├── Performance Benchmark         [sub-item]
│   ├── Performance Optimization      [sub-item]
│   └── Over Provisioning             [sub-item — hover-revealed]
│
├── Data Management          [group]  [hover to reveal]
│   └── Data Migration                [sub-item — mouse-sweep revealed]
│
├── Security Settings        [group]  [hover to reveal sub-items — TBD]
│
├── System Details                    [direct click]
├── Newsroom                          [direct click — iframe screen]
├── Help Center                       [direct click — iframe screen]
├── Chatbot                           [direct click]
└── Settings                          [direct click]
```

**4 collapsed groups, 5 global items, 9 confirmed navigable screens.**

---

## WHAT ARIA ROLES EXIST (AND DON'T)

Samsung Magician has almost no ARIA roles on interactive elements. This is highly unusual for an Electron app and makes standard automation impossible.

**Roles that exist:**
- `RootWebArea` — page root (1 per page)
- `StaticText` / `InlineTextBox` — all visible text
- `generic` — nearly all containers and interactive divs
- `none` — wrapper divs
- `image` — icons only
- `Iframe` — Newsroom and Help Center content areas

**The one exception:**
- `button` — exists ONLY on the System Details screen (3 tab buttons)
- `DescriptionList` / `term` / `definition` — System Details only

**Consequence:** `page.getByRole('button')` works on exactly 1 of 9 screens. Everywhere else, text-based selection is the only option.

---

## THE 9 CONFIRMED SCREENS

| Screen | Navigation | Text Nodes | Special Notes |
|--------|-----------|------------|---------------|
| Home Dashboard | Direct click | ~111 | Default landing; 4 embedded widgets |
| System Details | Direct click | ~89 | Only screen with real ARIA button roles |
| Performance Benchmark | Hover PM → click | ~179 | LNB sub-nav shared with OP and PO |
| Over Provisioning | Hover PM → click | ~24 | Hover-revealed; "unsupported" on non-Samsung drives |
| Data Migration | Mouse sweep | TBD | Hover-revealed via mouse |
| Newsroom | Direct click | ~16 | External iframe — content not accessible |
| Help Center | Direct click | ~15 | External iframe — same pattern as Newsroom |
| Chatbot | Direct click | TBD | Confirmed in sidebar; content not captured |
| Settings | Direct click | ~39 | Startup options, drive health config |

**Total DOM text nodes inspectable via CDP:** ~577 across 7 confirmed screens.

---

## ARIA FINDING: SYSTEM DETAILS TAB TRAP

**The bug:** Tests for "Memory Information" content were passing on the developer machine but failing elsewhere.

**Root cause chain:**
1. Spike was run with "System Details" tab already active (stale user-data-dir preserved tab state)
2. Default tab when opening fresh is "System Summary" — not "System Details"
3. "Motherboard" and "BIOS" sections appear in **both** tabs → tests gave false passes
4. "Memory Information" appears **only** in the System Details tab
5. Slot count suffix `(2/2)` is machine-specific

**Fix:** Explicit tab click in `beforeAll`, `exact: false` for text matching, `test.skip` guard for tab-specific tests.

---

## THE AI AGENT: HOW IT WORKS

### Natural Language → Executed Test

```
User writes plain English:
  "click the Setup Benchmark button"
  "verify that Sequential Read speed value is displayed."
  "click Performance Management section in the left sidebar."

Parser (parse_steps.py) converts to structured steps:
  { action: "click",    text: "Setup Benchmark" }
  { action: "verify",   text: "Sequential Read" }
  { action: "navigate", to:   "performance_benchmark",
    _converted_from: "click" }   ← auto-converted via sidebar map

Node.js bridge (run_steps.js) executes against live app:
  navigateTo(page, 'performance_benchmark')
  clickText(page, 'Setup Benchmark')
  page.getByText('Sequential Read').waitFor({ state: 'attached' })
```

### Self-Healing Loop

```
Execute Steps
     │
     ├── All pass ──────────────────────────────── Report Success ✅
     │
     └── Failure detected
              │
         Diagnose (GPT-4o)
              │
              ├── needs_reinspect: true ──► Reinspect (launch app, capture DOM)
              │                                    │
              │                              Update Config (patch JSON)
              │                                    │
              └── needs_reinspect: false ──► Update Config (use existing DOM)
                                                   │
                                              Retry (attempt N of max_retries)
                                                   │
                                            Execute Steps (again)
                                                   │
                                    ┌──────── All pass ──► Report Success ✅
                                    └── Still failing after max retries ──► Report Failure ❌
```

**Default max retries: 3**

---

## PARSER INTELLIGENCE: WHAT GETS STRIPPED

The natural-language parser handles verbose, human-written test steps:

| Raw Input | Extracted Target | Rule Applied |
|-----------|-----------------|--------------|
| `click "Setup Benchmark" button` | `Setup Benchmark` | Quoted text extraction |
| `click the Start button` | `Start` | Strip "the" + "button" |
| `click Performance Management section in the left sidebar.` | navigate → `performance_benchmark` | Sidebar map auto-convert |
| `verify that Sequential Read speed value is displayed.` | `Sequential Read` | Strip "that", strip "speed value is displayed" |
| `verify "Memory Information" is present` | `Memory Information` | Quoted text extraction |
| `verify Sequential Read (4K) speed value` | `Sequential Read` | Strip "(4K)" + "speed value" |

**Noise words stripped from click steps:** `button`, `section`, `link`, `tab`, `menu`, `icon`, `item`, `option`, `field`, `control`, `in the left sidebar`, `in the sidebar`

**Noise phrases stripped from verify steps:** `is displayed`, `is shown`, `is visible`, `is present`, `is correct`, `is available`, `is enabled`, `is active`, `speed value`, `performance metric`, `(4K)`, `(1MB)`

---

## CHROMADB: THE AGENT'S MEMORY

The agent uses ChromaDB (in-process vector database) to remember UI elements across runs.

**Collection:** `magician_elements`

**Two sources of data:**
1. **Config seed** — loaded from `Elements_Config/*.json` on demand. Each element gets an embedding of `"{text} {description} {css_class}"`. Deterministic ID: `screen__element_key`.
2. **Reinspect discoveries** — every live DOM capture indexes all text nodes. ID: `screen__reinspect__text`.

**How it helps:**
- Before calling GPT-4o, the agent searches ChromaDB for elements similar to the failing step
- Results give GPT-4o context: "here's what we know exists on this screen"
- Over time, the database grows richer — the agent gets better at diagnosing failures on known screens

**Embedding model options:**
- With `OPENAI_API_KEY`: `text-embedding-3-small` (OpenAI) — consistent with GPT-4o
- Without API key: `all-MiniLM-L6-v2` (local, ~80 MB) — fully offline fallback

---

## FAILURE DIAGNOSIS: GPT-4o PROMPT STRUCTURE

When a step fails, the agent builds a diagnosis prompt containing:

```
1. Failed step JSON         (what we tried to do)
2. Error message            (what went wrong)
3. Pre-classified category  (element_not_found | page_closed | navigation_failed | timeout)
4. Screen name              (inferred from last navigate step)
5. DOM snapshot at failure  (first 30 text nodes — captured by run_steps.js)
6. Similar known elements   (top 5 ChromaDB matches)
```

GPT-4o returns:
- `root_cause` — one sentence
- `needs_reinspect` — boolean (launch app again to capture live DOM?)
- `elements_to_find` — list of text labels to look for
- `suggested_fix` — corrected step text or instruction

**No API key?** Heuristic fallback rules handle all 4 categories without any AI call.

---

## TECH STACK SUMMARY

| Layer | Technology | Why |
|-------|-----------|-----|
| Test runner | Playwright (Node.js) | CDP support for Electron |
| App connection | `chromium.connectOverCDP()` | Only approach that works — `_electron.launch()` triggers app quit |
| AX tree | CDP `Accessibility.getFullAXTree` | `page.accessibility` is undefined over CDP |
| Element finding | JS DOM TreeWalker + dispatchEvent | Bypasses CSS visibility:hidden |
| Element configs | JSON files (`Elements_Config/`) | Human-readable, diffable, auto-patchable |
| Agent orchestration | LangGraph (Python) | Stateful retry loop with conditional routing |
| AI reasoning | GPT-4o | Failure classification + DOM-to-selector mapping |
| Embeddings | OpenAI text-embedding-3-small | Semantic element search |
| Vector DB | ChromaDB (in-process) | No server needed; persists to `chroma_db/` folder |
| UI | Streamlit | Live streaming log + results tabs |
| CLI | `python -m agentic.run` | Headless execution without Streamlit |

---

## THE RACE CONDITION: SERVICE RESTART BUG

**This bug caused tests to pass alone but fail when run as part of the full suite.**

**The timeline:**

```
Spec A afterAll:
  └── closeMagician()
       └── startService()  ← SVC starts but named-pipe NOT yet open (takes 2-3s)

Spec B beforeAll (starts immediately):
  └── launchMagician()
       ├── stopService()    ← SVC still initializing; stop succeeds BUT...
       ├── Sleep 3s         ← too short; SVC finishes starting during this sleep
       ├── Spawn app
       └── SVC wins named-pipe race → app calls app.quit() → test crashes

Error: "Target page, context or browser has been closed"
```

**Three-part fix:**

1. Pre-spawn sleep: `3 seconds → 5 seconds`
2. **Second `stopService()` call** after the 5s sleep (new — catches SCM auto-restart)
3. `page.isClosed()` guard after launch → throws → retry loop catches it

**Result:** Race condition eliminated across all spec orderings.

---

## REINSPECTION SYSTEM: KEEPING CONFIGS FRESH

When Samsung Magician is updated or new hardware is connected, element selectors may change.

**`npm run reinspect`** — dry-run comparison:
1. Launches app with a fresh user-data-dir (no stale tab state)
2. Navigates to every known screen
3. Captures all DOM text nodes
4. Diffs against `Elements_Config/*.json` — reports "missing" and "new" elements
5. Outputs: console report + `spike/output/reinspect_*.json`

**`npm run reinspect:update`** — auto-patches configs:
- New elements → added to `_discovered_YYYYMMDD` group marked `[REVIEW]`
- New screens → full skeleton config created
- Human reviews and moves entries to correct named groups

**`npm run reinspect:drives`** — cycles through all connected drives:
- Clicks drive-switcher arrows to step through each drive
- Re-runs reinspect for each drive context
- Different drives may unlock different screens/features

---

## ELEMENTS_CONFIG: THE SOURCE OF TRUTH

Each screen has one JSON file. Example structure:

```
Elements_Config/
  dashboard.json            ~111 elements
  system_details.json       ~89 elements, 3 real ARIA buttons
  performance_benchmark.json ~179 elements, LNB nav
  over_provisioning.json    ~24 elements
  data_migration.json       skeleton (content TBD)
  newsroom.json             iframe shell
  help_center.json          iframe shell
  settings.json             ~39 elements
```

**Four standard groups in every config:**
- `navigation` — sidebar click targets for all 9 screens (type: `domClick`)
- `header` — global header elements (Update badge, Notice badge, drive name)
- `page_structure` — page heading, LNB tabs if applicable
- Screen-specific groups (e.g., `controls`, `results`, `lnb_navigation`, `content`)

**Selector types:**

| Type | Playwright API | Use case |
|------|---------------|----------|
| `text` | `getByText(text, {exact})` | All content-area elements |
| `role` | `getByRole(role, {name})` | System Details tab buttons only |
| `domClick` | `getByText()` locate + `clickText()` click | Sidebar nav items |
| `iframe` | `getByRole('Iframe', {name})` | Newsroom/Help Center |

**Dynamic elements** (marked `"dynamic": true`): drive model, temperature, benchmark scores, ON/OFF states. Never assert their values — only their presence.

---

## KEY NUMBERS AT A GLANCE

| Metric | Value |
|--------|-------|
| Screens confirmed | 9 |
| Screens requiring hover-reveal | 2 |
| Total Playwright tests | 66 |
| Test spec files | 7 |
| Worker count (mandatory) | 1 |
| Single-instance lock layers | 3 |
| Launch sequence steps | 8 |
| Sidebar readiness gate timeout | 40 seconds |
| Agent max retries (default) | 3 |
| Subprocess timeout (run_steps.js) | 6 minutes |
| Reinspect timeout per screen | 3 minutes |
| ChromaDB similarity score range | 0.0 (unrelated) – 1.0 (identical) |
| GPT-4o context: DOM snapshot size | 30 text nodes |
| GPT-4o context: text nodes for matching | 60 text nodes |
| ChromaDB results fed to GPT-4o | 5 similar elements |

---

## WHAT DOESN'T WORK (DO-NOT LIST)

These approaches seem reasonable but all fail for specific technical reasons:

| Approach | Why It Fails |
|----------|-------------|
| `_electron.launch()` | App detects `--inspect` flag → calls `app.quit()` |
| `page.getByRole()` for navigation | No ARIA roles on interactive elements |
| `page.accessibility.snapshot()` | Returns `undefined` when connected via `connectOverCDP()` |
| `toBeVisible()` on sidebar elements | CSS `visibility: hidden` → assertion always fails |
| Kill only `SamsungMagician.exe` | SVC keeps named pipe alive → next spawn quits in 60ms |
| `workers: 2+` in config | Single-instance app → parallel workers crash each other |
| Assert exact drive/temp values | Machine-specific → tests fail on any different hardware |
| Assume "System Details" is default tab | Default is "System Summary" → content missing |
| `clickText('Over Provisioning')` directly | Text not in DOM until `_revealSidebarItem()` called |
| Run without Administrator | `net stop` silently fails → service stays alive → app quits |

---

## STREAMLIT UI: REAL-TIME TEST DASHBOARD

The Streamlit dashboard (`streamlit run agentic/ui/app.py`) provides:

**Left column (dynamic output):**
- Live execution log (last 60 lines, streaming)
- Progress bar with phase icons: 📝 Parsing → ▶️ Executing → 🔍 Diagnosing → 🔎 Reinspecting → ✏️ Updating
- Final results: ✅/❌ banner + 5-metric row (Total/Passed/Failed/Retries/Config Patches)
- Three result tabs: Step Details · Config Patches · Full Log (downloadable)

**Right column (static inputs):**
- File uploader for `.txt` test step files
- Syntax reference card
- `▶ Create TC` button (disabled until file loaded)

**Sidebar (config):**
- OpenAI API Key input (password field)
- Max retries slider (1–5)
- Seed Knowledge Base button
- Admin warning

---

## FLOW DIAGRAM: COMPLETE END-TO-END

```
Developer writes test steps (.txt file)
            │
            ▼
    Upload to Streamlit UI
    OR run: python -m agentic.run test.txt
            │
            ▼
    parse_steps.py
    ├── Extract quoted text from each line
    ├── Strip noise words (button, section, is displayed...)
    ├── Auto-convert sidebar clicks → navigate actions
    └── Output: list of structured step dicts
            │
            ▼
    execute_steps.py
    └── Writes temp JSON → node run_steps.js → reads result JSON
                │
                ▼
         run_steps.js (Node.js)
         ├── launchMagician() → 8-step sequence → CDP connected
         ├── For each step:
         │    navigate  → navigateTo(page, screen)
         │    click     → clickText(page, text) [3-strategy]
         │    verify    → getByText().waitFor({attached})
         │    wait      → waitForTimeout(ms)
         │    scroll    → mouse.wheel(dx, dy)
         │    select    → clickText(page, text) [React dropdowns]
         ├── Stop on first failure + capture DOM snapshot
         └── Write results JSON → exit 0 or 1
            │
            ├── All passed ─────────────────────► report_success ✅
            │
            └── Failure detected
                     │
                 diagnose.py
                 ├── Search ChromaDB for similar elements
                 ├── Call GPT-4o with step + error + DOM + context
                 │   OR use heuristic rules (no API key)
                 └── Output: root_cause + needs_reinspect + suggested_fix
                     │
                     ├── needs_reinspect: true
                     │        │
                     │    reinspect.py
                     │    └── node capture_dom.js
                     │         ├── launchMagician()
                     │         ├── navigateTo(screen)
                     │         ├── Pre-actions (e.g. click "Setup Benchmark")
                     │         ├── Capture: text_nodes + ax_nodes + selects
                     │         └── Index discoveries into ChromaDB
                     │
                     └── update_config.py
                          ├── Match failure to DOM element (GPT-4o or heuristic)
                          ├── Patch Elements_Config/<screen>.json
                          │   └── Adds to _discovered_by_agent group [REVIEW]
                          └── Record patch in config_patches
                                   │
                               retry_node
                               └── retry_count++
                                        │
                                   execute_steps.py (again)
                                        │
                                   max retries reached? → report_failure ❌
```

---

## THREE SPIKE CATEGORIES

The project includes inspection scripts for three purposes:

**1. Discovery spikes** (run once, read-only):
- `npm run spike` — captures AX trees for 5 screens
- `npm run spike:all-screens` — hovers all groups, clicks all revealed items, captures everything
- `npm run spike:sidebar-hover` — investigates what hover events reveal what items

**2. Re-inspection** (run when app changes):
- `npm run reinspect` — dry-run diff: what's in configs vs. what's in the live UI
- `npm run reinspect:update` — patches configs with newly discovered elements
- `npm run reinspect:drives` — cycles through all connected SSDs

**3. Agentic capture** (called automatically by the AI agent):
- `capture_dom.js` — navigates to a screen, performs pre-actions, dumps full DOM
- Called by `reinspect.py` when a step fails and the agent needs fresh DOM data

---

## HUMAN REVIEW WORKFLOW: WHAT TO DO AFTER AUTO-PATCHES

When the agent patches a config, new elements land in `_discovered_by_agent`:

```json
"_discovered_by_agent": {
  "_note": "Elements discovered by the AI agent. Review and move to correct groups.",
  "setup_benchmark": {
    "selector": { "type": "text", "text": "Setup Benchmark", "exact": true },
    "description": "Auto-discovered: Opens benchmark configuration popup",
    "type": "action",
    "cssClass": "pbView_setup_btn",
    "_status": "[REVIEW] — discovered by agent, confirm before promoting"
  }
}
```

**Human review checklist:**
1. Open the patched `Elements_Config/<screen>.json`
2. Find `_discovered_by_agent` group entries
3. Move each to the correct named group (`controls`, `navigation`, `page_structure`, etc.)
4. Change `"dynamic": true` to `false` if the element value is stable
5. Update `"type"` from `"unknown"` to correct type (`action`, `label`, `info`, `badge`)
6. Remove `[REVIEW]` from `_status`
7. Delete `_discovered_by_agent` group when empty

---

## ORIGINAL PLAN VS. REALITY

The project started with standard assumptions about Electron automation. Every assumption was wrong.

| What We Expected | What We Found |
|-----------------|--------------|
| `_electron.launch()` works | App quits on `--inspect` — must use CDP |
| ARIA roles on all interactive elements | Almost none — React renders without accessibility |
| Sidebar items are normal clickable elements | CSS `visibility: hidden` — invisible to Playwright |
| App starts in ~2 seconds | Sidebar takes 10–30 seconds to hydrate |
| One single-instance check | Three layered checks — service + global + Electron lock |
| 10 screens with standard ARIA structure | 9 screens, 2 hover-revealed, 2 with external iframes |
| Simple `getByRole()` selectors | Custom text-matching + JS DOM walker for all navigation |
| Configs maintainable manually | Required an AI agent to keep up with app changes |

**The result:** A framework that works despite these constraints, plus an AI layer that heals itself when elements change — turning a hard maintenance problem into an automated feedback loop.
