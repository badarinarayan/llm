# Samsung Magician Test Automation — Complete Knowledge Base

> **Purpose:** Everything needed to clone this repo and run it on a new machine,
> including every hard-won technical finding so no discovery work needs to be repeated.

---

## Table of Contents

1. [Machine Setup](#1-machine-setup)
2. [Project Structure](#2-project-structure)
3. [Samsung Magician — App Architecture](#3-samsung-magician--app-architecture)
4. [Critical: How to Launch the App for Testing](#4-critical-how-to-launch-the-app-for-testing)
5. [Navigation — JS DOM Walker Pattern](#5-navigation--js-dom-walker-pattern)
6. [Full Sidebar Structure](#6-full-sidebar-structure)
7. [Hover-Revealed Sidebar Items](#7-hover-revealed-sidebar-items)
8. [Confirmed Screens & Element Configs](#8-confirmed-screens--element-configs)
9. [ARIA Roles — What Exists and What Doesn't](#9-aria-roles--what-exists-and-what-doesnt)
10. [Running the Playwright Test Suite](#10-running-the-playwright-test-suite)
11. [Running the Spike / Inspection Scripts](#11-running-the-spike--inspection-scripts)
12. [Agentic Flow — AI Self-Healing Agent](#12-agentic-flow--ai-self-healing-agent)
13. [Writing Natural-Language Test Steps](#13-writing-natural-language-test-steps)
14. [Elements_Config JSON Format](#14-elements_config-json-format)
15. [Known Bugs Fixed & Why](#15-known-bugs-fixed--why)
16. [Do-Not List](#16-do-not-list)
17. [Troubleshooting](#17-troubleshooting)
18. [Implementation Reference — Agentic Layer](#18-implementation-reference--agentic-layer)
19. [Implementation Reference — Node.js Bridge Scripts](#19-implementation-reference--nodejs-bridge-scripts)
20. [Implementation Reference — ChromaDB / element_store.py](#20-implementation-reference--chromadb--element_storepy)
21. [Implementation Reference — Test Helpers](#21-implementation-reference--test-helpers)
22. [Implementation Reference — Streamlit UI](#22-implementation-reference--streamlit-ui)
23. [npm Scripts Reference](#23-npm-scripts-reference)
24. [Original Requirements vs. Reality](#24-original-requirements-vs-reality)

---

## 1. Machine Setup

### Prerequisites

| Requirement | Notes |
|-------------|-------|
| **Samsung Magician installed** | `C:\Program Files (x86)\Samsung\Samsung Magician\SamsungMagician.exe` |
| **Node.js 18+** | `node --version` |
| **Python 3.11+** | For the agentic flow only |
| **Administrator PowerShell** | Required — test framework stops a Windows service |
| **OpenAI API key** | Optional — heuristic fallback works without it |

### Node.js setup

```powershell
# Open Administrator PowerShell
cd C:\code\MagicianNewWay
npm install
```

### Python setup (for agentic flow only)

```powershell
pip install -r requirements-agentic.txt
```

Create `.env` at the project root (copy from `.env.example`):

```
OPENAI_API_KEY=sk-...
```

### Verify app path

```powershell
Test-Path "C:\Program Files (x86)\Samsung\Samsung Magician\SamsungMagician.exe"
# Must return True
```

If Samsung Magician is installed elsewhere, update `EXE_PATH` in:
- `tests/helpers/appLauncher.js`
- `spike/capture_accessibility_tree.js`
- `spike/reinspect.js`

---

## 2. Project Structure

```
MagicianNewWay/
│
├── Elements_Config/          ← SOURCE OF TRUTH for all UI selectors (one JSON per screen)
│   ├── dashboard.json
│   ├── system_details.json
│   ├── performance_benchmark.json
│   ├── over_provisioning.json
│   ├── data_migration.json
│   ├── newsroom.json
│   ├── help_center.json
│   └── settings.json
│
├── tests/
│   ├── helpers/
│   │   ├── appLauncher.js    ← launchMagician() / closeMagician() — SVC race-condition logic
│   │   ├── navigator.js      ← navigateTo(), clickText(), buildLocator()
│   │   ├── elementLoader.js  ← loadScreen(), flattenElements() — reads Elements_Config
│   │   └── logger.js         ← Structured JSON logger → logs/
│   ├── smoke/
│   │   └── app_launch.spec.js
│   ├── navigation/
│   │   └── sidebar_navigation.spec.js
│   └── screens/
│       ├── dashboard.spec.js
│       ├── system_details.spec.js
│       ├── newsroom.spec.js
│       ├── help_center.spec.js
│       └── settings.spec.js
│
├── spike/                    ← Read-only inspection scripts (safe to run anytime)
│   ├── capture_accessibility_tree.js   ← npm run spike
│   ├── inspect_sidebar_hover.js        ← npm run spike:sidebar-hover
│   ├── inspect_all_screens.js          ← npm run spike:all-screens
│   ├── reinspect.js                    ← npm run reinspect
│   ├── lib/
│   │   └── configDiff.js
│   ├── FINDINGS.md
│   └── output/               ← Captured AX trees and screen dumps (gitignored)
│
├── agentic/                  ← Python AI agent (LangGraph + ChromaDB + GPT-4o)
│   ├── agent.py              ← LangGraph StateGraph definition
│   ├── state.py              ← AgentState TypedDict
│   ├── nodes/
│   │   ├── parse_steps.py    ← Natural language → structured step dicts
│   │   ├── execute_steps.py  ← Calls run_steps.js via subprocess
│   │   ├── diagnose.py       ← GPT-4o failure analysis
│   │   ├── reinspect.py      ← Calls capture_dom.js, indexes to ChromaDB
│   │   ├── update_config.py  ← Patches Elements_Config JSON
│   │   └── report.py         ← Final pass/fail report
│   ├── tools/
│   │   └── element_store.py  ← ChromaDB wrapper (seed, search, upsert)
│   └── ui/
│       └── app.py            ← Streamlit dashboard
│
├── agentic_scripts/          ← Node.js bridge scripts (called by Python agent)
│   ├── run_steps.js          ← Execute structured steps, output JSON results
│   └── capture_dom.js        ← Capture DOM snapshot for a given screen
│
├── inputs/
│   └── test-steps/           ← Drop .txt test step files here for the agentic flow
│
├── chroma_db/                ← ChromaDB persistent storage (auto-created on first seed)
│
├── CLAUDE.md                 ← Claude Code project instructions (always read by Claude)
├── ONBOARDING.md             ← This file — complete knowledge base
├── AGENTIC_ARCHITECTURE.md   ← Agentic flow architecture details
├── playwright.config.js
├── package.json
└── requirements-agentic.txt
```

---

## 3. Samsung Magician — App Architecture

| Property | Value |
|----------|-------|
| Type | Electron (Chromium renderer) |
| EXE | `C:\Program Files (x86)\Samsung\Samsung Magician\SamsungMagician.exe` |
| Windows Service | `SamsungMagicianSVC` (runs as SYSTEM, auto-start on boot) |
| Debug port | `--remote-debugging-port=9222` |
| UI framework | React (minified, no dev tools) |
| ARIA roles | Almost none — nearly everything is `generic` or `none` |

### Why Samsung Magician is hard to automate

**Three layered single-instance checks:**

```js
Yt = Vt.amIAlreadyRunning();          // napi named-pipe IPC with SamsungMagicianSVC
Qt = Vt.amIAlreadyRunningGlobally();  // global check via service
Kt = app.requestSingleInstanceLock(); // Electron built-in lock file
```

`SamsungMagicianSVC` holds a named-pipe server. Even after killing the UI process,
the service keeps the pipe alive, so any new debug-launched instance sees itself as
a "second instance" and calls `app.quit()` within ~60 ms.

**Solution:** Stop the service BEFORE spawning — see Section 4.

---

## 4. Critical: How to Launch the App for Testing

### Admin is mandatory

`net stop SamsungMagicianSVC` requires Administrator. Without it, the service is not
stopped, the named-pipe check fires, and the app quits silently within 60 ms.

### Launch sequence (implemented in `tests/helpers/appLauncher.js`)

```
1. net stop SamsungMagicianSVC /y          — release named-pipe lock
2. taskkill /F /IM SamsungMagician.exe      — kill UI process
   taskkill /F /IM SamsungMagicianSVC.exe  — kill service EXE (BOTH must be killed)
3. Sleep 5 000 ms                           — OS releases mutex + pipe handles
4. net stop SamsungMagicianSVC /y (again)  — catches SCM crash-recovery auto-restart
5. Sleep 1 000 ms
6. Spawn: SamsungMagician.exe --remote-debugging-port=9222
7. Capture DevTools WS URL from process stderr (appears within ~500 ms)
8. chromium.connectOverCDP(wsUrl)           — connect immediately via CDP
9. Find the BrowserWindow page
10. waitForLoadState('domcontentloaded')
11. Sleep 2 000 ms
12. Poll DOM for 'Home Dashboard' text (up to 40 s, every 500 ms)
    → launchMagician() only returns AFTER the sidebar is fully rendered
    → This prevents "element not found" on the first navigateTo() call
```

**ALWAYS kill BOTH processes — never just the UI EXE:**

```powershell
taskkill /F /IM SamsungMagician.exe
taskkill /F /IM SamsungMagicianSVC.exe
```

Killing only `SamsungMagician.exe` leaves the service alive holding the named pipe.
The next spawn will see itself as "already running" and quit.

### CDP vs UIAutomation

- **CDP `Accessibility.getFullAXTree`** — the only viable approach. Exposes the full React render tree.
- **UIAutomation (UIA)** — Electron only exposes 2 UIA nodes (`[dialog] → [region]`) unless a screen reader is active or `--force-renderer-accessibility` is passed. Not useful.
- **`page.accessibility.snapshot()`** — undefined when connected via `connectOverCDP()`. Do not use.

### Connection code pattern

```js
const { chromium } = require('playwright');
const browser = await chromium.connectOverCDP('ws://127.0.0.1:9222/...');
// NOT: const { _electron } = require('playwright');  ← app detects --inspect and quits
```

---

## 5. Navigation — JS DOM Walker Pattern

Samsung Magician v8 has **no ARIA roles** on interactive elements. Sidebar items have
CSS `visibility: hidden` — Playwright's `.click({ force: true })` fails silently.

**`clickText(page, text)`** in `tests/helpers/navigator.js` tries three strategies:
1. `page.getByText(text, { exact: true }).first().click({ force: true })`
2. `page.getByText(text, { exact: false }).first().click({ force: true })`
3. **JS DOM walker** via `page.evaluate()`: `document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT)` → find exact `textContent.trim()` match → `el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }))` ← **required for sidebar**

Returns `boolean`. Strategies 1 and 2 work for main content; strategy 3 is mandatory for sidebar.

### Sidebar readiness polling

`navigateTo()` polls the DOM for the target label up to `SIDEBAR_POLL_MS=20_000 ms`
(every 400 ms) before clicking. Since `launchMagician()` now gates on sidebar readiness
(Section 4, step 12), this is mostly a safety margin for mid-session navigations.

---

## 6. Full Sidebar Structure

Confirmed via spike (2026-05-24). CSS classes are from `.groupMenuView_*` and `.globalItemView_*`.

```
Home Dashboard                              .featureItemView_homeDashboard_text
│
├── Diagnosis & Information  [group]        .groupMenuView_group_text
│   └─ sub-items: UNKNOWN — not yet hovered
│
├── Performance Management   [group]        .groupMenuView_group_text
│   ├─ Performance Benchmark                .groupMenuView_iconTooltip_menuItem
│   ├─ Performance Optimization             .groupMenuView_iconTooltip_menuItem
│   └─ Over Provisioning                    .groupMenuView_iconTooltip_menuItem
│
├── Data Management          [group]        .groupMenuView_group_text
│   └─ sub-items: likely "Data Migration" — not yet confirmed
│
├── Security Settings        [group]        .groupMenuView_group_text
│   └─ sub-items: UNKNOWN — not yet hovered
│
├── System Details                          .globalItemView_systemDetailText
├── Newsroom                                .globalItemView_newsRoomText
├── Help Center                             .globalItemView_helpCenterText
├── Chatbot                                 .globalItemView_chatbotText
└── Settings                                .globalItemView_settingsText
```

**Sidebar group states:**
- `groupMenuView_group_text` — collapsed/not active
- `groupMenuView_group_text_selected` — expanded/active group
- `groupMenuView_iconTooltip_title` — title of expanded group tooltip
- `groupMenuView_iconTooltip_menuItem` — sub-item in tooltip
- `groupMenuView_iconTooltip_menuItem_selected` — selected sub-item

**LNB (within-screen left nav) for Performance Management:**
- `lnbMenuView_menuListArea_item` — non-selected tab
- `lnbMenuView_menuListArea_item_selected` — active tab

---

## 7. Hover-Revealed Sidebar Items

Some sidebar items are **not in the DOM at rest** — they are dynamically injected
when a parent group receives a `mouseover`/`mouseenter` event.

| Screen | Trigger mechanism | Parent group | Status |
|--------|------------------|-------------|--------|
| `over_provisioning` | JS `dispatchEvent(mouseover+mouseenter)` on parent text | `Performance Management` | ✅ Confirmed |
| `data_migration` | `page.mouse.move()` sweep across sidebar column x≈47 | Likely `Data Management` | ⚠️ Parent TBD |

### Hover mechanism

For `over_provisioning`: JS `dispatchEvent(new MouseEvent('mouseover', { bubbles: true }))` +
`dispatchEvent(new MouseEvent('mouseenter', { bubbles: false }))` on the `"Performance Management"`
text node via TreeWalker, then `waitForTimeout(600)`. This injects the sub-items into the DOM.

For `data_migration` (parent group unconfirmed): real mouse sweep `page.mouse.move(47, y)` from y=420 to y=920 in steps of 40, then `waitForTimeout(600)`.

**`navigateTo()` handles this automatically.** Do NOT call `clickText('Over Provisioning')` directly —
the text is not in the DOM until `_revealSidebarItem()` runs.

```js
const HOVER_REVEAL = {
  over_provisioning: 'Performance Management',  // JS mouseover on parent label
  data_migration:    null,                      // null → mouse sweep fallback
};
const POLL_LABEL_OVERRIDE = {
  over_provisioning: 'Performance Management',
  data_migration:    'Home Dashboard',
};
```

---

## 8. Confirmed Screens & Element Configs

### Screen inventory (updated 2026-05-24)

| Screen key | Sidebar label | Navigate via | Text nodes | Notes |
|------------|--------------|--------------|------------|-------|
| `dashboard` | Home Dashboard | direct click | ~111 | Default; 4 widgets embedded |
| `system_details` | System Details | direct click | ~89, 3 AX buttons | Only screen with real ARIA button roles |
| `performance_benchmark` | Performance Management → Performance Benchmark | hover PM → click | ~179 | LNB sub-screen; PM group click lands here |
| `over_provisioning` | Performance Management → Over Provisioning | hover PM → click | ~24 | LNB sub-screen; "not supported" on non-Samsung drives |
| `data_migration` | sweep → Data Migration | mouse sweep | TBD | Parent group: likely Data Management |
| `newsroom` | Newsroom | direct click | ~16 | Iframe — external content inaccessible |
| `help_center` | Help Center | direct click | ~15 | Iframe — same component as Newsroom |
| `chatbot` | Chatbot | direct click | TBD | Confirmed in sidebar; content not yet captured |
| `settings` | Settings | direct click | ~39 | All real content |

### SCREEN_MARKERS (what proves navigation succeeded)

```js
const SCREEN_MARKERS = {
  dashboard:             'Home Dashboard',
  system_details:        'System Details',
  performance_benchmark: 'Performance Benchmark',   // pbTitleView_TitleName
  over_provisioning:     'Over Provisioning',       // lnbMenuView_menuListArea_item_selected
  data_migration:        'Data Migration',           // TODO: confirm
  newsroom:              'Newsroom Feature',         // iframe accessible name
  help_center:           'Help Center',
  chatbot:               'Chatbot',                  // TODO: confirm
  settings:              'Settings',
};
```

### Elements_Config JSON format

Each screen has one JSON file in `Elements_Config/`. See Section 14 for the full schema.

Key groups in each config:
- `navigation` — sidebar click targets for every screen (`type: "domClick"`)
- `header` — global header elements (Update badge, Notice badge, drive name)
- `page_structure` — page heading, LNB tabs (if any)
- Screen-specific groups (e.g., `controls`, `results`, `lnb_navigation`)

### Selector types

| Type | Builder | When to use |
|------|---------|-------------|
| `text` | `page.getByText(text, { exact })` | All content-area text elements |
| `role` | `page.getByRole(role, { name })` | System Details tab buttons ONLY |
| `domClick` | `page.getByText()` for locate; `clickText()` for clicking | Sidebar nav items |
| `iframe` | `page.getByRole('Iframe', { name })` | Newsroom / Help Center iframes |

---

## 9. ARIA Roles — What Exists and What Doesn't

| Role | Where | Notes |
|------|-------|-------|
| `RootWebArea` | Page root | Always present |
| `StaticText` / `InlineTextBox` | All text | |
| `generic` | Containers, interactive divs | Almost everything |
| `none` | Wrapper divs | |
| `image` | Icons | |
| `Iframe` | Newsroom + Help Center | Only accessible name, not content |
| **`button`** | **System Details only** | 3 tab buttons: System Summary, System Details, Drive Details |
| `DescriptionList` / `term` / `definition` | System Details only | |

**Key consequence:** `page.getByRole('button', ...)` only works on the System Details screen.
Use `page.getByText()` + `clickText()` everywhere else.

### Assertion pattern

```js
// CORRECT — sidebar items are visibility:hidden
await page.getByText('Home Dashboard').first().toBeAttached();

// WRONG — fails for visibility:hidden elements
await page.getByText('Home Dashboard').toBeVisible();
```

---

## 10. Running the Playwright Test Suite

```powershell
# Administrator PowerShell always required
cd C:\code\MagicianNewWay

npm test                     # full suite (all spec files, serial)
npm run test:smoke           # just app launch tests
npm run test:nav             # just sidebar navigation tests
npm run test:screens         # just screen-specific tests
npm run report               # open HTML report in browser
```

### Critical config (playwright.config.js)

```js
workers: 1,          // MANDATORY — single-instance app, parallel workers guaranteed to conflict
fullyParallel: false,
```

### Test file structure

Each spec file follows the same pattern:

```js
test.beforeAll(async () => {
  ({ app, page } = await launchMagician());
  await navigateTo(page, 'screen_name');
});

test.afterAll(async () => {
  await closeMagician(app);
});

test('thing exists', async () => {
  const loc = buildLocator(page, screen.section.element.selector);
  await expect(loc.first()).toBeAttached();
});
```

### System Details tab gotcha

The default tab when launching fresh is **"System Summary"** — not "System Details".
"Motherboard" and "BIOS" appear in both tabs. "Memory Information" appears **only** in
System Details. Always click the tab explicitly before asserting tab-specific content:

```js
await page.getByRole('button', { name: 'System Details' }).click();
await page.getByText('Memory Information', { exact: false }).first()
  .waitFor({ state: 'attached', timeout: 5_000 });
```

---

## 11. Running the Spike / Inspection Scripts

Spike scripts are **read-only** (inspect, don't modify). Safe to re-run anytime.

```powershell
# Administrator PowerShell
cd C:\code\MagicianNewWay

npm run spike                 # capture AX trees for all 5 original screens
npm run spike:sidebar-hover   # investigate sidebar hover mechanics
npm run spike:all-screens     # hover all groups, click each revealed item, capture all screens
npm run spike:popup           # inspect popup/dialog content (e.g., Setup Benchmark)

npm run reinspect             # diff current UI against configs (dry-run)
npm run reinspect:update      # same + auto-patch configs with discovered elements
npm run reinspect:drives      # cycle through all connected drives, update configs for each
```

### Output files (in spike/output/)

| File | Content |
|------|---------|
| `all_screens_summary_*.txt` | Phase 1/2 discovery log |
| `screen_<name>_*.txt` | Full text nodes + AX nodes + selects for each screen |
| `sidebar_hover_*.txt` | Hover mechanism investigation results |
| `popup_inspection_*.txt` | Popup/dialog DOM capture |

---

## 12. Agentic Flow — AI Self-Healing Agent

### How it works

1. **Upload** a `.txt` file with natural-language test steps
2. **Parser** (`parse_steps.py`) converts each line to a structured step dict
3. **Executor** (`execute_steps.py`) calls `run_steps.js` as a subprocess
4. `run_steps.js` launches Samsung Magician, runs steps, captures DOM on failure
5. On failure → **Diagnose** (`diagnose.py`) uses GPT-4o to classify root cause
6. → **Reinspect** (`reinspect.py`) calls `capture_dom.js` to get live DOM
7. → **Update Config** (`update_config.py`) patches `Elements_Config/*.json`
8. → **Retry** the full step sequence (up to `max_retries` times)
9. Report surfaces in the **Streamlit UI**

### Starting the UI

```powershell
# Administrator PowerShell (agent needs admin to stop SVC)
cd C:\code\MagicianNewWay
streamlit run agentic/ui/app.py
```

Open http://localhost:8501 in a browser.

### Seeding the knowledge base

ChromaDB is seeded from the Elements_Config JSON files. Run once after setup
(or after updating configs):

```powershell
# Option 1: via Streamlit UI — click "Seed Knowledge Base" in sidebar
# Option 2: via CLI
python -c "from agentic.tools.element_store import seed_from_configs; seed_from_configs('Elements_Config/')"
# Option 3: npm script
npm run agent:seed
```

The ChromaDB data is stored locally in `chroma_db/` and persists across sessions.
To transfer to a new machine, either copy the `chroma_db/` folder or re-seed from configs.

### Technology stack

| Layer | Technology | Purpose |
|-------|-----------|---------|
| Orchestration | LangGraph (Python) | State machine retry loop |
| AI reasoning | GPT-4o | Failure diagnosis, DOM→selector mapping |
| Embeddings | OpenAI text-embedding-3-small | Element similarity search |
| Vector DB | ChromaDB (in-process) | Store & search UI element patterns |
| Automation | Playwright (Node.js) | CDP bridge to Electron app |
| UI | Streamlit (Python) | Real-time test dashboard |
| Config store | JSON (`Elements_Config/`) | Source of truth for selectors |

### LangGraph node graph

```
parse_steps → execute_steps → [router]
                                  ├─ success  → report_success (END)
                                  ├─ fail     → diagnose → [router]
                                  │                ├─ needs_reinspect → reinspect → update_config → retry → execute_steps
                                  │                └─ skip_reinspect  → update_config → retry → execute_steps
                                  └─ max retries → report_failure (END)
```

### ChromaDB collection schema

Collection name: `magician_elements`

| Field | Content |
|-------|---------|
| `document` | `"{text}" on {screen} screen ({description})` |
| `metadata.screen` | screen key (e.g. `performance_benchmark`) |
| `metadata.group` | config group (e.g. `controls`) |
| `metadata.element_key` | config key (e.g. `btn_start`) |
| `metadata.selector_type` | `text` / `role` / `domClick` / `iframe` |
| `metadata.source` | `config` / `reinspect` |
| `id` | deterministic: `screen__element_key` (config) or `screen__source__text` (reinspect) |

---

## 13. Writing Natural-Language Test Steps

Test step files are plain `.txt` files, one step per line. Lines starting with `#` are comments.

### Supported step formats

```
# Navigate to a screen
navigate to performance benchmark screen
navigate to settings
navigate to system_details screen

# Click an element — quoted text preferred; sidebar labels auto-converted to navigate
click "Start"
click the "Setup Benchmark" button
click on Export
click "Performance Management" section in the left sidebar  ← auto-converts to navigate

# Verify text is present (noise stripped automatically)
verify Sequential Read
verify that Sequential Read speed value is displayed.        ← extracts "Sequential Read"
verify "Memory Information" is present

# Verify text is absent
verify Error is not present
verify absent Loading

# Wait
wait 2000
wait 500 ms

# Scroll
scroll down 500
scroll up

# Select from dropdown
select 512MB
select 1GB from test range
```

### Parser intelligence (parse_steps.py)

The parser applies these rules in order for every click/verify step:

1. **Extract quoted text** — if the step contains `"…"` or `'…'`, use that as the target
2. **Strip noise** — remove trailing words like `button`, `section`, `in the left sidebar`,
   `is displayed`, `speed value`, `(4K)`, etc.
3. **Auto-convert click→navigate** — if the extracted text matches a known sidebar label
   (e.g. "Performance Management"), emit a `navigate` action instead of `click`
   (sidebar items need `navigateTo()`, not raw `clickText()`)

### Non-automatable patterns (auto-detected)

The step parser marks these as `cannot_automate`:

| Pattern | Reason |
|---------|--------|
| save file / save as | OS file dialog |
| open file dialog | OS file dialog |
| plug in / unplug | Physical hardware |
| physically / touch / press | Physical action |
| reboot / restart | OS-level |
| secure erase / format drive | Destructive — never automated |
| print all / screenshot | External capture |
| wait until … disappears | Indeterminate timing |

---

## 14. Elements_Config JSON Format

Each screen has one JSON in `Elements_Config/`. Standard groups:

```json
{
  "screen": "screen_key",
  "sidebarLabel": "Exact Sidebar Text",
  "description": "Human-readable description",
  "_selectorNote": "Constraints for this screen",
  "_inspectedOn": "YYYY-MM-DD — spike output file reference",

  "navigation": {
    "nav_home_dashboard": {
      "selector": { "type": "domClick", "text": "Home Dashboard" },
      "description": "Sidebar nav",
      "navigatesTo": "dashboard"
    }
  },

  "header": {
    "badge_update": {
      "selector": { "type": "text", "text": "Update", "exact": true },
      "description": "Update notification badge",
      "type": "badge"
    }
  },

  "page_structure": {
    "page_heading": {
      "selector": { "type": "text", "text": "Settings", "exact": true },
      "description": "Page heading",
      "type": "heading"
    }
  },

  "some_group": {
    "element_key": {
      "selector": { "type": "text", "text": "Exact Text", "exact": true },
      "description": "What this element is",
      "type": "label|action|info|badge|heading|tab|iframe",
      "dynamic": true,            // omit if false — means value changes per machine/state
      "options": ["ON", "OFF"]    // for toggles
    }
  }
}
```

### Selector type reference

| `type` | Playwright API | Notes |
|--------|---------------|-------|
| `text` | `page.getByText(text, { exact })` | All content-area elements |
| `role` | `page.getByRole(role, { name })` | System Details tab buttons only |
| `domClick` | `page.getByText()` locate; `clickText()` click | Sidebar nav items |
| `iframe` | `page.getByRole('Iframe', { name })` | Newsroom/Help Center frames |

### Dynamic elements

Mark `"dynamic": true` on elements whose values change per machine or test run:
- Drive model/serial/firmware — machine-specific
- Temperature readings — changes constantly
- ON/OFF toggle states — may differ per machine config
- Benchmark result scores — run-specific

**Never assert exact values for dynamic elements** — assert the label, not the value.

---

## 15. Known Bugs Fixed & Why

### Bug 1 — SVC restart race condition

**Symptom:** "Target page, context or browser has been closed" in `beforeAll`
when run as part of the full suite (but passed alone).

**Root cause:** The previous spec's `afterAll` called `startService()`. The service
started but the named pipe wasn't open yet when the next spec called `stopService()`.
The service finished starting, won the named-pipe race, and called `app.quit()`.

**Fix (appLauncher.js):**
- Pre-spawn sleep: 3 000 ms → 5 000 ms
- Second `stopService()` after 5 s sleep (catches SCM crash-recovery auto-restart)
- `page.on('close')` registered before `waitForLoadState`
- `page.isClosed()` guard → throws so retry loop kicks in

### Bug 2 — Sidebar not found on first navigateTo() call

**Symptom:** `[element_not_found]` error on the very first `navigate` step in the agentic flow.
DOM snapshot shows "application is still in the loading state."

**Root cause:** `launchMagician()` returned after `domcontentloaded` + 2 s sleep, but the
React sidebar takes 10–30 s to fully hydrate and render the sidebar labels.
The 8 s sidebar poll in `navigateTo()` was expiring before "Performance Management" appeared.

**Fix (appLauncher.js):**
Added a sidebar readiness gate: polls DOM for `'Home Dashboard'` text (appears only after
full sidebar render), up to 40 s. `launchMagician()` now guarantees the sidebar is rendered
before returning. Also extended `SIDEBAR_POLL_MS` in navigator.js from 8 s → 20 s.

### Bug 3 — System Details tab content missing

**Symptom:** "Memory Information (2/2)" not found.

**Root cause A:** Spike captured with "System Details" tab already active (user-data-dir preserved
tab state). Real default is "System Summary". Motherboard/BIOS appear in BOTH tabs — false pass.
"Memory Information" is ONLY in System Details tab.

**Root cause B:** `(2/2)` suffix is machine-specific (slot count).

**Fix:** Explicit tab click in `beforeAll`, `exact: false` for "Memory Information", `test.skip`
guard for tab-specific tests.

### Bug 4 — Help Center "sidebar label not found"

**Root cause:** React sidebar hadn't hydrated when `clickText()` was called immediately
after `launchMagician()` returned (the 2 s sleep wasn't enough).

**Fix:** Sidebar readiness poll in `navigateTo()` (later promoted to `launchMagician()` gate).

### Bug 5 — Click parsing captures full phrase instead of target text

**Symptom:** `click "Performance Management" section in the left sidebar.` → agent tries to find
the full string `"Performance Management" section in the left sidebar.` in the DOM.

**Fix (parse_steps.py):**
- Extract quoted text first → `Performance Management`
- Check against `_SIDEBAR_TO_SCREEN` map → convert to `navigate to performance_benchmark`
- Strip noise suffixes (button, section, in the left sidebar) from unquoted click steps

---

## 16. Do-Not List

| What not to do | Why |
|----------------|-----|
| `_electron.launch()` | App detects `--inspect` flag and calls `app.quit()` |
| `page.getByRole()` for sidebar nav | No ARIA roles on interactive elements |
| `page.accessibility.snapshot()` | Undefined with `connectOverCDP()` |
| `toBeVisible()` on sidebar elements | CSS `visibility: hidden` — use `toBeAttached()` |
| Kill only `SamsungMagician.exe` | SVC keeps named pipe alive → next spawn quits in 60 ms |
| `workers > 1` in playwright.config.js | Single-instance app — parallel workers conflict |
| Assert exact field values | Drive model, temperature, scores are machine-specific |
| Assume System Details tab is default | Default is "System Summary" — always click the tab |
| Call `clickText('Over Provisioning')` directly | Not in DOM until `_revealSidebarItem()` is called |
| Run without Administrator | `net stop SamsungMagicianSVC` silently fails |

---

## 17. Troubleshooting

### "Target page, context or browser has been closed"

SVC race condition. `appLauncher.js` has retry logic (MAX_RETRIES=3). If it persists:
1. Open Services (services.msc) and manually stop SamsungMagicianSVC
2. Run `taskkill /F /IM SamsungMagician.exe` and `taskkill /F /IM SamsungMagicianSVC.exe`
3. Wait 10 s, then retry

### "Sidebar did not appear within 40000ms"

App is stuck on loading screen. Check:
1. Is SamsungMagicianSVC fully stopped? Run `net stop SamsungMagicianSVC /y` manually.
2. Is another Samsung Magician process running? Kill all instances.
3. Is the machine under heavy load? The 40 s gate may need extending.

### "Sidebar label 'X' not found on page"

Usually means the sidebar didn't render in time despite the readiness gate.
Check logs for `sidebar-ready` event — how long did it take?
If consistently > 35 s, increase `SIDEBAR_READY_MS` in `appLauncher.js`.

### Tests pass alone but fail in suite

Classic SVC race — see Bug 1 above. Ensure `afterAll` calls `closeMagician(app)` and not just `browser.close()`. The `closeMagician` wrapper calls `startService()` which restores the SVC for normal use but the next spec's `launchMagician()` must stop it again.

### "element not found" in agentic flow

1. Check the parsing log — does it show the extracted `text=` correctly?
2. If text looks wrong, add quotes around the exact DOM text in your step file:
   `click "Start"` instead of `click the Start button`
3. Run `npm run spike:all-screens` to capture current DOM of all screens
4. Check `spike/output/screen_<name>_*.txt` — is the text you're looking for actually there?

### Agentic flow: "Launch failed" after 3 retries

1. Ensure you're running as Administrator
2. Manually kill all Magician processes and stop the service, then retry
3. Check `logs/` folder for detailed JSON logs

### ChromaDB "collection is empty" on search

Run `npm run agent:seed` to seed from the current Elements_Config files.

### Performance Management nav not revealing sub-items

The JS `mouseover` dispatch must hit the correct element. Verify the parent group text
is exactly `"Performance Management"` (no trailing spaces). Run `npm run spike:sidebar-hover`
to re-confirm the mechanism.

---

## 18. Implementation Reference — Agentic Layer

This section documents every Python file in the `agentic/` folder with full implementation
detail so the code can be understood, extended, or ported without reading the source.

---

### 18.1 `agentic/state.py` — AgentState TypedDict

| Field | Type | Behaviour | Content |
|-------|------|-----------|---------|
| `test_file_path` | `str` | replaced | Path to .txt step file (display only) |
| `raw_steps` | `List[str]` | replaced | Raw lines including comments |
| `parsed_steps` | `List[dict]` | replaced | Output of parse_steps_node |
| `step_results` | `List[dict]` | replaced | Per-step outcome from run_steps.js |
| `current_run_output` | `dict` | replaced | Raw JSON output from run_steps.js |
| `failures` | `List[dict]` | replaced | Enriched failure records |
| `qdrant_context` | `List[dict]` | replaced | ChromaDB search results |
| `dom_captures` | `List[dict]` | **accumulated** (`operator.add`) | `{screen, data:{text_nodes,ax_nodes,selects}}` |
| `config_patches` | `List[dict]` | **accumulated** (`operator.add`) | `{screen, element_key, element_data}` |
| `retry_count` | `int` | replaced | Retries run so far |
| `max_retries` | `int` | replaced | Ceiling set at startup |
| `status` | `str` | replaced | `parsing\|executing\|diagnosing\|reinspecting\|updating\|success\|failed` |
| `report` | `dict` | replaced | Final summary |
| `log_messages` | `List[str]` | **accumulated** (`operator.add`) | All nodes append; Streamlit renders tail |

**Accumulator fields** never overwrite — each node returns only new items, LangGraph concatenates.
**Replaced fields** — node's return value overwrites previous value entirely.

**Parsed step dict** keys: `action`, `raw` (always); `to` for navigate (+ `_converted_from:'click'` if auto-converted); `text` for click/verify/select; `timeout` for wait; `direction`+`amount` for scroll.

**Failure dict** keys (post-diagnose): `step`, `error`, `category` (`element_not_found|page_closed|navigation_failed|timeout|unknown`), `screen`, `needs_reinspect`, `elements_to_find`, `suggested_fix`, `root_cause`, `dom_snapshot`.

---

### 18.2 `agentic/agent.py` — LangGraph StateGraph

**Graph topology:**

```
parse_steps
    │
execute_steps ─────────────────────────────────────────────────────────┐
    │                                                                   │ (retry loop)
check_results_router                                            ┌───────┴──────┐
 ├── 'success'  → report_success → END                          │  retry_node  │
 ├── 'diagnose' → diagnose_failure                              └──────────────┘
 │                    │                                                  ▲
 │               diagnose_router                                         │
 │                ├── 'reinspect'    → reinspect ──▶ update_config ─────┘
 │                └── 'update_config'─────────────▶ update_config ─────┘
 └── 'give_up'  → report_failure → END
```

**Router: `check_results_router(state)`**

Called after `execute_steps`. Returns:
- `'success'` — no real failures (only `cannot_automate` steps are ignored)
- `'give_up'` — `retry_count >= max_retries`
- `'diagnose'` — failures exist AND retries remain

**Router: `diagnose_router(state)`**

Called after `diagnose_failure`. Returns:
- `'reinspect'` — if ANY failure has `needs_reinspect=True`
- `'update_config'` — all failures can be addressed without launching app

**Node: `retry_node(state)`**

Increments `retry_count`, resets `status` to `'executing'`, appends a log separator.
Returns to `execute_steps`.

**Entry point:** `parse_steps`
**Terminal nodes:** `report_success`, `report_failure` (both edge to `END`)

**Singleton pattern:** `agent = build_agent()` is run at import time.
`from agentic.agent import agent, make_initial_state` — then call
`agent.stream(state, stream_mode='values')` to iterate events.

**`make_initial_state(raw_steps, test_file_path='', max_retries=3)`** — returns a dict
with all AgentState fields initialized to empty lists / `None` / `0` / `'starting'`.
`log_messages` pre-seeded with one header line.

---

### 18.3 `agentic/nodes/parse_steps.py` — Step Parser

Converts raw text lines to structured step dicts. Exposed as `parse_steps_node(state)`.

**Private helpers:**

`_SIDEBAR_TO_SCREEN` — lowercased sidebar label → screen key. Covers: `home dashboard`, `system details`, `performance management`, `performance benchmark`, `performance optimization`, `over provisioning`, `data migration`, `newsroom`, `help center`, `chatbot`, `settings`. Used to auto-convert `click "Performance Management"` → `navigate performance_benchmark`.

`_extract_quoted(s)` — returns content of first `"…"` (including curly quotes) or `'…'`
in the string, or `None`. Takes priority over all other extraction.

`_clean_click_text(raw)` — given everything after `"click [the|on]"`:
1. If quoted text found → return it
2. Strip trailing location: `"in the left sidebar"`, `"in the sidebar"`
3. Strip trailing UI type words: `button`, `section`, `link`, `tab`, `menu`, `icon`, `item`, `option`, `field`, `control`
4. Strip leading article: `the`, `a`, `an`

`_clean_verify_text(raw)` — given everything after `"verify"`:
1. If quoted text found → return it
2. Strip leading: `that`, `the`, `a`, `an`
3. Strip trailing state phrase: `is displayed`, `is shown`, `is visible`, `is present`, `is correct`, `is available`, `is enabled`, `is disabled`, `is active` (with optional `"now"`)
4. Strip trailing descriptor: `(4K) speed value`, `performance metric`, `current reading`, etc.
5. Strip remaining parenthetical: `(4K)`
6. Strip single noise word: `speed`, `performance`, `data`, `reading`

**`_parse_one(line)` — single-line dispatcher:**

Tries each pattern in order (first match wins):
1. `navigate to <screen> [screen]` → `{'action': 'navigate', 'to': screen_key}`
2. `verify <text> is not present / absent / gone` → `{'action': 'verify_absent', 'text': cleaned}`
3. `verify <text>` → `{'action': 'verify', 'text': cleaned}`
4. `click [the|on] <text>` → check sidebar map → navigate, else → `{'action': 'click', 'text': cleaned}`
5. `wait <N> [ms|s]` → `{'action': 'wait', 'timeout': ms}` (≤60 with 's' → multiply × 1000)
6. `scroll up|down|left|right [N]` → `{'action': 'scroll', 'direction': ..., 'amount': N or 300}`
7. `select <text> [from <source>]` → `{'action': 'select', 'text': cleaned}`
8. fallback → `{'action': 'cannot_automate', 'raw': line}`

**`parse_steps_node(state)` — LangGraph node:**

- Skips blank lines and `#` comments
- Calls `_parse_one()` on each line
- Logs each parsed step with icon `✓`/`✗`, action, raw text, and extracted `text=` / `screen=`
- Tags sidebar-converted steps with `[sidebar→navigate]`
- Returns: `{'parsed_steps', 'status': 'parsing', 'log_messages'}`

---

### 18.4 `agentic/nodes/execute_steps.py` — Step Executor

Calls `run_steps.js` via subprocess, parses results, builds failure list.

**`_categorise(error_str)` → category string:**

| Pattern in error (lowercased) | Category |
|-------------------------------|----------|
| `not found`, `could not find`, `option not found` | `element_not_found` |
| `page closed`, `browser has been closed`, `target page` | `page_closed` |
| `navigation`, `sidebar label` | `navigation_failed` |
| `timeout`, `timed out` | `timeout` |
| (none of the above) | `unknown` |

**`_infer_screen(steps, failed_index)` → screen key:**

Walks backwards from the failed step index, returns `to` from the most recent
`navigate` step. Returns `'unknown'` if no navigate step found.

**`execute_steps_node(state)` flow:**

1. Filter `parsed_steps` to only automatable steps (`action != 'cannot_automate'`)
2. Write `{ "steps": [...] }` to a temp file (`*_steps.json`)
3. Run: `node agentic_scripts/run_steps.js <steps_file> <output_file>`
   - 6-minute hard timeout (`timeout=360` seconds)
4. Read `*_output.json`; if missing (crash before write), build synthetic error result
5. Build `step_results` list and `failures` list from output
6. Each failure gets: `step`, `error`, `category`, `screen`, `needs_reinspect=None`,
   `elements_to_find`, `suggested_fix=None`, `root_cause=None`, `dom_snapshot`
7. Handle "launch-level error" (no steps ran at all — e.g. Samsung Magician wouldn't start)
8. Clean up both temp files in `finally` block
9. Return: `{'step_results', 'current_run_output', 'failures', 'status': 'executing', 'log_messages'}`

---

### 18.5 `agentic/nodes/diagnose.py` — Failure Diagnosis

Enriches each failure with AI or heuristic analysis.

**`_heuristic_diagnosis(failure)` — rule-based fallback (no API key needed):**

| Category | `root_cause` | `needs_reinspect` | `suggested_fix` |
|----------|-------------|------------------|-----------------|
| `element_not_found` | Element `"X"` not found in DOM | `True` | Reinspect and confirm visible label |
| `page_closed` | SVC race condition / named-pipe conflict | `False` | Re-run; launcher retries automatically |
| `navigation_failed` | Sidebar label not found | `True` | Check SIDEBAR_LABELS mapping |
| `unknown` | Unexpected error | `True` | None |

**`_openai_diagnosis(failure, similar_elements)` — GPT-4o analysis:**

Prompt includes: failed step JSON, error message, pre-classified category, screen name,
DOM snapshot (first 30 nodes), and ChromaDB similar elements (first 5).

Response format: `json_object` with keys `root_cause`, `needs_reinspect`,
`elements_to_find`, `suggested_fix`.

Falls back to `_heuristic_diagnosis()` if OpenAI import fails or API call fails.

**`diagnose_failure_node(state)` flow:**

1. For each failure:
   a. Extract search text from step (`text` or `to` or `raw`)
   b. Search ChromaDB: `search_similar_elements(search_text, screen=screen, limit=5)`
   c. If `OPENAI_API_KEY` set → call `_openai_diagnosis()`, else `_heuristic_diagnosis()`
   d. Merge analysis back into the failure dict (updating `needs_reinspect`, `root_cause`, etc.)
2. Log icon: `🔎` if needs reinspect, `💡` if handled without app launch
3. Return: `{'failures': enhanced, 'qdrant_context': all_similar, 'status': 'diagnosing', 'log_messages'}`

---

### 18.6 `agentic/nodes/reinspect.py` — Live DOM Capture

Launches Samsung Magician, navigates to failing screen(s), captures DOM, indexes into ChromaDB.

**`_pre_actions_for_failure(failure)` → list of pre-action dicts:**

If the failing step was a `click` (e.g. "Setup Benchmark"), include that click as a
pre-action so the popup/dropdown is visible during the capture. This is critical — without
it, the popup DOM isn't captured and `update_config` can't find the element.

**`reinspect_node(state)` flow:**

1. Group `failures` by screen (skip any with `needs_reinspect=False`)
2. For each screen:
   a. Collect unique pre-actions from all failures on that screen
   b. Build `capture_config = { screen, pre_actions, popup_wait_ms: 5000 }`
   c. Run: `node agentic_scripts/capture_dom.js '<json_config>'`
      — 3-minute timeout
   d. Parse stdout JSON
   e. Append to `new_dom_captures` list
   f. Call `_index_capture()` to upsert text nodes into ChromaDB
3. Return: `{'dom_captures': new_dom_captures, 'status': 'reinspecting', 'log_messages'}`
   (Note: `dom_captures` uses `operator.add` — only new captures are returned)

**`_index_capture(capture_data, screen, logs)`:**

Iterates text nodes. For each text ≥ 2 chars, calls `upsert_element()` with:
`{ screen, text, tag, css_class, source='reinspect', type='unknown' }`.
Skips empty text. Logs final count.

---

### 18.7 `agentic/nodes/update_config.py` — Config Patcher

Maps each failure to a DOM element and patches `Elements_Config/<screen>.json`.

**`_find_dom_capture(dom_captures, screen)` → capture data dict or None:**

Searches accumulated `dom_captures` (most-recent-first) for matching screen.
Returns the `data` sub-dict (containing `text_nodes`, `ax_nodes`, `selects`).

**`_openai_match(failure, text_nodes)` → match dict or None:**

Sends GPT-4o the failed step + up to 60 text nodes. Returns `{element_key, selector_text, css_class, description, type}` or `{element_key: None}`. Falls back to `_heuristic_match()` if no API key.

**`_heuristic_match(failure, text_nodes)` → match dict or None:**

Pass 1: case-insensitive exact `node['text']` match. Pass 2: `target in node['text'].lower()` partial. Returns minimal match dict or `None`.

**`_patch_config(screen, element_key, element_data, logs)` → bool:**

Reads `Elements_Config/<screen>.json`, upserts entry under `_discovered_by_agent` group,
writes back. Patched elements get `selector:{type:"text",text,exact:true}`, `_status:"[REVIEW]"`.

**`update_config_node(state)` flow:**

For each failure:
1. Find DOM capture for the failure's screen
2. If no capture → fall back to `qdrant_context` text nodes
3. Call `_openai_match()` (or `_heuristic_match()`)
4. If match found → call `_patch_config()` and record in `new_patches`
5. Return: `{'config_patches': new_patches, 'status': 'updating', 'log_messages'}`
   (Note: `config_patches` uses `operator.add`)

---

### 18.8 `agentic/nodes/report.py` — Final Report Nodes

Two terminal nodes; each returns `report` dict and final `status`.

**`report_success_node(state)` → dict:**

Counts steps/passes from `step_results`, retries from `retry_count`,
patches from `len(config_patches)`. Sets `status: 'success'`.

Report dict keys: `status`, `total_steps`, `passed`, `failed` (always 0), `retry_count`,
`config_patches`, `completed_at` (ISO timestamp).

**`report_failure_node(state)` → dict:**

Counts from `step_results`, lists unresolved failures with category and root_cause.
If patches were applied: "Re-run — the agent may succeed now."
If no patches: "Consider running npm run spike:popup manually."

Report dict keys: `status`, `total_steps`, `passed`, `failed`, `retry_count`,
`config_patches`, `unresolved` (list of `{step, error, category}`), `completed_at`.

---

### 18.9 `agentic/run.py` — CLI Entry Point

```powershell
python -m agentic.run inputs/test_steps/example.txt
python -m agentic.run inputs/test_steps/example.txt --max-retries 5
python -m agentic.run inputs/test_steps/example.txt --seed-qdrant
```

**Arguments:**
- `test_file` — positional; path to `.txt` file (must exist)
- `--max-retries` — integer, default 3
- `--seed-qdrant` — flag; seeds ChromaDB from `Elements_Config/` before running

**Behaviour:**

1. Loads `.env` via `python-dotenv` if present
2. Validates `test_file` exists (exits 1 if not)
3. Optional: `seed_from_configs(config_dir)` and print count
4. Calls `make_initial_state()` then `agent.stream(state, stream_mode='values')`
5. After all events: prints full `log_messages` list, then summary line
6. Exit code: `0` = success, `1` = failure, `130` = KeyboardInterrupt

Note: the comment in `run.py` still mentions `--seed-qdrant` (historical name from when
Qdrant was the planned vector DB). The actual implementation calls `seed_from_configs()`
which writes to ChromaDB. The flag name is harmless legacy.

---

## 19. Implementation Reference — Node.js Bridge Scripts

Both scripts live in `agentic_scripts/` and are called by Python nodes via `subprocess.run()`.

---

### 19.1 `agentic_scripts/run_steps.js` — Step Execution Bridge

**Invocation:**
```
node agentic_scripts/run_steps.js <steps_input.json> <results_output.json>
```

**Input:** `{ "steps": [ {action, to|text|timeout|direction|amount, raw}, ... ] }`

**Output:** `{ "success": bool, "total": N, "passed": N, "failed": N, "steps": [ {step, success, duration_ms, error?, dom_snapshot?}, ... ] }`

`dom_snapshot` present on failure: `{ "text_nodes": [{text, tag, role, class}, ...] }` (up to 100 nodes).

**Exit codes:** `0` = all automatable steps passed, `1` = one or more failed.

**Behaviour:**

- Calls `launchMagician()` once — all steps share one app session
- Runs steps in order; **stops on first failure** (stop-on-first-failure)
  - Avoids cascading errors from a bad state (e.g. wrong screen after nav failure)
- `cannot_automate` steps push a synthetic failure entry and `continue` (do not stop)
- `dom_snapshot` captured on failure via `captureDomSnapshot(page)`:
  - TreeWalker over `document.body` (SHOW_TEXT), up to 100 nodes
  - Each node: `{ text, tag, role, class }`
  - Returns `null` on any error (non-critical)
- `page.isClosed()` guard before every `navigate` step (detects app crash)

**Per-action implementation:**

| Action | Implementation |
|--------|---------------|
| `navigate` | `navigateTo(page, step.to)` from navigator.js |
| `click` | `clickText(page, step.text)` → throw if returns `false`; then `waitForTimeout(500)` |
| `verify` | `page.getByText(step.text, { exact: false }).first().waitFor({ state: 'attached', timeout: 10_000 })` |
| `verify_absent` | `page.getByText(step.text).count()` → throw if count > 0 |
| `wait` | `page.waitForTimeout(step.timeout \|\| 1000)` |
| `scroll` | `page.mouse.wheel(dx, dy)` then `waitForTimeout(300)` |
| `select` | `clickText(page, step.text)` → same as click (React dropdowns use visible text) |

**On any error (thrown or caught):** captures DOM snapshot and returns failure object.
The outer `main()` catch writes error JSON to output file and exits 1.

---

### 19.2 `agentic_scripts/capture_dom.js` — DOM Capture Bridge

**Invocation:**
```
node agentic_scripts/capture_dom.js '<json_config>'
```
Config is passed as a single shell-escaped JSON string argument.

**Input config:** `{ "screen": "performance_benchmark", "pre_actions": [{action, text}], "popup_wait_ms": 5000 }`

**Output (stdout):** `{ "screen", "captured_at", "text_nodes": [{text, tag, role, class}], "ax_nodes": [{role, name, states}], "selects": [{name, current, options}] }`

**Exit codes:** `0` = success JSON on stdout, `1` = error JSON on stdout.

**Capture sequence:**

1. `launchMagician()` — full launch with sidebar readiness gate
2. `navigateTo(page, config.screen, { verify: false })` — navigate without marker assertion
3. `waitForTimeout(2_000)` — let screen render
4. Execute `pre_actions` sequentially — for `click` actions: `clickText()` then `waitForTimeout(popup_wait_ms)`
5. Capture A — **text_nodes**: TreeWalker over `document.body` (SHOW_TEXT), truncate class to 50 chars
6. Capture B — **ax_nodes**: CDP `Accessibility.getFullAXTree`, filter to `INTERACTIVE_ROLES`:
   `button`, `combobox`, `listbox`, `option`, `radio`, `checkbox`, `menuitem`, `menu`,
   `menubar`, `tab`, `tablist`, `slider`
7. Capture C — **selects**: `document.querySelectorAll('select')` (native HTML selects)
8. `closeMagician(app)` in `finally`
9. `process.stdout.write(JSON.stringify(result))`

---

## 20. Implementation Reference — ChromaDB / element_store.py

**File:** `agentic/tools/element_store.py`

**Persistence:** `chroma_db/` folder at project root (relative to this file's `parent.parent.parent`).
No server process needed — ChromaDB runs in-process via `PersistentClient`.

**Collection name:** `magician_elements`

**Embedding function selection (at collection creation time):**
- If `OPENAI_API_KEY` is set: `OpenAIEmbeddingFunction(model='text-embedding-3-small')`
  — best quality, consistent with GPT-4o calls
- Else: `DefaultEmbeddingFunction()` — `all-MiniLM-L6-v2` via onnxruntime,
  ~80 MB download on first use, no API key needed

**Distance metric:** cosine (`hnsw:space: cosine`)

**Document format** (what gets embedded):
```python
document = f"{element['text']} {element['description']} {element['css_class']}"
```
Fields are concatenated and filtered for falsy values.

**ID generation (`_make_id`):**
- Config elements (have `element_key`): `"{screen}__{element_key}"` — e.g. `"dashboard__nav_home_dashboard"`
- Reinspect discoveries: `"{screen}__{source}__{text[:40].lower().replace(' ', '_')}"`

**Deterministic IDs** mean re-seeding is always safe — `upsert()` updates in place.

**Public API:**

```python
# Store or update one element
upsert_element(element: dict) -> bool
# element keys: screen, element_key, text, description, css_class,
#               selector_type, type, source

# Vector similarity search
search_similar_elements(query: str, screen: str|None = None, limit: int = 5) -> list
# Returns: [{ 'score': 0.92, 'screen': '...', 'text': '...', ... }, ...]
# score = 1 - cosine_distance (1.0 = identical, 0.0 = unrelated)
# where={'screen': screen} filter applied only if screen is not None

# Seed from all Elements_Config/*.json files
seed_from_configs(config_dir: str) -> int   # returns count of elements processed
```

**`seed_from_configs()` detail:**

Iterates all `*.json` in `config_dir`. For each file:
- Uses filename stem as screen name
- Iterates groups (skips keys starting with `_`)
- For each element (skips keys starting with `_`, skips entries without `selector`):
  - Calls `upsert_element()` with `source='config'`

**Error handling:** all three public functions catch exceptions and return
`False` / `[]` / `0` rather than raising — the agent degrades gracefully
if ChromaDB is unavailable.

---

## 21. Implementation Reference — Test Helpers

All helpers live in `tests/helpers/`. They are used by spec files AND by the agentic
bridge scripts (`run_steps.js`, `capture_dom.js`) which `require()` from the same folder.

### `appLauncher.js` — exports `{ launchMagician, closeMagician }`

Full launch sequence documented in Section 4. Key constants: `MAX_RETRIES=3`,
`LAUNCH_WAIT=12_000 ms`, `SIDEBAR_READY_MS=40_000 ms`, `SIDEBAR_READY_INT=500 ms`.
`closeMagician(app)` → `browser.close()` + `proc.kill('SIGTERM')` + `startService()`.

### `navigator.js` — exports `{ navigateTo, clickText, buildLocator, SIDEBAR_LABELS, SCREEN_MARKERS }`

Full nav patterns in Sections 5–7. Key constant: `SETTLE_MS=2_000 ms`.

`navigateTo(page, screenName, { verify=true })` steps:
1. Lookup `SIDEBAR_LABELS[screenName]` (throws if unknown)
2. Poll DOM for `POLL_LABEL_OVERRIDE[screenName] || sidebarLabel`, up to 20 s
3. If `HOVER_REVEAL[screenName]` exists → `_revealSidebarItem(page, hoverParent)`
4. `clickText(page, sidebarLabel)` → throws if false
5. `waitForTimeout(2_000)`
6. If `verify`: assert `SCREEN_MARKERS[screenName]` is attached

`buildLocator(page, selector)` — maps `selector.type`:
- `text`/`domClick` → `page.getByText(text, { exact })`
- `role`/`iframe` → `page.getByRole(role, { name })`

### `elementLoader.js` — exports `{ loadScreen, flattenElements, clearCache }`

In-memory `Map` cache — each JSON read once per process.
`loadScreen(name)` → reads `Elements_Config/<name>.json`.
`flattenElements(config)` → flat `{ key: elementDescriptor }` map; skips `_`-prefixed keys,
handles both leaf elements (have `selector`) and group objects (iterate their children).

### `logger.js` — exports `{ debug, info, warn, error }`

Thin wrapper: each call writes one JSON line to `console.log` with `timestamp` + `level` + fields.
Level filter via `LOG_LEVEL` env var (default `info`). Captured by Playwright HTML reporter.

---

## 22. Implementation Reference — Streamlit UI

**File:** `agentic/ui/app.py`

**Run command:**
```powershell
streamlit run agentic/ui/app.py
# OR:
npm run agent:ui
```
Opens at http://localhost:8501.

**Path bootstrap:** adds project root to `sys.path` so `agentic.*` imports work regardless
of working directory.

**Page config:** `layout='wide'`, icon `🧙`, title `'Magician Test Agent'`.

**Session state:** `run_history` (list of past run summaries), `last_log` (last run's log lines).

### Sidebar

- Samsung Magician badge image (via shields.io)
- **OpenAI API Key** text input (password) — reads from `OPENAI_API_KEY` env var, writes back on change
- **Max self-heal retries** slider (1–5, default 3)
- **Seed Knowledge Base** button: calls `seed_from_configs(Elements_Config/)`, shows count
- Warning: "Must run as Administrator"
- Version label: `v1.0 · LangGraph + ChromaDB + GPT-4o`

### Two-column layout

```python
col_output, col_inputs = st.columns([3, 2])
```

**Right column (`col_inputs`) — always visible:**

1. `st.file_uploader` for `.txt` files → decodes UTF-8 → displays in `st.code` block
2. Divider
3. `st.subheader` "Supported Step Syntax" → `st.code` with example steps
4. `st.caption` listing all action keywords
5. Divider
6. `▶  Create TC` button (primary, disabled until file uploaded)

**Left column (`col_output`) — three states:**

- **No file uploaded:** `st.info('⬆️ Upload a test steps file...')`
- **File loaded, not run:** `st.info('📋 File loaded. Click Create TC to execute.')`
- **Running / completed:**
  1. `from agentic.agent import agent, make_initial_state`
  2. Build `initial_state` with file content and `max_retries`
  3. `st.subheader` "Live Execution"
  4. `progress_bar = st.progress(0, text='Starting…')`
  5. `log_container = st.empty()`
  6. **Streaming loop:** `for event in agent.stream(initial_state, stream_mode='values'):`
     - Compute progress pct from `PHASE_ORDER` index (parsing/executing/diagnosing/reinspecting/updating)
     - Update progress bar with phase icon + status
     - Update `log_container` with last 60 log lines (`st.code`)
  7. **Final results:**
     - Success/failure banner (`st.success` / `st.error`)
     - 5-column metrics row: Total Steps / Passed / Failed / Retries / Config Patches
     - Three tabs:
       - **📋 Step Details** — one `st.expander` per step; failures show error + DOM snapshot (first 30 nodes)
       - **🔧 Config Patches** — one `st.expander` per patch; shows `st.json` of element_data
       - **📜 Full Log** — `st.code` of all log lines + `st.download_button` for `.txt` export
  8. Appends to `st.session_state.run_history`

**Phase icons:**
```python
PHASE_ICON = {
    'parsing': '📝', 'executing': '▶️', 'diagnosing': '🔍',
    'reinspecting': '🔎', 'updating': '✏️', 'success': '✅', 'failed': '❌',
}
```

**Session run history:** shown below both columns (full-width); last 8 runs, newest first.
Displays: icon, time, filename, passed/total, retries, patches.

---

## 23. npm Scripts Reference

All scripts in `package.json`. All require **Administrator PowerShell**.

### Test suite

| Script | Command | Notes |
|--------|---------|-------|
| `npm test` | `playwright test` | Full suite, workers:1, serial |
| `npm run test:smoke` | `playwright test tests/smoke` | Just launch tests |
| `npm run test:nav` | `playwright test tests/navigation` | Just sidebar nav tests |
| `npm run test:screens` | `playwright test tests/screens` | Just screen tests |
| `npm run report` | `playwright show-report` | Open HTML report |

### Spike / inspection

| Script | Command | Purpose |
|--------|---------|---------|
| `npm run spike` | `node spike/capture_accessibility_tree.js` | Capture AX trees for original 5 screens |
| `npm run spike:uia` | PowerShell UIA script | UIAutomation inspection (limited) |
| `npm run spike:popup` | `node spike/inspect_popup.js` | Capture popup/dialog DOM |
| `npm run spike:sidebar-hover` | `node spike/inspect_sidebar_hover.js` | Investigate hover mechanics |
| `npm run spike:all-screens` | `node spike/inspect_all_screens.js` | Hover all groups, capture all screens |

### Re-inspection

| Script | Command | Notes |
|--------|---------|-------|
| `npm run reinspect` | `node spike/reinspect.js` | Dry-run diff |
| `npm run reinspect:update` | `node spike/reinspect.js --update` | Write discovered elements |
| `npm run reinspect:drives` | `node spike/reinspect.js --all-drives --update` | Multi-drive scan |

### Agentic flow

| Script | Command | Notes |
|--------|---------|-------|
| `npm run agent:ui` | `streamlit run agentic/ui/app.py` | Streamlit dashboard |
| `npm run agent:run` | `python -m agentic.run` | CLI runner (append file path) |
| `npm run agent:seed` | Python one-liner | Seed ChromaDB from Elements_Config |

### `playwright.config.js` settings

```js
{
  testDir:       './tests',
  timeout:       60_000,            // per-test timeout
  expect:        { timeout: 10_000 },
  workers:       1,                 // MANDATORY — single-instance app
  fullyParallel: false,
  reporter:      [
    ['html', { outputFolder: 'playwright-report', open: 'never' }],
    ['list'],
  ],
  use: {
    screenshot: 'only-on-failure',
    video:      'retain-on-failure',
    trace:      'on-first-retry',
  },
}
```

---

## 24. Original Requirements vs. Reality

`DetailedRequirements.md` (in project root) documents the original planned approach.
Key divergences discovered during the initial spike:

| Planned | Actual |
|---------|--------|
| `_electron.launch()` for launch | `chromium.connectOverCDP()` — app detects `--inspect`, quits |
| Rich ARIA roles (button, combobox, link) | Nearly all `generic`/`none` — no roles on interactive elements |
| `page.getByRole()` selectors | `page.getByText()` + JS DOM walker dispatchEvent |
| Retry launch 2×, 10 s timeout | Full SVC stop/kill/5 s sleep/respawn + 40 s sidebar gate |
| Sidebar items accessible normally | CSS `visibility:hidden` — only JS `dispatchEvent('click')` works |
| 10 screens planned | 9 confirmed, some with hover-reveal sub-items not in DOM at rest |
| Config: `{ role, name }` | Config: `{ selector: { type, text, exact }, dynamic, ... }` |
| Only `@playwright/test` deps | Added: Python + LangGraph + ChromaDB + GPT-4o + Streamlit (agentic layer) |

The agentic layer was added after the spike confirmed that manual config maintenance
would be burdensome. See Sections 12–18 for full implementation detail.
