# MagicianNewWay — Claude Code Context

## What this project is
Playwright accessibility-tree test automation framework for **Samsung Magician** (Electron app, Windows only).  
Tests navigate the app via CDP, capture AX trees, and assert UI state using text-based selectors.  
When hardware changes (new drives, different SATA/NVMe mix) the re-inspection system updates configs automatically.

---

## Critical: Always run as Administrator
```powershell
# Every npm run spike / npm test / npm run reinspect must be from an Administrator PowerShell.
# Reason: stopping SamsungMagicianSVC requires admin elevation.
# Silently fails without admin — service keeps running and kills the spawned app.
```

---

## Quick commands
```powershell
npm run spike              # capture AX snapshots for all 5 screens (read-only, non-destructive)
npm test                   # run full Playwright test suite (workers:1, serial)
npm run report             # open HTML test report in browser

npm run reinspect          # re-capture AX tree, diff against configs, report new elements (dry-run)
npm run reinspect:update   # same + auto-patch configs with discovered elements
npm run reinspect:drives   # cycle through ALL connected drives, update configs for each
```

---

## App under test
- **EXE:** `C:\Program Files (x86)\Samsung\Samsung Magician\SamsungMagician.exe`
- **Service:** `SamsungMagicianSVC` (runs as SYSTEM, auto-start) — must be stopped before launch
- **Debug port:** `--remote-debugging-port=9222`
- **Connection:** `chromium.connectOverCDP(wsUrl)` — NOT `_electron.launch()`

---

## Launch sequence — why it is complex

Samsung Magician has **three** layered single-instance checks:
```js
Yt = Vt.amIAlreadyRunning();          // napiWrapper — named-pipe IPC with SVC
Qt = Vt.amIAlreadyRunningGlobally();  // napiWrapper — global check via service
Kt = app.requestSingleInstanceLock(); // Electron built-in lock file
```
`SamsungMagicianSVC` holds the named-pipe server. Even after killing the UI process, the service keeps
the pipe alive, so any new debug-launched instance sees itself as a "second instance" and calls
`app.quit()` within ~60 ms. **The service must be stopped first.**

### Working sequence (implemented in `appLauncher.js` and `spike/capture_accessibility_tree.js`)
1. `net stop SamsungMagicianSVC /y` — release the named pipe (admin required)
2. `taskkill /F /IM SamsungMagician.exe` AND `taskkill /F /IM SamsungMagicianSVC.exe` — kill BOTH
3. Sleep **5 s** — let OS release mutex + pipe handles  
   *(3 s was not enough when the previous test's `afterAll` just called `startService()` and the
   service was still initialising when the next test's `stopService()` ran — the service won the
   named-pipe race and killed the freshly spawned app)*
4. Spawn with `--remote-debugging-port=9222` (no `--user-data-dir` for tests, fresh dir for reinspect)
5. Capture DevTools WS URL from process **stderr** (appears within ~500 ms)
6. `chromium.connectOverCDP(wsUrl)` — connect immediately
7. `net start SamsungMagicianSVC` → poll until the `main/main.html` page appears (up to 40 s)
8. After 2 s render sleep, call `page.isClosed()` — if true, retry (SVC race condition)

### Kill rule (invariant — applies everywhere: tests, spike, reinspect)
**Always kill BOTH processes:**
```powershell
taskkill /F /IM SamsungMagician.exe
taskkill /F /IM SamsungMagicianSVC.exe
```
Killing only the UI EXE leaves the service alive holding the named pipe.

---

## Accessibility tree — use raw CDP, NOT page.accessibility

`page.accessibility` is **undefined** when connected via `connectOverCDP()`.

```js
async function getAxTree(page) {
  const session = await page.context().newCDPSession(page);
  try {
    await session.send('Accessibility.enable');
    const { nodes } = await session.send('Accessibility.getFullAXTree');
    // nodes is a flat array — build parent→child tree from parentId references
  } finally {
    await session.detach().catch(() => {});
  }
}
```

UIAutomation (UIA) only exposes 2 nodes (`[dialog] → [region]`) unless
`--force-renderer-accessibility` is passed or a screen reader is active.  
**CDP `Accessibility.getFullAXTree` is the only viable approach.**

---

## Navigation rule — use clickText() / JS DOM walker

Samsung Magician v8 has **no ARIA roles** on any interactive elements (all `generic` / `none`).  
Sidebar items have CSS `visibility: hidden` — Playwright's `.click({ force: true })` fails silently.

**Working approach (`tests/helpers/navigator.js`):**
```js
// Strategy 1 & 2: Playwright getByText with force:true — works for main content area
// Strategy 3 (required for sidebar): JS DOM walker via page.evaluate
const clicked = await page.evaluate((searchText) => {
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  let node;
  while ((node = walker.nextNode())) {
    if (node.textContent.trim() === searchText) {
      const el = node.parentElement;
      if (el) {
        el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
        return true;
      }
    }
  }
  return false;
}, text);
```

### Sidebar readiness polling (added after "Help Center not found" bug)
The sidebar React component can take 1–2 s to hydrate after launch. Before calling `clickText()`,
`navigateTo()` polls the DOM for the sidebar label to appear (up to 8 s, every 400 ms).

### Hover-revealed sidebar items (discovered 2026-05-24)
Some sidebar items are **not in the DOM at rest** — they are dynamically injected when a parent
group receives a `mouseover`/`mouseenter` event.  Confirmed via `spike/inspect_sidebar_hover.js`:

| Screen | Trigger | Parent group |
|--------|---------|-------------|
| `over_provisioning` | JS `dispatchEvent(mouseover)` on `"Performance Management"` | Performance Management |
| `data_migration` | `page.mouse.move()` sweep across sidebar column (x≈47) | Likely "Data Management" group — not yet confirmed by targeted hover spike |

CSS class for these items: `.groupMenuView_iconTooltip_menuItem`

`navigateTo()` handles this automatically via `HOVER_REVEAL` + `_revealSidebarItem()`:
```js
// In navigator.js — called automatically before clicking hover-revealed items
const HOVER_REVEAL = {
  over_provisioning: 'Performance Management',   // JS mouseover on parent
  data_migration:    null,                       // null = mouse sweep
};
```
**Do NOT** call `clickText('Over Provisioning')` or `clickText('Data Migration')` directly —
they are not in the DOM until after `_revealSidebarItem()` is called.  Use `navigateTo()` instead.

---

## ARIA role findings

| Role | Where it appears |
|------|-----------------|
| `RootWebArea` | Page root |
| `StaticText` / `InlineTextBox` | All text content |
| `generic` | All containers and interactive divs |
| `none` | Many wrapper divs |
| `image` | Icons |
| `Iframe` | Newsroom + Help Center content areas |
| **`button`** | **System Details screen only** (3 tab buttons) |
| `DescriptionList` / `term` / `definition` | System Details screen only |

**Consequence:** Use `page.getByText()` and `clickText()` for navigation. Only the three tab buttons
on System Details legitimately use `page.getByRole('button', { name })`.

---

## Confirmed screens (9 total, 2 TBD)

| Screen key | Sidebar label | Text nodes | Notes |
|------------|--------------|------------|-------|
| `dashboard` | "Home Dashboard" | ~111 | Default landing screen; 4 widgets embedded |
| `system_details` | "System Details" | ~89, 3 AX | Only screen with real `button` roles (3 tabs) |
| `performance_benchmark` | hover "Performance Management" → "Performance Benchmark" | ~179 | LNB sub-screen; default when PM group clicked |
| `over_provisioning` | hover "Performance Management" → "Over Provisioning" | ~24 | **Hover-revealed** LNB sub-screen; "not supported" on non-Samsung drives |
| `data_migration` | mouse sweep → "Data Migration" | TBD | **Hover-revealed**; parent group likely "Data Management" |
| `newsroom` | "Newsroom" | ~16 | Iframe — AX tree shows shell only |
| `help_center` | "Help Center" | ~15 | Iframe — AX tree shows shell only |
| `chatbot` | "Chatbot" | TBD | Confirmed in sidebar 2026-05-24; screen content not yet captured |
| `settings` | "Settings" | ~39 | Real content (startup options, etc.) |

### Full sidebar structure (confirmed 2026-05-24 via all_screens spike)
```
Home Dashboard                          ← featureItemView_homeDashboard_text
Diagnosis & Information  [group]        ← groupMenuView_group_text (sub-items: unknown — not yet hovered)
Performance Management   [group]        ← groupMenuView_group_text / group_text_selected
  └─ Performance Benchmark              ← groupMenuView_iconTooltip_menuItem (also lnbMenuView_menuListArea_item)
  └─ Performance Optimization           ← groupMenuView_iconTooltip_menuItem (also lnbMenuView_menuListArea_item)
  └─ Over Provisioning                  ← groupMenuView_iconTooltip_menuItem (also lnbMenuView_menuListArea_item)
Data Management          [group]        ← groupMenuView_group_text (sub-items: likely Data Migration — not yet confirmed)
Security Settings        [group]        ← groupMenuView_group_text (sub-items: unknown — not yet hovered)
System Details                          ← globalItemView_systemDetailText
Newsroom                                ← globalItemView_newsRoomText
Help Center                             ← globalItemView_helpCenterText
Chatbot                                 ← globalItemView_chatbotText
Settings                                ← globalItemView_settingsText
```

**Dashboard also embeds Drive Health, Diagnostic Scan, and Performance Optimization widgets.**
Performance Benchmark has its own dedicated sidebar screen (`performance_benchmark`) in addition
to the dashboard widget.

### System Details — tab state trap
The spike was run with the "System Details" tab active (because the spike reused the same
`MagicianSpike` user-data-dir and preserved tab state). **The real default is "System Summary" tab.**

- `beforeAll` must explicitly click the "System Details" tab before asserting tab-specific content.
- "Motherboard" and "BIOS" sections appear in **both** System Summary and System Details tabs —
  these tests pass even without the tab switch.
- "Memory Information" appears **only** in the System Details tab — it is the confirmation marker.
- Slot-count suffix `(2/2)` is machine-specific — use `"Memory Information"` with `exact: false`.
- Tests that require the System Details tab active are guarded with `test.skip(!systemDetailsTabActive, …)`.

### Newsroom / Help Center
Both screens render external web content inside an iframe. The AX tree shows the shell only.
- Tests use `{ verify: false }` in `navigateTo()` to skip the screen-marker assertion.
- Iframe presence is asserted via `page.locator('iframe[title="Newsroom Feature"]')`.
- `page.getByText('Newsroom Feature')` does NOT work — it matches text content, not `title` attributes.

---

## Test architecture

### Parallelism — workers: 1 is mandatory
```js
// playwright.config.js
workers: 1,
fullyParallel: false,
```
Samsung Magician is single-instance. Parallel workers would both try to stop/start SamsungMagicianSVC
and spawn the app simultaneously — guaranteed conflict.

### Test file layout
```
tests/
  smoke/
    app_launch.spec.js          # 4 tests — does it launch and show the dashboard?
  navigation/
    sidebar_navigation.spec.js  # 7 tests — can we click each sidebar item?
  screens/
    dashboard.spec.js           # 16 tests — widget headings, labels, buttons
    system_details.spec.js      # 18 tests — tabs, section headings, field labels
    newsroom.spec.js            # 5 tests  — iframe presence, stability
    help_center.spec.js         # 5 tests  — iframe presence, stability
    settings.spec.js            # 11 tests — group labels, descriptions, Delete button
```

### Selector strategy
- `type: "text"` → `page.getByText(text, { exact })` — used for all labels/headings
- `type: "role"` → `page.getByRole(role, { name })` — only for System Details tab buttons
- `type: "domClick"` → built as `page.getByText()` but click goes through `clickText()` JS walker
- `type: "iframe"` → `page.getByRole(role, { name })` — for iframe accessible name assertions

### Assertion rule — toBeAttached, not toBeVisible
Sidebar elements are CSS `visibility: hidden`. Use `toBeAttached()` (exists in DOM) not
`toBeVisible()` (visible to user). For content area elements, either works but `toBeAttached()` is
safer across tab-switching scenarios.

---

## Service restart race condition — how it was diagnosed and fixed

**Symptom:** `dashboard.spec.js` crashed with "Target page, context or browser has been closed"
in `beforeAll`, but only when run after another spec file.

**Root cause chain:**
1. `system_details.spec.js` `afterAll` calls `closeMagician` → `startService()`
2. Service starts but hasn't finished initialising (named-pipe not yet open)
3. `dashboard.spec.js` `beforeAll` calls `launchMagician` → `stopService()` runs while service is
   still in its startup phase
4. Service finishes starting, wins the named-pipe check on the freshly spawned app
5. App sees itself as "already running", calls `app.quit()` — page closes

**Fix (three parts in `appLauncher.js`):**
1. Pre-spawn sleep: `3_000 ms` → `5_000 ms` (covers service initialisation time)
2. `page.on('close')` listener registered **before** `waitForLoadState` (catches the early quit)
3. `page.isClosed()` guard after the 2 s render sleep — throws so `MAX_RETRIES` loop retries

---

## Re-inspection system

### When to use
Run `npm run reinspect:update` whenever:
- A new Samsung SSD is connected (may unlock new features / screens)
- Samsung Magician is updated to a new version
- Tests start failing because elements changed
- You want to verify configs are still accurate

### CLI flags
```powershell
node spike/reinspect.js                    # dry-run: capture + diff, no file writes
node spike/reinspect.js --update           # write discovered elements to configs
node spike/reinspect.js --all-drives       # cycle through all connected drives
node spike/reinspect.js --screen settings  # inspect a single screen only
node spike/reinspect.js --all-drives --update  # full multi-drive update
```

### How it works
1. **Launches with a fresh unique user-data-dir** (`MagicianReinspect_<timestamp>`) so tab state
   is always at default — no stale state from previous runs.
2. **Detects drive context:** drive model names, interfaces (NVMe/SATA), and count pattern ("1 / 3").
3. **Discovers unknown sidebar items:** walks all DOM text nodes, filters against a `NON_NAV_TEXTS`
   exclusion set, and tries each candidate by clicking it and measuring AX node count delta.
   Delta ≥ 15 = confirmed new screen.
4. **Diffs per screen:** `extractConfigNames()` separates static vs. dynamic config selectors.
   Dynamic selectors (ON/OFF toggle states, drive names) are excluded from "missing" reports.
5. **Patches configs:** New elements go into a `_discovered_YYYYMMDD` group marked `[REVIEW]`.
   New screens get a full skeleton config with `navigation`, `header`, and `_discovered` groups.
6. **Multi-drive cycling:** `switchToNextDrive()` clicks drive-switcher arrows (">", "›", "→").

### Output
- Console report: per-screen delta table + manual follow-up steps
- `spike/output/reinspect_<YYYY-MM-DDTHH-MM>.json` — full machine-readable result
- Patched `Elements_Config/<screen>.json` files (only with `--update`)

### After running reinspect:update — manual follow-up
1. Open each patched `Elements_Config/*.json`
2. Find `_discovered_YYYYMMDD` groups
3. Move each entry to the correct named group (e.g. `page_structure`, `navigation`)
4. Change `"dynamic": true` to `false` if the element is actually stable
5. Update `"type"` from `"unknown"` to the correct type
6. Remove `[REVIEW]` from `description`
7. If a new screen was created, populate its `navigation` and `header` groups manually

### Key files
```
spike/
  reinspect.js                # Orchestrator — CLI entry point
  lib/
    configDiff.js             # Reusable diff/patch utilities (no side effects unless configPath given)
```

---

## Key files — full map
```
Elements_Config/              # One JSON per screen — the source of truth for selectors
  dashboard.json
  system_details.json
  newsroom.json
  help_center.json
  settings.json

spike/
  capture_accessibility_tree.js   # Spike script — captures AX trees for all 5 screens
  reinspect.js                    # Re-inspection orchestrator (npm run reinspect)
  lib/
    configDiff.js                 # loadConfig, extractConfigNames, diffElements, patchConfig, createNewConfig
  FINDINGS.md                     # Full technical findings, architecture notes, screen inventory
  output/                         # Captured AX trees + summary (not committed)

tests/
  helpers/
    appLauncher.js    # launchMagician() / closeMagician() — handles SVC stop/start/race
    navigator.js      # navigateTo(), clickText(), buildLocator()
    elementLoader.js  # loadScreen(), flattenElements() — reads Elements_Config JSON
    logger.js         # Structured JSON logger (writes to logs/)
  smoke/
    app_launch.spec.js
  navigation/
    sidebar_navigation.spec.js
  screens/
    dashboard.spec.js
    system_details.spec.js
    newsroom.spec.js
    help_center.spec.js
    settings.spec.js

playwright.config.js   # workers:1, fullyParallel:false, html+list reporters
package.json
```

---

## Do not
- Do **NOT** use `_electron.launch()` — app detects `--inspect` flag and quits
- Do **NOT** use `page.getByRole()` for navigation — no roles on interactive elements
- Do **NOT** call `page.accessibility.snapshot()` — undefined with connectOverCDP
- Do **NOT** run without Administrator privileges — service stop silently fails
- Do **NOT** kill only `SamsungMagician.exe` — always kill `SamsungMagicianSVC.exe` too
- Do **NOT** set `workers > 1` in playwright.config.js — single-instance app, guaranteed conflicts
- Do **NOT** assert field VALUES (drive model, temperatures, scores) — machine-specific
- Do **NOT** assume System Details tab is the default — it is "System Summary"; always click the tab

---

## New machine setup checklist
```powershell
# 1. Install Samsung Magician from Samsung's website (required to be installed)
# 2. Open Administrator PowerShell
# 3. Navigate to this folder
cd "C:\code\MagicianNewWay"   # or wherever you cloned it

# 4. Install dependencies
npm install

# 5. Verify the app path exists
Test-Path "C:\Program Files (x86)\Samsung\Samsung Magician\SamsungMagician.exe"

# 6. Run the spike to capture fresh AX trees for this machine's hardware
npm run spike 2>&1 | Tee-Object -FilePath spike\output\spike_log.txt

# 7. Run reinspect to check if configs are accurate for this machine
npm run reinspect

# 8. If reinspect reports new elements, update configs
npm run reinspect:update

# 9. Run the test suite
npm test

# 10. Check the report
npm run report
```

### If Samsung Magician is not installed at the default path
Update `EXE_PATH` in:
- `tests/helpers/appLauncher.js` (line ~7)
- `spike/capture_accessibility_tree.js` (near top)
- `spike/reinspect.js` (near top)

### If tests fail on a new machine
1. Run `npm run reinspect` — it will show what's present vs. what the config expects
2. Check "missingInCapture" — these are static selectors the tests assert but the machine doesn't show
   (may mean a feature is hardware-gated on this machine)
3. Use `test.skip` for hardware-gated tests rather than deleting them
