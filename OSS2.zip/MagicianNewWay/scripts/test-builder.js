'use strict';

/**
 * test-builder.js
 *
 * Interactive CLI for generating Samsung Magician Playwright tests.
 *
 *   npm run build-test
 *   node scripts/test-builder.js
 *
 * Flow:
 *   1. Greet the user and ask for input method (interactive or file)
 *   2. Collect ALL steps (no step-by-step evaluation)
 *   3. Validate all steps at once and show the full report
 *   4. If any step cannot be automated → exit with CANNOT AUTOMATE message
 *   5. If all steps pass → write tests/<name>.spec.js and show run command
 *
 * Script name is derived from the first step.
 * Step files live in inputs/test_steps/*.txt
 */

const readline = require('readline');
const fs       = require('fs');
const path     = require('path');

const { parseStringStep } = require('../tests/helpers/stepRunner');

// ── Paths ────────────────────────────────────────────────────────────────────
const ROOT        = path.join(__dirname, '..');
const TESTS_DIR   = path.join(ROOT, 'tests');
const STEPS_DIR   = path.join(ROOT, 'inputs', 'test_steps');

// ── ANSI colours ─────────────────────────────────────────────────────────────
const A = {
  reset:  '\x1b[0m',
  bold:   '\x1b[1m',
  dim:    '\x1b[2m',
  green:  '\x1b[32m',
  red:    '\x1b[31m',
  yellow: '\x1b[33m',
  cyan:   '\x1b[36m',
};
const clr  = (col, s) => `${A[col]}${s}${A.reset}`;
const W    = 64;                                    // box inner width
const HR   = clr('dim', '  ' + '─'.repeat(W));

// ── Box primitives ────────────────────────────────────────────────────────────
const boxTop  = col => clr(col, '╔' + '═'.repeat(W) + '╗');
const boxMid  = col => clr(col, '╠' + '═'.repeat(W) + '╣');
const boxBot  = col => clr(col, '╚' + '═'.repeat(W) + '╝');
const boxRow  = (col, txt) =>
  clr(col, '║') + ' ' + txt.padEnd(W - 1) + clr(col, '║');

// ── Welcome banner ────────────────────────────────────────────────────────────
function showBanner() {
  console.clear();
  console.log('\n' + boxTop('cyan'));
  console.log(boxRow('cyan', clr('bold', '  Samsung Magician  ·  Test Builder')));
  console.log(boxMid('cyan'));
  console.log(boxRow('cyan', '  Provide steps interactively or from a file.'));
  console.log(boxRow('cyan', '  All steps are validated together at the end.'));
  console.log(boxRow('cyan', '  First step sets the script name.'));
  console.log(boxMid('cyan'));
  console.log(boxRow('cyan', clr('dim', '  Supported steps:')));
  console.log(boxRow('cyan', clr('dim', '    navigate to <screen>           click [on] <text>')));
  console.log(boxRow('cyan', clr('dim', '    click tab <name>               verify <text>')));
  console.log(boxRow('cyan', clr('dim', '    verify <text> is not visible   wait <ms>')));
  console.log(boxRow('cyan', clr('dim', '    scroll down [pixels]           scroll up [pixels]')));
  console.log(boxRow('cyan', clr('dim', '    select <option>                select <opt> from <field>')));
  console.log(boxRow('cyan', clr('dim', '  Screens: dashboard | system_details |')));
  console.log(boxRow('cyan', clr('dim', '           performance_benchmark | newsroom')));
  console.log(boxRow('cyan', clr('dim', '           help_center | settings')));
  console.log(boxRow('cyan', clr('dim', '  Navigate accepts spaces & "screen" suffix:')));
  console.log(boxRow('cyan', clr('dim', '    navigate to performance benchmark screen')));
  console.log(boxBot('cyan'));
  console.log();
}

// ── readline helpers ──────────────────────────────────────────────────────────
function makePrompt() {
  const rl  = readline.createInterface({ input: process.stdin, output: process.stdout });
  const ask = q  => new Promise(res => rl.question(q, res));
  return { rl, ask };
}

// ── Input method selection ────────────────────────────────────────────────────
async function chooseInputMethod(ask) {
  console.log('  How would you like to provide test steps?\n');
  console.log(`    ${clr('bold', '[1]')}  Type steps interactively`);
  console.log(`    ${clr('bold', '[2]')}  Load from a file  ` +
              clr('dim', '(inputs/test_steps/*.txt)'));
  console.log();
  const ans = (await ask('  Your choice [1 / 2] : ')).trim();
  console.log();
  return ans === '2' ? 'file' : 'interactive';
}

// ── Interactive: collect all steps first, validate later ──────────────────────
async function collectInteractive(ask) {
  console.log(HR);
  console.log();
  console.log(`  ${clr('bold', 'Enter steps — one per line.')}  Empty line when done.\n`);

  const steps = [];
  let n = 1;
  while (true) {
    const raw = (await ask(`  Step ${String(n).padStart(2)} :  `)).trim();
    if (!raw) {
      if (steps.length === 0) {
        console.log(clr('yellow', '\n  No steps entered.\n'));
        return [];
      }
      break;
    }
    steps.push(raw);
    n++;
  }
  return steps;
}

// ── File: list .txt files and let user pick one ───────────────────────────────
async function collectFromFile(ask) {
  // Ensure the folder exists
  if (!fs.existsSync(STEPS_DIR)) {
    fs.mkdirSync(STEPS_DIR, { recursive: true });
  }

  const files = fs.readdirSync(STEPS_DIR)
    .filter(f => f.endsWith('.txt'))
    .sort();

  if (files.length === 0) {
    console.log(clr('yellow',
      `  No .txt files found in inputs/test_steps/\n` +
      `  Create one and try again.\n`
    ));
    return [];
  }

  console.log(HR);
  console.log();
  console.log(`  ${clr('bold', 'Available step files:')}\n`);
  files.forEach((f, i) => {
    console.log(`    ${clr('bold', `[${i + 1}]`)}  ${f}`);
  });
  console.log();

  const ans   = (await ask(`  Choose a file [1–${files.length}] : `)).trim();
  const idx   = parseInt(ans, 10) - 1;

  console.log();

  if (isNaN(idx) || idx < 0 || idx >= files.length) {
    console.log(clr('red', '  Invalid choice.\n'));
    return [];
  }

  const chosen   = files[idx];
  const filePath = path.join(STEPS_DIR, chosen);

  console.log(clr('dim', `  Reading: inputs/test_steps/${chosen}\n`));

  const lines = fs.readFileSync(filePath, 'utf8')
    .split(/\r?\n/)
    .map(l => l.trim())
    .filter(l => l && !l.startsWith('#'));

  if (lines.length === 0) {
    console.log(clr('yellow', '  File has no usable steps (all blank or comments).\n'));
    return [];
  }

  return lines;
}

// ── Validate all steps and print a full report ────────────────────────────────
function validateAll(steps) {
  console.log(HR);
  console.log();
  console.log(`  ${clr('bold', `Validating ${steps.length} step${steps.length > 1 ? 's' : ''}...`)}\n`);

  let anyFailed = false;
  const results = steps.map((raw, i) => {
    const parsed  = parseStringStep(raw);
    const ok      = parsed.action !== 'cannot_automate';
    const num     = String(i + 1).padStart(2);

    if (ok) {
      console.log(
        `  ${num}.  ${clr('green', '✔')}  ${clr('dim', raw)}`
      );
    } else {
      console.log(
        `  ${num}.  ${clr('red',   '✗')}  ${raw}`
      );
      console.log(
        `        ${clr('red', '↳  ' + parsed.reason)}`
      );
      anyFailed = true;
    }
    return { raw, parsed, ok };
  });

  console.log();
  return { results, anyFailed };
}

// ── Cannot-automate exit box ──────────────────────────────────────────────────
function showCannotAutomate(results) {
  const failed = results.filter(r => !r.ok);

  console.log(boxTop('red'));
  console.log(boxRow('red', clr('bold', '  ✗  CANNOT AUTOMATE')));
  console.log(boxRow('red', `     Test steps do not cover 100% of the scenario.`));
  console.log(boxMid('red'));
  console.log(boxRow('red', `  ${failed.length} step${failed.length > 1 ? 's' : ''} cannot be automated:`));
  console.log(boxRow('red', ''));
  for (const r of failed) {
    const line = `    • ${r.raw}`.slice(0, W - 1);
    console.log(boxRow('red', line));
    const reason = `      ${r.parsed.reason}`.slice(0, W - 1);
    console.log(boxRow('red', clr('dim', reason)));
  }
  console.log(boxRow('red', ''));
  console.log(boxRow('red', '  Fix or remove the flagged steps, then run again.'));
  console.log(boxBot('red'));
  console.log();
}

// ── Script filename from step 1 ───────────────────────────────────────────────
function toFilename(step) {
  const name = step
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 55);
  return `${name}.spec.js`;
}

// ── Spec file content ─────────────────────────────────────────────────────────
function buildSpec(filename, testName, steps) {
  const stepLines = steps.map(s => `  ${JSON.stringify(s)},`).join('\n');
  return `'use strict';

/**
 * ${filename}
 *
 * Generated by : npm run build-test
 * Generated on : ${new Date().toISOString().slice(0, 10)}
 * Steps        : ${steps.length}
 *
 * Run:
 *   npx playwright test tests/${filename} --reporter=list
 */

const { defineTest } = require('./helpers/testBuilder');

defineTest(${JSON.stringify(testName)}, [
${stepLines}
]);
`;
}

// ── Step summary before writing ───────────────────────────────────────────────
function showSummary(filename, steps) {
  console.log(HR);
  console.log();
  console.log(`  ${clr('bold', 'Script name')}  →  tests/${clr('cyan', filename)}`);
  console.log(`  ${clr('bold', 'Steps')}        →  ${steps.length}`);
  console.log();
  steps.forEach((s, i) => {
    console.log(clr('dim', `  ${String(i + 1).padStart(2)}.  ${s}`));
  });
  console.log();
}

// ── Success box ───────────────────────────────────────────────────────────────
function showSuccess(filename) {
  const runCmd = `npx playwright test tests/${filename} --reporter=list`;
  console.log(boxTop('green'));
  console.log(boxRow('green', clr('bold', '  ✔  Script generated successfully!')));
  console.log(boxMid('green'));
  console.log(boxRow('green', ''));
  console.log(boxRow('green', `  File  :  tests/${filename}`));
  console.log(boxRow('green', ''));
  console.log(boxRow('green', '  Run   :'));
  console.log(boxRow('green', `    ${runCmd}`));
  console.log(boxRow('green', ''));
  console.log(boxRow('green', clr('dim', '  ⚠  Must be run from Administrator PowerShell')));
  console.log(boxRow('green', clr('dim', '     cd "C:\\code\\MagicianNewWay"')));
  console.log(boxRow('green', ''));
  console.log(boxBot('green'));
  console.log();
}

// ── Main ──────────────────────────────────────────────────────────────────────
async function main() {
  showBanner();

  const { rl, ask } = makePrompt();

  // ── 1. Choose input method ─────────────────────────────────────────────────
  const method = await chooseInputMethod(ask);

  // ── 2. Collect steps ───────────────────────────────────────────────────────
  const steps = method === 'file'
    ? await collectFromFile(ask)
    : await collectInteractive(ask);

  rl.close();

  if (!steps || steps.length === 0) {
    console.log(clr('dim', '  Exiting — no steps to process.\n'));
    return;
  }

  // ── 3. Validate all at once ────────────────────────────────────────────────
  const { results, anyFailed } = validateAll(steps);

  // ── 4. Cannot automate → exit ──────────────────────────────────────────────
  if (anyFailed) {
    showCannotAutomate(results);
    process.exit(1);
  }

  // ── 5. Derive filename and show summary ────────────────────────────────────
  const filename = toFilename(steps[0]);
  const outPath  = path.join(TESTS_DIR, filename);

  showSummary(filename, steps);

  // ── 6. Overwrite guard ─────────────────────────────────────────────────────
  if (fs.existsSync(outPath)) {
    const { rl: rl2, ask: ask2 } = makePrompt();
    const ans = (await ask2(
      clr('yellow', `  ⚠  tests/${filename} already exists. Overwrite? [Y / N] : `)
    )).trim().toUpperCase();
    rl2.close();
    console.log();
    if (ans !== 'Y') {
      console.log(clr('dim', '  Cancelled. No file written.\n'));
      return;
    }
  }

  // ── 7. Write file ──────────────────────────────────────────────────────────
  const content = buildSpec(filename, steps[0], steps);
  fs.writeFileSync(outPath, content, 'utf8');

  // ── 8. Success ─────────────────────────────────────────────────────────────
  showSuccess(filename);
}

main().catch(err => {
  console.error(clr('red', `\n  Error: ${err.message}\n`));
  process.exit(1);
});
