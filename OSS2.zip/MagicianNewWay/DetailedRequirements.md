# Samsung Magician Test Automation Framework — Detailed Requirements

## 1. Overview

Build a Playwright-based test automation framework that drives the Samsung Magician Electron desktop application via its accessibility tree. The framework must be maintainable, CI-friendly, and require zero pixel-level image comparison — all element selection is done through ARIA roles, names, and accessibility IDs.

---

## 2. Target Application

| Property | Value |
|---|---|
| Executable | `C:\Program Files (x86)\Samsung\Samsung Magician\SamsungMagician.exe` |
| App type | Electron (Chromium-based, BrowserWindow) |
| Launch args | None required for normal mode |
| Min supported version | To be confirmed during initial spike |

---

## 3. Project Structure

```
MagicianNewWay/
├── Elements_Config/              # Per-screen element descriptor JSONs
│   ├── dashboard.json
│   ├── drive_info.json
│   ├── performance_benchmark.json
│   ├── over_provisioning.json
│   ├── secure_erase.json
│   ├── psid_revert.json
│   ├── firmware_update.json
│   ├── diagnostic_scan.json
│   ├── drive_health.json
│   └── settings.json
│
├── tests/                        # Playwright test files
│   ├── smoke/
│   │   └── app_launch.spec.js
│   ├── navigation/
│   │   └── sidebar_navigation.spec.js
│   ├── screens/
│   │   ├── dashboard.spec.js
│   │   ├── drive_info.spec.js
│   │   ├── performance_benchmark.spec.js
│   │   ├── over_provisioning.spec.js
│   │   ├── secure_erase.spec.js
│   │   ├── firmware_update.spec.js
│   │   ├── diagnostic_scan.spec.js
│   │   ├── drive_health.spec.js
│   │   └── settings.spec.js
│   └── helpers/
│       ├── appLauncher.js        # Launch/teardown Electron app
│       ├── elementLoader.js      # Load Elements_Config JSONs
│       ├── navigator.js          # Navigate between screens
│       └── logger.js             # Structured logging wrapper
│
├── playwright.config.js
├── package.json
└── DetailedRequirements.md
```

---

## 4. Framework Architecture

### 4.1 Electron Launch (appLauncher.js)

- Use `_electron.launch()` from `@playwright/test` (no CDP workaround needed).
- Wait for the main `BrowserWindow` with `electronApp.firstWindow()`.
- Expose `electronApp` and `page` as shared fixtures via `playwright.config.js` `use.launchOptions`.
- On teardown, call `electronApp.close()`.
- Retry launch up to 2 times if the process fails to start within 10 s.

```js
// Minimal shape — actual implementation in helpers/appLauncher.js
const { _electron: electron } = require('@playwright/test');
async function launchMagician() {
  const app = await electron.launch({
    executablePath: 'C:\\Program Files (x86)\\Samsung\\Samsung Magician\\SamsungMagician.exe',
  });
  const page = await app.firstWindow();
  await page.waitForLoadState('domcontentloaded');
  return { app, page };
}
```

### 4.2 Element Config Loader (elementLoader.js)

- `loadScreen(screenName)` reads `Elements_Config/<screenName>.json` synchronously at test setup.
- Returns a plain object whose keys are logical element names; values are selector descriptors (see §5).
- Caches loaded configs in a module-level Map so each JSON is read at most once per test run.

### 4.3 Navigation Helper (navigator.js)

- `navigateTo(page, screenName)` clicks the correct sidebar/top-nav link to reach the target screen.
- After click, waits for the screen's heading landmark (`role=heading, name=<screen title>`) to be visible.
- Navigation map is a plain JS object — no magic, easy to update when the app changes.

### 4.4 Logger (logger.js)

- Thin wrapper around `console.log`; writes structured JSON lines to stdout.
- Fields per log line: `timestamp`, `level` (`info|warn|error|debug`), `screen`, `element`, `action`, `status`, `detail`.
- In CI, stdout is captured by the Playwright HTML reporter automatically.
- Playwright's built-in `page.on('console', …)` is attached in appLauncher to surface renderer-side logs.

---

## 5. Elements_Config — Schema

Each JSON file describes one application screen. Schema:

```jsonc
{
  "screen": "dashboard",               // logical name, matches filename
  "title": "Dashboard",                // expected heading text for navigation assertion
  "elements": {
    "<logicalName>": {
      "role": "<aria-role>",           // required — ARIA role string
      "name": "<accessible-name>",     // required — visible label or aria-label
      "description": "<human note>",   // optional — what this element does
      "type": "link|button|combobox|listitem|heading|img|checkbox|menuitem|tab",
      "navigatesTo": "<screenName>",   // optional — screen this link/button leads to
      "options": ["opt1", "opt2"],     // optional — expected values for combobox/listitem
      "state": "enabled|disabled|visible|hidden"  // optional — expected default state
    }
  }
}
```

All selectors in tests are built as:
```js
page.getByRole(el.role, { name: el.name })
```
No CSS class selectors, no XPath, no text-only selectors unless ARIA is unavailable.

---

## 6. Screen-by-Screen Element Inventory

### 6.1 Dashboard

Expected elements:
- App logo / branding image
- Sidebar navigation links (one entry per screen — see §6.10)
- Drive selector dropdown (combobox) — lists detected drives by model name
- Drive health status indicator (heading or img with aria-label "Good / Warning / Critical")
- Total capacity text
- Used space text / progress indicator
- Temperature reading
- Quick-action buttons: "Benchmark", "Firmware Update", "Diagnostic Scan"
- Notification banner area (role=alert, may be absent)

### 6.2 Drive Info

Expected elements:
- Screen heading "Drive Information" or "Drive Info"
- Drive model name (text, role=term or paragraph)
- Serial number
- Firmware version
- Interface type (SATA / NVMe / USB)
- Total capacity
- Power on count
- Power on hours
- Total bytes written (TBW)
- Drive status badge

### 6.3 Performance Benchmark

Expected elements:
- Screen heading "Performance Benchmark"
- Drive selector (combobox) — may mirror Dashboard selector
- "Start" button (initiates benchmark)
- Benchmark mode selector: "Sequential" / "Random" tabs or radio group
- Block size selector (combobox): 4KB, 8KB, 128KB, 1MB
- Queue depth selector (combobox)
- Test area size selector (combobox)
- Results table / grid: Sequential Read, Sequential Write, Random Read 4K, Random Write 4K (MB/s values)
- "Stop" button (visible only during active benchmark)
- "Save Results" button

### 6.4 Over Provisioning

Expected elements:
- Screen heading "Over Provisioning"
- Drive selector (combobox)
- Current OP % indicator
- OP % input / slider
- "Set" / "Apply" button
- Reset to default button
- Warning dialog elements (role=dialog): confirm, cancel buttons

### 6.5 Secure Erase

Expected elements:
- Screen heading "Secure Erase"
- Drive selector
- Erase mode selector: "ATA Secure Erase" / "Enhanced Secure Erase" (radio or combobox)
- Warning checkbox: "I understand this action is irreversible"
- "Erase" button (disabled until checkbox checked)
- Confirmation dialog: heading, confirm button, cancel button

### 6.6 PSID Revert

Expected elements:
- Screen heading "PSID Revert"
- Drive selector
- PSID input field (textbox)
- "Revert" button (disabled until PSID entered)
- Warning text / alert
- Confirmation dialog elements

### 6.7 Firmware Update

Expected elements:
- Screen heading "Firmware Update"
- Drive selector
- Current firmware version label
- Latest available version label
- Update source toggle: "Online" / "Manual" (radio or tab)
- "Check for Update" button
- "Update" button (disabled when firmware is current)
- Progress bar (role=progressbar, during update)
- Status message area

### 6.8 Diagnostic Scan

Expected elements:
- Screen heading "Diagnostic Scan"
- Drive selector
- Scan type selector: "Quick Scan" / "Full Scan" (radio or combobox)
- "Start Scan" button
- "Stop Scan" button (visible during scan)
- Progress bar
- Results area: pass/fail per test category
- "Save Report" button

### 6.9 Drive Health

Expected elements:
- Screen heading "Drive Health"
- Drive selector
- Overall health status (heading or status badge)
- SMART attribute table: attribute name, current value, worst value, threshold, raw value
- Health score / percentage
- Estimated lifespan remaining
- Temperature graph / current temp

### 6.10 Settings

Expected elements:
- Screen heading "Settings"
- Language selector (combobox)
- Theme selector: "Light" / "Dark" (radio or combobox)
- Auto-update toggle (checkbox or switch)
- Notification toggle
- "Save" / "Apply" button
- "Reset to Defaults" button
- About section: app version label, copyright text

### 6.11 Sidebar / Global Navigation

Sidebar links present on all screens (role=link or role=menuitem):
- Dashboard
- Drive Info
- Performance Benchmark
- Over Provisioning
- Secure Erase
- PSID Revert
- Firmware Update
- Diagnostic Scan
- Drive Health
- Settings

---

## 7. Test Script Requirements

### 7.1 General Rules

- All test files use `@playwright/test` — `test`, `expect` imports only.
- Each spec file imports `appLauncher`, `elementLoader`, `navigator`, and `logger`.
- `beforeAll`: launch app, load element config for the screen.
- `afterAll`: close app.
- No `page.waitForTimeout()` — use `expect(locator).toBeVisible()` with a timeout.
- Default assertion timeout: 10 000 ms. Extended to 60 000 ms for long operations (benchmark, secure erase).

### 7.2 Smoke Tests (`tests/smoke/`)

| Test | Description |
|---|---|
| App launches | Electron process starts, first window appears within 15 s |
| Dashboard loads | Heading or drive selector visible within 10 s of launch |
| No crash on idle | App remains stable for 5 s after launch with no interaction |

### 7.3 Navigation Tests (`tests/navigation/`)

| Test | Description |
|---|---|
| Sidebar links present | All 10 sidebar links are visible on Dashboard |
| Navigate to each screen | Click each link, assert destination heading is visible |
| Back navigation | Navigate A→B→A and assert A's heading is visible |

### 7.4 Per-Screen Tests (`tests/screens/`)

For each screen, implement these test categories:

1. **Element presence** — assert every element in the screen's config JSON is visible.
2. **Element state** — assert buttons/inputs have the expected default enabled/disabled state.
3. **Dropdown options** — for each combobox, open it and assert the expected option list.
4. **Interaction** — where safe (non-destructive): click buttons, change combobox values, assert UI response.
5. **Navigation links** — assert that links with `navigatesTo` actually navigate to the correct screen.

Destructive actions (Secure Erase, PSID Revert) are tested only up to the confirmation dialog — the final confirm step is **not** executed in automated tests.

---

## 8. Logging Requirements

Every meaningful test step emits a log line before and after the action:

```
[2026-05-23T10:00:00Z] INFO  screen=dashboard element=driveSelector action=getByRole status=found
[2026-05-23T10:00:01Z] INFO  screen=dashboard element=driveSelector action=click status=success
[2026-05-23T10:00:02Z] ERROR screen=dashboard element=benchmarkButton action=isEnabled status=fail detail="expected: enabled, got: disabled"
```

Log levels:
- `DEBUG`: locator built, waits started
- `INFO`: element found, action performed, navigation completed
- `WARN`: element not in config but found on screen; slow response (>3 s)
- `ERROR`: assertion failed, element not found, app crash detected

---

## 9. Configuration (playwright.config.js)

```js
module.exports = {
  testDir: './tests',
  timeout: 60_000,
  expect: { timeout: 10_000 },
  reporter: [['html', { outputFolder: 'playwright-report' }], ['list']],
  use: {
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
    trace: 'on-first-retry',
  },
  projects: [
    { name: 'electron', testMatch: '**/*.spec.js' },
  ],
};
```

---

## 10. package.json Dependencies

```json
{
  "devDependencies": {
    "@playwright/test": "^1.45.0",
    "playwright": "^1.45.0"
  },
  "scripts": {
    "test": "playwright test",
    "test:smoke": "playwright test tests/smoke",
    "test:nav": "playwright test tests/navigation",
    "test:screens": "playwright test tests/screens",
    "report": "playwright show-report"
  }
}
```

---

## 11. Implementation Phases

| Phase | Deliverables | Priority |
|---|---|---|
| 1 — Spike | Launch Electron app from Playwright, capture full accessibility tree snapshot, confirm ARIA roles are populated | Must-have |
| 2 — Infrastructure | `appLauncher`, `elementLoader`, `navigator`, `logger`; `playwright.config.js`; `package.json` | Must-have |
| 3 — Element Configs | All 10 `Elements_Config/*.json` files populated with real ARIA data from spike | Must-have |
| 4 — Smoke & Nav tests | `app_launch.spec.js`, `sidebar_navigation.spec.js` | Must-have |
| 5 — Screen tests | One spec per screen (element presence + state + dropdowns) | Must-have |
| 6 — Interaction tests | Non-destructive interactions per screen | Should-have |
| 7 — Reporting | Playwright HTML report, screenshot-on-failure, video-on-failure | Should-have |

---

## 12. Constraints and Non-Goals

- **No pixel matching** — zero image comparison assertions; all checks are ARIA-based.
- **No live hardware required for CI** — tests that need a physical SSD (benchmark, secure erase) must be skipped gracefully when no drive is detected (`test.skip(condition, reason)`).
- **No external dependencies** beyond `@playwright/test`.
- **Windows only** — Samsung Magician is a Windows application; no cross-platform porting needed.
- **Admin rights** — some Magician operations require elevation; the test runner process must be started as Administrator where needed.
- **Scope exclusion** — performance regression tracking, load testing, and network interception are out of scope for this phase.
