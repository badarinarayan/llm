# Samsung Magician Test Automation Framework
Use playwright accessibility tree to automate electron framework built app: SamsungMagician.

## Samsung Magician installation path
"C:\Program Files (x86)\Samsung\Samsung Magician"\SamsungMagician.exe

## Develop framework to extract elements from Samsung Magician 
- Create Elements_Config folder and dump the configs
- Create test scripts in tests folder
- Test script can be in javascript based on PLaywright API
- Stick to Playwright API for element selection and interaction using Playwright accessibility tree
- Have sufficient logging
- Each screen will have link for other screens, drop down boxes etc identify them and have exhaustive element configuration
