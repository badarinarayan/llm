# Agentic Test Automation Architecture
## Samsung Magician — Self-Healing Test Agent

---

## 1. Overview

The agentic layer wraps the existing Playwright/CDP test infrastructure with an
AI-driven orchestrator that can:

1. Accept natural-language test step files
2. Execute them against the live Samsung Magician Electron app
3. Detect failures and diagnose *why* they failed (element not found, page closed, etc.)
4. **Automatically re-inspect the live UI** to discover missing selectors
5. Patch `Elements_Config/*.json` with discovered elements
6. **Retry** the full step sequence up to `max_retries` times
7. Build a vector knowledge base (Qdrant) of all known UI elements so future runs
   get better first-pass accuracy
8. Surface everything in a real-time Streamlit dashboard

---

## 2. Technology Stack

| Layer              | Technology                          | Purpose                                      |
|--------------------|-------------------------------------|----------------------------------------------|
| Orchestration      | **LangGraph** (Python)              | State-machine retry loop; conditional routing|
| AI reasoning       | **OpenAI GPT-4o**                   | Failure diagnosis; DOM→selector mapping      |
| Embeddings         | **OpenAI text-embedding-3-small**   | Encode element descriptions for search       |
| Vector DB          | **ChromaDB**                        | Store & retrieve known UI element patterns   |
| Browser automation | **Playwright** (Node.js)            | CDP bridge to Samsung Magician Electron app  |
| UI                 | **Streamlit** (Python)              | Real-time test dashboard                     |
| Config store       | **JSON files** (`Elements_Config/`) | Source-of-truth for selectors                |

---

## 3. High-Level Architecture Diagram

```
 ┌──────────────────────────────────────────────────────────────────────┐
 │                        STREAMLIT UI  (agentic/ui/app.py)            │
 │  File upload │ Config (API keys, Qdrant URL) │ Real-time log │ Report│
 └──────────────────────────┬───────────────────────────────────────────┘
                            │  initial state (raw_steps, max_retries)
                            ▼
 ┌──────────────────────────────────────────────────────────────────────┐
 │                  LANGGRAPH AGENT  (agentic/agent.py)                │
 │                                                                      │
 │  ┌────────────┐    ┌──────────────┐    ┌───────────────────────────┐ │
 │  │parse_steps │───▶│execute_steps │───▶│    check_results (router) │ │
 │  └────────────┘    └──────────────┘    └─────┬────────┬────────────┘ │
 │                          ▲                   │        │              │
 │                          │           success │  fail  │ max retries  │
 │                    ┌─────┴────┐              │        │              │
 │                    │  retry   │              ▼        ▼              │
 │                    └─────▲────┘    ┌──────────────┐ ┌────────────┐  │
 │                          │         │report_success│ │report_fail │  │
 │                    ┌─────┴──────┐  └──────────────┘ └────────────┘  │
 │                    │update_cfg  │                                    │
 │                    └─────▲──────┘                                    │
 │                          │                                           │
 │               ┌──────────┴───────────┐                              │
 │               │                      │                              │
 │         ┌─────┴──────┐    ┌──────────┴─────┐                       │
 │         │ reinspect  │    │diagnose_failure │                       │
 │         │(capture_   │    │(OpenAI + Qdrant)│                       │
 │         │ dom.js)    │    └────────────────┘                        │
 │         └────────────┘                                              │
 └──────────────────────────────────────────────────────────────────────┘
          │ subprocess                        │ API calls
          ▼                                   ▼
 ┌──────────────────┐              ┌─────────────────────┐
 │  Node.js Bridge  │              │    OpenAI API       │
 │  run_steps.js    │              │  GPT-4o + embeddings│
 │  capture_dom.js  │              └──────────┬──────────┘
 └────────┬─────────┘                         │
          │ CDP                               ▼
          ▼                        ┌─────────────────────┐
 ┌──────────────────┐              │   Qdrant Vector DB  │
 │ Samsung Magician │              │ magician_elements   │
 │ (Electron / CDP) │              │  collection         │
 └──────────────────┘              └─────────────────────┘
```

---

## 4. LangGraph State Machine

### State Schema (`agentic/state.py`)

```python
class AgentState(TypedDict):
    # ── Input ────────────────────────────────────────────────────────────
    test_file_path: str
    raw_steps: List[str]            # raw lines from the .txt file

    # ── Parsed ───────────────────────────────────────────────────────────
    parsed_steps: List[dict]        # [{action, text, to, direction, …}]

    # ── Execution (replaced each run cycle) ──────────────────────────────
    step_results: List[dict]        # per-step {success, error, dom_snapshot}
    current_run_output: dict        # full JSON from run_steps.js
    failures: List[dict]            # failures with category + diagnosis

    # ── AI context ───────────────────────────────────────────────────────
    qdrant_context: List[dict]      # similar elements retrieved from Qdrant

    # ── Reinspection (accumulated) ───────────────────────────────────────
    dom_captures: List[dict]        # DOM snapshots; accumulate across retries
    config_patches: List[dict]      # patches applied; accumulate across retries

    # ── Control flow ─────────────────────────────────────────────────────
    retry_count: int                # incremented by the retry node
    max_retries: int                # from UI / CLI (default 3)
    status: str                     # current phase label for UI

    # ── Output ───────────────────────────────────────────────────────────
    report: dict                    # final summary
    log_messages: List[str]         # accumulated human-readable log (Annotated reducer)
```

### Nodes

| Node              | What it does                                                              |
|-------------------|---------------------------------------------------------------------------|
| `parse_steps`     | Natural language → structured `ParsedStep` dicts                          |
| `execute_steps`   | Calls `run_steps.js` via subprocess; collects per-step results            |
| `diagnose_failure`| OpenAI GPT-4o + Qdrant search → categorised failures + `needs_reinspect` |
| `reinspect`       | Calls `capture_dom.js` for each failing screen; indexes nodes in Qdrant   |
| `update_config`   | OpenAI matches DOM nodes → element keys; patches `Elements_Config/*.json` |
| `retry`           | Increments `retry_count` then loops back to `execute_steps`               |
| `report_success`  | Builds success summary report                                             |
| `report_failure`  | Builds failure summary report with unresolved failures                    |

### Edges & Routing

```
parse_steps  ──────────────────────────▶  execute_steps
                                               │
                               ┌───────────────┤
                          pass │          fail │  max_retries exhausted
                               ▼               ▼               ▼
                        report_success   diagnose_failure  report_failure
                                               │
                          needs_reinspect?     │
                           ┌───────────────────┤
                       yes │               no  │
                           ▼                   ▼
                       reinspect         update_config
                           │
                           ▼
                       update_config
                           │
                           ▼
                         retry ──────────▶ execute_steps (loop)
```

---

## 5. Data Flows

### A. First Run (Happy Path)
```
test_steps.txt ──parse──▶ [{navigate, performance_benchmark}, {click, Start}, …]
                               │
                      run_steps.js subprocess
                               │
                    ✓ all steps pass → report_success
```

### B. Failure + Auto-Heal
```
test_steps.txt ──parse──▶ steps
                               │
                      run_steps.js: step 3 fails "Apply not found"
                               │
                   diagnose: category=element_not_found, needs_reinspect=true
                               │
                   reinspect: navigate → click "Setup Benchmark" → capture DOM
                               │
                   capture_dom.js outputs {text_nodes, ax_nodes, selects}
                               │
                   Qdrant: index all discovered text nodes
                               │
                   update_config: GPT-4o maps "Apply" → {key:btn_apply, text:"Apply", …}
                               │
                   patch Elements_Config/performance_benchmark.json
                               │
                   retry → run_steps.js runs again
                               │
                    ✓ step 3 now passes → report_success
```

### C. Qdrant Knowledge Accumulation
```
On first run:  seed_from_configs() embeds all Elements_Config selectors → Qdrant
On reinspect:  each discovered text node → embedded → upserted to Qdrant
On diagnose:   failed step text → embed → cosine search → top-5 similar elements
```

---

## 6. Node.js Bridge API Contracts

### `agentic_scripts/run_steps.js`

**Invocation:**
```
node run_steps.js <steps_input.json> <results_output.json>
```

**Input (`steps_input.json`):**
```json
{
  "steps": [
    { "action": "navigate", "to": "performance_benchmark", "raw": "navigate to performance benchmark screen" },
    { "action": "click",    "text": "Setup Benchmark",     "raw": "click on Setup Benchmark" },
    { "action": "select",   "text": "512MB",               "raw": "select 512MB" },
    { "action": "click",    "text": "Apply",               "raw": "click Apply" },
    { "action": "verify",   "text": "Sequential Read",     "raw": "verify Sequential Read" }
  ]
}
```

**Output (`results_output.json`):**
```json
{
  "success": false,
  "total": 5,
  "passed": 2,
  "failed": 3,
  "steps": [
    { "step": {"action":"navigate","to":"performance_benchmark"}, "success": true,  "duration_ms": 4200 },
    { "step": {"action":"click","text":"Setup Benchmark"},        "success": true,  "duration_ms":  350 },
    {
      "step": {"action":"select","text":"512MB"},
      "success": false,
      "error": "Option not found: \"512MB\"",
      "duration_ms": 5100,
      "dom_snapshot": {
        "text_nodes": [
          {"text":"1GB","tag":"div","class":"dropdownItem"},
          {"text":"128MB","tag":"div","class":"dropdownItem"}
        ]
      }
    }
  ]
}
```

**Exit codes:**
- `0` — all steps passed
- `1` — one or more steps failed

---

### `agentic_scripts/capture_dom.js`

**Invocation:**
```
node capture_dom.js '<json_config>'
```

**Input (inline JSON):**
```json
{
  "screen": "performance_benchmark",
  "pre_actions": [
    { "action": "click", "text": "Setup Benchmark" }
  ],
  "popup_wait_ms": 3000
}
```

**Output (stdout JSON):**
```json
{
  "screen": "performance_benchmark",
  "captured_at": "2026-05-24T12:00:00.000Z",
  "text_nodes": [
    {"text":"Setup Benchmark","tag":"div","role":"","class":"benchmarkView_SetupBenchmark"},
    {"text":"Test Volume",    "tag":"div","role":"","class":"popupView_label"},
    {"text":"(C:) OS (475GB)","tag":"div","role":"","class":"dropdownView_selected"},
    {"text":"Test Range",     "tag":"div","role":"","class":"popupView_label"},
    {"text":"1GB",            "tag":"div","role":"","class":"dropdownItem_selected"},
    {"text":"128MB",          "tag":"div","role":"","class":"dropdownItem"},
    {"text":"512MB",          "tag":"div","role":"","class":"dropdownItem"},
    {"text":"Apply",          "tag":"div","role":"","class":"popupView_btn_apply"},
    {"text":"Cancel",         "tag":"div","role":"","class":"popupView_btn_cancel"}
  ],
  "ax_nodes": [],
  "selects": []
}
```

---

## 7. ChromaDB Collection Schema

**Collection:** `magician_elements`  
**Persisted to:** `chroma_db/` in the project root (auto-created)  
**Embeddings:** OpenAI `text-embedding-3-small` (if API key set) or built-in ONNX model  
**Distance:** Cosine

### Metadata fields

| Field          | Type   | Description                                        |
|----------------|--------|----------------------------------------------------|
| `screen`       | string | Screen key (e.g. `performance_benchmark`)          |
| `element_key`  | string | Config key (e.g. `btn_apply`)                      |
| `text`         | string | Visible text / selector text                       |
| `description`  | string | Human description from Elements_Config             |
| `css_class`    | string | First CSS class (e.g. `popupView_btn_apply`)       |
| `selector_type`| string | `text`, `role`, `domClick`                         |
| `type`         | string | `action`, `label`, `info`, `dropdown`, `unknown`   |
| `source`       | string | `config` (seeded) or `reinspect` (discovered live) |

### Seeding
Run once before first test to load all Elements_Config data:
```
Streamlit sidebar → "🌱 Seed from Configs"
```
Or programmatically:
```python
from agentic.tools.element_store import seed_from_configs
seed_from_configs("Elements_Config/")
```

---

## 8. Directory Structure

```
MagicianNewWay/
├── AGENTIC_ARCHITECTURE.md         ← this file
│
├── agentic/                        ← Python agent package
│   ├── __init__.py
│   ├── state.py                    # LangGraph AgentState TypedDict
│   ├── agent.py                    # Graph definition + compile()
│   ├── run.py                      # CLI entry point (python -m agentic.run)
│   │
│   ├── nodes/                      # One file per LangGraph node
│   │   ├── __init__.py
│   │   ├── parse_steps.py
│   │   ├── execute_steps.py
│   │   ├── diagnose.py
│   │   ├── reinspect.py
│   │   ├── update_config.py
│   │   └── report.py
│   │
│   ├── tools/                      # Reusable tools (no LangGraph coupling)
│   │   ├── __init__.py
│   │   └── element_store.py        # Qdrant CRUD + OpenAI embeddings
│   │
│   └── ui/                         # Streamlit dashboard
│       ├── __init__.py
│       └── app.py
│
├── agentic_scripts/                ← Node.js bridge scripts
│   ├── run_steps.js                # Execute structured steps → JSON results
│   └── capture_dom.js             # Capture DOM snapshot for a screen
│
├── Elements_Config/                ← Existing: source-of-truth JSON configs
├── tests/                          ← Existing: Playwright spec files
├── spike/                          ← Existing: inspection scripts
│
├── requirements-agentic.txt        ← Python dependencies
└── .env.example                    ← Environment variable template
```

---

## 9. Setup & Running

### Prerequisites
- Node.js ≥ 18 (existing)
- Python ≥ 3.11
- ChromaDB (installed via pip, no server needed)
- OpenAI API key
- Samsung Magician installed at default path

### Install Python dependencies
```powershell
pip install -r requirements-agentic.txt
```

### ChromaDB — nothing to start
ChromaDB runs in-process and persists data to `chroma_db/` inside the project
folder automatically. No server, no install beyond `pip install chromadb`.

### Configure environment
```powershell
copy .env.example .env
# Edit .env: set OPENAI_API_KEY, QDRANT_URL
```

### Seed knowledge base (one-time)
```powershell
# Via Streamlit UI: sidebar → "🌱 Seed from Configs"
# OR via CLI:
python -c "from agentic.tools.element_store import seed_from_configs; seed_from_configs('Elements_Config/')"
```

### Run via Streamlit UI
```powershell
# From Administrator PowerShell (required — agent launches Samsung Magician)
streamlit run agentic/ui/app.py
```

### Run via CLI
```powershell
# From Administrator PowerShell
python -m agentic.run inputs/test_steps/example_benchmark.txt --max-retries 3
```

---

## 10. Failure Diagnosis Categories

| Category           | Meaning                                                          | Agent action               |
|--------------------|------------------------------------------------------------------|----------------------------|
| `element_not_found`| `clickText` returned false; element text not in DOM             | Reinspect screen + popup   |
| `navigation_failed`| `navigateTo` threw; sidebar label missing or SVC race           | Reinspect sidebar          |
| `page_closed`      | `page.waitForTimeout` threw — SVC race condition                | Re-launch Magician         |
| `timeout`          | `waitFor` exceeded timeout — element slow to appear              | Reinspect + adjust wait    |
| `unknown`          | Uncategorised JS error                                           | Reinspect for context      |

---

## 11. Extension Points

| Extension                      | Where to add                                      |
|--------------------------------|---------------------------------------------------|
| New action type (e.g. `hover`) | `agentic/nodes/parse_steps.py` + `run_steps.js`  |
| New failure category           | `execute_steps.py` `_categorise()` + `diagnose.py`|
| New screen config              | `Elements_Config/<screen>.json` + `SIDEBAR_LABELS`|
| Multi-drive cycling            | `reinspect.py` → call `switchToNextDrive()` logic |
| Slack notifications            | `report.py` → add Slack webhook call              |
| GitHub Actions CI              | `.github/workflows/` → run as Admin via SSH       |

---

## 12. Key Design Decisions

### Why subprocess bridge (not Python Playwright)?
The existing Node.js helper ecosystem (`appLauncher.js`, `navigator.js`) has months of
hardened logic for the SVC race condition. Rewriting in Python would duplicate fragile
timing-sensitive code. The subprocess bridge reuses all of it unchanged.

### Why Qdrant (not in-memory)?
Embeddings persist across agent runs. The first run seeds 200+ elements from config;
subsequent runs benefit immediately without re-inspection. Qdrant also supports metadata
filtering (by screen) which keeps search precise.

### Why LangGraph (not simple retry loop)?
The self-healing loop has branching logic (reinspect vs. direct patch, per-failure
diagnosis, per-screen grouping). LangGraph makes the state and transitions explicit,
observable via `stream()`, and easy to extend with new nodes.

### Why stop-on-first-failure in run_steps.js?
Cascading failures (step 3 fails → steps 4-10 also fail because state is wrong) would
mislead the diagnosis. Single-failure isolation gives the AI precise context.
