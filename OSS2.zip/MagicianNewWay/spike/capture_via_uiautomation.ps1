<#
.SYNOPSIS
Phase 1 Spike (alternative) - capture Samsung Magician accessibility tree
via Windows UI Automation API.

This script works with the ALREADY-RUNNING Samsung Magician instance, requires
no administrator rights, and produces the same JSON output format as the
CDP-based spike so it can feed directly into Elements_Config authoring.

Usage:
  powershell -ExecutionPolicy Bypass -File spike\capture_via_uiautomation.ps1

Output: spike\output\<screen>_uia.json  and  spike\output\_summary_uia.json
#>

Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes

$OutputDir = Join-Path $PSScriptRoot "output"
if (-not (Test-Path $OutputDir)) { New-Item -ItemType Directory -Force $OutputDir | Out-Null }

function Write-Log {
    param([string]$Level, [string]$Msg)
    $ts = (Get-Date -Format "o")
    Write-Host (ConvertTo-Json @{ timestamp = $ts; level = $Level; msg = $Msg } -Compress)
}

# ── UIAutomation helpers ──────────────────────────────────────────────────────

# Map ControlType IDs to Playwright-compatible ARIA role strings
$ControlTypeRoleMap = @{
    "ControlType.Button"       = "button"
    "ControlType.CheckBox"     = "checkbox"
    "ControlType.ComboBox"     = "combobox"
    "ControlType.DataGrid"     = "grid"
    "ControlType.DataItem"     = "row"
    "ControlType.Document"     = "document"
    "ControlType.Edit"         = "textbox"
    "ControlType.Group"        = "group"
    "ControlType.Header"       = "rowheader"
    "ControlType.Hyperlink"    = "link"
    "ControlType.Image"        = "img"
    "ControlType.List"         = "list"
    "ControlType.ListItem"     = "listitem"
    "ControlType.Menu"         = "menu"
    "ControlType.MenuBar"      = "menubar"
    "ControlType.MenuItem"     = "menuitem"
    "ControlType.Pane"         = "region"
    "ControlType.ProgressBar"  = "progressbar"
    "ControlType.RadioButton"  = "radio"
    "ControlType.ScrollBar"    = "scrollbar"
    "ControlType.Separator"    = "separator"
    "ControlType.Slider"       = "slider"
    "ControlType.Spinner"      = "spinbutton"
    "ControlType.SplitButton"  = "button"
    "ControlType.StatusBar"    = "status"
    "ControlType.Tab"          = "tablist"
    "ControlType.TabItem"      = "tab"
    "ControlType.Table"        = "table"
    "ControlType.Text"         = "text"
    "ControlType.Thumb"        = "slider"
    "ControlType.TitleBar"     = "banner"
    "ControlType.ToolBar"      = "toolbar"
    "ControlType.ToolTip"      = "tooltip"
    "ControlType.Tree"         = "tree"
    "ControlType.TreeItem"     = "treeitem"
    "ControlType.Window"       = "dialog"
    "ControlType.Custom"       = "generic"
}

function Get-RoleString([System.Windows.Automation.AutomationElement]$el) {
    $ct = $el.Current.ControlType.ProgrammaticName
    if ($ControlTypeRoleMap.ContainsKey($ct)) { return $ControlTypeRoleMap[$ct] }
    # fallback: strip "ControlType." prefix and lowercase
    return ($ct -replace "^ControlType\.", "").ToLower()
}

function Get-UIATree {
    param(
        [System.Windows.Automation.AutomationElement]$Element,
        [int]$Depth = 0,
        [int]$MaxDepth = 20
    )

    if ($Depth -gt $MaxDepth) { return $null }

    $cur     = $Element.Current
    $role    = Get-RoleString $Element
    $name    = $cur.Name
    $autoId  = $cur.AutomationId
    $enabled = $cur.IsEnabled
    $offscreen = $cur.IsOffscreen

    $node = [ordered]@{
        role         = $role
        name         = if ($name) { $name } else { $null }
        automationId = if ($autoId) { $autoId } else { $null }
        disabled     = -not $enabled
        offscreen    = $offscreen
        depth        = $Depth
        children     = @()
    }

    # Try to get value for editable controls
    try {
        $valPat = $Element.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern)
        if ($valPat) { $node["value"] = $valPat.Current.Value }
    } catch {}

    # Get children
    $kids = $Element.FindAll(
        [System.Windows.Automation.TreeScope]::Children,
        [System.Windows.Automation.Condition]::TrueCondition
    )
    foreach ($kid in $kids) {
        $childNode = Get-UIATree -Element $kid -Depth ($Depth + 1) -MaxDepth $MaxDepth
        if ($childNode) { $node["children"] += $childNode }
    }

    return $node
}

function Flatten-Tree($node, $results = [System.Collections.Generic.List[object]]::new()) {
    if (-not $node) { return $results }
    $results.Add($node)
    foreach ($child in $node.children) { Flatten-Tree $child $results | Out-Null }
    return $results
}

function Get-Summary($flat) {
    $roles  = $flat | ForEach-Object { $_.role } | Sort-Object -Unique
    $named  = $flat | Where-Object { $_.name } | ForEach-Object {
        [ordered]@{
            role     = $_.role
            name     = $_.name
            disabled = $_.disabled
            value    = $_.value
        }
    }
    return @{
        uniqueRoles    = @($roles)
        namedElements  = @($named)
        totalNodes     = $flat.Count
    }
}

function Tree-ToText($node, $depth = 0) {
    if (-not $node) { return "" }
    $indent  = "  " * $depth
    $namePt  = if ($node.name)  { " `"$($node.name)`""     } else { "" }
    $valPt   = if ($node.value) { " [val=$($node.value)]"  } else { "" }
    $disPt   = if ($node.disabled) { " [disabled]" }          else { "" }
    $out     = "$indent[$($node.role)]$namePt$valPt$disPt`n"
    foreach ($child in $node.children) { $out += Tree-ToText $child ($depth + 1) }
    return $out
}

# ── Find Samsung Magician window ──────────────────────────────────────────────

Write-Log "info" "Searching for Samsung Magician window..."

$root = [System.Windows.Automation.AutomationElement]::RootElement
$allWindows = $root.FindAll(
    [System.Windows.Automation.TreeScope]::Children,
    [System.Windows.Automation.Condition]::TrueCondition
)

$magWindow = $null
foreach ($w in $allWindows) {
    $wName  = $w.Current.Name
    $wClass = $w.Current.ClassName
    Write-Log "debug" "Window: '$wName' class='$wClass' pid=$($w.Current.ProcessId)"
    # Match the Electron window exactly — title is "Samsung Magician", class is Chrome_WidgetWin_1
    if ($wName -eq "Samsung Magician" -and $wClass -eq "Chrome_WidgetWin_1") {
        $magWindow = $w
        Write-Log "info" "Found Samsung Magician window (pid=$($w.Current.ProcessId))"
        break
    }
}

if (-not $magWindow) {
    Write-Log "error" "Samsung Magician window not found. Is it running? Launch it first."
    exit 1
}

# ── Capture current screen tree ───────────────────────────────────────────────

Write-Log "info" "Capturing accessibility tree from current screen..."
$tree = Get-UIATree -Element $magWindow -MaxDepth 25

if (-not $tree) {
    Write-Log "error" "Failed to get accessibility tree"
    exit 1
}

# Save initial / dashboard capture
$screenName = "initial_screen"
$jsonPath   = Join-Path $OutputDir "${screenName}_uia.json"
$txtPath    = Join-Path $OutputDir "${screenName}_uia.txt"

$tree | ConvertTo-Json -Depth 40 | Out-File -FilePath $jsonPath -Encoding utf8
Tree-ToText $tree | Out-File -FilePath $txtPath -Encoding utf8

$flat    = Flatten-Tree $tree
$summary = Get-Summary $flat

$msg = $screenName + " : " + $summary.totalNodes + " nodes / " + $summary.uniqueRoles.Count + " roles / " + $summary.namedElements.Count + " named"
Write-Log "info" $msg
Write-Log "info" ("  Roles: " + ($summary.uniqueRoles -join ", "))

foreach ($el in $summary.namedElements) {
    $dis = if ($el.disabled) { " (disabled)" } else { "" }
    $val = if ($el.value)    { " val=$($el.value)" } else { "" }
    Write-Log "debug" ("  [$($el.role)] `"$($el.name)`"$dis$val")
}

# ── Attempt sidebar navigation ────────────────────────────────────────────────

$sidebarLabels = @(
    "Drive Information",
    "Performance Benchmark",
    "Over Provisioning",
    "Secure Erase",
    "PSID Revert",
    "Firmware Update",
    "Diagnostic Scan",
    "Drive Health",
    "Settings"
)

$globalSummary = @{
    initial_screen = $summary
}

foreach ($label in $sidebarLabels) {
    Write-Log "info" "Navigating to: $label"

    # Find a clickable element matching the label
    $textCondition = New-Object System.Windows.Automation.PropertyCondition(
        [System.Windows.Automation.AutomationElement]::NameProperty,
        $label
    )
    $clickable = $magWindow.FindFirst(
        [System.Windows.Automation.TreeScope]::Descendants,
        $textCondition
    )

    if (-not $clickable) {
        Write-Log "warn" "  Could not find element '$label' - skipping"
        continue
    }

    # Click via InvokePattern or click coords
    try {
        $invokePat = $clickable.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern)
        $invokePat.Invoke()
    } catch {
        # Fall back to mouse click at element center
        $rect = $clickable.Current.BoundingRectangle
        $cx   = [int]($rect.X + $rect.Width  / 2)
        $cy   = [int]($rect.Y + $rect.Height / 2)
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.Cursor]::Position = [System.Drawing.Point]::new($cx, $cy)
        Start-Sleep -Milliseconds 100
        $sig = '[DllImport("user32.dll")] public static extern void mouse_event(int flags, int dx, int dy, int buttons, int info);'
        $type = Add-Type -MemberDefinition $sig -Name Mouse -Namespace Win32 -PassThru
        $type::mouse_event(0x0002, 0, 0, 0, 0)  # MOUSEEVENTF_LEFTDOWN
        $type::mouse_event(0x0004, 0, 0, 0, 0)  # MOUSEEVENTF_LEFTUP
    }

    Start-Sleep -Milliseconds 2500

    # Capture tree
    $screenSlug = $label -replace "\s+", "_" | ForEach-Object { $_.ToLower() }
    $tree2 = Get-UIATree -Element $magWindow -MaxDepth 25

    if ($tree2) {
        $jp = Join-Path $OutputDir "${screenSlug}_uia.json"
        $tp = Join-Path $OutputDir "${screenSlug}_uia.txt"
        $tree2 | ConvertTo-Json -Depth 40 | Out-File -FilePath $jp -Encoding utf8
        Tree-ToText $tree2 | Out-File -FilePath $tp -Encoding utf8

        $flat2    = Flatten-Tree $tree2
        $summary2 = Get-Summary $flat2
        $globalSummary[$screenSlug] = $summary2

        $msg2 = "  " + $screenSlug + " : " + $summary2.totalNodes + " nodes / " + $summary2.uniqueRoles.Count + " roles / " + $summary2.namedElements.Count + " named"
        Write-Log "info" $msg2
        foreach ($el in $summary2.namedElements) {
            $dis = if ($el.disabled) { " (disabled)" } else { "" }
            Write-Log "debug" ("    [$($el.role)] `"$($el.name)`"$dis")
        }
    } else {
        Write-Log "warn" "  Empty snapshot for $label"
    }
}

# ── Write global summary ──────────────────────────────────────────────────────

$summaryPath = Join-Path $OutputDir "_summary_uia.json"
$globalSummary | ConvertTo-Json -Depth 10 | Out-File -FilePath $summaryPath -Encoding utf8
Write-Log "info" "Summary written to $summaryPath"

$allRoles = $globalSummary.Values |
    ForEach-Object { $_.uniqueRoles } |
    Sort-Object -Unique
Write-Log "info" ("All roles across all screens: " + ($allRoles -join ", "))
Write-Log "info" ("Done. Review files in: " + $OutputDir)
