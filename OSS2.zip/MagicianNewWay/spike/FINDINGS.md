# Phase 1 Spike — Findings

**Last run:** 2026-05-23  
**Status:** Complete — all 5 screens captured with distinct accessibility trees.

---

## Quick Start (new machine)

```powershell
# Must be Administrator PowerShell
cd "C:\code\MagicianNewWay"
npm install
npm run spike 2>&1 | Tee-Object -FilePath spike\output\spike_log.txt
```

The spike stops the Samsung Magician service, launches the app under CDP, captures the
accessibility tree for all 5 screens, then restarts the service automatically.

---

## App Architecture

| Property | Value |
|---|---|
| Type | Electron (class `Chrome_WidgetWin_1`) |
| EXE | `C:\Program Files (x86)\Samsung\Samsung Magician\SamsungMagician.exe` (~154 MB) |
| Source | `resources\app\dist\main\app\main.js` (minified) |
| Native addons | `magutils-napi.node`, `uimpewrapper-napi.node` |
| Windows service | `SamsungMagicianSVC` (runs as SYSTEM, auto-start) |

---

## Single-Instance Lock — Why Admin Is Required

Samsung Magician has **three** layered single-instance checks:

```js
Yt = Vt.amIAlreadyRunning();          // napi wrapper — named-pipe IPC with SVC
Qt = Vt.amIAlreadyRunningGlobally();  // napi wrapper — global check via service
Kt = app.requestSingleInstanceLock(); // Electron built-in lock file
```

`SamsungMagicianSVC` holds a named-pipe server that the napi wrapper pings at startup.
Even after killing all `SamsungMagician.exe` UI processes, the service keeps the pipe alive,
so any new debug-launched instance sees itself as "second instance" and calls `app.quit()`
within ~60 ms.

**Working launch sequence (in `spike/capture_accessibility_tree.js`):**
1. `net stop SamsungMagicianSVC /y` — release the pipe (admin required)
2. `taskkill /F /IM SamsungMagician.exe` + `taskkill /F /IM SamsungMagicianSVC.exe`
3. Sleep 3 s — let OS release mutex handles
4. Spawn with `--remote-debugging-port=9222 --user-data-dir=<tmp>`
5. Capture DevTools WS URL from process **stderr** (appears within ~500 ms)
6. `chromium.connectOverCDP(wsUrl)` — connect immediately
7. `net start SamsungMagicianSVC` — restart so napiWrapper can finish init → BrowserWindow opens
8. Poll for page URL containing `main/main.html` (up to 40 s; splash.html appears first, ignore it)

---

## Why UIAutomation Is Insufficient

Chrome/Electron only exposes renderer accessibility to Windows UIA when:
- `--force-renderer-accessibility` is passed, OR
- A screen reader (NVDA, JAWS, Narrator) is active

Without these, UIA sees only 2 nodes: `[dialog] "Samsung Magician"` → `[region]`.

**CDP (`Accessibility.getFullAXTree`) is the only viable approach.**

---

## Why `page.accessibility.snapshot()` Doesn't Work

Playwright's `page.accessibility` property is **undefined** when connected via
`chromium.connectOverCDP()`. Use raw CDP instead:

```js
async function getAxTree(page) {
  const session = await page.context().newCDPSession(page);
  try {
    await session.send('Accessibility.enable');
    const { nodes } = await session.send('Accessibility.getFullAXTree');
    // build parent→child tree from flat node list
  } finally {
    await session.detach().catch(() => {});
  }
}
```

---

## Navigation — Why `page.click()` Fails for Sidebar Items

Samsung Magician's sidebar uses CSS `visibility: hidden` on individual nav elements
(custom animated sidebar). Playwright's `click()` refuses these as non-interactable even
with `{ force: true }`.

**Working solution — JS DOM walker:**

```js
async function clickText(page, text) {
  // Strategies 1+2: Playwright with force (works for main content area)
  for (const exact of [true, false]) {
    try {
      const loc = page.getByText(text, { exact });
      if (await loc.count() > 0) {
        await loc.first().click({ force: true });
        return true;
      }
    } catch (_) {}
  }

  // Strategy 3: JS DOM walker — required for sidebar nav items
  const clicked = await page.evaluate((searchText) => {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      if (node.textContent.trim() === searchText) {
        const el = node.parentElement;
        if (el) {
          el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
          return true;
        }
      }
    }
    return false;
  }, text);
  return !!clicked;
}
```

---

## ARIA Role Findings

Samsung Magician v8 has **almost no ARIA roles** on interactive elements.
Every sidebar nav item, button, and control is rendered as a generic div.

| Role | Where it appears |
|---|---|
| `RootWebArea` | Page root |
| `StaticText` / `InlineTextBox` | All text content |
| `generic` | All containers and interactive divs |
| `none` | Many wrapper divs |
| `image` | Icons |
| `Iframe` | Newsroom + Help Center content areas |
| **`button`** | **System Details screen only** (3 tab buttons) |
| **`DescriptionList`** / `term` / `definition` | **System Details screen only** |

**Consequence for tests:** Use `page.getByText()` and the JS DOM walker, NOT `page.getByRole()`.

---

## Screen Inventory (confirmed 2026-05-23)

| Screen name | Sidebar label | Nodes | Unique roles | Named elements | Notes |
|---|---|---|---|---|---|
| `dashboard` | "Home Dashboard" | 435 | 6 | 65 | Default screen; 4 widgets embedded |
| `system_details` | "System Details" | 428 | 10 | 82 | Has button/term/definition roles; 3 tabs inside |
| `newsroom` | "Newsroom" | 130 | 7 | 7 | Iframe (`"Newsroom Feature"`); shell only in AX tree |
| `help_center` | "Help Center" | 130 | 7 | 7 | Iframe; shell only |
| `settings` | "Settings" | 261 | 6 | 30 | Real content (startup options, etc.) |

### Dashboard widgets (NOT separate nav screens)
These are embedded on the dashboard, not reachable via sidebar nav:
- **Drive Health** — shows S.M.A.R.T., TBW, temperatures
- **Performance Benchmark** — seq/random read+write in MB/s and IOPS; has "Start" button text
- **Diagnostic Scan** — "This drive is not supported" for non-Samsung drives
- **Performance Optimization** — "This drive is not supported" for non-Samsung drives

### System Details inner tabs
Three `[button]` elements (only real buttons in the app):
- "System Summary"
- "System Details"
- "Drive Details"

### Newsroom / Help Center
Both screens render external web content inside an iframe. The accessibility tree
captures only the Samsung Magician shell wrapper (header + device selector + iframe node).
Tests for these screens can only assert the iframe is present; content inside is inaccessible
via `Accessibility.getFullAXTree`.

---

## Real Sidebar Labels (from DOM text dump)

Discovered via `page.evaluate()` querying leaf text nodes:
```
Samsung Magician
Update
Notice
Home Dashboard
System Details
Newsroom
Help Center
Settings
```

No other top-level nav items exist. "0" in the dump is the notification badge count.

---

## Files Produced

| File | Purpose |
|---|---|
| `capture_accessibility_tree.js` | Main spike script — run with `npm run spike` |
| `capture_via_uiautomation.ps1` | UIAutomation alternative (sparse — 2 nodes) |
| `output/_summary.json` | Per-screen role/element summary (node counts, named elements) |
| `output/_page_text.txt` | Unique leaf text nodes (sidebar label discovery) |
| `output/dashboard.{json,txt}` | Full AX tree for dashboard |
| `output/system_details.{json,txt}` | Full AX tree for System Details |
| `output/newsroom.{json,txt}` | Full AX tree for Newsroom (shell + iframe node) |
| `output/help_center.{json,txt}` | Full AX tree for Help Center (shell + iframe node) |
| `output/settings.{json,txt}` | Full AX tree for Settings |
| `output/spike_log.txt` | Full console log from last spike run |

---

## Test Phase Learnings (added after running the full test suite)

### Bug 1 — SVC restart race condition

**Symptom:** `dashboard.spec.js` crashed with "Target page, context or browser has been closed"
in `beforeAll` when run as part of the full suite (but passed alone).

**Root cause:** The previous spec's `afterAll` called `startService()`. The service started but was
still initialising (named pipe not yet open) when the next spec's `launchMagician` called
`stopService()`. The service finished starting, won the named-pipe race against the freshly spawned
app, and the app called `app.quit()`.

**Fix (`tests/helpers/appLauncher.js`):**
1. Pre-spawn sleep: 3 000 ms → 5 000 ms
2. `page.on('close')` registered **before** `waitForLoadState`
3. `page.isClosed()` guard after the 2 s render sleep — throws so `MAX_RETRIES` retries

---

### Bug 2 — Sidebar label not found on Help Center navigation

**Symptom:** `help_center.spec.js` threw "sidebar label 'Help Center' not found on page" in `beforeAll`.

**Root cause:** The sidebar React component had not yet hydrated when `clickText()` was called
immediately after `launchMagician` returned. All three click strategies failed because the text node
did not exist in the DOM yet.

**Fix (`tests/helpers/navigator.js`):**
Added an 8 s poll (400 ms intervals) using the JS DOM walker to confirm the sidebar label is in the
DOM before attempting the click.

---

### Bug 3 — System Details tab content assertion failures

**Symptom:** "Memory Information (2/2)" not found. Also Motherboard/BIOS tests passed even though
the tab was never switched.

**Root cause A — wrong default tab assumption:**
The spike captured the AX tree with the "System Details" tab already active (because the spike reused
the same `MagicianSpike` user-data-dir and the user had left the app on that tab). The real default
tab when launching fresh is "System Summary". Motherboard and BIOS appear in BOTH tabs, so those
tests gave a false pass. "Memory Information" appears ONLY in the System Details tab.

**Root cause B — machine-specific slot count:**
The selector `"Memory Information (2/2)"` with `exact: false` still requires `(2/2)` as a substring.
On a machine with 1 or 4 RAM slots, the count suffix differs and the selector fails.

**Fix:**
- `system_details.spec.js`: robust `beforeAll` with explicit tab click, retry, and
  `systemDetailsTabActive` flag; tab-specific tests guarded with `test.skip(!systemDetailsTabActive)`
- `Elements_Config/system_details.json`: `"Memory Information (2/2)"` → `"Memory Information"` with `exact: false`

---

### Design decisions confirmed by testing

| Decision | Rationale |
|----------|-----------|
| `toBeAttached()` not `toBeVisible()` | Sidebar elements are CSS visibility:hidden |
| `workers: 1` in playwright.config.js | Single-instance app — parallel workers guaranteed to conflict |
| `{ verify: false }` for newsroom/help_center | `SCREEN_MARKERS['newsroom'] = 'Newsroom Feature'` only matches accessible name (iframe title), not text content — `getByText` can't find it |
| Assert LABELS not VALUES | All data fields (temperatures, scores, drive names) are machine-specific |
| `navigateTo(page, 'newsroom', { verify: false })` | iframe accessible name is not a text node |

---

### Tab-specific content reference

| Content | System Summary | System Details | Drive Details |
|---------|---------------|---------------|---------------|
| Motherboard section | ✅ | ✅ | ❌ |
| BIOS section | ✅ | ✅ | ❌ |
| Memory Information | ❌ | ✅ | ❌ |
| PCI Information | ❌ | ✅ | ❌ |
| Drive-specific hardware | ❌ | ❌ | ✅ |

Use "Memory Information" as the sentinel to confirm the System Details tab is active.
