'use strict';

/**
 * spike/inspect_all_screens.js
 *
 * Comprehensive screen inspector — discovers and captures every screen
 * reachable from the Samsung Magician sidebar, including hover-revealed
 * sub-items (Over Provisioning, Data Migration, etc.).
 *
 * What it does:
 *   1. Launches Samsung Magician
 *   2. For each known sidebar group:
 *        a. Dispatches mouseover to reveal hidden sub-items
 *        b. Records every .groupMenuView_iconTooltip_menuItem that appears
 *   3. For every discovered nav item (top-level + hover-revealed):
 *        a. Navigates to the screen (hover-reveal + click)
 *        b. Waits for the screen to render
 *        c. Captures:
 *             • All visible text nodes (tag · role · CSS class)
 *             • Interactive AX nodes (buttons, combos, options…) via CDP
 *             • Native <select> elements
 *        d. Saves to spike/output/screen_<name>_<timestamp>.txt
 *   4. Writes a combined summary file
 *
 * Run from Administrator PowerShell:
 *   npm run spike:all-screens
 *
 * Output: spike/output/screen_<screenName>_*.txt  +  spike/output/all_screens_summary_*.txt
 */

const path = require('path');
const fs   = require('fs');

const { launchMagician, closeMagician } = require('../tests/helpers/appLauncher');
const { clickText }                     = require('../tests/helpers/navigator');

// ── Output setup ──────────────────────────────────────────────────────────────

const OUT_DIR   = path.join(__dirname, 'output');
const TIMESTAMP = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
if (!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive: true });

function makeWriter(filename) {
  const lines = [];
  const write = (line = '') => { console.log(line); lines.push(line); };
  const flush = () => {
    const filePath = path.join(OUT_DIR, filename);
    fs.writeFileSync(filePath, lines.join('\n'), 'utf8');
    console.log(`  → Saved: ${filePath}`);
    return filePath;
  };
  return { write, flush, lines };
}

const HR = '─'.repeat(70);
function box(w, title) { w.write('\n' + HR); w.write(' ' + title); w.write(HR); }

// ── Known sidebar groups to hover (order matters — top to bottom) ─────────────

const SIDEBAR_GROUPS = [
  'Home Dashboard',
  'System Details',
  'Diagnosis & Information',   // collapsed group — sub-items unknown, discovered 2026-05-24
  'Performance Management',    // reveals: Performance Benchmark, Performance Optimization, Over Provisioning
  'Data Management',           // collapsed group — likely reveals: Data Migration (TBD)
  'Security Settings',         // collapsed group — sub-items unknown
  'Newsroom',
  'Help Center',
  'Chatbot',
  'Settings',
];

// ── DOM evaluation helpers ────────────────────────────────────────────────────

async function getTextNodes(page) {
  return page.evaluate(() => {
    const results = [];
    const walker  = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      const t  = node.textContent.trim();
      if (!t) continue;
      const el  = node.parentElement;
      if (!el)  continue;
      const tag  = el.tagName.toLowerCase();
      const role = el.getAttribute('role') || '';
      const cls  = [...el.classList].find(c => c.length > 1) || '';
      results.push({ text: t, tag, role, class: cls.slice(0, 50) });
    }
    return results;
  });
}

async function getAxNodes(page) {
  const INTERACTIVE = new Set([
    'button', 'combobox', 'listbox', 'option',
    'radio', 'checkbox', 'menuitem', 'menu',
    'menubar', 'tab', 'tablist', 'slider',
  ]);
  const session = await page.context().newCDPSession(page);
  try {
    await session.send('Accessibility.enable');
    const { nodes } = await session.send('Accessibility.getFullAXTree');
    return nodes
      .filter(n => n.role && INTERACTIVE.has(n.role.value))
      .map(n => ({
        role:   n.role?.value  || '',
        name:   n.name?.value  || '(no name)',
        states: (n.states || []).map(s => s.value).filter(Boolean),
      }));
  } finally {
    await session.detach().catch(() => {});
  }
}

async function getSelects(page) {
  return page.evaluate(() =>
    [...document.querySelectorAll('select')].map(el => ({
      name:    el.name || el.id || '(unnamed)',
      current: el.value,
      options: [...el.options].map(o => ({ value: o.value, text: o.text })),
    }))
  );
}

// ── Hover a group label and collect newly appeared nav items ──────────────────

async function hoverGroupAndCollect(page, groupLabel) {
  // Snapshot text nodes before hover
  const before = new Set(
    (await getTextNodes(page)).map(n => n.text)
  );

  // Dispatch mouseover + mouseenter on the group
  await page.evaluate((text) => {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      if (node.textContent.trim() === text) {
        const el = node.parentElement;
        if (el) {
          el.dispatchEvent(new MouseEvent('mouseover',  { bubbles: true,  cancelable: true }));
          el.dispatchEvent(new MouseEvent('mouseenter', { bubbles: false, cancelable: true }));
        }
        return;
      }
    }
  }, groupLabel);

  await page.waitForTimeout(600);

  // Snapshot after hover — collect new items with the tooltip class
  const after = await getTextNodes(page);
  const newItems = after.filter(n =>
    !before.has(n.text) &&
    n.class.includes('groupMenuView_iconTooltip_menuItem')
  );

  return newItems;
}

// ── Full sidebar sweep for items with unknown parent ──────────────────────────

async function sweepSidebarAndCollect(page, alreadyKnown) {
  const before = new Set((await getTextNodes(page)).map(n => n.text));

  for (let y = 420; y <= 920; y += 30) {
    await page.mouse.move(47, y);
  }
  await page.waitForTimeout(600);

  const after = await getTextNodes(page);
  return after.filter(n =>
    !before.has(n.text) &&
    !alreadyKnown.has(n.text) &&
    n.class.includes('groupMenuView_iconTooltip_menuItem')
  );
}

// ── Navigate to a screen by hovering parent then clicking ─────────────────────

async function navigateToScreen(page, { label, hoverParent }) {
  // Reveal the item if it needs a hover first
  if (hoverParent) {
    await page.evaluate((text) => {
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      let node;
      while ((node = walker.nextNode())) {
        if (node.textContent.trim() === text) {
          const el = node.parentElement;
          if (el) {
            el.dispatchEvent(new MouseEvent('mouseover',  { bubbles: true,  cancelable: true }));
            el.dispatchEvent(new MouseEvent('mouseenter', { bubbles: false, cancelable: true }));
          }
          return;
        }
      }
    }, hoverParent);
    await page.waitForTimeout(600);
  } else if (hoverParent === null) {
    // Unknown parent — use mouse sweep
    for (let y = 420; y <= 920; y += 30) {
      await page.mouse.move(47, y);
    }
    await page.waitForTimeout(600);
  }

  const ok = await clickText(page, label);
  if (!ok) return false;

  await page.waitForTimeout(3_000);  // let screen render fully
  return true;
}

// ── Capture and write a full screen dump ──────────────────────────────────────

async function captureScreen(page, screenLabel, hoverParent, summaryLines) {
  const safeName = screenLabel.toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, '');
  const w = makeWriter(`screen_${safeName}_${TIMESTAMP}.txt`);

  w.write(`\n  Screen: ${screenLabel}`);
  w.write(`  Hover parent: ${hoverParent === undefined ? 'none (top-level)' : hoverParent ?? 'mouse-sweep'}`);
  w.write(`  Captured: ${new Date().toISOString()}\n`);

  // ── Navigate ──────────────────────────────────────────────────────────────
  const navOk = await navigateToScreen(page, {
    label: screenLabel,
    hoverParent: hoverParent === undefined ? false : hoverParent,
  });

  if (!navOk) {
    w.write(`  ✗  Navigation failed — "${screenLabel}" not found after hover`);
    w.flush();
    summaryLines.push(`  ✗  ${screenLabel}  — navigation FAILED`);
    return;
  }

  // ── Text nodes ────────────────────────────────────────────────────────────
  box(w, 'A) ALL TEXT NODES (tag · role · CSS class)');
  const textNodes = await getTextNodes(page);
  textNodes.forEach((n, i) => {
    const role = n.role  ? `  role="${n.role}"` : '';
    const cls  = n.class ? `  .${n.class}`      : '';
    w.write(`  ${String(i + 1).padStart(3)}.  "${n.text}"  <${n.tag}>${role}${cls}`);
  });

  // ── AX nodes ─────────────────────────────────────────────────────────────
  box(w, 'B) INTERACTIVE AX NODES (buttons, combos, options…)');
  let axNodes = [];
  try {
    axNodes = await getAxNodes(page);
  } catch (e) {
    w.write(`  (AX capture error: ${e.message})`);
  }
  if (axNodes.length === 0) {
    w.write('  (none)');
  } else {
    axNodes.forEach(n => {
      const stateStr = n.states.length ? `  [${n.states.join(', ')}]` : '';
      w.write(`  ${n.role.padEnd(14)}  "${n.name}"${stateStr}`);
    });
  }

  // ── Native <select> ───────────────────────────────────────────────────────
  box(w, 'C) NATIVE <select> ELEMENTS');
  const selects = await getSelects(page);
  if (selects.length === 0) {
    w.write('  (none)');
  } else {
    selects.forEach((s, i) => {
      w.write(`\n  [${i + 1}] name="${s.name}"  current="${s.current}"`);
      s.options.forEach(o => {
        const cur = o.value === s.current ? ' ◀ current' : '';
        w.write(`        value="${o.value}"  text="${o.text}"${cur}`);
      });
    });
  }

  w.write('');
  w.flush();

  summaryLines.push(`  ✓  ${screenLabel.padEnd(28)}  ${textNodes.length} text nodes, ${axNodes.length} AX nodes, ${selects.length} selects`);
}

// ── Main ──────────────────────────────────────────────────────────────────────

async function main() {
  const summary = makeWriter(`all_screens_summary_${TIMESTAMP}.txt`);
  summary.write('\n  inspect_all_screens.js — Full sidebar discovery + screen capture\n');

  let app, page;
  try {
    summary.write('  Launching Samsung Magician…');
    ({ app, page } = await launchMagician());
    summary.write('  Launch OK\n');
  } catch (e) {
    summary.write(`  Launch FAILED: ${e.message}`);
    summary.flush();
    process.exit(1);
  }

  page.on('close', () => summary.write('\n  !! Page closed unexpectedly — SVC race condition'));

  const summaryLines = [];

  try {
    await page.waitForTimeout(2_000);

    // ── Phase 1: Discover all nav items by hovering each group ────────────────
    box(summary, 'PHASE 1 — Hover each group, collect revealed sub-items');

    // screensToDo: [{ label, hoverParent }]
    //   hoverParent = false → top-level item (no hover needed)
    //   hoverParent = string → hover that parent first
    //   hoverParent = null  → mouse sweep (unknown parent)
    const screensToDo = [];
    const knownFromHover = new Set();

    // Top-level clickable groups (clicking the group itself navigates)
    const TOP_LEVEL = [
      { label: 'Home Dashboard',  hoverParent: false },
      { label: 'System Details',  hoverParent: false },
      { label: 'Newsroom',        hoverParent: false },
      { label: 'Help Center',     hoverParent: false },
      { label: 'Chatbot',         hoverParent: false },
      { label: 'Settings',        hoverParent: false },
    ];
    screensToDo.push(...TOP_LEVEL);

    // Hover each sidebar group and collect revealed sub-items
    for (const groupLabel of SIDEBAR_GROUPS) {
      summary.write(`  Hovering: "${groupLabel}"`);
      const revealed = await hoverGroupAndCollect(page, groupLabel);

      if (revealed.length === 0) {
        summary.write(`    → no sub-items revealed`);
        // The group itself is a direct nav target (e.g. "Performance Management"
        // navigates to Performance Benchmark)
        if (!screensToDo.find(s => s.label === groupLabel)) {
          screensToDo.push({ label: groupLabel, hoverParent: false });
        }
      } else {
        revealed.forEach(item => {
          summary.write(`    + "${item.text}"  .${item.class}`);
          knownFromHover.add(item.text);
          screensToDo.push({ label: item.text, hoverParent: groupLabel });
        });
        // The group itself may also be navigable (e.g. click "Performance Management"
        // → Performance Benchmark screen in addition to the revealed sub-items)
        screensToDo.push({ label: groupLabel, hoverParent: false });
      }
    }

    // Mouse sweep to catch any items not revealed by group-specific hover
    summary.write('\n  Mouse sweep across sidebar for remaining items…');
    const sweepItems = await sweepSidebarAndCollect(page, knownFromHover);
    sweepItems.forEach(item => {
      summary.write(`    + "${item.text}"  .${item.class}  (parent: unknown)`);
      screensToDo.push({ label: item.text, hoverParent: null });
    });

    summary.write(`\n  Total screens to inspect: ${screensToDo.length}`);
    // Deduplicate
    const seen = new Set();
    const unique = screensToDo.filter(s => {
      if (seen.has(s.label)) return false;
      seen.add(s.label);
      return true;
    });
    summary.write(`  After dedup: ${unique.length}\n`);
    unique.forEach(s => summary.write(`    • ${s.label}  (hover: ${s.hoverParent ?? 'sweep'})`));

    // ── Phase 2: Navigate to each screen and capture ──────────────────────────
    box(summary, 'PHASE 2 — Navigate + capture each screen');
    summary.write('');

    for (const screen of unique) {
      summary.write(`\n  Inspecting: ${screen.label}`);
      try {
        await captureScreen(page, screen.label, screen.hoverParent, summaryLines);
      } catch (err) {
        summary.write(`  ✗  ERROR: ${err.message}`);
        summaryLines.push(`  ✗  ${screen.label}  — ERROR: ${err.message}`);
      }
    }

    // ── Summary ───────────────────────────────────────────────────────────────
    box(summary, 'SUMMARY');
    summaryLines.forEach(l => summary.write(l));
    summary.write('');
    summary.write(`  Individual screen files: spike/output/screen_*_${TIMESTAMP}.txt`);
    summary.write('');

  } catch (err) {
    summary.write(`\n  UNHANDLED ERROR: ${err.message}`);
    summary.write(err.stack || '');
  } finally {
    summary.write('\n  Closing app…');
    await closeMagician(app);
    summary.write('  Done.');
    summary.flush();
  }
}

main().catch(e => {
  console.error(`\n  Error: ${e.message}`);
  process.exit(1);
});
