'use strict';

/**
 * Phase 1 Spike — Samsung Magician Accessibility Tree Capture
 *
 * Approach:
 *  1. Stop SamsungMagicianSVC service (prevents auto-restart of existing instances)
 *  2. Kill all running SamsungMagician.exe processes (clears single-instance lock)
 *  3. Spawn Samsung Magician with --remote-debugging-port=9222
 *  4. Watch stderr for the "DevTools listening on ws://..." message
 *  5. Connect via CDP the instant the URL appears (no fixed wait)
 *  6. Snapshot accessibility tree for each screen
 *  7. Restart the service when done
 *
 * Run:  npm run spike
 * Requires: Administrator (to stop service and kill protected processes)
 */

const fs     = require('fs');
const path   = require('path');
const { execSync, spawn } = require('child_process');
const { chromium } = require('playwright');

const EXE_PATH   = 'C:\\Program Files (x86)\\Samsung\\Samsung Magician\\SamsungMagician.exe';
const SVC_NAME   = 'SamsungMagicianSVC';
const CDP_PORT   = 9222;
const OUTPUT_DIR = path.join(__dirname, 'output');
const SETTLE_MS  = 3_000;

// Real sidebar labels discovered from _page_text.txt dump.
// Each entry also carries a 'clickText' — the exact visible text to click.
// 'widgetClick' entries click a dashboard widget heading to reach a sub-screen.
// Confirmed screens (spike 2026-05-23):
//   - Newsroom and Help Center use iframes; AX tree captures shell only (7 named nodes)
//   - Drive Health, Performance Benchmark, Diagnostic Scan are dashboard widgets, NOT nav screens
const SCREENS_TO_VISIT = [
  { name: 'dashboard',      sidebarLabel: null },
  { name: 'system_details', sidebarLabel: 'System Details' },
  { name: 'newsroom',       sidebarLabel: 'Newsroom' },
  { name: 'help_center',    sidebarLabel: 'Help Center' },
  { name: 'settings',       sidebarLabel: 'Settings' },
];

// ── Helpers ───────────────────────────────────────────────────────────────────

function log(level, msg) {
  console.log(JSON.stringify({ timestamp: new Date().toISOString(), level, msg }));
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function ensureDir(dir) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

function runCmd(cmd) {
  try {
    execSync(cmd, { stdio: 'pipe' });
    return true;
  } catch (e) {
    return false;
  }
}

/**
 * Get the full accessibility tree via CDP Accessibility.getFullAXTree.
 * Works with connectOverCDP() where page.accessibility is undefined.
 * Returns a tree in the same shape as Playwright's accessibility snapshot.
 */
async function getAxTree(page) {
  const session = await page.context().newCDPSession(page);
  try {
    await session.send('Accessibility.enable');
    const { nodes } = await session.send('Accessibility.getFullAXTree');

    // Build a map nodeId → node for parent lookup
    const map = {};
    for (const n of nodes) map[n.nodeId] = n;

    // Convert CDP AX node to our plain object shape
    function convert(n) {
      const role  = n.role?.value  ?? 'generic';
      const name  = n.name?.value  ?? null;
      const value = n.value?.value ?? null;
      const desc  = n.description?.value ?? null;

      const props = {};
      for (const p of n.properties ?? []) {
        props[p.name] = p.value?.value;
      }

      return {
        role,
        name,
        value,
        description: desc,
        disabled:  props.disabled  ?? false,
        expanded:  props.expanded  ?? undefined,
        checked:   props.checked   ?? undefined,
        children:  [],
      };
    }

    // Attach children and find root
    const converted = {};
    for (const n of nodes) converted[n.nodeId] = convert(n);

    let root = null;
    for (const n of nodes) {
      if (!n.parentId || !converted[n.parentId]) {
        root = converted[n.nodeId];
      } else {
        converted[n.parentId].children.push(converted[n.nodeId]);
      }
    }
    return root;
  } finally {
    await session.detach().catch(() => {});
  }
}

function flattenTree(node, depth = 0, results = []) {
  if (!node) return results;
  results.push({
    depth,
    role:        node.role,
    name:        node.name,
    value:       node.value,
    description: node.description,
    disabled:    node.disabled,
    expanded:    node.expanded,
    checked:     node.checked,
  });
  for (const child of node.children ?? []) {
    flattenTree(child, depth + 1, results);
  }
  return results;
}

function treeToText(node, depth = 0) {
  if (!node) return '';
  const indent   = '  '.repeat(depth);
  const namePart = node.name     ? ` "${node.name}"`      : '';
  const valPart  = node.value    ? ` [val=${node.value}]` : '';
  const disPart  = node.disabled ? ' [disabled]'          : '';
  let out = `${indent}[${node.role}]${namePart}${valPart}${disPart}\n`;
  for (const child of node.children ?? []) {
    out += treeToText(child, depth + 1);
  }
  return out;
}

function buildSummary(flat) {
  const roleSet       = new Set();
  const namedElements = [];
  for (const n of flat) {
    roleSet.add(n.role);
    if (n.name) {
      namedElements.push({
        role:     n.role,
        name:     n.name,
        disabled: n.disabled ?? false,
        value:    n.value ?? null,
      });
    }
  }
  return {
    uniqueRoles:    [...roleSet].sort(),
    namedElements,
    totalNodes:     flat.length,
  };
}

/**
 * Spawn Samsung Magician, watch stderr for the DevTools WS URL,
 * and return { proc, wsUrl } as soon as the URL is emitted.
 * Times out after `timeoutMs` milliseconds.
 */
function spawnAndWaitForDevTools(timeoutMs = 15_000, extraArgs = []) {
  return new Promise((resolve, reject) => {
    const proc = spawn(EXE_PATH, extraArgs, {
      stdio: ['ignore', 'pipe', 'pipe'],
    });

    proc.stdout.on('data', d => log('debug', `[stdout] ${d.toString().trim()}`));

    let wsUrl = null;
    proc.stderr.on('data', d => {
      const text = d.toString();
      log('debug', `[stderr] ${text.trim()}`);

      if (!wsUrl) {
        const match = text.match(/DevTools listening on (ws:\/\/[^\s]+)/);
        if (match) {
          wsUrl = match[1];
          log('info', `DevTools WS URL: ${wsUrl}`);
          resolve({ proc, wsUrl });
        }
      }
    });

    proc.on('exit', (code) => {
      log('info', `SamsungMagician.exe exited with code ${code}`);
      if (!wsUrl) {
        reject(new Error(`Process exited (code ${code}) before DevTools URL was emitted`));
      }
    });

    proc.on('error', (err) => {
      reject(new Error(`Failed to spawn process: ${err.message}`));
    });

    setTimeout(() => {
      if (!wsUrl) {
        proc.kill();
        reject(new Error(`Timeout: DevTools URL not seen within ${timeoutMs}ms`));
      }
    }, timeoutMs);
  });
}

async function clickText(page, text) {
  // Strategy 1: Playwright exact match, force=true bypasses visibility checks
  try {
    const loc = page.getByText(text, { exact: true });
    const cnt = await loc.count();
    log('debug', `clickText "${text}" exact: ${cnt} match(es)`);
    if (cnt > 0) {
      await loc.first().click({ force: true });
      log('debug', `clickText "${text}" — clicked via exact getByText`);
      return true;
    }
  } catch (e) {
    log('debug', `clickText "${text}" exact threw: ${e.message}`);
  }

  // Strategy 2: Playwright inexact match, force=true
  try {
    const loc = page.getByText(text, { exact: false });
    const cnt = await loc.count();
    log('debug', `clickText "${text}" inexact: ${cnt} match(es)`);
    if (cnt > 0) {
      await loc.first().click({ force: true });
      log('debug', `clickText "${text}" — clicked via inexact getByText`);
      return true;
    }
  } catch (e) {
    log('debug', `clickText "${text}" inexact threw: ${e.message}`);
  }

  // Strategy 3: Direct JS DOM click — bypasses all Playwright visibility rules.
  // Walks text nodes to find an exact match, then fires a bubbling MouseEvent
  // on the parent element (sidebar divs respond to bubbled clicks).
  try {
    const clicked = await page.evaluate((searchText) => {
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      let node;
      while ((node = walker.nextNode())) {
        if (node.textContent.trim() === searchText) {
          const el = node.parentElement;
          if (el) {
            el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
            return true;
          }
        }
      }
      return false;
    }, text);
    if (clicked) {
      log('debug', `clickText "${text}" — clicked via JS DOM walker`);
      return true;
    }
  } catch (e) {
    log('debug', `clickText "${text}" JS click threw: ${e.message}`);
  }

  log('warn', `clickText "${text}" — all strategies failed`);
  return false;
}

async function navigateTo(page, screen) {
  const { name: screenName, sidebarLabel, thenClick } = screen;
  if (!sidebarLabel) return true;

  const navOk = await clickText(page, sidebarLabel);
  if (!navOk) {
    log('warn', `Sidebar text "${sidebarLabel}" not found — skipping ${screenName}`);
    return false;
  }
  await sleep(SETTLE_MS);
  log('info', `Clicked sidebar "${sidebarLabel}"`);

  if (thenClick) {
    const subOk = await clickText(page, thenClick);
    if (!subOk) {
      log('warn', `Sub-click "${thenClick}" not found on ${screenName}`);
      return false;
    }
    await sleep(SETTLE_MS);
    log('info', `Clicked sub-item "${thenClick}" → ${screenName}`);
  }

  // Confirm page content shifted after navigation
  try {
    const title = await page.evaluate(() => document.title);
    log('debug', `After nav to ${screenName}: page title = "${title}"`);
  } catch (_) {}

  return true;
}

// ── Admin check ───────────────────────────────────────────────────────────────

function isAdmin() {
  try {
    // net session requires admin; exit code 0 = admin
    execSync('net session', { stdio: 'pipe' });
    return true;
  } catch (_) {
    return false;
  }
}

/**
 * Delete the Electron single-instance lock file so Samsung Magician's
 * app.requestSingleInstanceLock() sees no existing holder.
 * Electron on Windows stores this at %APPDATA%\<AppName>\SingletonLock
 */
function clearSingletonLock() {
  const candidates = [
    path.join(process.env.APPDATA || '', 'Samsung Magician', 'SingletonLock'),
    path.join(process.env.APPDATA || '', 'SamsungMagician', 'SingletonLock'),
    path.join(process.env.LOCALAPPDATA || '', 'Samsung Magician', 'SingletonLock'),
    path.join(process.env.LOCALAPPDATA || '', 'SamsungMagician', 'SingletonLock'),
  ];
  let cleared = false;
  for (const p of candidates) {
    if (fs.existsSync(p)) {
      try {
        fs.unlinkSync(p);
        log('info', `Deleted singleton lock: ${p}`);
        cleared = true;
      } catch (e) {
        log('warn', `Could not delete singleton lock at ${p}: ${e.message}`);
      }
    }
  }
  if (!cleared) log('info', 'No singleton lock file found (checked common paths)');
}

// ── Main ─────────────────────────────────────────────────────────────────────

(async () => {
  ensureDir(OUTPUT_DIR);

  // 0. Check admin — killing elevated Samsung Magician processes requires elevation
  if (!isAdmin()) {
    log('warn', [
      'NOT running as Administrator.',
      'Samsung Magician runs elevated; taskkill will be denied.',
      'Re-run this script from an Administrator PowerShell for reliable results.',
      'Continuing anyway — if the single-instance lock blocks us, elevation is required.',
    ].join(' '));
  } else {
    log('info', 'Running as Administrator — OK');
  }

  // 1. Stop the Samsung Magician service so it can't auto-restart the app
  log('info', `Stopping service ${SVC_NAME}...`);
  const svcStopped = runCmd(`net stop "${SVC_NAME}" /y`);
  log('info', svcStopped ? 'Service stopped' : `Service stop failed (may not be running or need elevation)`);

  // 2. Kill all Samsung Magician processes including the service process
  for (const exe of ['SamsungMagician.exe', 'SamsungMagicianSVC.exe']) {
    const ok = runCmd(`taskkill /F /IM ${exe}`);
    log('info', ok ? `Killed ${exe}` : `No ${exe} to kill (or access denied)`);
  }

  // 2b. Try to remove the Electron singleton lock file
  clearSingletonLock();

  await sleep(3_000);   // let OS release the single-instance mutex

  // 3. Spawn Samsung Magician with remote debugging, wait for DevTools URL.
  //
  //    We pass --user-data-dir to a throwaway directory so that Electron's
  //    requestSingleInstanceLock() sees no existing holder for this profile.
  //    The napiWrapper checks (amIAlreadyRunning / amIAlreadyRunningGlobally)
  //    communicate via named pipes with SamsungMagicianSVC — if those still
  //    block us here, the only remaining fix is stopping the service (admin).
  const tmpDataDir = path.join(require('os').tmpdir(), 'MagicianSpike');
  ensureDir(tmpDataDir);
  log('info', `Using temporary user-data-dir: ${tmpDataDir}`);

  let proc, wsUrl;
  try {
    log('info', 'Spawning Samsung Magician...');
    ({ proc, wsUrl } = await spawnAndWaitForDevTools(15_000, [
      `--remote-debugging-port=${CDP_PORT}`,
      `--user-data-dir=${tmpDataDir}`,
    ]));
  } catch (err) {
    log('error', `Spawn/DevTools failed: ${err.message}`);
    runCmd(`net start "${SVC_NAME}"`);
    process.exit(1);
  }

  // 4. Connect via CDP IMMEDIATELY — the app exits ~60ms after emitting the URL
  //    so we must not sleep before connecting.
  let browser;
  try {
    log('info', `Connecting to CDP via WS URL (immediate)...`);
    browser = await chromium.connectOverCDP(wsUrl, { timeout: 15_000 });
    log('info', 'CDP connection established');
  } catch (err) {
    log('error', `CDP connect failed: ${err.message}`);
    proc.kill();
    runCmd(`net start "${SVC_NAME}"`);
    process.exit(1);
  }

  // 5. Find the main page
  const contexts = browser.contexts();
  log('info', `CDP contexts: ${contexts.length}`);
  let page;
  for (const ctx of contexts) {
    const pages = ctx.pages();
    log('info', `  Context: ${pages.length} page(s)`);
    if (pages.length > 0 && !page) {
      page = pages[0];
    }
  }

  if (!page) {
    // No window yet — the napiWrapper is waiting for the service.
    // Restart the service NOW so initialization can complete, then poll for the page.
    log('info', 'No page yet — restarting service so napiWrapper can finish init...');
    runCmd(`net start "${SVC_NAME}"`);
  } else {
    log('info', `First page: ${page.url()} — waiting for main window...`);
  }

  // The app shows a splash screen first, then creates the main window.
  // Poll until we see a page whose URL contains 'main.html'.
  const MAIN_URL_MARKER = 'main/main.html';
  let mainPage = null;
  const deadline = Date.now() + 40_000;

  while (!mainPage && Date.now() < deadline) {
    for (const ctx of browser.contexts()) {
      for (const p of ctx.pages()) {
        const url = p.url();
        log('debug', `Polling — found page: ${url}`);
        if (url.includes(MAIN_URL_MARKER)) { mainPage = p; break; }
      }
      if (mainPage) break;
    }
    if (!mainPage) await sleep(1_500);
  }

  if (!mainPage) {
    log('error', `Main window (${MAIN_URL_MARKER}) not found within 40s`);
    await browser.close();
    proc.kill();
    process.exit(1);
  }

  page = mainPage;
  log('info', `Main page found: ${page.url()}`);
  await page.waitForLoadState('domcontentloaded').catch(() => {});
  await sleep(SETTLE_MS);   // let the UI fully render after load

  page.on('console', msg => log('debug', `[renderer] ${msg.type()}: ${msg.text()}`));
  page.on('pageerror', err => log('error', `[renderer] ${err.message}`));

  // 5b. Dump visible text so we can discover real sidebar labels
  try {
    const visibleText = await page.evaluate(() =>
      [...document.querySelectorAll('*')]
        .filter(el => el.children.length === 0 && el.textContent.trim())
        .map(el => el.textContent.trim())
        .filter((t, i, a) => a.indexOf(t) === i)   // unique
        .join('\n')
    );
    fs.writeFileSync(path.join(OUTPUT_DIR, '_page_text.txt'), visibleText, 'utf8');
    log('info', `Page text dump written (${visibleText.split('\n').length} unique strings)`);
    log('debug', `First 50 text nodes:\n${visibleText.split('\n').slice(0, 50).join('\n')}`);
  } catch (err) {
    log('warn', `Page text dump failed: ${err.message}`);
  }

  // 6. Snapshot each screen
  const globalSummary = { screens: {} };

  for (const screen of SCREENS_TO_VISIT) {
    log('info', `──── ${screen.name} ────`);

    const ok = await navigateTo(page, screen);
    if (!ok) {
      globalSummary.screens[screen.name] = { skipped: true };
      continue;
    }
    await sleep(1_000);

    let snapshot;
    try {
      snapshot = await getAxTree(page);
    } catch (err) {
      log('error', `Snapshot error (${screen.name}): ${err.message}`);
      globalSummary.screens[screen.name] = { error: err.message };
      continue;
    }

    if (!snapshot) {
      log('warn', `Empty snapshot: ${screen.name}`);
      globalSummary.screens[screen.name] = { empty: true };
      continue;
    }

    fs.writeFileSync(
      path.join(OUTPUT_DIR, `${screen.name}.json`),
      JSON.stringify(snapshot, null, 2), 'utf8'
    );
    fs.writeFileSync(
      path.join(OUTPUT_DIR, `${screen.name}.txt`),
      treeToText(snapshot), 'utf8'
    );

    const flat    = flattenTree(snapshot);
    const summary = buildSummary(flat);
    globalSummary.screens[screen.name] = summary;

    log('info', `${screen.name}: ${summary.totalNodes} nodes | ${summary.uniqueRoles.length} roles | ${summary.namedElements.length} named`);
    log('info', `  Roles: ${summary.uniqueRoles.join(', ')}`);
    for (const el of summary.namedElements) {
      const dis = el.disabled ? ' (disabled)' : '';
      const val = el.value    ? ` val=${el.value}` : '';
      log('debug', `  [${el.role}] "${el.name}"${dis}${val}`);
    }
  }

  // 7. Write global summary
  fs.writeFileSync(
    path.join(OUTPUT_DIR, '_summary.json'),
    JSON.stringify(globalSummary, null, 2), 'utf8'
  );

  const allRoles = new Set();
  for (const s of Object.values(globalSummary.screens)) {
    for (const r of s.uniqueRoles ?? []) allRoles.add(r);
  }
  log('info', `All ARIA roles: ${[...allRoles].sort().join(', ')}`);
  log('info', `Output: ${OUTPUT_DIR}`);

  await browser.close();
  proc.kill('SIGTERM');

  // 8. Restart the service
  log('info', `Restarting service ${SVC_NAME}...`);
  runCmd(`net start "${SVC_NAME}"`);

  log('info', 'Done.');
})();
