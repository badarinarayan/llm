'use strict';

/**
 * spike/inspect_popup.js
 *
 * Inspects the Setup Benchmark popup on the Performance Benchmark screen.
 *
 * What it does:
 *   1. Launches Samsung Magician (stops SVC, kills old processes, etc.)
 *   2. Navigates to Performance Benchmark via the sidebar
 *   3. Clicks "Setup Benchmark" to open the configuration popup
 *   4. Waits for the popup to render
 *   5. Dumps:
 *        A) Every visible text node (tag, role, first CSS class)
 *        B) Every interactive AX node (buttons, comboboxes, listboxes, options …)
 *        C) Every <select> element (native dropdowns — different interaction path)
 *   6. Closes the app cleanly
 *
 * Run from Administrator PowerShell:
 *   npm run spike:popup
 *
 * Output is printed to the console AND saved to spike/output/popup_inspection_*.txt
 */

const path = require('path');
const fs   = require('fs');

const { launchMagician, closeMagician } = require('../tests/helpers/appLauncher');
const { navigateTo, clickText }         = require('../tests/helpers/navigator');

// ── Tee logger (console + file) ───────────────────────────────────────────────

const OUT_DIR  = path.join(__dirname, 'output');
const OUT_FILE = path.join(
  OUT_DIR,
  `popup_inspection_${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.txt`
);
if (!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive: true });

const _lines = [];
function tee(line = '') {
  console.log(line);          // ← calls the real console.log, not tee
  _lines.push(line);
}
function flush() {
  fs.writeFileSync(OUT_FILE, _lines.join('\n'), 'utf8');
  console.log(`\n  Output saved → ${OUT_FILE}`);
}

// ── Box helper ────────────────────────────────────────────────────────────────

const HR  = '─'.repeat(70);
function box(title) {
  tee('\n' + HR);
  tee(' ' + title);
  tee(HR);
}

// ── Main ──────────────────────────────────────────────────────────────────────

async function main() {
  tee('\n  inspect_popup.js — Setup Benchmark popup inspector\n');

  // ── 1. Launch ──────────────────────────────────────────────────────────────
  tee('  Launching Samsung Magician…');
  let app, page;
  try {
    ({ app, page } = await launchMagician());
  } catch (e) {
    console.error(`\n  Launch failed: ${e.message}`);
    process.exit(1);
  }

  // Detect early page close (SVC race condition) and surface a clear message.
  let pageClosed = false;
  page.on('close', () => {
    pageClosed = true;
    tee('\n  !! Page closed unexpectedly — SVC race condition (run again)');
  });

  try {
    // ── 2. Navigate ──────────────────────────────────────────────────────────
    tee('  Navigating to Performance Benchmark…');
    try {
      await navigateTo(page, 'performance_benchmark');
    } catch (navErr) {
      tee(`  ERROR during navigation: ${navErr.message}`);
      tee('  Falling back: trying direct sidebar click without screen-marker verify…');
      // navigateTo with verify:false — just clicks the sidebar, no assertion
      await navigateTo(page, 'performance_benchmark', { verify: false });
    }
    await page.waitForTimeout(2_000);

    // ── 3. Click "Setup Benchmark" ───────────────────────────────────────────
    tee('  Clicking "Setup Benchmark"…');
    const clicked = await clickText(page, 'Setup Benchmark');
    if (!clicked) {
      tee('  ERROR: "Setup Benchmark" not found — is the Performance Benchmark screen loaded?');
      tee('  Dumping all text nodes on current screen to help diagnose:');
      const current = await page.evaluate(() => {
        const out = [];
        const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
        let n;
        while ((n = w.nextNode())) { const t = n.textContent.trim(); if (t) out.push(t); }
        return out;
      });
      current.forEach((t, i) => tee(`    ${String(i+1).padStart(3)}.  "${t}"`));
      return;
    }

    // ── 4. Wait for popup ────────────────────────────────────────────────────
    tee('  Waiting 5 s for popup to render…');
    await page.waitForTimeout(5_000);

    // ── 5A. All text nodes ───────────────────────────────────────────────────
    box('A) ALL VISIBLE TEXT NODES (tag · role · first CSS class)');

    const textNodes = await page.evaluate(() => {
      const results = [];
      const walker  = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      let node;
      while ((node = walker.nextNode())) {
        const t  = node.textContent.trim();
        if (!t) continue;
        const el  = node.parentElement;
        if (!el)  continue;
        const tag  = el.tagName.toLowerCase();
        const role = el.getAttribute('role') || '';
        const cls  = [...el.classList].find(c => c.length > 1) || '';
        results.push({ text: t, tag, role, class: cls.slice(0, 45) });
      }
      return results;
    });

    textNodes.forEach((n, i) => {
      const role = n.role  ? `  role="${n.role}"` : '';
      const cls  = n.class ? `  .${n.class}`      : '';
      tee(`  ${String(i + 1).padStart(3)}.  "${n.text}"  <${n.tag}>${role}${cls}`);
    });

    // ── 5B. Interactive AX nodes ──────────────────────────────────────────────
    box('B) INTERACTIVE AX NODES (buttons, combos, options, radios …)');

    const INTERACTIVE_ROLES = new Set([
      'button', 'combobox', 'listbox', 'option',
      'radio', 'checkbox', 'menuitem', 'menu',
      'menubar', 'tab', 'tablist', 'slider',
    ]);

    const session = await page.context().newCDPSession(page);
    let axNodes = [];
    try {
      await session.send('Accessibility.enable');
      const { nodes } = await session.send('Accessibility.getFullAXTree');
      axNodes = nodes.filter(n => n.role && INTERACTIVE_ROLES.has(n.role.value));
    } finally {
      await session.detach().catch(() => {});
    }

    if (axNodes.length === 0) {
      tee('  (none — no interactive ARIA roles found in the popup)');
    } else {
      for (const n of axNodes) {
        const role     = (n.role?.value || '').padEnd(14);
        const name     = n.name?.value  || '(no name)';
        const state    = (n.states || []).map(s => s.value).filter(Boolean).join(', ');
        const stateStr = state ? `  [${state}]` : '';
        tee(`  ${role}  "${name}"${stateStr}`);
      }
    }

    // ── 5C. Native <select> elements ──────────────────────────────────────────
    box('C) NATIVE <select> ELEMENTS (require page.selectOption, not DOM click)');

    const selects = await page.evaluate(() =>
      [...document.querySelectorAll('select')].map(el => ({
        name:    el.name || el.id || '(unnamed)',
        current: el.value,
        options: [...el.options].map(o => ({ value: o.value, text: o.text })),
      }))
    );

    if (selects.length === 0) {
      tee('  (none — no native <select> elements found)');
    } else {
      selects.forEach((s, i) => {
        tee(`\n  [${i + 1}] name="${s.name}"  current="${s.current}"`);
        s.options.forEach(o => {
          const cur = o.value === s.current ? ' ◀ current' : '';
          tee(`        value="${o.value}"  text="${o.text}"${cur}`);
        });
      });
    }

    // ── Guidance ──────────────────────────────────────────────────────────────
    box('INTERPRETATION GUIDE');
    tee('  • Options in section A/B as text nodes or role=option');
    tee('    → "select <text>" step works (DOM walker click)');
    tee('  • Options in section C as native <select>');
    tee('    → need a "choose <value>" step (page.selectOption)');
    tee();

  } catch (err) {
    tee(`\n  UNHANDLED ERROR: ${err.message}`);
    tee(err.stack || '');
  } finally {
    tee('\n  Closing app…');
    await closeMagician(app);
    tee('  Done.');
    flush();
  }
}

main().catch(e => {
  console.error(`\n  Error: ${e.message}\n`);
  process.exit(1);
});
