'use strict';

/**
 * spike/inspect_sidebar_hover.js
 *
 * Investigates Samsung Magician's sidebar hover behaviour.
 *
 * The sidebar items have CSS visibility:hidden at rest.  When the user
 * moves the mouse over the sidebar, submenus appear.  This script
 * determines:
 *
 *   A) Which mechanism reveals them — CSS :hover (real mouse move) or
 *      JS mouseover/mouseenter events
 *   B) What new text nodes appear after each hover strategy
 *   C) Whether those items are clickable via the existing JS DOM walker
 *
 * Run from Administrator PowerShell:
 *   npm run spike:sidebar-hover
 *
 * Output: spike/output/sidebar_hover_<timestamp>.txt
 */

const path = require('path');
const fs   = require('fs');

const { launchMagician, closeMagician } = require('../tests/helpers/appLauncher');
const { clickText }                     = require('../tests/helpers/navigator');

// ── Tee logger ────────────────────────────────────────────────────────────────

const OUT_DIR  = path.join(__dirname, 'output');
const OUT_FILE = path.join(
  OUT_DIR,
  `sidebar_hover_${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.txt`
);
if (!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive: true });

const _lines = [];
function tee(line = '') { console.log(line); _lines.push(line); }
function flush() {
  fs.writeFileSync(OUT_FILE, _lines.join('\n'), 'utf8');
  console.log(`\nOutput saved → ${OUT_FILE}`);
}

const HR = '─'.repeat(70);
function box(title) { tee('\n' + HR); tee(' ' + title); tee(HR); }

// ── DOM helpers (run inside page.evaluate) ────────────────────────────────────

function getAllTextNodes() {
  // Returns [{text, tag, role, class, visible, x, y, w, h}]
  const results = [];
  const walker  = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  let node;
  while ((node = walker.nextNode())) {
    const t  = node.textContent.trim();
    if (!t) continue;
    const el = node.parentElement;
    if (!el) continue;
    const style = window.getComputedStyle(el);
    const rect  = el.getBoundingClientRect();
    results.push({
      text:    t,
      tag:     el.tagName.toLowerCase(),
      cls:     [...el.classList].find(c => c.length > 1) || '',
      visible: style.visibility !== 'hidden' && style.display !== 'none' && rect.width > 0,
      x: Math.round(rect.left + rect.width  / 2),
      y: Math.round(rect.top  + rect.height / 2),
      w: Math.round(rect.width),
      h: Math.round(rect.height),
    });
  }
  return results;
}

function getSidebarBounds() {
  // Find the sidebar container — widths < 200px on the left edge of the screen
  const candidates = [];
  document.querySelectorAll('*').forEach(el => {
    const r = el.getBoundingClientRect();
    if (r.left < 10 && r.width > 40 && r.width < 220 && r.height > 200) {
      candidates.push({
        tag: el.tagName.toLowerCase(),
        cls: [...el.classList][0] || '',
        x: Math.round(r.left + r.width / 2),
        y: Math.round(r.top  + r.height / 2),
        w: Math.round(r.width),
        h: Math.round(r.height),
      });
    }
  });
  return candidates;
}

function dispatchHoverEvents(selector) {
  // Dispatch JS mouseover + mouseenter on an element found by text match
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  let node;
  while ((node = walker.nextNode())) {
    if (node.textContent.trim() === selector) {
      const el = node.parentElement;
      if (el) {
        el.dispatchEvent(new MouseEvent('mouseover',  { bubbles: true,  cancelable: true }));
        el.dispatchEvent(new MouseEvent('mouseenter', { bubbles: false, cancelable: true }));
        return true;
      }
    }
  }
  return false;
}

// ── Main ──────────────────────────────────────────────────────────────────────

async function captureTextSet(page) {
  const nodes = await page.evaluate(getAllTextNodes);
  return new Map(nodes.map(n => [n.text, n]));
}

function diffTexts(before, after) {
  const added   = [];
  const nowVis  = [];
  for (const [text, node] of after) {
    if (!before.has(text)) {
      added.push(node);
    } else if (!before.get(text).visible && node.visible) {
      nowVis.push(node);
    }
  }
  return { added, nowVis };
}

async function main() {
  tee('\n  inspect_sidebar_hover.js — Samsung Magician sidebar hover inspector\n');

  let app, page;
  try {
    ({ app, page } = await launchMagician());
  } catch (e) {
    tee(`  Launch failed: ${e.message}`);
    process.exit(1);
  }

  try {
    // ── Baseline ─────────────────────────────────────────────────────────────
    box('BASELINE — text nodes at rest (no hover)');
    await page.waitForTimeout(2_000);
    const baseline = await captureTextSet(page);

    const visibleAtRest = [...baseline.values()].filter(n => n.visible);
    const hiddenAtRest  = [...baseline.values()].filter(n => !n.visible);
    tee(`  Visible text nodes: ${visibleAtRest.length}`);
    tee(`  Hidden text nodes:  ${hiddenAtRest.length}`);
    tee('');
    tee('  Visible nodes:');
    visibleAtRest.forEach(n => tee(`    "${n.text}"  <${n.tag}>  .${n.cls}`));

    // ── Sidebar container bounds ──────────────────────────────────────────────
    box('SIDEBAR CONTAINER — bounding boxes');
    const sidebars = await page.evaluate(getSidebarBounds);
    if (sidebars.length === 0) {
      tee('  No sidebar container detected via bounding-box heuristic.');
    } else {
      sidebars.forEach((s, i) =>
        tee(`  [${i}] <${s.tag}> .${s.cls}  x=${s.x} y=${s.y} w=${s.w} h=${s.h}`)
      );
    }

    // ── Strategy 1: Real mouse hover over sidebar container ───────────────────
    box('STRATEGY 1 — Real mouse hover (page.mouse.move) over sidebar container');

    if (sidebars.length > 0) {
      const sb = sidebars[0];
      tee(`  Moving mouse to sidebar centre (${sb.x}, ${sb.y})…`);
      await page.mouse.move(sb.x, sb.y);
      await page.waitForTimeout(1_500);   // let CSS transitions complete

      const afterMouseMove = await captureTextSet(page);
      const { added: mmAdded, nowVis: mmNowVis } = diffTexts(baseline, afterMouseMove);

      tee(`  New text nodes appeared:   ${mmAdded.length}`);
      tee(`  Nodes became visible:      ${mmNowVis.length}`);
      mmAdded .forEach(n => tee(`  + (NEW)   "${n.text}"  <${n.tag}> .${n.cls}  visible=${n.visible}`));
      mmNowVis.forEach(n => tee(`  + (SHOWN) "${n.text}"  <${n.tag}> .${n.cls}`));

      if (mmAdded.length === 0 && mmNowVis.length === 0) {
        tee('  → No change from real mouse-move.  CSS :hover may not be the mechanism.');
      }

      // Also try sweeping the mouse down the sidebar column
      tee('\n  Sweeping mouse down the sidebar column…');
      for (let yOffset = 0; yOffset < sb.h; yOffset += 30) {
        await page.mouse.move(sb.x, sb.y - sb.h / 2 + yOffset);
        await page.waitForTimeout(200);
      }
      await page.waitForTimeout(1_000);

      const afterSweep = await captureTextSet(page);
      const { added: swAdded, nowVis: swNowVis } = diffTexts(baseline, afterSweep);
      tee(`  After sweep — new: ${swAdded.length}, became visible: ${swNowVis.length}`);
      swAdded .forEach(n => tee(`  + (NEW)   "${n.text}"  .${n.cls}`));
      swNowVis.forEach(n => tee(`  + (SHOWN) "${n.text}"  .${n.cls}`));
    } else {
      tee('  Skipped — no sidebar container found.');
    }

    // ── Strategy 2: JS mouseover/mouseenter events ────────────────────────────
    box('STRATEGY 2 — JS mouseover + mouseenter dispatch on known sidebar labels');

    const SIDEBAR_LABELS = [
      'Home Dashboard',
      'System Details',
      'Performance Management',
      'Newsroom',
      'Help Center',
      'Settings',
    ];

    for (const label of SIDEBAR_LABELS) {
      tee(`\n  Hovering (JS events): "${label}"`);
      const beforeHover = await captureTextSet(page);

      const dispatched = await page.evaluate(dispatchHoverEvents, label);
      tee(`  dispatchHoverEvents: ${dispatched ? 'found element' : 'element NOT FOUND'}`);
      await page.waitForTimeout(800);

      const afterHover = await captureTextSet(page);
      const { added, nowVis } = diffTexts(beforeHover, afterHover);

      if (added.length === 0 && nowVis.length === 0) {
        tee('  → No new items revealed');
      } else {
        added .forEach(n => tee(`  + (NEW)   "${n.text}"  .${n.cls}  visible=${n.visible}`));
        nowVis.forEach(n => tee(`  + (SHOWN) "${n.text}"  .${n.cls}`));
      }
    }

    // ── Strategy 3: Playwright hover() with force ─────────────────────────────
    box('STRATEGY 3 — Playwright page.getByText().hover({ force:true })');

    for (const label of SIDEBAR_LABELS) {
      tee(`\n  Hovering (Playwright force): "${label}"`);
      const beforeHover = await captureTextSet(page);

      try {
        await page.getByText(label, { exact: true }).first().hover({ force: true, timeout: 3_000 });
        await page.waitForTimeout(800);
      } catch (e) {
        tee(`  hover() error: ${e.message.split('\n')[0]}`);
        continue;
      }

      const afterHover = await captureTextSet(page);
      const { added, nowVis } = diffTexts(beforeHover, afterHover);

      if (added.length === 0 && nowVis.length === 0) {
        tee('  → No new items revealed');
      } else {
        added .forEach(n => tee(`  + (NEW)   "${n.text}"  .${n.cls}  visible=${n.visible}`));
        nowVis.forEach(n => tee(`  + (SHOWN) "${n.text}"  .${n.cls}`));
      }
    }

    // ── Summary ───────────────────────────────────────────────────────────────
    box('SUMMARY');
    tee('  Run strategies used:');
    tee('    1. page.mouse.move() to sidebar bounding-box  → triggers CSS :hover');
    tee('    2. JS dispatchEvent mouseover+mouseenter       → triggers JS listeners');
    tee('    3. Playwright .hover({ force:true })           → hybrid');
    tee('');
    tee('  Check the SHOWN/NEW lines above to see which strategy reveals submenus.');
    tee('  If strategy 1 shows items, sidebar uses CSS :hover → add mouse.move()');
    tee('  to navigator.js before clicking sidebar labels.');
    tee('  If strategy 2 shows items, JS events suffice → clickText() already works.');
    tee('  If strategy 3 shows items, use page.hover({ force:true }) in navigator.');
    tee('');

  } catch (err) {
    tee(`\n  UNHANDLED ERROR: ${err.message}`);
    tee(err.stack || '');
  } finally {
    tee('\n  Closing app…');
    await closeMagician(app);
    tee('  Done.');
    flush();
  }
}

main().catch(e => {
  console.error(`\n  Error: ${e.message}`);
  process.exit(1);
});
