'use strict';

/**
 * reinspect.js
 *
 * Re-inspects Samsung Magician's accessibility tree and compares it against
 * existing Elements_Config/*.json files.  Run this whenever the hardware
 * configuration changes — e.g. a Samsung NVMe or SATA SSD is connected,
 * additional drives are added, or a previously-disabled setting is enabled.
 *
 * What it does:
 *   1. Launches the app (same approach as the spike script)
 *   2. Detects connected drives and records them as "drive context"
 *   3. Scans the sidebar for NEW navigation items not in the known 5 screens
 *   4. Navigates to every known screen + every newly-discovered screen
 *   5. Captures the full accessibility tree for each
 *   6. Diffs each capture against its Elements_Config/*.json
 *   7. Writes a timestamped delta report to spike/output/
 *   8. Optionally patches Elements_Config files with discovered elements
 *
 * Usage (run from an Administrator PowerShell):
 *   node spike/reinspect.js                          # report only
 *   node spike/reinspect.js --update                 # patch configs
 *   node spike/reinspect.js --screen settings        # single screen
 *   node spike/reinspect.js --screen settings --update
 *
 *   # When multiple drives are connected, inspect each drive's UI:
 *   node spike/reinspect.js --all-drives             # cycle through all drives
 *   node spike/reinspect.js --all-drives --update
 *
 * Output:
 *   spike/output/reinspect_<YYYY-MM-DDTHH-MM>.json   full delta report
 *   Elements_Config/<screen>.json                     patched (--update only)
 *
 * How new screens are named:
 *   Sidebar label → lower_snake_case → Elements_Config/<name>.json
 *   e.g. "Over Provisioning" → over_provisioning → over_provisioning.json
 *
 * After running with new Samsung drives connected you may see new screens:
 *   Diagnostic Scan (full)  Over Provisioning  Secure Erase
 *   Firmware Update         PSSD Management    Drive Manager
 *
 * Manual follow-up after --update:
 *   1. Review each _discovered_YYYYMMDD group in updated config files
 *   2. Move entries to appropriate semantic groups (header, content, etc.)
 *   3. If new screens were found, add their keys to navigator.js SIDEBAR_LABELS
 *      and SCREEN_MARKERS (see console output for the exact lines to add)
 *   4. Run npm run spike to capture a fresh full AX tree for the new screens
 *   5. Write tests in tests/screens/<new_screen>.spec.js
 */

const fs   = require('fs');
const path = require('path');
const os   = require('os');
const { execSync, spawn } = require('child_process');
const { chromium } = require('playwright');

const {
  loadConfig,
  extractConfigNames,
  diffElements,
  patchConfig,
  createNewConfig,
} = require('./lib/configDiff');

// ── Paths & constants ─────────────────────────────────────────────────────────

const EXE_PATH          = 'C:\\Program Files (x86)\\Samsung\\Samsung Magician\\SamsungMagician.exe';
const SVC_NAME          = 'SamsungMagicianSVC';
const CDP_PORT          = 9222;
const SETTLE_MS         = 3_000;  // ms to wait after each navigation click
const SIDEBAR_POLL_MS   = 8_000;  // max ms to wait for sidebar to hydrate
const SIDEBAR_POLL_INT  = 400;

const ELEMENTS_CONFIG_DIR = path.join(__dirname, '..', 'Elements_Config');
const OUTPUT_DIR          = path.join(__dirname, 'output');

// ── Known sidebar screens (source of truth: navigator.js SIDEBAR_LABELS) ─────

const KNOWN_SCREENS = {
  dashboard:      'Home Dashboard',
  system_details: 'System Details',
  newsroom:       'Newsroom',
  help_center:    'Help Center',
  settings:       'Settings',
};

// Text that looks like a nav label but is definitively NOT a new screen.
// Extend this list if false-positives appear.
const NON_NAV_TEXTS = new Set([
  // Header badges
  'Update', 'Notice',
  // Action buttons
  'Export', 'Edit', 'Delete', 'Start', 'See All Widgets',
  // Drive badges / interface types
  'Non-Samsung', 'NVMe', 'SATA', 'USB', 'PCIe',
  // Common setting values
  'ON', 'OFF', 'Auto', 'English',
  // UI noise
  'Samsung Magician', 'N/A', 'Result', 'No Result',
]);

// ── CLI args ──────────────────────────────────────────────────────────────────

const argv       = process.argv.slice(2);
const UPDATE     = argv.includes('--update');
const ALL_DRIVES = argv.includes('--all-drives');
const screenArg  = (() => {
  const idx = argv.indexOf('--screen');
  return idx !== -1 ? argv[idx + 1] : null;
})();

// ── Logging ───────────────────────────────────────────────────────────────────

function log(level, msg, extra = {}) {
  const line = { timestamp: new Date().toISOString(), level, msg, ...extra };
  console.log(JSON.stringify(line));
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function ensureDir(d) { if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true }); }

function runCmd(cmd) {
  try { execSync(cmd, { stdio: 'pipe' }); return true; }
  catch (_) { return false; }
}

// ── App launch (mirrors capture_accessibility_tree.js) ────────────────────────

function spawnAndWaitForDevTools(timeoutMs = 15_000, extraArgs = []) {
  return new Promise((resolve, reject) => {
    const proc = spawn(EXE_PATH, extraArgs, { stdio: ['ignore', 'pipe', 'pipe'] });
    let wsUrl = null;

    proc.stdout.on('data', d => log('debug', `[stdout] ${d.toString().trim()}`));
    proc.stderr.on('data', d => {
      const text = d.toString();
      log('debug', `[stderr] ${text.trim()}`);
      if (!wsUrl) {
        const m = text.match(/DevTools listening on (ws:\/\/[^\s]+)/);
        if (m) { wsUrl = m[1]; resolve({ proc, wsUrl }); }
      }
    });
    proc.on('exit', code => {
      if (!wsUrl) reject(new Error(`Process exited (code ${code}) before DevTools URL`));
    });
    proc.on('error', err => reject(new Error(`Spawn error: ${err.message}`)));
    setTimeout(() => {
      if (!wsUrl) { proc.kill(); reject(new Error(`Timeout waiting for DevTools URL (${timeoutMs}ms)`)); }
    }, timeoutMs);
  });
}

async function launchApp() {
  log('info', 'Stopping service and clearing existing instances...');
  runCmd(`net stop "${SVC_NAME}" /y`);
  runCmd('taskkill /F /IM SamsungMagician.exe');
  runCmd('taskkill /F /IM SamsungMagicianSVC.exe');
  await sleep(5_000);

  // Use a unique temp dir so we always start with a clean/default UI state.
  // This prevents the spike's stale tab-state problem from affecting discovery.
  const tmpDataDir = path.join(os.tmpdir(), `MagicianReinspect_${Date.now()}`);
  ensureDir(tmpDataDir);
  log('info', `Using fresh user-data-dir: ${tmpDataDir}`);

  log('info', 'Spawning Samsung Magician...');
  let proc, wsUrl;
  try {
    ({ proc, wsUrl } = await spawnAndWaitForDevTools(15_000, [
      `--remote-debugging-port=${CDP_PORT}`,
      `--user-data-dir=${tmpDataDir}`,
    ]));
  } catch (err) {
    runCmd(`net start "${SVC_NAME}"`);
    throw new Error(`Spawn/DevTools failed: ${err.message}`);
  }

  log('info', 'Connecting via CDP...', { wsUrl });
  const browser = await chromium.connectOverCDP(wsUrl, { timeout: 15_000 });

  // Find or wait for the main page
  let page = null;
  for (const ctx of browser.contexts()) {
    const pages = ctx.pages();
    if (pages.length > 0) { page = pages[0]; break; }
  }

  if (!page) {
    log('info', 'No page yet — starting service so napiWrapper can complete init...');
    runCmd(`net start "${SVC_NAME}"`);
  }

  // Poll for main/main.html (splash → main window transition)
  const MAIN_URL = 'main/main.html';
  const deadline = Date.now() + 40_000;
  let mainPage   = null;

  while (!mainPage && Date.now() < deadline) {
    for (const ctx of browser.contexts()) {
      for (const p of ctx.pages()) {
        if (p.url().includes(MAIN_URL)) { mainPage = p; break; }
      }
      if (mainPage) break;
    }
    if (!mainPage) await sleep(1_000);
  }

  if (!mainPage) throw new Error('Main window (main.html) not found within 40s');

  page = mainPage;
  log('info', 'Main page found', { url: page.url() });

  await page.waitForLoadState('domcontentloaded').catch(() => {});
  await sleep(SETTLE_MS);  // let React sidebar hydrate

  page.on('close',     ()    => log('warn',  'Renderer page closed unexpectedly'));
  page.on('console',   msg   => log('debug', `[renderer] ${msg.type()}: ${msg.text()}`));
  page.on('pageerror', err   => log('error', `[renderer] ${err.message}`));

  if (page.isClosed()) throw new Error('Page closed immediately after launch');

  log('info', 'App ready');
  return { browser, page, proc };
}

async function closeApp({ browser, proc }) {
  try { await browser.close(); } catch (_) {}
  try { proc.kill('SIGTERM'); } catch (_) {}
  runCmd(`net start "${SVC_NAME}"`);
  log('info', 'App closed, service restarted');
}

// ── JS DOM walker (identical to capture_accessibility_tree.js) ────────────────

async function jsClick(page, text) {
  return page.evaluate((searchText) => {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      if (node.textContent.trim() === searchText) {
        node.parentElement?.dispatchEvent(
          new MouseEvent('click', { bubbles: true, cancelable: true })
        );
        return true;
      }
    }
    return false;
  }, text).catch(() => false);
}

/** Wait for the sidebar label to hydrate, then click it. */
async function navigateTo(page, sidebarLabel) {
  // Poll until the text node appears (sidebar React component may not be mounted yet)
  const pollEnd = Date.now() + SIDEBAR_POLL_MS;
  let ready = false;
  while (!ready && Date.now() < pollEnd) {
    ready = await page.evaluate((text) => {
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      let node;
      while ((node = walker.nextNode())) {
        if (node.textContent.trim() === text) return true;
      }
      return false;
    }, sidebarLabel).catch(() => false);
    if (!ready) await sleep(SIDEBAR_POLL_INT);
  }

  if (!ready) {
    log('warn', `Sidebar label "${sidebarLabel}" not found after ${SIDEBAR_POLL_MS}ms poll`);
    return false;
  }

  const clicked = await jsClick(page, sidebarLabel);
  if (!clicked) {
    log('warn', `JS click failed for "${sidebarLabel}"`);
    return false;
  }

  await sleep(SETTLE_MS);
  log('info', `Navigated to "${sidebarLabel}"`);
  return true;
}

// ── AX tree capture ───────────────────────────────────────────────────────────

async function captureNamedElements(page) {
  const cdp = await page.context().newCDPSession(page);
  try {
    await cdp.send('Accessibility.enable');
    const { nodes } = await cdp.send('Accessibility.getFullAXTree');

    const SKIP_ROLES = new Set([
      'InlineTextBox', 'RootWebArea', 'none', 'generic', 'image',
    ]);

    const named = [];
    for (const node of nodes) {
      const role     = node.role?.value  ?? '';
      const name     = (node.name?.value ?? '').trim();
      const disabled = node.properties?.find(p => p.name === 'disabled')?.value?.value ?? false;

      if (!name || SKIP_ROLES.has(role)) continue;
      named.push({ role, name, disabled });
    }
    return named;
  } finally {
    await cdp.detach().catch(() => {});
  }
}

async function getAxNodeCount(page) {
  const cdp = await page.context().newCDPSession(page);
  try {
    await cdp.send('Accessibility.enable');
    const { nodes } = await cdp.send('Accessibility.getFullAXTree');
    return nodes.length;
  } finally {
    await cdp.detach().catch(() => {});
  }
}

// ── Drive detection ───────────────────────────────────────────────────────────

/**
 * Collect all text nodes and extract drive-related strings:
 *   driveNames  — model strings (SAMSUNG ..., etc.)
 *   interfaces  — NVMe, SATA, USB
 *   badges      — Samsung / Non-Samsung
 *
 * Also attempts to count how many drives are shown by looking for the
 * drive-selector navigation arrows (the "‹" / "›" or "<" / ">" controls).
 */
async function detectDrives(page) {
  const allText = await page.evaluate(() => {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    const texts  = [];
    let node;
    while ((node = walker.nextNode())) {
      const t = node.textContent.trim();
      if (t) texts.push(t);
    }
    return [...new Set(texts)];
  });

  // Drive model patterns: Samsung NVMe models start with MZ or PM; SATA with S
  const driveNames = allText.filter(t =>
    /^(SAMSUNG|WD|SEAGATE|TOSHIBA|CRUCIAL|INTEL|SK\s*HYNIX)/i.test(t) ||
    /^(MZ|PM|SM\d|S[A-Z]\d{3})/i.test(t)
  );

  const interfaces = allText.filter(t => ['NVMe', 'SATA', 'USB', 'PCIe'].includes(t));
  const badges     = allText.filter(t => ['Samsung', 'Non-Samsung'].includes(t));

  // Drive count heuristic: in multi-drive setups the header shows "1 / 3" or similar
  const driveCountText = allText.find(t => /^\d\s*\/\s*\d$/.test(t));
  const driveCount     = driveCountText
    ? parseInt(driveCountText.split('/')[1], 10)
    : 1;

  return { driveNames, interfaces, badges, driveCount };
}

/**
 * When multiple drives are present, cycle through each by clicking the
 * drive-selector arrow (text "›" or ">").  Returns the index of the last
 * drive visited (useful for reporting).
 *
 * NOTE: This is a best-effort heuristic.  If the drive selector uses a
 * different control (dropdown, cards), this may not work — check the AX tree
 * and update accordingly.
 */
async function switchToNextDrive(page) {
  // Try common arrow labels for the drive-switcher control
  const arrowLabels = ['>', '›', '→', 'next', 'Next drive'];
  for (const label of arrowLabels) {
    const clicked = await jsClick(page, label);
    if (clicked) {
      await sleep(SETTLE_MS);
      log('info', `Switched to next drive via "${label}"`);
      return true;
    }
  }
  log('warn', 'Could not find drive-switcher arrow — drive cycling skipped');
  return false;
}

// ── Sidebar discovery ─────────────────────────────────────────────────────────

/**
 * Walk all text nodes on the current page and return candidate sidebar labels
 * that are NOT in the known SIDEBAR_LABELS set.
 *
 * These candidates are probed by tryNavigateToCandidate() to confirm they are
 * actual navigation items (AX tree changes significantly after clicking them).
 */
async function discoverUnknownSidebarItems(page) {
  const allText = await page.evaluate(() => {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    const seen   = new Set();
    let node;
    while ((node = walker.nextNode())) {
      const t = node.textContent.trim();
      if (t) seen.add(t);
    }
    return [...seen];
  });

  const knownLabelSet = new Set(Object.values(KNOWN_SCREENS));

  return allText.filter(text => {
    if (knownLabelSet.has(text))     return false;  // already known
    if (NON_NAV_TEXTS.has(text))     return false;  // definitely not a nav
    if (/^\d+$/.test(text))          return false;  // badge count
    if (/^\d+\.\d/.test(text))       return false;  // version number
    if (text.length < 4)             return false;  // too short
    if (text.length > 50)            return false;  // too long for a nav label
    if (/[°/%\[\]]/.test(text))      return false;  // units / punctuation
    if (/^\d/.test(text))            return false;  // starts with digit
    // Drive model names are all-caps or contain embedded digits
    if (/^[A-Z]{3,}[\d\-]+/.test(text)) return false;

    // Plausible nav items: Title Case or known Samsung feature name patterns
    return /^[A-Z][a-z]/.test(text);
  });
}

/**
 * Try clicking a candidate text and check if the page content changes
 * substantially (> AX_CHANGE_THRESHOLD nodes difference).
 * Returns true if navigation happened; also returns the AX node counts.
 */
const AX_CHANGE_THRESHOLD = 15;

async function tryNavigateToCandidate(page, label) {
  const before = await getAxNodeCount(page);
  const clicked = await jsClick(page, label);
  if (!clicked) return { navigated: false, before, after: before };

  await sleep(SETTLE_MS);
  const after = await getAxNodeCount(page);
  const delta = Math.abs(after - before);

  log('debug', `Probe "${label}": AX delta=${delta} (before=${before}, after=${after})`);
  return { navigated: delta >= AX_CHANGE_THRESHOLD, before, after, delta };
}

// ── Multi-drive inspection ────────────────────────────────────────────────────

/**
 * Inspect a single drive context: navigate to each screen, capture elements,
 * diff against config, return per-screen results.
 *
 * @param {object}  page
 * @param {Array}   screensToInspect  [{ screenName, label, isNew }]
 * @param {object}  driveCtx          Result of detectDrives()
 * @param {string}  driveIndex        "0", "1", "2" — for report labelling
 */
async function inspectDriveContext(page, screensToInspect, driveCtx, driveIndex) {
  const results = {};

  for (const { screenName, label, isNew } of screensToInspect) {
    log('info', `  [drive ${driveIndex}] ${screenName} "${label}"`);

    // Navigate (dashboard needs no click — it's the landing screen)
    if (label !== 'Home Dashboard') {
      const ok = await navigateTo(page, label);
      if (!ok) {
        results[screenName] = { skipped: true, reason: 'navigation failed' };
        continue;
      }
    } else {
      // Back to dashboard between screen visits to avoid stale state
      await jsClick(page, 'Home Dashboard');
      await sleep(SETTLE_MS);
    }

    // Capture
    const captured = await captureNamedElements(page).catch(err => {
      log('error', `AX capture error on ${screenName}: ${err.message}`);
      return null;
    });

    if (!captured) {
      results[screenName] = { skipped: true, reason: 'AX capture error' };
      continue;
    }

    // Diff against config
    const existingConfig = isNew ? null : loadConfig(screenName, ELEMENTS_CONFIG_DIR);

    let diff;
    if (!existingConfig) {
      diff = {
        isNew:            true,
        totalCaptured:    captured.length,
        newInCapture:     captured,
        missingInCapture: [],
        presentDynamic:   [],
      };
    } else {
      const configNames = extractConfigNames(existingConfig);
      diff = { isNew: false, ...diffElements(captured, configNames) };
    }

    results[screenName] = {
      label,
      isNew,
      driveIndex,
      driveContext:    driveCtx.driveNames,
      capturedCount:   diff.totalCaptured,
      newCount:        diff.newInCapture.length,
      missingCount:    diff.missingInCapture.length,
      newElements:     diff.newInCapture,
      missingElements: diff.missingInCapture,
      presentDynamic:  diff.presentDynamic,
    };

    log('info', `    +${diff.newInCapture.length} new, -${diff.missingInCapture.length} missing (${diff.totalCaptured} total)`);
  }

  return results;
}

// ── Config update ─────────────────────────────────────────────────────────────

function applyUpdates(allScreenResults, allNewScreens) {
  let patchedCount  = 0;
  let createdCount  = 0;

  for (const [screenName, data] of Object.entries(allScreenResults)) {
    if (data.skipped)         continue;
    if (data.newCount === 0)  continue;

    if (data.isNew) {
      // Create a brand-new config
      const filePath = createNewConfig(
        screenName, data.label, data.newElements,
        data.driveContext, ELEMENTS_CONFIG_DIR
      );
      log('info', `Created new config: ${filePath}`);
      createdCount++;
    } else {
      // Patch existing config
      const configPath = path.join(ELEMENTS_CONFIG_DIR, `${screenName}.json`);
      const config     = loadConfig(screenName, ELEMENTS_CONFIG_DIR);
      patchConfig(config, configPath, data.newElements, data.driveContext);
      log('info', `Patched: ${screenName}.json (+${data.newCount} elements)`);
      patchedCount++;
    }
  }

  return { patchedCount, createdCount };
}

// ── Console report ────────────────────────────────────────────────────────────

function printReport(report) {
  const { summary, screens, newScreens, driveContexts } = report;

  console.log('\n' + '═'.repeat(60));
  console.log('  REINSPECT SUMMARY');
  console.log('═'.repeat(60));
  console.log(`  Mode           : ${report.mode}`);
  console.log(`  Drives detected: ${driveContexts.map(d => d.driveNames.join(', ')).join(' | ') || 'none'}`);
  console.log(`  Screens checked: ${summary.screensInspected}`);
  console.log(`  New elements   : ${summary.totalNew}`);
  console.log(`  Missing elements: ${summary.totalMissing}  (state-dependent — review manually)`);
  console.log(`  New screens    : ${summary.newScreens}`);
  console.log('');

  // Per-screen table
  for (const [screenName, data] of Object.entries(screens)) {
    if (data.skipped) {
      console.log(`  ✗ SKIP  ${screenName.padEnd(22)} ${data.reason}`);
      continue;
    }
    const tag   = data.isNew ? ' NEW  ' : '      ';
    const parts = [];
    if (data.newCount > 0)     parts.push(`+${data.newCount} new`);
    if (data.missingCount > 0) parts.push(`-${data.missingCount} missing`);
    if (!parts.length)         parts.push('no changes');
    console.log(`  ✓${tag}${screenName.padEnd(22)} ${parts.join(', ')}`);

    // Print first 6 new elements
    for (const e of (data.newElements ?? []).slice(0, 6)) {
      const dis = e.disabled ? ' [disabled]' : '';
      console.log(`         + [${e.role.padEnd(12)}] "${e.name}"${dis}`);
    }
    if ((data.newElements?.length ?? 0) > 6) {
      console.log(`         … +${data.newElements.length - 6} more (see report file)`);
    }
  }

  // New screen instructions
  if (newScreens.length > 0) {
    console.log('\n⚠️  NEW SCREENS — add these to tests/helpers/navigator.js manually:');
    console.log('');
    console.log('   SIDEBAR_LABELS additions:');
    for (const s of newScreens) {
      console.log(`     ${s.screenName}: '${s.label}',`);
    }
    console.log('');
    console.log('   SCREEN_MARKERS additions (set to a visible text unique to each screen):');
    for (const s of newScreens) {
      console.log(`     ${s.screenName}: '${s.label}',   // TODO: verify this is a reliable marker`);
    }
    console.log('');
    console.log('   Then add a test file: tests/screens/' +
      newScreens[0].screenName + '.spec.js');
  }

  // Mode-specific footer
  if (summary.totalNew > 0 && !UPDATE) {
    console.log('\n  💡  Re-run with --update to patch Elements_Config files automatically.');
  }
  if (UPDATE) {
    console.log(`\n  ✅  Elements_Config updated (${summary.patchedConfigs ?? 0} patched, ${summary.createdConfigs ?? 0} created).`);
    console.log('  Review _discovered_* groups before writing tests.');
  }

  console.log(`\n  Report: ${report.reportPath}`);
  console.log('═'.repeat(60) + '\n');
}

// ── Main ──────────────────────────────────────────────────────────────────────

async function main() {
  ensureDir(OUTPUT_DIR);

  const timestamp  = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 16);
  const reportPath = path.join(OUTPUT_DIR, `reinspect_${timestamp}.json`);

  log('info', 'reinspect.js starting', {
    update: UPDATE, allDrives: ALL_DRIVES, screen: screenArg ?? 'all',
  });

  // ── Launch ────────────────────────────────────────────────────────────────
  let browser, page, proc;
  try {
    ({ browser, page, proc } = await launchApp());
  } catch (err) {
    log('error', `Launch failed: ${err.message}`);
    process.exit(1);
  }

  const report = {
    timestamp:     new Date().toISOString(),
    mode:          UPDATE ? 'update' : 'report-only',
    driveContexts: [],
    screens:       {},
    newScreens:    [],
    summary: {
      screensInspected: 0,
      totalNew:         0,
      totalMissing:     0,
      newScreens:       0,
      patchedConfigs:   0,
      createdConfigs:   0,
    },
    reportPath,
  };

  try {
    // ── Detect drives ─────────────────────────────────────────────────────
    const driveCtx = await detectDrives(page);
    report.driveContexts.push(driveCtx);
    log('info', 'Drive context', {
      driveNames:  driveCtx.driveNames,
      interfaces:  driveCtx.interfaces,
      driveCount:  driveCtx.driveCount,
    });

    // ── Discover unknown sidebar items ────────────────────────────────────
    const candidateLabels = await discoverUnknownSidebarItems(page);
    log('info', `Sidebar scan: ${candidateLabels.length} candidate(s) to probe`, { candidateLabels });

    const confirmedNewScreens = [];
    for (const label of candidateLabels) {
      const { navigated } = await tryNavigateToCandidate(page, label);
      if (navigated) {
        const screenName = label.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/, '');
        log('info', `New screen confirmed: "${label}" → ${screenName}`);
        confirmedNewScreens.push({ screenName, label, isNew: true });
        report.newScreens.push({ screenName, label });

        // Return to dashboard so next probe starts from a known state
        await jsClick(page, 'Home Dashboard');
        await sleep(SETTLE_MS);
      }
    }

    // ── Build inspection list ─────────────────────────────────────────────
    let screensToInspect;

    if (screenArg) {
      // Single screen mode
      const label = KNOWN_SCREENS[screenArg] ?? screenArg;
      screensToInspect = [{ screenName: screenArg, label, isNew: false }];
    } else {
      // All known screens + newly discovered
      screensToInspect = [
        ...Object.entries(KNOWN_SCREENS).map(([screenName, label]) => ({
          screenName, label, isNew: false,
        })),
        ...confirmedNewScreens,
      ];
    }

    // ── Inspect: drive 0 (current drive) ─────────────────────────────────
    const driveResults = await inspectDriveContext(page, screensToInspect, driveCtx, 0);
    Object.assign(report.screens, driveResults);

    // ── Inspect: additional drives (--all-drives) ─────────────────────────
    if (ALL_DRIVES && driveCtx.driveCount > 1) {
      log('info', `Multiple drives detected (${driveCtx.driveCount}) — cycling through remaining drives`);

      for (let driveIdx = 1; driveIdx < driveCtx.driveCount; driveIdx++) {
        // Navigate to dashboard first (drive switcher is in the header)
        await jsClick(page, 'Home Dashboard');
        await sleep(SETTLE_MS);

        const switched = await switchToNextDrive(page);
        if (!switched) {
          log('warn', `Could not switch to drive ${driveIdx} — stopping multi-drive scan`);
          break;
        }

        const ctx2     = await detectDrives(page);
        report.driveContexts.push(ctx2);

        const results2 = await inspectDriveContext(page, screensToInspect, ctx2, driveIdx);

        // Merge results: add new elements found on this drive that weren't on drive 0
        for (const [screenName, data2] of Object.entries(results2)) {
          if (!data2.newElements?.length) continue;
          const existing = report.screens[screenName];
          if (!existing) { report.screens[screenName] = data2; continue; }

          const alreadyFound = new Set(existing.newElements.map(e => e.name));
          const uniqueToThisDrive = data2.newElements.filter(e => !alreadyFound.has(e.name));
          if (uniqueToThisDrive.length > 0) {
            existing.newElements.push(...uniqueToThisDrive);
            existing.newCount += uniqueToThisDrive.length;
            log('info', `Drive ${driveIdx}: ${uniqueToThisDrive.length} additional elements on ${screenName}`);
          }
        }
      }
    }

    // ── Aggregate summary ─────────────────────────────────────────────────
    for (const data of Object.values(report.screens)) {
      if (data.skipped) continue;
      report.summary.screensInspected++;
      report.summary.totalNew     += data.newCount     ?? 0;
      report.summary.totalMissing += data.missingCount ?? 0;
    }
    report.summary.newScreens = report.newScreens.length;

    // ── Apply updates ─────────────────────────────────────────────────────
    if (UPDATE) {
      const { patchedCount, createdCount } = applyUpdates(report.screens, report.newScreens);
      report.summary.patchedConfigs = patchedCount;
      report.summary.createdConfigs = createdCount;
    }

  } finally {
    await closeApp({ browser, proc });
  }

  // ── Write report ──────────────────────────────────────────────────────────
  fs.writeFileSync(reportPath, JSON.stringify(report, null, 2) + '\n', 'utf8');
  log('info', `Report written: ${reportPath}`);

  // ── Print console summary ─────────────────────────────────────────────────
  printReport(report);
}

main().catch(err => {
  log('error', 'reinspect.js crashed', { detail: err.message, stack: err.stack });
  process.exit(1);
});
