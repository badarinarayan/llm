'use strict';

/**
 * agentic_scripts/run_steps.js
 *
 * Node.js bridge: execute a list of structured test steps against Samsung Magician
 * and write per-step results to a JSON output file.
 *
 * Called by the Python agent as a subprocess:
 *   node agentic_scripts/run_steps.js <steps_input.json> <results_output.json>
 *
 * Input JSON schema:
 *   { "steps": [{ "action": "navigate"|"click"|"verify"|..., ... }] }
 *
 * Output JSON schema:
 *   { "success": bool, "total": N, "passed": N, "failed": N,
 *     "steps": [{ "step": {...}, "success": bool, "error"?: "...",
 *                 "duration_ms": N, "dom_snapshot"?: {...} }] }
 *
 * Exit codes:
 *   0 = all steps passed
 *   1 = one or more steps failed
 *
 * Design notes:
 *   - Stops at the FIRST failure (stop-on-first-failure) to avoid cascading
 *     errors from a bad state (e.g., wrong screen after a failed navigate).
 *   - Captures a DOM snapshot on failure so the Python agent can diagnose
 *     without launching the app a second time.
 *   - Reuses the existing helpers (appLauncher.js, navigator.js) so all
 *     SVC race-condition logic is inherited for free.
 */

const path = require('path');
const fs   = require('fs');

const ROOT = path.join(__dirname, '..');
const { launchMagician, closeMagician } = require(path.join(ROOT, 'tests/helpers/appLauncher'));
const { navigateTo, clickText }         = require(path.join(ROOT, 'tests/helpers/navigator'));

// ── CLI args ──────────────────────────────────────────────────────────────────

const [,, stepsFile, outputFile] = process.argv;

if (!stepsFile || !outputFile) {
  console.error('Usage: node run_steps.js <steps_input.json> <results_output.json>');
  process.exit(1);
}

const stepsData = JSON.parse(fs.readFileSync(stepsFile, 'utf8'));
const steps = stepsData.steps || [];

// ── DOM snapshot helper ───────────────────────────────────────────────────────

async function captureDomSnapshot(page) {
  try {
    return await page.evaluate(() => {
      const nodes = [];
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      let node;
      while ((node = walker.nextNode())) {
        const t = node.textContent.trim();
        if (!t) continue;
        const el = node.parentElement;
        if (!el) continue;
        nodes.push({
          text:  t,
          tag:   el.tagName.toLowerCase(),
          role:  el.getAttribute('role') || '',
          class: [...el.classList].find(c => c.length > 1) || '',
        });
      }
      return { text_nodes: nodes.slice(0, 100) };
    });
  } catch (_) {
    return null;
  }
}

// ── Step executor ─────────────────────────────────────────────────────────────

async function executeStep(page, step) {
  const start = Date.now();

  try {
    switch (step.action) {

      // ── Navigate ──────────────────────────────────────────────────────────
      case 'navigate':
        if (page.isClosed()) throw new Error('Page closed before navigate — app may have crashed');
        await navigateTo(page, step.to);
        break;

      // ── Click ─────────────────────────────────────────────────────────────
      case 'click': {
        const ok = await clickText(page, step.text);
        if (!ok) throw new Error(`Element not found: "${step.text}"`);
        await page.waitForTimeout(500);
        break;
      }

      // ── Verify present ────────────────────────────────────────────────────
      case 'verify': {
        const loc = page.getByText(step.text, { exact: false });
        await loc.first().waitFor({ state: 'attached', timeout: 10_000 });
        break;
      }

      // ── Verify absent ─────────────────────────────────────────────────────
      case 'verify_absent': {
        const loc = page.getByText(step.text, { exact: false });
        const cnt = await loc.count();
        if (cnt > 0) {
          throw new Error(`Expected "${step.text}" to be absent but found ${cnt} instance(s)`);
        }
        break;
      }

      // ── Wait ──────────────────────────────────────────────────────────────
      case 'wait':
        await page.waitForTimeout(step.timeout || 1000);
        break;

      // ── Scroll ────────────────────────────────────────────────────────────
      case 'scroll': {
        const amount = step.amount || 300;
        const dx = step.direction === 'left'  ? -amount
                 : step.direction === 'right' ?  amount : 0;
        const dy = step.direction === 'up'    ? -amount
                 : step.direction === 'down'  ?  amount : 0;
        await page.mouse.wheel(dx, dy);
        await page.waitForTimeout(300);
        break;
      }

      // ── Select (custom React dropdown — click by visible text) ────────────
      case 'select': {
        const ok = await clickText(page, step.text);
        if (!ok) throw new Error(`Option not found: "${step.text}"`);
        await page.waitForTimeout(500);
        break;
      }

      default:
        throw new Error(`Unknown action type: "${step.action}"`);
    }

    return { step, success: true, duration_ms: Date.now() - start };

  } catch (err) {
    const snapshot = await captureDomSnapshot(page);
    return {
      step,
      success:      false,
      error:        err.message,
      duration_ms:  Date.now() - start,
      dom_snapshot: snapshot,
    };
  }
}

// ── Main ──────────────────────────────────────────────────────────────────────

async function main() {
  const results = [];
  let app = null;

  try {
    // Single launch — reuses all SVC race-condition logic from appLauncher.js
    const launch = await launchMagician();
    app = launch.app;
    const page = launch.page;

    for (const step of steps) {
      if (step.action === 'cannot_automate') {
        results.push({
          step,
          success:     false,
          error:       'Step type cannot be automated',
          duration_ms: 0,
        });
        continue;
      }

      const result = await executeStep(page, step);
      results.push(result);

      // Stop-on-first-failure: avoids cascading errors from a bad state
      if (!result.success) break;
    }

  } catch (launchErr) {
    results.push({
      step:        { action: 'launch', raw: 'launch samsung magician' },
      success:     false,
      error:       `Launch failed: ${launchErr.message}`,
      duration_ms: 0,
    });
  } finally {
    if (app) {
      await closeMagician(app).catch(() => {});
    }
  }

  const passed = results.filter(r => r.success).length;
  const allPassed = passed === steps.filter(s => s.action !== 'cannot_automate').length;

  const output = {
    success: allPassed && steps.length > 0,
    total:   steps.length,
    passed,
    failed:  results.filter(r => !r.success).length,
    steps:   results,
  };

  fs.writeFileSync(outputFile, JSON.stringify(output, null, 2), 'utf8');
  process.exit(output.success ? 0 : 1);
}

main().catch(err => {
  const output = {
    success: false,
    total:   steps.length,
    passed:  0,
    failed:  steps.length,
    error:   err.message,
    steps:   [],
  };
  try { fs.writeFileSync(outputFile, JSON.stringify(output, null, 2), 'utf8'); } catch (_) {}
  process.exit(1);
});
