'use strict';

/**
 * agentic_scripts/capture_dom.js
 *
 * Launches Samsung Magician, navigates to a target screen, optionally performs
 * pre-actions (e.g. clicking "Setup Benchmark" to open a popup), then dumps:
 *   A) All visible text nodes (tag, role, first CSS class)
 *   B) Interactive AX nodes (buttons, combos, options…) via CDP
 *   C) Native <select> elements
 *
 * Called by the Python reinspect node:
 *   node agentic_scripts/capture_dom.js '<json_config>'
 *
 * Config JSON:
 *   {
 *     "screen":        "performance_benchmark",
 *     "pre_actions":   [{ "action": "click", "text": "Setup Benchmark" }],
 *     "popup_wait_ms": 5000
 *   }
 *
 * Output: JSON to stdout
 *   {
 *     "screen": "...",
 *     "captured_at": "ISO timestamp",
 *     "text_nodes": [...],
 *     "ax_nodes":   [...],
 *     "selects":    [...]
 *   }
 *
 * Exit codes:
 *   0 = success (JSON on stdout)
 *   1 = failure (error JSON on stdout)
 */

const path = require('path');

const ROOT = path.join(__dirname, '..');
const { launchMagician, closeMagician } = require(path.join(ROOT, 'tests/helpers/appLauncher'));
const { navigateTo, clickText }         = require(path.join(ROOT, 'tests/helpers/navigator'));

// ── Parse config ──────────────────────────────────────────────────────────────

const configArg = process.argv[2];
if (!configArg) {
  process.stdout.write(JSON.stringify({ error: 'Usage: node capture_dom.js \'<json_config>\'' }));
  process.exit(1);
}

let config;
try {
  config = JSON.parse(configArg);
} catch (e) {
  process.stdout.write(JSON.stringify({ error: `Invalid JSON config: ${e.message}` }));
  process.exit(1);
}

const INTERACTIVE_ROLES = new Set([
  'button', 'combobox', 'listbox', 'option',
  'radio', 'checkbox', 'menuitem', 'menu',
  'menubar', 'tab', 'tablist', 'slider',
]);

// ── Main ──────────────────────────────────────────────────────────────────────

async function main() {
  const launch = await launchMagician();
  const app  = launch.app;
  const page = launch.page;

  try {
    // ── 1. Navigate to target screen ─────────────────────────────────────────
    if (config.screen) {
      await navigateTo(page, config.screen, { verify: false });
      await page.waitForTimeout(2_000);
    }

    // ── 2. Pre-actions (e.g. open popup) ─────────────────────────────────────
    const preActions = config.pre_actions || [];
    for (const action of preActions) {
      if (action.action === 'click') {
        const ok = await clickText(page, action.text);
        if (ok) {
          // Wait for popup/dropdown to render
          await page.waitForTimeout(config.popup_wait_ms || 5_000);
        }
      }
    }

    // ── 3A. Text nodes ────────────────────────────────────────────────────────
    const text_nodes = await page.evaluate(() => {
      const results = [];
      const walker  = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      let node;
      while ((node = walker.nextNode())) {
        const t  = node.textContent.trim();
        if (!t) continue;
        const el  = node.parentElement;
        if (!el)  continue;
        const tag  = el.tagName.toLowerCase();
        const role = el.getAttribute('role') || '';
        const cls  = [...el.classList].find(c => c.length > 1) || '';
        results.push({ text: t, tag, role, class: cls.slice(0, 50) });
      }
      return results;
    });

    // ── 3B. AX nodes via CDP ──────────────────────────────────────────────────
    const session = await page.context().newCDPSession(page);
    let ax_nodes = [];
    try {
      await session.send('Accessibility.enable');
      const { nodes } = await session.send('Accessibility.getFullAXTree');
      ax_nodes = nodes
        .filter(n => n.role && INTERACTIVE_ROLES.has(n.role.value))
        .map(n => ({
          role:   n.role?.value  || '',
          name:   n.name?.value  || '',
          states: (n.states || []).map(s => s.value).filter(Boolean),
        }));
    } finally {
      await session.detach().catch(() => {});
    }

    // ── 3C. Native <select> elements ──────────────────────────────────────────
    const selects = await page.evaluate(() =>
      [...document.querySelectorAll('select')].map(el => ({
        name:    el.name || el.id || '(unnamed)',
        current: el.value,
        options: [...el.options].map(o => ({ value: o.value, text: o.text })),
      }))
    );

    // ── 4. Output ─────────────────────────────────────────────────────────────
    const result = {
      screen:       config.screen || 'unknown',
      captured_at:  new Date().toISOString(),
      text_nodes,
      ax_nodes,
      selects,
    };

    process.stdout.write(JSON.stringify(result));

  } finally {
    await closeMagician(app).catch(() => {});
  }
}

main().catch(err => {
  process.stdout.write(JSON.stringify({
    error:      err.message,
    screen:     config.screen || 'unknown',
    text_nodes: [],
    ax_nodes:   [],
    selects:    [],
  }));
  process.exit(1);
});
