---
name: windows-ui-automation
description: Utilities for controlling and inspecting Windows OS-level UI state during test automation — changing screen resolution, showing/hiding/querying the taskbar, enumerating and manipulating windows (move/resize/minimize/maximize/close/focus), simulating mouse/keyboard input, reading system tray icons, and taking screenshots. Use this skill whenever the user is automating or testing a Windows desktop app (Electron, Win32, WPF, UWP) and needs to manipulate OS chrome or window state rather than the app's own UI — e.g. "change the display resolution before this test", "check if the app pinned itself to the taskbar", "minimize/restore/close a window by title", "click at these screen coordinates", "enumerate open windows", "hide the taskbar for a kiosk-mode test". Trigger this even if the user only mentions "taskbar", "screen resolution", "window handle", "HWND", or "system tray" without saying "Windows automation" explicitly.
---

# Windows UI Automation Utilities

A collection of standalone PowerShell scripts for controlling Windows OS-level UI
state during desktop application testing. Built for the kind of black-box UI test
scenarios where you need to manipulate the OS around an app under test (e.g. Samsung
Magician-style Electron apps) rather than instrument the app itself.

All scripts are self-contained (no external modules required beyond what ships with
Windows 10/11 PowerShell 5.1+ or PowerShell 7+) and use P/Invoke against `user32.dll`,
`shell32.dll`, and `gdi32.dll` under the hood.

## When to reach for which script

| Task | Script |
|---|---|
| Read or change display resolution | `scripts/Screen-Resolution.ps1` |
| Show / hide / auto-hide the taskbar, query its state | `scripts/Taskbar-Control.ps1` |
| Enumerate windows, get/set position, minimize/maximize/restore/close, bring to front | `scripts/Window-Management.ps1` |
| Simulate mouse clicks/moves and keystrokes | `scripts/Input-Simulation.ps1` |
| Enumerate system tray (notification area) icons | `scripts/SystemTray-Icons.ps1` |
| Capture a screenshot (full screen, a monitor, or a window) | `scripts/Screenshot-Capture.ps1` |

Each script can be **dot-sourced** to import its functions into your session, or **run
directly** with parameters for one-off use. Run any script with `-?` or open it to see
parameter docs in the header comment block.

```powershell
# Dot-source to get functions in your current session
. .\scripts\Window-Management.ps1
Get-WindowList | Where-Object Title -like "*Samsung Magician*"

# Or run directly for a one-shot action
.\scripts\Screen-Resolution.ps1 -Width 1920 -Height 1080
```

## Core workflow for a UI test that needs OS-level setup

1. **Capture baseline state** before mutating anything (current resolution, taskbar
   auto-hide setting, window list) so the test can restore it in teardown.
2. **Apply the OS-level change** (resolution, taskbar visibility, window
   position/state) using the relevant script.
3. **Locate the window(s) under test** with `Get-WindowList` (supports filtering by
   title substring or process name) to get a reliable `HWND` before doing anything
   further — don't assume window enumeration order is stable across runs.
4. **Drive the UI** via `Input-Simulation.ps1` (coordinate-based clicks/keys) if you
   don't have (or don't want to depend on) UI Automation element handles. For anything
   beyond simple clicks/keystrokes — reading control properties, tree walking — prefer
   `UIAutomation.dll`/FlaUI instead; this skill is deliberately scoped to OS chrome and
   coarse input, not full accessibility-tree automation.
5. **Restore baseline state** in teardown using the values captured in step 1.

## Important gotchas

- **Run as the interactive user, not SYSTEM/a service.** `user32.dll` window and input
  APIs operate on the calling session's desktop. If your test runner executes as a
  Windows service or via a scheduled task without "Interactive" session access, these
  calls will silently no-op or fail. This is the same class of issue as the
  MSIX/AppContainer isolation problem you'd hit trying to reach an Electron app's CDP
  port — check session context first if a script reports success but nothing visibly
  happens.
- **DPI scaling affects coordinates.** If the test machine uses display scaling
  (>100%), raw pixel coordinates from `Get-WindowList`/screenshots may not match
  physical pixels. Scripts call `SetProcessDpiAwareness` where relevant, but if you're
  mixing this with another automation layer (Playwright, FlaUI), make sure both agree
  on DPI awareness mode or clicks will land in the wrong place.
- **Resolution changes can fail silently** if the requested mode isn't supported by
  the display. `Screen-Resolution.ps1` checks `ChangeDisplaySettings`'s return code and
  throws with the actual Win32 error rather than assuming success — check the script's
  exit behavior if wiring it into a CI pipeline.
- **Taskbar auto-hide is a per-monitor, per-user Explorer setting**, not a simple
  on/off — `Taskbar-Control.ps1` handles the registry + `SHAppBarMessage` combination
  needed to make it take effect without an Explorer restart.
- **Elevation**: none of these require admin rights for a single interactive session,
  except changing resolution on some locked-down enterprise images — if
  `Screen-Resolution.ps1` fails with access denied, re-run elevated.

## Reference

See `references/win32-api-reference.md` for the underlying P/Invoke signatures
(`user32.dll`, `shell32.dll`, `gdi32.dll` functions used) if you need to extend a
script or call the APIs directly from another language (C#, Python via `ctypes`,
Node via `ffi-napi`).
