# Win32 API Reference

Raw signatures for the APIs used across these scripts, for porting to another
language (C#, Python `ctypes`/`pywin32`, Node `ffi-napi`) or extending a script.

## Display / resolution (`user32.dll`)

| Function | Purpose |
|---|---|
| `EnumDisplaySettings(lpszDeviceName, iModeNum, ref DEVMODE)` | Read current or enumerate all supported display modes |
| `ChangeDisplaySettings(ref DEVMODE, dwFlags)` | Apply a display mode. Call with `CDS_TEST` first to validate without applying. |

Key `DEVMODE` fields: `dmPelsWidth`, `dmPelsHeight`, `dmDisplayFrequency`, `dmBitsPerPel`, `dmFields` (bitmask of which fields are meaningful: `DM_PELSWIDTH=0x80000`, `DM_PELSHEIGHT=0x100000`, `DM_DISPLAYFREQUENCY=0x400000`).

`ChangeDisplaySettings` return codes: `0`=success, `1`=needs restart, negative = various failure modes (bad mode, bad params, etc.) — always check this, don't assume success.

## Taskbar (`user32.dll` + `shell32.dll`)

| Function | Purpose |
|---|---|
| `FindWindow("Shell_TrayWnd", null)` | Get the taskbar's own window handle |
| `SHAppBarMessage(ABM_GETSTATE / ABM_SETSTATE, ref APPBARDATA)` | Query/set live auto-hide + always-on-top appbar state |
| `ShowWindow(hwnd, SW_HIDE / SW_SHOW)` | Immediately hide/show the taskbar window |

Persisted auto-hide setting lives in the registry at
`HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\StuckRects3`, value
`Settings` (binary blob) — byte offset 8, bit `0x1`. Changing it requires an
Explorer restart to visibly apply; the live `SHAppBarMessage` toggle applies
immediately but doesn't survive an Explorer restart or re-login on its own.

## Window enumeration & control (`user32.dll`)

| Function | Purpose |
|---|---|
| `EnumWindows(callback, lParam)` | Walk all top-level windows |
| `IsWindowVisible(hwnd)` | Filter to visible windows |
| `GetWindowText` / `GetWindowTextLength` | Read window title |
| `GetWindowThreadProcessId(hwnd, out pid)` | Map HWND → owning process |
| `GetWindowRect(hwnd, out RECT)` | Get window bounds (screen coords) |
| `ShowWindow(hwnd, SW_MINIMIZE/SW_MAXIMIZE/SW_RESTORE)` | Change window state |
| `SetForegroundWindow(hwnd)` | Bring window to front / give focus |
| `MoveWindow(hwnd, x, y, w, h, repaint)` | Reposition/resize |
| `PostMessage(hwnd, WM_CLOSE, 0, 0)` | Ask the window to close gracefully (app can intercept, unlike `DestroyWindow`) |

Note: window enumeration order is not a stable identifier across app
restarts — always re-resolve by title/process filter per test step rather
than caching a stale HWND.

## Input simulation (`user32.dll`)

| Function | Purpose |
|---|---|
| `SetCursorPos(x, y)` | Move the cursor |
| `mouse_event(dwFlags, ...)` | Legacy but simple mouse button events (`MOUSEEVENTF_LEFTDOWN/UP`, `RIGHTDOWN/UP`) |
| `System.Windows.Forms.SendKeys` (.NET, not raw Win32) | Keystrokes/text — simpler than raw `SendInput` keyboard events for most test purposes |

For more robust input (games, apps that ignore synthetic `mouse_event`),
switch to the newer `SendInput` API with `INPUT` structs — more verbose but
handles some edge cases `mouse_event` doesn't (e.g. UAC-elevated target
windows in some configurations).

## System tray (UI Automation, not raw Win32)

The tray toolbar (`TrayNotifyWnd` for the visible tray,
`NotifyIconOverflowWindow` for the hidden-icons flyout) exposes each icon as
a UI Automation `Button` element with a `Name` (tooltip text). This is
markedly more reliable than trying to read tray icons via `Shell_NotifyIcon`
internals or raw window scraping. Requires `UIAutomationClient` /
`UIAutomationTypes` assemblies (built into .NET / Windows, no extra install).

## Session context requirement

All of the above operate on the calling process's window station / desktop.
If the process automating these calls runs as a Windows service or scheduled
task without "Run only when user is logged on" + interactive session access,
these calls will typically return success codes but have no visible effect,
because they're acting on a non-interactive Session 0 desktop rather than the
user's actual desktop. This is the same root cause class as the
MSIX/AppContainer CDP isolation issue — always verify session context (`query
session` / `whoami /groups` for the interactive SID) before assuming a script
bug if calls report success but nothing happens.
