<#
.SYNOPSIS
    Simulate mouse clicks/moves and keystrokes at the OS level via SendInput.

.DESCRIPTION
    Coordinate-based input simulation - use this for coarse interactions
    (click a known screen position, type text, send a key combo) when you
    don't need/want full UI Automation element targeting. Coordinates are
    absolute screen pixels; call Screen-Resolution.ps1 first if you need to
    convert relative/percentage positions.

    NOTE: Must run in the interactive desktop session (not as a service).

.PARAMETER Action
    Click | RightClick | DoubleClick | Move | Type | KeyPress

.PARAMETER X
.PARAMETER Y
    Screen coordinates for Click/RightClick/DoubleClick/Move.

.PARAMETER Text
    String to type, used with -Action Type.

.PARAMETER Keys
    Key combo for -Action KeyPress, e.g. "^s" (Ctrl+S), "%{F4}" (Alt+F4),
    using SendKeys syntax.

.EXAMPLE
    .\Input-Simulation.ps1 -Action Click -X 500 -Y 300

.EXAMPLE
    .\Input-Simulation.ps1 -Action Type -Text "hello world"

.EXAMPLE
    .\Input-Simulation.ps1 -Action KeyPress -Keys "%{F4}"
    Sends Alt+F4 to the currently focused window.
#>
param(
    [ValidateSet("Click", "RightClick", "DoubleClick", "Move", "Type", "KeyPress")]
    [string]$Action,
    [int]$X, [int]$Y,
    [string]$Text,
    [string]$Keys
)

$signature = @"
using System;
using System.Runtime.InteropServices;

public class InputSim {
    [DllImport("user32.dll")]
    public static extern bool SetCursorPos(int X, int Y);

    [DllImport("user32.dll")]
    public static extern void mouse_event(uint dwFlags, int dx, int dy, uint dwData, IntPtr dwExtraInfo);

    public const uint MOUSEEVENTF_LEFTDOWN  = 0x0002;
    public const uint MOUSEEVENTF_LEFTUP    = 0x0004;
    public const uint MOUSEEVENTF_RIGHTDOWN = 0x0008;
    public const uint MOUSEEVENTF_RIGHTUP   = 0x0010;
}
"@

Add-Type -TypeDefinition $signature -Language CSharp -ErrorAction SilentlyContinue
# SendKeys needs System.Windows.Forms
Add-Type -AssemblyName System.Windows.Forms

function Move-Cursor {
    param([int]$X, [int]$Y)
    [InputSim]::SetCursorPos($X, $Y) | Out-Null
}

function Invoke-Click {
    param([int]$X, [int]$Y, [switch]$Right, [switch]$Double)
    Move-Cursor -X $X -Y $Y
    Start-Sleep -Milliseconds 50
    if ($Right) {
        [InputSim]::mouse_event([InputSim]::MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, [IntPtr]::Zero)
        [InputSim]::mouse_event([InputSim]::MOUSEEVENTF_RIGHTUP, 0, 0, 0, [IntPtr]::Zero)
    } else {
        [InputSim]::mouse_event([InputSim]::MOUSEEVENTF_LEFTDOWN, 0, 0, 0, [IntPtr]::Zero)
        [InputSim]::mouse_event([InputSim]::MOUSEEVENTF_LEFTUP, 0, 0, 0, [IntPtr]::Zero)
        if ($Double) {
            Start-Sleep -Milliseconds 80
            [InputSim]::mouse_event([InputSim]::MOUSEEVENTF_LEFTDOWN, 0, 0, 0, [IntPtr]::Zero)
            [InputSim]::mouse_event([InputSim]::MOUSEEVENTF_LEFTUP, 0, 0, 0, [IntPtr]::Zero)
        }
    }
}

switch ($Action) {
    "Click"       { Invoke-Click -X $X -Y $Y }
    "RightClick"  { Invoke-Click -X $X -Y $Y -Right }
    "DoubleClick" { Invoke-Click -X $X -Y $Y -Double }
    "Move"        { Move-Cursor -X $X -Y $Y }
    "Type"        {
        if (-not $Text) { throw "-Text is required for -Action Type." }
        [System.Windows.Forms.SendKeys]::SendWait($Text)
    }
    "KeyPress"    {
        if (-not $Keys) { throw "-Keys is required for -Action KeyPress (SendKeys syntax, e.g. '%{F4}')." }
        [System.Windows.Forms.SendKeys]::SendWait($Keys)
    }
    default { throw "Specify -Action." }
}
