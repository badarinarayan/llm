<#
.SYNOPSIS
    Capture a screenshot of the full virtual screen, a specific monitor, or
    a specific window by title/process.

.PARAMETER OutFile
    Path to save the PNG. Defaults to a timestamped file in the current
    directory.

.PARAMETER TitleLike
    If given, captures only that window's client area instead of the full
    screen (resolves via the same matching logic as Window-Management.ps1).

.EXAMPLE
    .\Screenshot-Capture.ps1
    Captures the full virtual screen (all monitors).

.EXAMPLE
    .\Screenshot-Capture.ps1 -TitleLike "Magician" -OutFile C:\temp\before.png
#>
param(
    [string]$OutFile,
    [string]$TitleLike,
    [string]$ProcessName
)

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

if (-not $OutFile) {
    $OutFile = ".\screenshot-$(Get-Date -Format 'yyyyMMdd-HHmmss').png"
}

if ($TitleLike -or $ProcessName) {
    # Reuse window lookup by dot-sourcing the management script's function
    . "$PSScriptRoot\Window-Management.ps1" -Action List -TitleLike $TitleLike -ProcessName $ProcessName | Out-Null
    $w = Get-WindowList -TitleLike $TitleLike -ProcessName $ProcessName | Select-Object -First 1
    if (-not $w) { throw "No window matched." }

    $bmp = New-Object System.Drawing.Bitmap $w.Width, $w.Height
    $graphics = [System.Drawing.Graphics]::FromImage($bmp)
    $graphics.CopyFromScreen($w.X, $w.Y, 0, 0, $bmp.Size)
    $bmp.Save($OutFile, [System.Drawing.Imaging.ImageFormat]::Png)
    $graphics.Dispose(); $bmp.Dispose()
    Write-Host "Saved window screenshot to $OutFile" -ForegroundColor Green
} else {
    $bounds = [System.Windows.Forms.SystemInformation]::VirtualScreen
    $bmp = New-Object System.Drawing.Bitmap $bounds.Width, $bounds.Height
    $graphics = [System.Drawing.Graphics]::FromImage($bmp)
    $graphics.CopyFromScreen($bounds.Location, [System.Drawing.Point]::Empty, $bounds.Size)
    $bmp.Save($OutFile, [System.Drawing.Imaging.ImageFormat]::Png)
    $graphics.Dispose(); $bmp.Dispose()
    Write-Host "Saved full-screen screenshot to $OutFile" -ForegroundColor Green
}
