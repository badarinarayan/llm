<#
.SYNOPSIS
    Enumerate visible and hidden system tray (notification area) icons.

.DESCRIPTION
    Useful for verifying that an app under test correctly registered a tray
    icon (and its tooltip text). Walks the tray toolbar's child controls via
    UI Automation (System.Windows.Automation) rather than raw HWND scraping,
    since the tray toolbar is a single window with UI Automation-exposed
    button elements per icon - far more reliable than window enumeration for
    this specific case.

.EXAMPLE
    .\SystemTray-Icons.ps1
    Lists all tray icons (visible overflow + main tray) with name/tooltip.

.EXAMPLE
    .\SystemTray-Icons.ps1 -NameLike "Magician"
#>
param(
    [string]$NameLike
)

Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes

function Get-TrayIcons {
    $results = @()

    # Two locations to check: the main visible tray, and the hidden-icons
    # overflow flyout (only populated while that flyout is open).
    $trayContainers = @(
        @{ ClassName = "TrayNotifyWnd"; Label = "Visible tray" }
        @{ ClassName = "NotifyIconOverflowWindow"; Label = "Hidden icons overflow" }
    )

    foreach ($container in $trayContainers) {
        $root = [System.Windows.Automation.AutomationElement]::RootElement
        $condition = New-Object System.Windows.Automation.PropertyCondition(
            [System.Windows.Automation.AutomationElement]::ClassNameProperty,
            $container.ClassName
        )
        $window = $root.FindFirst([System.Windows.Automation.TreeScope]::Descendants, $condition)
        if (-not $window) { continue }

        $buttonCondition = New-Object System.Windows.Automation.PropertyCondition(
            [System.Windows.Automation.AutomationElement]::ControlTypeProperty,
            [System.Windows.Automation.ControlType]::Button
        )
        $buttons = $window.FindAll([System.Windows.Automation.TreeScope]::Descendants, $buttonCondition)

        foreach ($btn in $buttons) {
            if (-not $btn.Current.Name) { continue }
            $results += [PSCustomObject]@{
                Location = $container.Label
                Name     = $btn.Current.Name
                Rect     = $btn.Current.BoundingRectangle
            }
        }
    }

    $results
}

$icons = Get-TrayIcons
if ($NameLike) { $icons = $icons | Where-Object { $_.Name -like "*$NameLike*" } }

if (-not $icons) {
    Write-Host "No tray icons found. Note: hidden-icons overflow only populates while its flyout is open - click the '^' chevron on the taskbar first if checking a hidden icon." -ForegroundColor Yellow
} else {
    $icons | Format-Table -AutoSize
}
