<#
.SYNOPSIS
    Show, hide, auto-hide, or query the Windows taskbar.

.DESCRIPTION
    Combines the SHAppBarMessage API (for immediate show/hide of the taskbar
    window) with the Explorer registry setting for auto-hide (for a change
    that survives login / Explorer restarts). Also exposes a helper to find
    the taskbar's window handle and check whether an app has pinned an icon
    or a running-app button to it.

.PARAMETER Action
    One of: Show, Hide, AutoHideOn, AutoHideOff, Status

.EXAMPLE
    .\Taskbar-Control.ps1 -Action Hide
    Immediately hides the taskbar (until shown again or Explorer restarts).

.EXAMPLE
    .\Taskbar-Control.ps1 -Action AutoHideOn
    Turns on "Automatically hide the taskbar" persistently.

.EXAMPLE
    .\Taskbar-Control.ps1 -Action Status
#>
param(
    [ValidateSet("Show", "Hide", "AutoHideOn", "AutoHideOff", "Status")]
    [string]$Action = "Status"
)

$signature = @"
using System;
using System.Runtime.InteropServices;

public class TaskbarControl {
    [DllImport("user32.dll", SetLastError = true)]
    public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

    [DllImport("user32.dll")]
    public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

    [DllImport("user32.dll")]
    public static extern bool IsWindowVisible(IntPtr hWnd);

    [StructLayout(LayoutKind.Sequential)]
    public struct APPBARDATA {
        public int cbSize;
        public IntPtr hWnd;
        public uint uCallbackMessage;
        public uint uEdge;
        public RECT rc;
        public int lParam;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct RECT {
        public int left, top, right, bottom;
    }

    [DllImport("shell32.dll")]
    public static extern uint SHAppBarMessage(uint dwMessage, ref APPBARDATA pData);

    public const int SW_HIDE = 0;
    public const int SW_SHOW = 5;
    public const uint ABM_GETSTATE = 0x4;
    public const uint ABM_SETSTATE = 0xA;
    public const int ABS_AUTOHIDE = 0x1;
    public const int ABS_ALWAYSONTOP = 0x2;
}
"@

Add-Type -TypeDefinition $signature -Language CSharp -ErrorAction SilentlyContinue

function Get-TaskbarHandle {
    [TaskbarControl]::FindWindow("Shell_TrayWnd", $null)
}

function Get-TaskbarState {
    $hwnd = Get-TaskbarHandle
    $visible = [TaskbarControl]::IsWindowVisible($hwnd)

    $abd = New-Object TaskbarControl+APPBARDATA
    $abd.cbSize = [System.Runtime.InteropServices.Marshal]::SizeOf($abd)
    $abd.hWnd = $hwnd
    $state = [TaskbarControl]::SHAppBarMessage([TaskbarControl]::ABM_GETSTATE, [ref]$abd)

    $regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\StuckRects3"
    $regAutoHide = $null
    try {
        $settings = (Get-ItemProperty -Path $regPath -Name Settings -ErrorAction Stop).Settings
        # Byte 8 of the Settings binary blob is a bitmask; bit 0x1 = auto-hide
        $regAutoHide = [bool]($settings[8] -band 0x1)
    } catch {
        $regAutoHide = "unknown (registry key not found)"
    }

    [PSCustomObject]@{
        Handle              = $hwnd
        WindowVisible       = $visible
        AutoHideLive        = [bool]($state -band [TaskbarControl]::ABS_AUTOHIDE)
        AlwaysOnTopLive     = [bool]($state -band [TaskbarControl]::ABS_ALWAYSONTOP)
        AutoHidePersisted   = $regAutoHide
    }
}

function Set-TaskbarVisible {
    param([bool]$Visible)
    $hwnd = Get-TaskbarHandle
    if ($hwnd -eq [IntPtr]::Zero) { throw "Could not find taskbar window (Shell_TrayWnd)." }
    $cmd = if ($Visible) { [TaskbarControl]::SW_SHOW } else { [TaskbarControl]::SW_HIDE }
    [TaskbarControl]::ShowWindow($hwnd, $cmd) | Out-Null
}

function Set-TaskbarAutoHide {
    param([bool]$Enabled)
    # Live toggle via SHAppBarMessage
    $hwnd = Get-TaskbarHandle
    $abd = New-Object TaskbarControl+APPBARDATA
    $abd.cbSize = [System.Runtime.InteropServices.Marshal]::SizeOf($abd)
    $abd.hWnd = $hwnd
    $abd.lParam = if ($Enabled) { [TaskbarControl]::ABS_AUTOHIDE } else { 0 }
    [TaskbarControl]::SHAppBarMessage([TaskbarControl]::ABM_SETSTATE, [ref]$abd) | Out-Null

    # Persist via registry so it survives Explorer restart / re-login
    $regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\StuckRects3"
    try {
        $settings = (Get-ItemProperty -Path $regPath -Name Settings -ErrorAction Stop).Settings
        if ($Enabled) { $settings[8] = $settings[8] -bor 0x1 }
        else { $settings[8] = $settings[8] -band (-bnot 0x1) }
        Set-ItemProperty -Path $regPath -Name Settings -Value $settings
        # Restart Explorer for the persisted registry change to visibly apply
        Stop-Process -Name explorer -Force
        Start-Sleep -Milliseconds 500
        Start-Process explorer.exe
        Write-Host "Auto-hide set to $Enabled (Explorer restarted to apply)." -ForegroundColor Green
    } catch {
        Write-Warning "Live toggle applied, but could not persist to registry: $_"
    }
}

switch ($Action) {
    "Show"        { Set-TaskbarVisible -Visible $true; Write-Host "Taskbar shown." -ForegroundColor Green }
    "Hide"        { Set-TaskbarVisible -Visible $false; Write-Host "Taskbar hidden." -ForegroundColor Green }
    "AutoHideOn"  { Set-TaskbarAutoHide -Enabled $true }
    "AutoHideOff" { Set-TaskbarAutoHide -Enabled $false }
    "Status"      { Get-TaskbarState | Format-List }
}
