<#
.SYNOPSIS
    Enumerate and manipulate top-level windows: list, focus, move/resize,
    minimize/maximize/restore/close.

.DESCRIPTION
    Core window-handle (HWND) discovery and control, intended as the starting
    point before driving input with Input-Simulation.ps1. Window enumeration
    order is NOT guaranteed stable across runs - always re-resolve the HWND
    by title/process filter rather than caching it across test steps that
    might recreate the window.

.PARAMETER Action
    List | Focus | Minimize | Maximize | Restore | Close | Move

.PARAMETER TitleLike
    Substring filter on window title (case-insensitive).

.PARAMETER ProcessName
    Filter by owning process name (without .exe).

.PARAMETER X
.PARAMETER Y
.PARAMETER Width
.PARAMETER Height
    Used with -Action Move to reposition/resize the matched window.

.EXAMPLE
    .\Window-Management.ps1 -Action List

.EXAMPLE
    .\Window-Management.ps1 -Action List -ProcessName "Samsung Magician"

.EXAMPLE
    .\Window-Management.ps1 -Action Focus -TitleLike "Magician"

.EXAMPLE
    .\Window-Management.ps1 -Action Move -TitleLike "Magician" -X 0 -Y 0 -Width 1280 -Height 800

.EXAMPLE
    .\Window-Management.ps1 -Action Close -TitleLike "Magician"
#>
param(
    [ValidateSet("List", "Focus", "Minimize", "Maximize", "Restore", "Close", "Move")]
    [string]$Action = "List",
    [string]$TitleLike,
    [string]$ProcessName,
    [int]$X, [int]$Y, [int]$Width, [int]$Height
)

$signature = @"
using System;
using System.Text;
using System.Collections.Generic;
using System.Runtime.InteropServices;

public class WindowMgmt {
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

    [DllImport("user32.dll")]
    public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

    [DllImport("user32.dll")]
    public static extern bool IsWindowVisible(IntPtr hWnd);

    [DllImport("user32.dll")]
    public static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);

    [DllImport("user32.dll")]
    public static extern int GetWindowTextLength(IntPtr hWnd);

    [DllImport("user32.dll")]
    public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

    [DllImport("user32.dll")]
    public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

    [DllImport("user32.dll")]
    public static extern bool SetForegroundWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    public static extern bool CloseWindow(IntPtr hWnd); // minimizes

    [DllImport("user32.dll")]
    public static extern bool DestroyWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    public static extern bool PostMessage(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);

    [DllImport("user32.dll")]
    public static extern bool MoveWindow(IntPtr hWnd, int X, int Y, int nWidth, int nHeight, bool bRepaint);

    [DllImport("user32.dll")]
    public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

    [StructLayout(LayoutKind.Sequential)]
    public struct RECT { public int Left, Top, Right, Bottom; }

    public const int SW_MINIMIZE = 6;
    public const int SW_MAXIMIZE = 3;
    public const int SW_RESTORE = 9;
    public const uint WM_CLOSE = 0x0010;

    public static List<IntPtr> EnumerateTopLevelWindows() {
        var handles = new List<IntPtr>();
        EnumWindows((hWnd, lParam) => {
            if (IsWindowVisible(hWnd) && GetWindowTextLength(hWnd) > 0) {
                handles.Add(hWnd);
            }
            return true;
        }, IntPtr.Zero);
        return handles;
    }

    public static string GetTitle(IntPtr hWnd) {
        int len = GetWindowTextLength(hWnd);
        var sb = new StringBuilder(len + 1);
        GetWindowText(hWnd, sb, sb.Capacity);
        return sb.ToString();
    }
}
"@

Add-Type -TypeDefinition $signature -Language CSharp -ErrorAction SilentlyContinue

function Get-WindowList {
    <#
    .SYNOPSIS
        Returns all visible top-level windows as objects with Handle, Title,
        ProcessName, Pid, and bounding Rect.
    #>
    param([string]$TitleLike, [string]$ProcessName)

    $results = foreach ($h in [WindowMgmt]::EnumerateTopLevelWindows()) {
        $title = [WindowMgmt]::GetTitle($h)
        if (-not $title) { continue }

        [uint32]$procId = 0
        [WindowMgmt]::GetWindowThreadProcessId($h, [ref]$procId) | Out-Null
        $procName = try { (Get-Process -Id $procId -ErrorAction Stop).ProcessName } catch { "?" }

        $rect = New-Object WindowMgmt+RECT
        [WindowMgmt]::GetWindowRect($h, [ref]$rect) | Out-Null

        [PSCustomObject]@{
            Handle      = $h
            Title       = $title
            ProcessName = $procName
            Pid         = $procId
            X           = $rect.Left
            Y           = $rect.Top
            Width       = $rect.Right - $rect.Left
            Height      = $rect.Bottom - $rect.Top
        }
    }

    if ($TitleLike)   { $results = $results | Where-Object { $_.Title -like "*$TitleLike*" } }
    if ($ProcessName) { $results = $results | Where-Object { $_.ProcessName -like "*$ProcessName*" } }
    $results
}

function Resolve-SingleWindow {
    param([string]$TitleLike, [string]$ProcessName)
    $matches = Get-WindowList -TitleLike $TitleLike -ProcessName $ProcessName
    if (-not $matches) { throw "No window matched TitleLike='$TitleLike' ProcessName='$ProcessName'." }
    if ($matches.Count -gt 1) {
        Write-Warning "Multiple windows matched; using the first. Matches: $($matches.Title -join ', ')"
    }
    $matches | Select-Object -First 1
}

switch ($Action) {
    "List" {
        Get-WindowList -TitleLike $TitleLike -ProcessName $ProcessName | Format-Table -AutoSize
    }
    "Focus" {
        $w = Resolve-SingleWindow -TitleLike $TitleLike -ProcessName $ProcessName
        [WindowMgmt]::SetForegroundWindow($w.Handle) | Out-Null
        Write-Host "Focused: $($w.Title)" -ForegroundColor Green
    }
    "Minimize" {
        $w = Resolve-SingleWindow -TitleLike $TitleLike -ProcessName $ProcessName
        [WindowMgmt]::ShowWindow($w.Handle, [WindowMgmt]::SW_MINIMIZE) | Out-Null
    }
    "Maximize" {
        $w = Resolve-SingleWindow -TitleLike $TitleLike -ProcessName $ProcessName
        [WindowMgmt]::ShowWindow($w.Handle, [WindowMgmt]::SW_MAXIMIZE) | Out-Null
    }
    "Restore" {
        $w = Resolve-SingleWindow -TitleLike $TitleLike -ProcessName $ProcessName
        [WindowMgmt]::ShowWindow($w.Handle, [WindowMgmt]::SW_RESTORE) | Out-Null
    }
    "Close" {
        $w = Resolve-SingleWindow -TitleLike $TitleLike -ProcessName $ProcessName
        # WM_CLOSE gives the app a chance to prompt / clean up, unlike DestroyWindow
        [WindowMgmt]::PostMessage($w.Handle, [WindowMgmt]::WM_CLOSE, [IntPtr]::Zero, [IntPtr]::Zero) | Out-Null
        Write-Host "Sent WM_CLOSE to: $($w.Title)" -ForegroundColor Green
    }
    "Move" {
        if (-not ($Width -and $Height)) { throw "-Width and -Height are required for -Action Move." }
        $w = Resolve-SingleWindow -TitleLike $TitleLike -ProcessName $ProcessName
        [WindowMgmt]::MoveWindow($w.Handle, $X, $Y, $Width, $Height, $true) | Out-Null
        Write-Host "Moved '$($w.Title)' to ($X,$Y) ${Width}x${Height}." -ForegroundColor Green
    }
}
