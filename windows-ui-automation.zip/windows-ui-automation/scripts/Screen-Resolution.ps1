<#
.SYNOPSIS
    Get or set the primary display's screen resolution.

.DESCRIPTION
    Wraps EnumDisplaySettings / ChangeDisplaySettings from user32.dll.
    With no parameters, prints the current resolution and refresh rate.
    With -Width/-Height, attempts to change to that mode (must be a mode
    the display actually supports - use -ListModes to see what's available).

.PARAMETER Width
    Target horizontal resolution in pixels.

.PARAMETER Height
    Target vertical resolution in pixels.

.PARAMETER RefreshRate
    Optional target refresh rate in Hz. If omitted, keeps current refresh rate.

.PARAMETER ListModes
    List all display modes the current adapter supports, then exit.

.EXAMPLE
    .\Screen-Resolution.ps1
    Prints current resolution.

.EXAMPLE
    .\Screen-Resolution.ps1 -Width 1920 -Height 1080

.EXAMPLE
    .\Screen-Resolution.ps1 -ListModes
#>
param(
    [int]$Width,
    [int]$Height,
    [int]$RefreshRate,
    [switch]$ListModes
)

$signature = @"
using System;
using System.Runtime.InteropServices;

public class DisplaySettings {
    [StructLayout(LayoutKind.Sequential)]
    public struct DEVMODE {
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
        public string dmDeviceName;
        public short dmSpecVersion;
        public short dmDriverVersion;
        public short dmSize;
        public short dmDriverExtra;
        public int dmFields;
        public int dmPositionX;
        public int dmPositionY;
        public int dmDisplayOrientation;
        public int dmDisplayFixedOutput;
        public short dmColor;
        public short dmDuplex;
        public short dmYResolution;
        public short dmTTOption;
        public short dmCollate;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
        public string dmFormName;
        public short dmLogPixels;
        public int dmBitsPerPel;
        public int dmPelsWidth;
        public int dmPelsHeight;
        public int dmDisplayFlags;
        public int dmDisplayFrequency;
        public int dmICMMethod;
        public int dmICMIntent;
        public int dmMediaType;
        public int dmDitherType;
        public int dmReserved1;
        public int dmReserved2;
        public int dmPanningWidth;
        public int dmPanningHeight;
    }

    [DllImport("user32.dll", CharSet = CharSet.Ansi)]
    public static extern bool EnumDisplaySettings(string deviceName, int modeNum, ref DEVMODE devMode);

    [DllImport("user32.dll", CharSet = CharSet.Ansi)]
    public static extern int ChangeDisplaySettings(ref DEVMODE devMode, int flags);

    public const int ENUM_CURRENT_SETTINGS = -1;
    public const int DM_PELSWIDTH = 0x80000;
    public const int DM_PELSHEIGHT = 0x100000;
    public const int DM_DISPLAYFREQUENCY = 0x400000;
    public const int CDS_TEST = 0x2;
    public const int CDS_UPDATEREGISTRY = 0x1;

    // Return codes from ChangeDisplaySettings
    public const int DISP_CHANGE_SUCCESSFUL = 0;
    public const int DISP_CHANGE_RESTART = 1;
    public const int DISP_CHANGE_FAILED = -1;
    public const int DISP_CHANGE_BADMODE = -2;
    public const int DISP_CHANGE_NOTUPDATED = -3;
    public const int DISP_CHANGE_BADFLAGS = -4;
    public const int DISP_CHANGE_BADPARAM = -5;
}
"@

Add-Type -TypeDefinition $signature -Language CSharp -ErrorAction SilentlyContinue

function Get-CurrentResolution {
    $mode = New-Object DisplaySettings+DEVMODE
    $mode.dmSize = [System.Runtime.InteropServices.Marshal]::SizeOf($mode)
    $ok = [DisplaySettings]::EnumDisplaySettings($null, [DisplaySettings]::ENUM_CURRENT_SETTINGS, [ref]$mode)
    if (-not $ok) { throw "EnumDisplaySettings failed to read current mode." }
    [PSCustomObject]@{
        Width       = $mode.dmPelsWidth
        Height      = $mode.dmPelsHeight
        RefreshHz   = $mode.dmDisplayFrequency
        BitsPerPel  = $mode.dmBitsPerPel
    }
}

function Get-SupportedModes {
    $modes = @()
    $i = 0
    $mode = New-Object DisplaySettings+DEVMODE
    $mode.dmSize = [System.Runtime.InteropServices.Marshal]::SizeOf($mode)
    while ([DisplaySettings]::EnumDisplaySettings($null, $i, [ref]$mode)) {
        $modes += [PSCustomObject]@{
            Width      = $mode.dmPelsWidth
            Height     = $mode.dmPelsHeight
            RefreshHz  = $mode.dmDisplayFrequency
            BitsPerPel = $mode.dmBitsPerPel
        }
        $i++
    }
    $modes | Sort-Object Width, Height, RefreshHz -Unique
}

function Set-Resolution {
    param([int]$W, [int]$H, [int]$Hz)

    $mode = New-Object DisplaySettings+DEVMODE
    $mode.dmSize = [System.Runtime.InteropServices.Marshal]::SizeOf($mode)
    [DisplaySettings]::EnumDisplaySettings($null, [DisplaySettings]::ENUM_CURRENT_SETTINGS, [ref]$mode) | Out-Null

    $mode.dmPelsWidth = $W
    $mode.dmPelsHeight = $H
    $mode.dmFields = [DisplaySettings]::DM_PELSWIDTH -bor [DisplaySettings]::DM_PELSHEIGHT
    if ($Hz -gt 0) {
        $mode.dmDisplayFrequency = $Hz
        $mode.dmFields = $mode.dmFields -bor [DisplaySettings]::DM_DISPLAYFREQUENCY
    }

    # Test first so we fail with a clear error instead of silently no-op'ing
    $testResult = [DisplaySettings]::ChangeDisplaySettings([ref]$mode, [DisplaySettings]::CDS_TEST)
    if ($testResult -ne [DisplaySettings]::DISP_CHANGE_SUCCESSFUL) {
        throw "Requested mode ${W}x${H}@${Hz}Hz is not supported by this display (CDS_TEST returned $testResult). Run with -ListModes to see supported modes."
    }

    $result = [DisplaySettings]::ChangeDisplaySettings([ref]$mode, [DisplaySettings]::CDS_UPDATEREGISTRY)
    switch ($result) {
        0  { Write-Host "Resolution changed to ${W}x${H}$(if($Hz){"@${Hz}Hz"})." -ForegroundColor Green }
        1  { Write-Warning "Change applied but requires a restart to take full effect." }
        default { throw "ChangeDisplaySettings failed with code $result." }
    }
}

if ($ListModes) {
    Get-SupportedModes | Format-Table -AutoSize
    return
}

if ($Width -and $Height) {
    Set-Resolution -W $Width -H $Height -Hz $RefreshRate
} else {
    Get-CurrentResolution | Format-Table -AutoSize
}
