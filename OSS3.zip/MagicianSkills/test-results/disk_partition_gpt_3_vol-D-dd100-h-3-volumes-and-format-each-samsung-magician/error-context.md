# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: disk_partition_gpt_3_vol.test.js >> Disk Partition — GPT, 3 Volumes, Format Each >> initialize disk GPT with 3 volumes and format each
- Location: tests\disk_partition_gpt_3_vol.test.js:362:3

# Error details

```
Error: Expected exactly 3 partitions in disk visualization

expect(received).toBe(expected) // Object.is equality

Expected: 3
Received: 0
```

# Test source

```ts
  374 |       expect(snap, `Page signal missing: "${signal}"`).toContain(signal);
  375 |     }
  376 |     console.log('[disk] Navigated — page signals confirmed');
  377 | 
  378 |     // ═══════════════════════════════════════════════════════════════════════
  379 |     // PHASE A — INITIALIZE DISK
  380 |     // ═══════════════════════════════════════════════════════════════════════
  381 | 
  382 |     // ── Step 2: Open wizard ─────────────────────────────────────────────────
  383 | 
  384 |     ab.clickLabel('Initialize Disk');
  385 |     ab.wait(1000);
  386 | 
  387 |     expect(ab.snapshotFull(), 'Initialize Disk wizard did not open').toContain('Initialize Disk');
  388 |     console.log('[init] Wizard opened — step 1/2');
  389 | 
  390 |     // ── Step 3: Select GPT, advance to step 2 ───────────────────────────────
  391 | 
  392 |     // Open the partition table format dropdown (current value = MBR) and select GPT
  393 |     dismissAnyNotification();
  394 |     selectDropdownOption('MBR', 'GPT');
  395 |     console.log('[init] Partition table format: GPT');
  396 | 
  397 |     dismissAnyNotification();
  398 |     ab.clickLabel('Next');
  399 |     ab.wait(500);
  400 | 
  401 |     expect(ab.snapshotFull(), 'Wizard step 2 not reached').toContain('Add Partition');
  402 |     console.log('[init] Step 2/2 — partition configuration panel open');
  403 | 
  404 |     // ── Step 4: Configure 3 partitions ──────────────────────────────────────
  405 | 
  406 |     // Add card 2 first, then change its file system while it's still in view.
  407 |     // Each Add Partition scrolls the list to the newest card. Changing the file
  408 |     // system immediately after adding avoids the card being scrolled out of
  409 |     // viewport — off-screen dropdowns open outside the visible area and their
  410 |     // options don't appear in the accessibility tree.
  411 |     dismissAnyNotification();
  412 |     ab.clickLabel('Add Partition');
  413 |     ab.wait(400);
  414 | 
  415 |     // Card 2 is now the last (visible) card — change its file system to exFAT
  416 |     dismissAnyNotification();
  417 |     const vol2FsRef = findNthRef('NTFS', 2);
  418 |     selectDropdownOptionByRef(vol2FsRef, 'exFAT');
  419 |     console.log('[init] Volume 2 file system set to exFAT');
  420 | 
  421 |     // Add card 3 (NTFS by default — no change needed)
  422 |     dismissAnyNotification();
  423 |     ab.clickLabel('Add Partition');
  424 |     ab.wait(400);
  425 | 
  426 |     const wizSnap = ab.snapshotFull();
  427 |     // Counter line: "The number of total partition: 3/4(Maximum)"
  428 |     expect(wizSnap, 'Partition counter should show 3').toContain('3');
  429 |     console.log('[init] 3 partition cards configured (Vol1=NTFS, Vol2=exFAT, Vol3=NTFS)');
  430 | 
  431 |     ab.screenshot('test-results/disk-partition-init-before-start.png');
  432 | 
  433 |     // ── Step 5: Execute initialization ──────────────────────────────────────
  434 | 
  435 |     // Start ref shifts between single-partition and multi-partition states.
  436 |     // With 3 cards the Start label is still unique — clickLabel is safe.
  437 |     ab.clickLabel('Start');
  438 | 
  439 |     // Handle the pre-execution confirmation dialog (TBD — may or may not appear)
  440 |     handleConfirmIfPresent('[init]');
  441 | 
  442 |     ab.wait(2000);
  443 |     ab.screenshot('test-results/disk-partition-init-progress.png');
  444 | 
  445 |     const initDone = awaitCompletion(
  446 |       'Initializing the disk',
  447 |       INIT_TIMEOUT_MS,
  448 |       'test-results/disk-partition-init-complete.png',
  449 |       '[init]',
  450 |     );
  451 |     if (!initDone) {
  452 |       console.warn('[init] Proceeding to post-init assertions despite completion timeout');
  453 |     }
  454 | 
  455 |     // ═══════════════════════════════════════════════════════════════════════
  456 |     // VERIFY POST-INITIALIZATION STATE
  457 |     // ═══════════════════════════════════════════════════════════════════════
  458 | 
  459 |     // ── Step 6: Assert 3 volumes on the disk ────────────────────────────────
  460 | 
  461 |     ensureDiskPartitionPage();
  462 | 
  463 |     snap = ab.snapshotFull();
  464 |     ab.screenshot('test-results/disk-partition-post-init.png');
  465 | 
  466 |     for (const vol of VOLUMES) {
  467 |       expect(snap, `Post-init: "${vol.label}" not found`).toContain(vol.label);
  468 |     }
  469 |     console.log('[disk] All 3 volume labels present');
  470 | 
  471 |     // Count distinct partition blocks in the disk visualization.
  472 |     // Pattern matches "Volume N  NNN.NN GB" in the snapshotFull text.
  473 |     const partMatches = snap.match(/Volume\s+\d+\s+[\d.]+\s*GB/g) ?? [];
> 474 |     expect(partMatches.length, 'Expected exactly 3 partitions in disk visualization').toBe(3);
      |                                                                                       ^ Error: Expected exactly 3 partitions in disk visualization
  475 |     console.log(`[disk] ${partMatches.length} partitions confirmed`);
  476 | 
  477 |     // ═══════════════════════════════════════════════════════════════════════
  478 |     // PHASE B — FORMAT EACH VOLUME
  479 |     // ═══════════════════════════════════════════════════════════════════════
  480 | 
  481 |     // Shared format + verify routine used for all 3 volumes.
  482 |     // After each format the page re-scans; ensureDiskPartitionPage() waits for it.
  483 |     function formatAndVerify(volumeLabel, fileSystem, screenshotPath, prefix) {
  484 |       ensureDiskPartitionPage();
  485 |       dismissAnyNotification();  // clear any popup before opening the Format dialog
  486 | 
  487 |       // Select the partition row by volume label (partial match handles drive-letter prefix)
  488 |       selectVolume(volumeLabel);
  489 |       console.log(`${prefix} Selected ${volumeLabel}`);
  490 | 
  491 |       // Open Format dialog
  492 |       ab.clickLabel('Format');
  493 |       ab.wait(600);
  494 | 
  495 |       // The Format dialog defaults to NTFS. Change only when exFAT is needed.
  496 |       if (fileSystem !== 'NTFS') {
  497 |         selectDropdownOption('NTFS', fileSystem);
  498 |         console.log(`${prefix} File system set to ${fileSystem}`);
  499 |       }
  500 | 
  501 |       ab.screenshot(screenshotPath);
  502 | 
  503 |       // Click Start and handle optional pre-execution confirmation
  504 |       ab.clickLabel('Start');
  505 |       handleConfirmIfPresent(prefix);
  506 |       ab.wait(1500);
  507 | 
  508 |       awaitCompletion(
  509 |         'Formatting the partition',
  510 |         FORMAT_TIMEOUT_MS,
  511 |         null,
  512 |         prefix,
  513 |       );
  514 | 
  515 |       // Verify Partition Management panel after format
  516 |       ensureDiskPartitionPage();
  517 |       const panelSnap = selectVolume(volumeLabel);
  518 | 
  519 |       const fs     = extractPanelField(panelSnap, 'File system');
  520 |       const status = extractPanelField(panelSnap, 'Status');
  521 |       const free   = extractPanelField(panelSnap, 'Free Space');
  522 | 
  523 |       console.log(`${prefix} File system=${fs} | Status=${status} | Free Space=${free}`);
  524 | 
  525 |       expect(fs,     `${volumeLabel}: file system mismatch`).toBe(fileSystem);
  526 |       expect(status, `${volumeLabel}: unexpected status`).toBe('Healthy (Primary Partition)');
  527 |       expect(free,   `${volumeLabel}: Free Space should not be N/A after format`).not.toBe('N/A');
  528 |     }
  529 | 
  530 |     // ── Step 7: Format Volume 1 (NTFS) ──────────────────────────────────────
  531 |     formatAndVerify('Volume 1', 'NTFS',  'test-results/disk-partition-format-vol1.png',       '[fmt-vol1]');
  532 | 
  533 |     // ── Step 8: Format Volume 2 (exFAT) ─────────────────────────────────────
  534 |     formatAndVerify('Volume 2', 'exFAT', 'test-results/disk-partition-format-vol2-exfat.png', '[fmt-vol2]');
  535 | 
  536 |     // ── Step 9: Format Volume 3 (NTFS) ──────────────────────────────────────
  537 |     formatAndVerify('Volume 3', 'NTFS',  'test-results/disk-partition-format-vol3.png',       '[fmt-vol3]');
  538 | 
  539 |     // ═══════════════════════════════════════════════════════════════════════
  540 |     // FINAL ASSERTIONS
  541 |     // ═══════════════════════════════════════════════════════════════════════
  542 | 
  543 |     // ── Step 10: Final state verification ───────────────────────────────────
  544 | 
  545 |     ensureDiskPartitionPage();
  546 |     snap = ab.snapshotFull();
  547 |     ab.screenshot('test-results/disk-partition-final-state.png');
  548 | 
  549 |     // 10c — exactly 3 partitions
  550 |     const finalParts = snap.match(/Volume\s+\d+\s+[\d.]+\s*GB/g) ?? [];
  551 |     expect(finalParts.length, 'Final: expected 3 partitions').toBe(3);
  552 | 
  553 |     // 10d — all volume labels present
  554 |     for (const vol of VOLUMES) {
  555 |       expect(snap, `Final: "${vol.label}" missing`).toContain(vol.label);
  556 |     }
  557 | 
  558 |     // 10h — "Create Partition" is non-interactive (no unallocated space)
  559 |     // With 3 partitions fully consuming the disk, it renders as a plain StaticText.
  560 |     const createRef = findRefContaining('Create Partition');
  561 |     expect(
  562 |       createRef,
  563 |       '"Create Partition" should have no ref (disk fully allocated)',
  564 |     ).toBeNull();
  565 | 
  566 |     console.log('[disk] All final assertions passed');
  567 |   });
  568 | });
  569 | 
```