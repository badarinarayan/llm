const path = require('path');
const ab = require('./ab');

function screen(name) {
  const config = require(path.resolve(__dirname, '../../Elements_Config', `${name}.json`));

  function find(label) {
    const el = config.elements.find(e => e.label === label);
    if (!el) throw new Error(`[screen:${name}] No element with label "${label}"`);
    return el;
  }

  return {
    navigate() {
      if (config.navLabel) ab.clickLabel(config.navLabel);
    },

    // Click a stable element by its config label.
    // For drive-selector entries use ab.findDrive() instead.
    click(label) {
      find(label); // validates the label exists in the config
      ab.clickLabel(label);
    },

    // All labels of a given type, e.g. 'button', 'nav-link', 'toggle'
    labels(type) {
      return config.elements
        .filter(e => e.type === type && e.label)
        .map(e => e.label);
    },

    get navLabel() { return config.navLabel; },
    get elements() { return config.elements; },
  };
}

module.exports = screen;
