const { execSync, spawn } = require('child_process');
const http = require('http');
const ab = require('./ab');

const EXE = 'C:\\Program Files (x86)\\Samsung\\Samsung Magician\\SamsungMagician.exe';
const CDP_PORT = 9222;
const CDP_HOST = '127.0.0.1';

const sleep = ms => new Promise(r => setTimeout(r, ms));

function httpGet(url) {
  return new Promise((resolve, reject) => {
    http.get(url, res => {
      let body = '';
      res.on('data', d => body += d);
      res.on('end', () => resolve(body));
    }).on('error', reject);
  });
}

function isCdpReady() {
  return httpGet(`http://${CDP_HOST}:${CDP_PORT}/json/version`)
    .then(() => true).catch(() => false);
}

// Return the webSocketDebuggerUrl for the main Magician window (main.html).
// Falls back to any page target if main.html isn't listed yet.
async function getMainTargetWs() {
  const body = await httpGet(`http://${CDP_HOST}:${CDP_PORT}/json`);
  const targets = JSON.parse(body);
  const main = targets.find(t => t.url && t.url.includes('main.html'))
            || targets.find(t => t.type === 'page');
  if (!main) throw new Error('No page target found in CDP /json');
  return main.webSocketDebuggerUrl;
}

async function waitForCdp(timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs;

  // Phase 1: HTTP endpoint up
  while (Date.now() < deadline) {
    if (await isCdpReady()) break;
    await sleep(500);
  }
  if (!(await isCdpReady())) throw new Error(`CDP HTTP not ready after ${timeoutMs}ms`);
  console.log(`[magician] CDP HTTP ready at http://${CDP_HOST}:${CDP_PORT}`);

  // Phase 2: main.html target registered
  while (Date.now() < deadline) {
    try {
      const ws = await getMainTargetWs();
      console.log(`[magician] Main target: ${ws}`);
      ab.setTarget(ws);
      await sleep(1500); // let renderer finish painting after target registration
      return;
    } catch { await sleep(500); }
  }
  throw new Error('Main CDP target not available within timeout');
}

const UI_READY_SIGNALS = ['Home Dashboard', 'Performance Management', 'Diagnosis & Information', 'Settings'];

// Dismiss the Samsung Magician firmware update notification popup if present.
// The popup has: X close button (unlabeled generic ref) + "Don't show again" per card.
// Returns true if a popup was found and dismissed.
function dismissStartupNotification() {
  try {
    const snap = ab.snapshot();
    const hasFirmware = snap.includes("Don't show again") || snap.includes('Update your firmware');
    if (!hasFirmware) return false;

    console.log('[magician] Startup notification popup detected — suppressing');
    // Click "Don't show again" for each card to permanently suppress future appearances
    for (let i = 0; i < 4; i++) {
      const s = ab.snapshot();
      if (!s.includes("Don't show again")) break;
      const esc = "Don't show again".replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const m = s.match(new RegExp(`"${esc}"[^\\[]*\\[ref=(e\\d+)\\]`));
      if (!m) break;
      console.log(`[magician] Clicked "Don't show again" card ${i + 1} (${m[1]})`);
      ab.click(m[1]);
      ab.wait(400);
    }
    // Always try X button to close the popup container — "Don't show again"
    // removes per-card buttons but the modal stays until X is explicitly clicked.
    const s2 = ab.snapshot();
    const xMatch = s2.match(/^\s*-\s+generic\s+\[ref=(e\d+)\]\s+clickable/m);
    if (xMatch) {
      console.log(`[magician] Closed notification via X (${xMatch[1]})`);
      ab.click(xMatch[1]);
      ab.wait(500);
    }
    return true;
  } catch (err) {
    console.log(`[magician] Notification dismiss error: ${err.message.split('\n')[0]}`);
    return false;
  }
}

async function waitForUiReady(timeoutMs = 60000) {
  const deadline = Date.now() + timeoutMs;
  let attempt = 0;
  while (Date.now() < deadline) {
    attempt++;
    try {
      // Dismiss any startup notification popup blocking the UI before checking signals
      dismissStartupNotification();

      const snapshot = ab.snapshot();
      console.log(`[magician] UI attempt ${attempt}: ${snapshot.slice(0, 120).replace(/\n/g, ' ')}`);
      if (UI_READY_SIGNALS.some(s => snapshot.includes(s))) return;
    } catch (err) {
      console.log(`[magician] UI attempt ${attempt} error: ${err.message.split('\n')[0]}`);
    }
    await sleep(1500);
  }
  throw new Error(`Samsung Magician UI did not become ready within ${timeoutMs}ms`);
}

async function killExisting() {
  for (const proc of ['SamsungMagician.exe', 'SamsungMagicianSVC.exe']) {
    try {
      execSync(`taskkill /F /IM ${proc}`, { stdio: 'pipe' });
      console.log(`[magician] Killed ${proc}`);
    } catch {}
  }
  await sleep(1500);
}

async function startMagician() {
  if (await isCdpReady()) {
    console.log('[magician] Already running with CDP.');
    const ws = await getMainTargetWs();
    console.log(`[magician] Main target: ${ws}`);
    ab.setTarget(ws);
  } else {
    await killExisting();
    spawn(EXE, [
      `--remote-debugging-port=${CDP_PORT}`,
      `--remote-debugging-address=${CDP_HOST}`,
    ], { detached: true, stdio: 'ignore' }).unref();

    console.log('[magician] Process started, waiting for CDP...');
    await waitForCdp();
  }

  console.log('[magician] Waiting for UI...');
  await waitForUiReady();
  console.log('[magician] UI ready.');
}

function stopMagician() {
  try {
    execSync('taskkill /F /IM SamsungMagician.exe', { stdio: 'pipe' });
    console.log('[magician] Process stopped.');
  } catch {}
}

module.exports = { startMagician, stopMagician, killExisting };
