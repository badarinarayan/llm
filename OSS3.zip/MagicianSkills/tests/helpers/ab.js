const { execSync } = require('child_process');

let _cdpPort = null;

function setTarget(wsUrl) {
  const m = wsUrl.match(/:(\d+)\//);
  _cdpPort = m ? m[1] : '9222';
  console.log(`[ab] Target set via CDP port ${_cdpPort} (${wsUrl})`);
}

function run(cmd) {
  if (!_cdpPort) throw new Error('[ab] No target set — call ab.setTarget(wsUrl) before using ab');
  return execSync(`agent-browser --cdp ${_cdpPort} ${cmd}`, {
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
  });
}

const ab = {
  setTarget,
  snapshot()            { return run('snapshot -i'); },
  snapshotFull()        { return run('snapshot'); },
  screenshot(file)      { return run(`screenshot "${file}"`); },
  click(ref)            { return run(`click ${ref}`); },
  fill(ref, text)       { return run(`fill ${ref} "${text}"`); },
  press(key)            { return run(`press ${key}`); },
  type(text)            { return run(`keyboard type "${text}"`); },
  tab(index)            { return run(index !== undefined ? `tab ${index}` : 'tab'); },
  wait(ms)              { return run(`wait ${ms}`); },
  scroll(dir, px)       { return run(`scroll ${dir} ${px}`); },
  get(attr, ref)        { return run(`get ${attr} ${ref}`); },
  snapshotJson()        { return JSON.parse(run('snapshot --json')); },

  findRef(label) {
    const text = run('snapshot -i');
    const escaped = label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const match = text.match(new RegExp(`"${escaped}"[^\\[]*\\[ref=(e\\d+)\\]`));
    if (!match) throw new Error(`[ab] No element found with label "${label}"`);
    return match[1];
  },

  // Returns { ref, label } for the first drive found in the live snapshot.
  // Use this instead of a stored label — drive model strings are machine-specific.
  findDrive() {
    const DRIVE_RE = /samsung|ssd|nvme|mzvl|drive|disk|pm\d{3}|860|870|980|990/i;
    const text = run('snapshot -i');
    for (const line of text.split('\n')) {
      const labelMatch = line.match(/"([^"]+)"/);
      const refMatch   = line.match(/\[ref=(e\d+)\]/);
      if (labelMatch && refMatch && DRIVE_RE.test(labelMatch[1])) {
        return { ref: refMatch[1], label: labelMatch[1] };
      }
    }
    throw new Error('[ab] No drive element found in snapshot');
  },

  clickLabel(label) {
    const ref = ab.findRef(label);
    return run(`click ${ref}`);
  },
};

module.exports = ab;
