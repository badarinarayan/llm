#!/usr/bin/env python3.14
"""
Samsung Magician Automation — entry point.

Usage:
    python main.py <feature>
    python main.py health_status
    python main.py benchmark
    python main.py --list-features
"""

import sys
from pathlib import Path

from dotenv import load_dotenv
from rich.console import Console

load_dotenv()

from telemetry.setup import init_telemetry
from orchestrator.graph import run_pipeline

console = Console()

KNOWN_FEATURES = [
    "health_status",
    "benchmark",
    "secure_erase",
    "over_provisioning",
    "diagnostic",
    "firmware_update",
    "settings",
    "encryption",
    "performance",
    "wear_leveling",
]


def list_features() -> None:
    console.print("[bold]Known Magician features:[/bold]")
    for f in KNOWN_FEATURES:
        console.print(f"  • {f}")


def main() -> int:
    if len(sys.argv) < 2 or sys.argv[1] in ("-h", "--help"):
        console.print(__doc__)
        return 0

    if sys.argv[1] == "--list-features":
        list_features()
        return 0

    feature = sys.argv[1]
    console.rule(f"[bold cyan]Magician Automation — {feature}[/bold cyan]")

    init_telemetry()

    final_state = run_pipeline(feature)

    console.rule()
    if final_state["status"] == "success":
        console.print("[bold green]Pipeline completed: PASSED[/bold green]")
        return 0
    elif final_state["status"] == "blocked":
        console.print(
            "[bold yellow]Pipeline blocked: Samsung Magician must be running "
            "with --remote-debugging-port=9222[/bold yellow]"
        )
        return 2
    else:
        console.print("[bold red]Pipeline completed: FAILED[/bold red]")
        return 1


if __name__ == "__main__":
    sys.exit(main())
