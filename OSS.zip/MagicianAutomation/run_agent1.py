from dotenv import load_dotenv
load_dotenv()

from telemetry.setup import init_telemetry
init_telemetry()

from agents.agent1_inspector import run
result = run()
print("Configs written:")
for p in result["configs_written"]:
    print(f"  {p}")
print(f"Common elements: {result['common_element_count']}")
print("Feature element counts:")
for feat, count in result["feature_element_counts"].items():
    print(f"  {feat}: {count}")
