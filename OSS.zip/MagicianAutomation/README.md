# Samsung Magician Automation

Agentic test automation for Samsung Magician (Electron app) using CDP, LangGraph, and OpenTelemetry.

## Architecture

```
START → check_connection → Agent1 (inspect) → Agent2 (generate) → Agent3 (validate) → END
                                   ↑                                      |
                                   └──── re-inspect on element failure ───┘
                                   └──── regenerate on script failure ────┘
```

| Agent | What it does |
|---|---|
| **Agent 1** | Connects via CDP to Magician, enumerates all DOM elements, writes `config/common.json` + `config/features/<feature>.json` |
| **Agent 2** | Reads element maps, calls OpenAI to generate a `scripts/<feature>_test.js` test script |
| **Agent 3** | Runs the script with Node.js, parses PASS/FAIL output, triggers retries on failure |

## Prerequisites

1. **Samsung Magician** running with remote debugging enabled:
   ```
   "Samsung Magician.exe" --remote-debugging-port=9222
   ```
2. **Python 3.14+**
3. **Node.js 18+**
4. An **OpenAI API key**

## Setup

```bash
# Python dependencies
py -3.14 -m pip install -e .

# Node dependencies
npm install

# Configure environment
cp .env.example .env
# Edit .env and set OPENAI_API_KEY
```

## Usage

```bash
# Run the full pipeline for a specific feature
py -3.14 main.py health_status
py -3.14 main.py benchmark
py -3.14 main.py diagnostic

# List known features
py -3.14 main.py --list-features

# Run all generated test scripts directly
npm test
```

## Config Files

After Agent 1 runs, configs are written to:
- `config/common.json` — elements present on every page (nav, header, etc.)
- `config/features/<feature>.json` — feature-specific element mappings

Each element entry contains:
```json
{
  "tag": "button",
  "id": "btn-start-benchmark",
  "role": "button",
  "ariaLabel": "Start Benchmark",
  "disabled": false,
  "visible": true
}
```

## OpenTelemetry

Set `OTEL_EXPORTER=console` (default) to print traces to stdout, or `OTEL_EXPORTER=otlp` with `OTEL_ENDPOINT=http://localhost:4317` to export to a collector (Jaeger, Tempo, etc.).

## Retry Logic

If Agent 3 detects element-not-found errors → Agent 1 re-inspects the live app.
If Agent 3 detects script logic errors → Agent 2 regenerates using the error as context.
Maximum retries controlled by `MAX_RETRIES` env var (default: 3).
