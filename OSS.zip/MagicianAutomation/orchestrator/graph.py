"""
LangGraph orchestration for the Magician automation pipeline.

Flow:
  START -> check_connection -> agent1_inspect -> collect_steps -> agent2_generate -> agent3_validate
                                                                        ^                  |
                                                                        +--- (on failure) --+
                                                                                           v
                                                                                          END
"""

from __future__ import annotations

import os
from typing import TypedDict

from langgraph.graph import StateGraph, START, END
from rich.console import Console

from agents import agent1_inspector, agent2_script_gen, agent3_validator
from cdp.client import MagicianNotRunningError
from telemetry.setup import get_tracer

console = Console(highlight=False)
MAX_RETRIES = int(os.getenv("MAX_RETRIES", "3"))


# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------

class AutomationState(TypedDict):
    feature: str                # target feature to test
    test_steps: str             # user-confirmed test steps (plain numbered list)
    inspector_result: dict      # output from Agent 1
    script_result: dict         # output from Agent 2
    validation_result: dict     # output from Agent 3
    error_context: str          # last error description for Agent 2 retry
    retry_count: int
    status: str                 # running | success | failed | blocked


# ---------------------------------------------------------------------------
# Nodes
# ---------------------------------------------------------------------------

def node_check_connection(state: AutomationState) -> AutomationState:
    tracer = get_tracer()
    with tracer.start_as_current_span("node.check_connection"):
        from cdp.client import check_magician_running
        try:
            targets = check_magician_running()
            console.print(
                f"[green]OK[/green] Magician reachable -- {len(targets)} CDP target(s) found."
            )
            return {**state, "status": "running"}
        except MagicianNotRunningError as exc:
            console.print(f"[bold red]BLOCKED: {exc}[/bold red]")
            return {**state, "status": "blocked"}


def node_agent1_inspect(state: AutomationState) -> AutomationState:
    tracer = get_tracer()
    with tracer.start_as_current_span("node.agent1"):
        console.print("[cyan]Agent 1:[/cyan] Inspecting elements via CDP...")
        try:
            result = agent1_inspector.run(feature=state.get("feature"))
            console.print(
                f"[green]  OK[/green] Configs written: {len(result['configs_written'])} file(s)"
            )
            return {**state, "inspector_result": result}
        except MagicianNotRunningError as exc:
            console.print(f"[bold red]  FAIL: {exc}[/bold red]")
            return {**state, "status": "blocked"}


def node_collect_steps(state: AutomationState) -> AutomationState:
    """Interactive chat: ask the user what to test, return confirmed steps."""
    tracer = get_tracer()
    with tracer.start_as_current_span("node.collect_steps"):
        # Skip if steps were already provided (e.g. retry path)
        if state.get("test_steps"):
            console.print(
                "[dim]Skipping step collection -- using previously confirmed steps.[/dim]"
            )
            return state

        from chat.prompt import collect_test_steps
        steps = collect_test_steps(feature=state["feature"])
        if not steps:
            console.print("[bold red]No test steps provided. Pipeline aborted.[/bold red]")
            return {**state, "status": "blocked"}
        return {**state, "test_steps": steps}


def node_agent2_generate(state: AutomationState) -> AutomationState:
    tracer = get_tracer()
    with tracer.start_as_current_span("node.agent2"):
        console.print("[cyan]Agent 2:[/cyan] Generating test script from your steps...")
        result = agent2_script_gen.run(
            feature=state["feature"],
            test_steps=state.get("test_steps", ""),
            error_context=state.get("error_context"),
        )
        console.print(f"[green]  OK[/green] Script: {result['script_path']}")
        return {**state, "script_result": result, "error_context": ""}


def node_agent3_validate(state: AutomationState) -> AutomationState:
    tracer = get_tracer()
    with tracer.start_as_current_span("node.agent3"):
        console.print("[cyan]Agent 3:[/cyan] Running test script...")
        result = agent3_validator.run(feature=state["feature"])

        if result["passed"]:
            console.print(
                f"[bold green]  PASS: All tests passed "
                f"({len(result['passed_tests'])} checks)[/bold green]"
            )
            return {**state, "validation_result": result, "status": "success"}

        console.print(
            f"[yellow]  FAIL: {len(result['failed_tests'])} test(s) failed "
            f"(retry {state['retry_count'] + 1}/{MAX_RETRIES})[/yellow]"
        )
        for line in result["failed_tests"]:
            console.print(f"    [red]{line[:200]}[/red]")
        if result.get("stdout"):
            console.print("[dim]  -- Playwright output --[/dim]")
            for line in result["stdout"].splitlines()[-20:]:
                if line.strip():
                    console.print(f"  [dim]{line}[/dim]")

        error_ctx = (
            "\n".join(result["failed_tests"])
            + "\n\nPlaywright stdout:\n" + result.get("stdout", "")
            + "\n\nPlaywright stderr:\n" + result.get("stderr", "")
        ).strip()
        return {
            **state,
            "validation_result": result,
            "error_context": error_ctx,
            "retry_count": state["retry_count"] + 1,
        }


# ---------------------------------------------------------------------------
# Conditional edges
# ---------------------------------------------------------------------------

def route_after_check(state: AutomationState) -> str:
    return END if state["status"] == "blocked" else "agent1_inspect"


def route_after_validate(state: AutomationState) -> str:
    if state["status"] in ("success", "blocked"):
        return END
    if state["retry_count"] >= MAX_RETRIES:
        console.print(f"[bold red]Max retries ({MAX_RETRIES}) reached. Aborting.[/bold red]")
        return END
    vr = state.get("validation_result", {})
    if vr.get("needs_reinspect"):
        return "agent1_inspect"
    return "agent2_generate"


# ---------------------------------------------------------------------------
# Build graph
# ---------------------------------------------------------------------------

def build_graph() -> StateGraph:
    g = StateGraph(AutomationState)

    g.add_node("check_connection", node_check_connection)
    g.add_node("agent1_inspect", node_agent1_inspect)
    g.add_node("collect_steps", node_collect_steps)
    g.add_node("agent2_generate", node_agent2_generate)
    g.add_node("agent3_validate", node_agent3_validate)

    g.add_edge(START, "check_connection")
    g.add_conditional_edges("check_connection", route_after_check)
    g.add_edge("agent1_inspect", "collect_steps")
    g.add_edge("collect_steps", "agent2_generate")
    g.add_edge("agent2_generate", "agent3_validate")
    g.add_conditional_edges("agent3_validate", route_after_validate)

    return g.compile()


def run_pipeline(feature: str) -> AutomationState:
    graph = build_graph()
    initial: AutomationState = {
        "feature": feature,
        "test_steps": "",
        "inspector_result": {},
        "script_result": {},
        "validation_result": {},
        "error_context": "",
        "retry_count": 0,
        "status": "running",
    }
    return graph.invoke(initial)
