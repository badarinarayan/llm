from dotenv import load_dotenv
load_dotenv()

from cdp.client import check_magician_running, MagicianNotRunningError

try:
    targets = check_magician_running()
    print(f"Connected — {len(targets)} target(s):")
    for t in targets:
        ws = (t.get("webSocketDebuggerUrl") or "")[:60]
        print(f"  [{t.get('type')}] {t.get('title')!r}  ws={ws}")
except MagicianNotRunningError as e:
    print(f"NOT RUNNING: {e}")
