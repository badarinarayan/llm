// @ts-check
const { defineConfig } = require('@playwright/test');
const path = require('path');

module.exports = defineConfig({
  testDir: path.join(__dirname, 'scripts'),
  testMatch: '**/*.spec.js',
  timeout: 60_000,
  retries: 0,
  reporter: [
    ['list'],
    ['json', { outputFile: path.join(__dirname, 'playwright-results.json') }],
  ],
  use: {
    headless: false,
  },
});
