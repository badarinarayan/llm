"""
Interactive chat prompt that collects test steps from the user.

The chat assistant has two OpenAI function-call tools:
  - refresh_element_map : re-runs Agent 1 to get the latest element IDs
  - navigate_to_section : clicks a nav item in Magician and re-inspects
                          so elements for a specific section are captured
"""

from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path

from openai import OpenAI
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from rich.table import Table

ELEMENTS_CONFIG_DIR = Path(__file__).parent.parent / "Elements_Config"

console = Console(highlight=False)

# ---------------------------------------------------------------------------
# Tool definitions exposed to the OpenAI model
# ---------------------------------------------------------------------------

_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "refresh_element_map",
            "description": (
                "Re-run Agent 1 to inspect the live Samsung Magician UI and update "
                "the element map for the current feature. Call this whenever the "
                "element map is missing IDs you need or seems incomplete."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "feature": {
                        "type": "string",
                        "description": "Feature name to refresh (e.g. 'benchmark', 'main_window').",
                    }
                },
                "required": ["feature"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "navigate_to_section",
            "description": (
                "Click a navigation element in Magician to open a specific section, "
                "then refresh the element map so section-specific IDs become available. "
                "Use the nav element ID from the current element map (e.g. 'groupmenuview_performancemanagement')."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "nav_element_id": {
                        "type": "string",
                        "description": "The id of the sidebar nav item to click.",
                    },
                    "feature": {
                        "type": "string",
                        "description": "Feature name to assign to the newly captured elements.",
                    },
                },
                "required": ["nav_element_id", "feature"],
            },
        },
    },
]

# ---------------------------------------------------------------------------
# System prompt
# ---------------------------------------------------------------------------

_SYSTEM_PROMPT = """\
You are a helpful test-planning assistant for Samsung Magician, a storage drive management app.
Your job: help the user build a concrete, ordered list of test steps for a specific feature.

You have two tools:
1. refresh_element_map(feature) — re-inspects the live app and updates the element map.
   Call this whenever an element ID is missing or the map looks incomplete.
2. navigate_to_section(nav_element_id, feature) — clicks a sidebar nav item, waits for
   the view to load, then refreshes. Use this to capture elements for sub-pages.

Guidelines:
- Always prefer real element IDs from the map over guesses.
- If an element ID is not in the map, call refresh_element_map or navigate_to_section instead of asking the user.
- Ask ONE clarifying question at a time if the user's intent is unclear.
- When you have enough information, present a numbered test-step list and ask the user to confirm.
- Once the user confirms with words like "yes", "looks good", "confirm", "ok", output ONLY this JSON:
  {"confirmed": true, "steps": ["step 1 text", "step 2 text", ...]}
- If the user asks to change something, update the list and ask again.
"""

# ---------------------------------------------------------------------------
# Tool execution
# ---------------------------------------------------------------------------

def _run_refresh_element_map(feature: str) -> str:
    """Execute Agent 1 and return a summary of newly found elements."""
    console.print(f"[dim]  [tool] Running Agent 1 to refresh element map for '{feature}'...[/dim]")
    from agents.agent1_inspector import run as agent1_run
    try:
        result = agent1_run(feature=feature)
        summary = _load_element_summary(feature)
        return (
            f"Element map refreshed. "
            f"Common elements: {result['common_element_count']}. "
            f"Feature counts: {result['feature_element_counts']}.\n\n"
            f"Updated element map:\n{summary}"
        )
    except Exception as exc:
        return f"Agent 1 failed: {exc}"


def _run_navigate_to_section(nav_element_id: str, feature: str) -> str:
    """Click a nav element, then re-inspect."""
    console.print(
        f"[dim]  [tool] Clicking '{nav_element_id}' to navigate to '{feature}'...[/dim]"
    )
    from cdp.client import check_magician_running, click_element
    try:
        targets = check_magician_running()
        pages = [t for t in targets if t.get("type") in ("page", "webview")]
        if not pages:
            return "No page targets found. Is Magician running?"
        ws_url = pages[0]["webSocketDebuggerUrl"]
        asyncio.run(click_element(ws_url, nav_element_id))
        console.print(f"[dim]  [tool] Navigated. Re-running Agent 1...[/dim]")
        return _run_refresh_element_map(feature)
    except Exception as exc:
        return f"Navigation failed: {exc}"


_TOOL_HANDLERS = {
    "refresh_element_map": lambda args: _run_refresh_element_map(args["feature"]),
    "navigate_to_section": lambda args: _run_navigate_to_section(
        args["nav_element_id"], args["feature"]
    ),
}

# ---------------------------------------------------------------------------
# Element display helpers
# ---------------------------------------------------------------------------

def _load_element_summary(feature: str) -> str:
    """Compact text summary of current element maps for the system context."""
    common_path = ELEMENTS_CONFIG_DIR / "common.json"
    feature_path = ELEMENTS_CONFIG_DIR / f"{feature}.json"

    lines: list[str] = []
    for path, label in [(common_path, "common"), (feature_path, feature)]:
        if not path.exists():
            continue
        data = json.loads(path.read_text())
        data.pop("_meta", None)
        for key, el in list(data.items())[:50]:
            el_id = el.get("id") or el.get("dataTestId") or key
            role = el.get("role") or el.get("tag", "")
            label_text = (el.get("ariaLabel") or el.get("text", ""))[:40]
            visible = el.get("visible", "?")
            lines.append(
                f"  [{label}] id={el_id!r:42s} role={role:12s} visible={visible}  {label_text}"
            )

    return "\n".join(lines) if lines else "(no elements found)"


def _show_element_table(feature: str) -> None:
    common_path = ELEMENTS_CONFIG_DIR / "common.json"
    feature_path = ELEMENTS_CONFIG_DIR / f"{feature}.json"

    table = Table(title=f"Available elements  --  {feature}", show_lines=False)
    table.add_column("ID / Key", style="cyan", no_wrap=True, max_width=44)
    table.add_column("Tag/Role", style="yellow")
    table.add_column("Visible")
    table.add_column("Label / Text", style="dim")

    for path in (common_path, feature_path):
        if not path.exists():
            continue
        data = json.loads(path.read_text())
        data.pop("_meta", None)
        for key, el in data.items():
            el_id = el.get("id") or el.get("dataTestId") or key
            role = el.get("role") or el.get("tag", "")
            visible = "[green]yes[/green]" if el.get("visible") else "[dim]no[/dim]"
            label_text = (el.get("ariaLabel") or el.get("text", ""))[:50]
            table.add_row(el_id, role, visible, label_text)

    console.print(table)

# ---------------------------------------------------------------------------
# Main chat loop
# ---------------------------------------------------------------------------

def collect_test_steps(feature: str) -> str:
    """
    Interactive loop: chat with the user until they confirm test steps.
    The assistant can call Agent 1 tools to fetch missing element IDs.
    Returns a plain-text numbered list of confirmed steps.
    """
    console.print(
        Panel(
            f"[bold cyan]Test Step Planner[/bold cyan]  --  feature: [yellow]{feature}[/yellow]\n\n"
            "Describe what you want to test. The assistant can refresh element IDs\n"
            "from the live app whenever something is missing.",
            border_style="cyan",
        )
    )

    _show_element_table(feature)

    client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    model = os.getenv("OPENAI_MODEL", "gpt-4o")

    element_summary = _load_element_summary(feature)
    history: list[dict] = [
        {
            "role": "system",
            "content": (
                f"{_SYSTEM_PROMPT}\n\n"
                f"## Current element map for feature '{feature}':\n{element_summary}"
            ),
        },
        {
            "role": "assistant",
            "content": (
                f"Hi! I can see the element map for '{feature}'. "
                "What would you like to test? If I'm missing any element IDs, "
                "I'll refresh the map from the live app automatically."
            ),
        },
    ]

    console.print(f"\n[bold green]Assistant:[/bold green] {history[-1]['content']}\n")

    confirmed_steps: list[str] | None = None

    _EXIT_CMDS = {"quit", "exit", "bye", "q"}

    while confirmed_steps is None:
        user_input = Prompt.ask("[bold blue]You[/bold blue]").strip()
        if not user_input:
            continue

        if user_input.lower() in _EXIT_CMDS:
            console.print("[yellow]Chat exited. No test steps were confirmed.[/yellow]")
            return ""

        history.append({"role": "user", "content": user_input})

        # Agentic inner loop: keep calling the model until it stops using tools
        while True:
            response = client.chat.completions.create(
                model=model,
                messages=history,
                tools=_TOOLS,
                tool_choice="auto",
                temperature=0.3,
            )

            msg = response.choices[0].message
            finish = response.choices[0].finish_reason

            # Append the raw assistant message (may contain tool_calls)
            history.append(msg.model_dump(exclude_unset=True))

            if finish == "tool_calls" and msg.tool_calls:
                # Execute each requested tool and feed results back
                for tc in msg.tool_calls:
                    fn_name = tc.function.name
                    fn_args = json.loads(tc.function.arguments)
                    console.print(
                        f"[dim]  [tool call] {fn_name}({fn_args})[/dim]"
                    )
                    handler = _TOOL_HANDLERS.get(fn_name)
                    tool_result = handler(fn_args) if handler else f"Unknown tool: {fn_name}"

                    history.append({
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "content": tool_result,
                    })
                # Loop back — model will now respond with updated information
                continue

            # Model finished with a normal text reply
            reply = (msg.content or "").strip()

            # Check for confirmation JSON
            if reply.startswith("{") and '"confirmed"' in reply:
                try:
                    payload = json.loads(reply)
                    if payload.get("confirmed") and payload.get("steps"):
                        confirmed_steps = payload["steps"]
                except json.JSONDecodeError:
                    pass

            if confirmed_steps is None:
                console.print(f"\n[bold green]Assistant:[/bold green] {reply}\n")

            break   # exit inner tool loop, back to user input

    steps_text = "\n".join(f"{i + 1}. {s}" for i, s in enumerate(confirmed_steps))
    console.print(
        Panel(
            "[bold green]Confirmed test steps:[/bold green]\n\n" + steps_text,
            border_style="green",
        )
    )
    return steps_text
