from dotenv import load_dotenv
load_dotenv()
from telemetry.setup import init_telemetry; init_telemetry()
from agents.agent1_inspector import run, ELEMENTS_CONFIG_DIR

result = run()
print(f"Written to: {ELEMENTS_CONFIG_DIR}")
for p in result["configs_written"]:
    print(f"  {p}")
print(f"Common elements: {result['common_element_count']}")
print(f"Features: {list(result['feature_element_counts'].keys())}")
