import os
import logging
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, SimpleSpanProcessor
from opentelemetry.sdk.trace.export import SpanExporter, SpanExportResult
from opentelemetry.sdk.resources import Resource

_tracer: trace.Tracer | None = None

# File-based span exporter so traces don't pollute stdout
class _FileSpanExporter(SpanExporter):
    def __init__(self, path: str = "telemetry.log"):
        import json
        self._path = path
        self._json = json

    def export(self, spans):
        with open(self._path, "a", encoding="utf-8") as f:
            for span in spans:
                f.write(self._json.dumps({
                    "name": span.name,
                    "trace_id": format(span.context.trace_id, "032x"),
                    "span_id": format(span.context.span_id, "016x"),
                    "start_ms": span.start_time // 1_000_000,
                    "end_ms": span.end_time // 1_000_000,
                    "status": span.status.status_code.name,
                    "attrs": dict(span.attributes or {}),
                }) + "\n")
        return SpanExportResult.SUCCESS

    def shutdown(self):
        pass


def init_telemetry() -> trace.Tracer:
    global _tracer
    if _tracer is not None:
        return _tracer

    service_name = os.getenv("OTEL_SERVICE_NAME", "magician-automation")
    exporter_type = os.getenv("OTEL_EXPORTER", "file")

    resource = Resource.create({"service.name": service_name})
    provider = TracerProvider(resource=resource)

    if exporter_type == "otlp":
        from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
        endpoint = os.getenv("OTEL_ENDPOINT", "http://localhost:4317")
        exporter = OTLPSpanExporter(endpoint=endpoint, insecure=True)
        provider.add_span_processor(BatchSpanProcessor(exporter))
    else:
        # Default: write spans to telemetry.log (quiet stdout)
        exporter = _FileSpanExporter("telemetry.log")
        provider.add_span_processor(SimpleSpanProcessor(exporter))

    trace.set_tracer_provider(provider)
    _tracer = trace.get_tracer(service_name)
    return _tracer


def get_tracer() -> trace.Tracer:
    if _tracer is None:
        return init_telemetry()
    return _tracer
