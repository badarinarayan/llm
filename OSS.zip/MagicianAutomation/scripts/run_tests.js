/**
 * Runs all *_test.js files in this directory via Playwright.
 * Usage: npm test  (or: npx playwright test scripts/)
 */
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const testFiles = fs.readdirSync(__dirname)
  .filter(f => f.endsWith('.spec.js'))
  .map(f => path.join(__dirname, f));

if (testFiles.length === 0) {
  console.log('No test scripts found. Run the Python pipeline first.');
  process.exit(0);
}

console.log(`Found ${testFiles.length} test file(s). Running with Playwright...\n`);

try {
  execSync(
    `npx playwright test ${testFiles.map(f => `"${f}"`).join(' ')} --reporter=list`,
    { stdio: 'inherit' }
  );
} catch (err) {
  process.exit(err.status || 1);
}
