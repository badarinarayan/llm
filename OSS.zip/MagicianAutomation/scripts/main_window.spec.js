const { test, expect, chromium } = require('@playwright/test');
const common = require('../Elements_Config/common.json');
const elements = require('../Elements_Config/main_window.json');

const sel = (el) => {
  if (el.id) return `#${el.id}`;
  if (el.dataTestId) return `[data-testid="${el.dataTestId}"]`;
  if (el.ariaLabel) return `[aria-label="${el.ariaLabel}"]`;
  return el.tag || '*';
};

test.describe('main_window', () => {
  let browser, context, page;

  test.beforeAll(async () => {
    browser = await chromium.connectOverCDP('http://localhost:9222');
    context = browser.contexts()[0];
    page = context.pages()[0];
  });

  test.afterAll(async () => {
    await browser.close();
  });

  test('Navigate to the Performance Benchmark section using the sidebar navigation', async () => {
    const performanceBenchmarkMenuItem = { id: 'groupMenuView_iconTooltip_menuItem_0' };
    await page.waitForSelector(sel(performanceBenchmarkMenuItem), { state: 'visible', timeout: 30000 });
    await page.locator(sel(performanceBenchmarkMenuItem)).click();
  });

  test('Click the "Start" button with ID "circularProgressBarView_Start_Button" to begin the benchmark test', async () => {
    const startButton = { id: 'circularProgressBarView_Start_Button' };
    await page.waitForSelector(sel(startButton), { state: 'visible', timeout: 30000 });
    await page.locator(sel(startButton)).first().click();
  });

  test('Wait for the benchmark test to complete', async () => {
    const resultsView = { id: 'pbFrame_ResultsView' };
    await page.waitForSelector(sel(resultsView), { state: 'visible', timeout: 30000 });
  });

  test('Extract the performance metrics from the results view with ID "pbFrame_ResultsView"', async () => {
    const resultsView = { id: 'pbFrame_ResultsView' };
    const metricsText = await page.locator(sel(resultsView)).innerText();
    console.log(metricsText);
  });
});