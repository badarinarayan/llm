# Validate Test Script

Runs `scripts/<feature>.spec.js` with `npx playwright test` and reports pass/fail per test step with actual error messages.

## Usage
```
/validate <feature>
```
- `feature`: feature name matching `scripts/<feature>.spec.js` (e.g. `main_window`)

## What it does
1. Runs `npx playwright test "scripts/<feature>.spec.js"` from the project root.
2. Playwright picks up `playwright.config.js` which configures:
   - list reporter → stdout
   - json reporter → `playwright-results.json`
3. Parses `playwright-results.json` recursively (handles nested suites).
4. Reports each test step as PASS or FAIL with the actual Playwright error message.
5. Flags `needs_reinspect: true` if failures contain element-not-found / locator timeout errors.

## Run
Execute agent3_validator.run():

```python
from dotenv import load_dotenv; load_dotenv()
from agents.agent3_validator import run
result = run(feature="<feature>")
print("Passed:", result["passed"])
for t in result["passed_tests"]:
    print(" ", t)
for t in result["failed_tests"]:
    print(" ", t)
```

Parse `$ARGUMENTS` for the feature name.
After running, display a formatted summary:
- Green for PASS lines, red for FAIL lines.
- If `needs_reinspect` is True, suggest running `/inspect <feature>` to refresh element IDs.
- If all passed, show total test count and duration from playwright-results.json stats.
