# List Features

Lists all features that have element configs in `Elements_Config/` and generated test scripts in `scripts/`.

## Usage
```
/list-features
```

## What it shows
A summary table with columns:
- **Feature** — feature name
- **Elements Config** — path to `Elements_Config/<feature>.json` (exists / missing)
- **Element Count** — number of elements in the config
- **Dynamic Elements** — count of elements tagged dynamic
- **Test Script** — `scripts/<feature>.spec.js` (exists / missing)

## Run
```python
import json
from pathlib import Path

config_dir = Path("Elements_Config")
scripts_dir = Path("scripts")

features = set()
for p in config_dir.glob("*.json"):
    if p.stem != "common":
        features.add(p.stem)
for p in scripts_dir.glob("*.spec.js"):
    features.add(p.stem.replace(".spec", ""))

print(f"{'Feature':<25} {'Config':^8} {'Elements':^10} {'Dynamic':^9} {'Script':^8}")
print("-" * 65)
for feat in sorted(features):
    cfg_path = config_dir / f"{feat}.json"
    scr_path = scripts_dir / f"{feat}.spec.js"
    if cfg_path.exists():
        data = json.loads(cfg_path.read_text())
        data.pop("_meta", None)
        n_total = len(data)
        n_dyn = sum(1 for v in data.values() if v.get("dynamic"))
        cfg_status = "OK"
    else:
        n_total = n_dyn = 0
        cfg_status = "missing"
    scr_status = "OK" if scr_path.exists() else "missing"
    print(f"{feat:<25} {cfg_status:^8} {n_total:^10} {n_dyn:^9} {scr_status:^8}")
```

Run this Python snippet using the Bash tool. No arguments needed.
After displaying the table, suggest `/inspect <feature>` for any missing configs and `/generate <feature>` for any missing scripts.
