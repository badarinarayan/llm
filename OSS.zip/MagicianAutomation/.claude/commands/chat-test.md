# Chat Test Planner

Opens an interactive multi-turn chat to help define test steps for a feature. The assistant has two live tools it can call:
- `refresh_element_map(feature)` — re-runs Agent 1 against the live app
- `navigate_to_section(nav_element_id, feature)` — clicks a sidebar item then re-inspects

Once you confirm the steps, it passes them directly to Agent 2 to generate the test script.

## Usage
```
/chat-test <feature>
```
- `feature`: feature name (e.g. `main_window`, `performance`, `diagnostic`)

## Chat commands
| Input | Effect |
|---|---|
| Any plain English | Assistant refines test steps |
| `yes` / `looks good` / `confirm` | Locks in steps, triggers Agent 2 |
| `quit` / `exit` / `bye` / `q` | Exits without generating |

## What the assistant can do autonomously
- Call `navigate_to_section('groupmenuview_performancemanagement', 'performance')` to open a section in Magician and capture its elements before suggesting steps
- Call `refresh_element_map('feature')` if element IDs are missing or stale
- Chain multiple tool calls before replying (e.g. navigate → refresh → answer)

## Run
```
py -3.14 main.py <feature>
```

Parse `$ARGUMENTS` for feature name. Run the full pipeline via the Bash tool — the collect_steps node handles the interactive chat automatically. The terminal will become interactive at the chat prompt.
