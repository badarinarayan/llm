# Generate Test Script

Uses OpenAI (gpt-4o) to generate a Playwright test script for a feature based on element configs in `Elements_Config/` and user-provided test steps.

## Usage
```
/generate <feature> "<test steps>"
```
- `feature`: feature name matching an `Elements_Config/<feature>.json` file (e.g. `main_window`, `diagnostic`)
- `test steps`: plain-English description of what to test (quoted string)

## What it does
1. Loads `Elements_Config/common.json` and `Elements_Config/<feature>.json`.
2. Sends element map + test steps to GPT-4o with a Playwright-specific system prompt.
3. Ensures generated script:
   - Imports element configs via `require('../Elements_Config/<feature>.json')`
   - Uses `sel()` helper to build selectors from config (never hardcodes IDs)
   - Uses `test.describe` / `test.beforeAll` / `test.afterAll` correctly
   - Uses `toBeVisible()` + `console.log(innerText)` for dynamic elements (serial numbers, scores)
   - Uses `toHaveText()` only for static labels
4. Saves to `scripts/<feature>.spec.js`.

## Run
Execute the agent2_script_gen.run() function:

```python
from dotenv import load_dotenv; load_dotenv()
from agents.agent2_script_gen import run
result = run(feature="<feature>", test_steps="<test_steps>")
print("Script written to:", result["script_path"])
print(f"Tokens used: {result['prompt_tokens']} in / {result['completion_tokens']} out")
```

Parse `$ARGUMENTS`: first token = feature name, remainder = test steps string.
After generating, display the script contents using the Read tool.
