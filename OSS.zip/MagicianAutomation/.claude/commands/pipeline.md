# Run Full Pipeline

Runs the complete 3-agent LangGraph pipeline for a feature:
`check_connection → inspect → chat (collect steps) → generate → validate`
with automatic retry on failure (up to MAX_RETRIES=3).

## Usage
```
/pipeline <feature>
```
- `feature`: any known Magician feature (e.g. `main_window`, `diagnostic`, `performance`, `security`, `data_management`)

## Pipeline flow
```
check_connection
      ↓
  agent1_inspect  ←──────────────────────────┐
      ↓                                       │ (needs_reinspect)
  collect_steps (interactive chat)            │
      ↓                                       │
  agent2_generate  ←─────────────────────────┤
      ↓                                       │ (script error)
  agent3_validate ──── PASS → END            │
      └──────────────────────────────────────┘ (FAIL + retry_count < MAX_RETRIES)
```

## Retry behaviour
- Element not found / locator timeout → re-inspects live app (Agent 1) then regenerates
- Script logic error → regenerates with full Playwright stdout as error context
- Stops after MAX_RETRIES (env var, default 3)

## Run
```python
from dotenv import load_dotenv; load_dotenv()
from telemetry.setup import init_telemetry; init_telemetry()
from orchestrator.graph import run_pipeline
final = run_pipeline(feature="<feature>")
print("Status:", final["status"])
```

Parse `$ARGUMENTS` for the feature name. Run using the Bash tool:
```
py -3.14 main.py <feature>
```
Stream output live. After completion show final status and path to generated script.
