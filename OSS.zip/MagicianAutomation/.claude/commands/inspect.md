# Inspect Elements

Connects to the running Samsung Magician app via CDP on port 9222, inspects all DOM elements, and writes element configs to `Elements_Config/`.

## Usage
```
/inspect [feature]
```
- `feature` (optional): limit inspection output to one feature (e.g. `main_window`, `diagnostic`). Omit to inspect all.

## What it does
1. Checks Magician is reachable on `localhost:9222` — stops with a clear message if not.
2. Runs the CDP inspector JS across all page targets.
3. Classifies elements as **common** (app chrome) or **feature-specific** by element ID prefix.
4. Detects **dynamic** content (serial numbers, temperatures, benchmark scores, MB/s) and marks `"dynamic": true` in the config.
5. Writes:
   - `Elements_Config/common.json`
   - `Elements_Config/<feature>.json` for each detected feature

## Run
```powershell
py -3.14 -c "
from dotenv import load_dotenv; load_dotenv()
from telemetry.setup import init_telemetry; init_telemetry()
from agents.agent1_inspector import run
import sys
feature = sys.argv[1] if len(sys.argv) > 1 else None
result = run(feature=feature)
for p in result['configs_written']:
    print('Written:', p)
print('Common elements:', result['common_element_count'])
print('Features:', result['feature_element_counts'])
" $ARGUMENTS
```

Execute the above using the Bash tool with `py -3.14 run_agent1.py` from the project root.
Parse `$ARGUMENTS` for an optional feature name. If provided, pass it as `feature=<arg>` to `run()`.
After running, show a summary table of written files and element counts.
