# Show Element Config

Displays the element config for a feature from `Elements_Config/`, formatted as a table with dynamic/static classification.

## Usage
```
/show-elements [feature]
```
- `feature` (optional): feature name (e.g. `main_window`, `diagnostic`). Omit to show common elements only.

## What it shows
For each element entry in `Elements_Config/<feature>.json`:
- **ID** — the element's DOM id (or dataTestId)
- **Tag/Role** — HTML tag and ARIA role
- **Visible** — whether the element was visible at inspection time
- **Dynamic** — `yes` if content changes at runtime (serial numbers, temperatures, scores, MB/s)
- **Text** — text content snapshot (truncated)

## Run
Read the JSON file and format as a table:

```python
import json
from pathlib import Path

base = Path("Elements_Config")
feature = "$ARGUMENTS".strip() or None

files = []
if (base / "common.json").exists():
    files.append(("common", base / "common.json"))
if feature and (base / f"{feature}.json").exists():
    files.append((feature, base / f"{feature}.json"))
elif not feature:
    for p in sorted(base.glob("*.json")):
        if p.stem != "common":
            files.append((p.stem, p))

for label, path in files:
    data = json.loads(path.read_text())
    data.pop("_meta", None)
    print(f"\n=== {label} ({len(data)} elements) ===")
    for key, el in data.items():
        dyn = "DYN" if el.get("dynamic") else "   "
        vis = "yes" if el.get("visible") else "no "
        eid = el.get("id") or key
        txt = (el.get("text") or "")[:40]
        print(f"  {dyn} {vis}  {eid:<40}  {txt}")
```

Parse `$ARGUMENTS` for optional feature name.
After running, note how many elements are dynamic vs static, and suggest `/inspect` if configs are stale.
