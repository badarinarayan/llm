"""
Agent 3 — Script Validator
Runs the generated Playwright test script and parses results.
Detects element-not-found failures so the retry loop can decide
whether to re-inspect (Agent 1) or just regenerate (Agent 2).
"""

import json
import re
import subprocess
from pathlib import Path

from telemetry.setup import get_tracer

PROJECT_ROOT = Path(__file__).parent.parent
SCRIPTS_DIR  = PROJECT_ROOT / "scripts"
RESULTS_FILE = PROJECT_ROOT / "playwright-results.json"

_ELEMENT_FAILURES = re.compile(
    r"(locator\s+resolved\s+to\s+hidden|"
    r"no\s+element\s+matching|"
    r"element\s+not\s+found|"
    r"strict\s+mode\s+violation|"
    r"Locator\..*timeout|"
    r"waiting\s+for\s+locator\(.*?\).*?timeout)",
    re.IGNORECASE,
)

_TIMEOUT_FAILURE = re.compile(r"timed?\s*out", re.IGNORECASE)


def _collect_specs(node: dict) -> list[dict]:
    """Recursively collect all spec entries from nested Playwright suite JSON."""
    specs = list(node.get("specs", []))
    for child_suite in node.get("suites", []):
        specs.extend(_collect_specs(child_suite))
    return specs


def _parse_results(stdout: str, stderr: str, returncode: int) -> dict:
    passed_tests: list[str] = []
    failed_tests: list[str] = []

    # Primary: parse the JSON reporter output file written by playwright.config.js
    if RESULTS_FILE.exists():
        try:
            data = json.loads(RESULTS_FILE.read_text(encoding="utf-8"))
            all_specs: list[dict] = []
            for suite in data.get("suites", []):
                all_specs.extend(_collect_specs(suite))

            for spec in all_specs:
                title = spec.get("title", "unknown")
                ok = spec.get("ok", False)
                if ok:
                    passed_tests.append(f"PASS: {title}")
                else:
                    err_msg = ""
                    for test in spec.get("tests", []):
                        for r in test.get("results", []):
                            err = r.get("error") or {}
                            err_msg = err.get("message", "") or err.get("value", "")
                            if err_msg:
                                break
                    failed_tests.append(f"FAIL: {title} -- {err_msg[:400]}")
        except (json.JSONDecodeError, KeyError):
            pass

    # Fallback: scan stdout lines for ✓ / ✗ markers
    if not passed_tests and not failed_tests:
        for line in stdout.splitlines():
            s = line.strip()
            if s.startswith(("✓", "√", "  ✓", "ok ")):
                passed_tests.append(s)
            elif s.startswith(("✗", "×", "  ✗", "  ×", "FAILED")):
                failed_tests.append(s)

    # Last resort: surface the tail of stdout as the error so retries have context
    if not failed_tests and returncode != 0:
        tail = "\n".join(l for l in stdout.splitlines() if l.strip())[-2000:]
        failed_tests = [f"FAIL: Playwright exited {returncode}:\n{tail}"]

    combined = stdout + stderr
    return {
        "passed": returncode == 0,
        "return_code": returncode,
        "passed_tests": passed_tests,
        "failed_tests": failed_tests,
        "needs_reinspect": bool(_ELEMENT_FAILURES.search(combined)),
        "is_timeout": bool(_TIMEOUT_FAILURE.search(combined)),
        "stdout": stdout[-4000:],
        "stderr": stderr[-1000:],
    }


def run(feature: str) -> dict:
    """Execute scripts/<feature>.spec.js with Playwright and return structured results."""
    tracer = get_tracer()
    with tracer.start_as_current_span("agent3.validate") as span:
        span.set_attribute("feature", feature)

        script_path = SCRIPTS_DIR / f"{feature}.spec.js"
        if not script_path.exists():
            raise FileNotFoundError(
                f"Test script not found: {script_path}. Run Agent 2 first."
            )

        if RESULTS_FILE.exists():
            RESULTS_FILE.unlink()

        # Do NOT pass --reporter on CLI — it overrides playwright.config.js reporters
        # entirely (including the outputFile for json). Let the config handle both
        # list (stdout) and json (file) reporters.
        result = subprocess.run(
            f'npx playwright test "scripts/{feature}.spec.js"',
            capture_output=True,
            text=True,
            timeout=300,
            shell=True,
            cwd=str(PROJECT_ROOT),
        )

        parsed = _parse_results(result.stdout, result.stderr, result.returncode)

        span.set_attribute("test_passed", parsed["passed"])
        span.set_attribute("tests_passed_count", len(parsed["passed_tests"]))
        span.set_attribute("tests_failed_count", len(parsed["failed_tests"]))
        span.set_attribute("needs_reinspect", parsed["needs_reinspect"])

        return parsed
