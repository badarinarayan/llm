"""
Agent 2 — Test Script Generator
Reads element configs from Elements_Config/ and uses OpenAI to generate a
Playwright test script. Scripts import element configs at runtime so selectors
stay in one place — update the config, not the test.
"""

import json
import os
from pathlib import Path

from openai import OpenAI
from telemetry.setup import get_tracer

ELEMENTS_CONFIG_DIR = Path(__file__).parent.parent / "Elements_Config"
SCRIPTS_DIR = Path(__file__).parent.parent / "scripts"

_SYSTEM_PROMPT = """You are an expert test automation engineer writing Playwright tests for an
Electron desktop application (Samsung Magician) that exposes a CDP endpoint at localhost:9222.

## How element configs work
Element IDs are NOT hardcoded in the script. Instead, load them from JSON config files:

  const common   = require('../Elements_Config/common.json');
  const elements = require('../Elements_Config/<feature>.json');

Each entry in the JSON looks like:
  "featureItemView": { "id": "featureItemView", "tag": "div", "visible": true, ... }

Build selectors using the helper at the top of the script:
  const sel = (el) => {
    if (el.id)         return `#${el.id}`;
    if (el.dataTestId) return `[data-testid="${el.dataTestId}"]`;
    if (el.ariaLabel)  return `[aria-label="${el.ariaLabel}"]`;
    return el.tag || '*';
  };

Then use: page.locator(sel(elements.featureItemView))

## Dynamic vs static content
Elements in the config have a "dynamic": true/false field.
- dynamic: true  → content changes at runtime (device serial, temperatures, benchmark scores,
                   MB/s, GB written, firmware versions, percentages, timestamps).
                   NEVER use toHaveText() or toContainText() on these.
                   Instead: assert toBeVisible(), then read and log the value with innerText().
- dynamic: false → stable UI labels. Safe to use toHaveText() / toContainText().

## Playwright rules
- Import: const { test, expect, chromium } = require('@playwright/test');
- ALWAYS use test.describe(...) NOT describe(...).
- beforeAll: browser = await chromium.connectOverCDP('http://localhost:9222');
             context = browser.contexts()[0];
             page = context.pages()[0];
- afterAll:  await browser.close();
- Use .first() when a selector might match multiple elements.
- For static assertions: expect(locator).toBeVisible() / toBeEnabled() / toHaveText() etc.
- For dynamic elements: expect(locator).toBeVisible(), then console.log(await locator.innerText()).
- For waiting:    page.waitForSelector(sel(el), { state: 'visible', timeout: 30000 })
- One test() block per user-defined step, named after the step.
- Output ONLY valid JavaScript. No markdown fences, no explanation.
"""

_USER_TEMPLATE = """Generate a Playwright test script for Samsung Magician feature: **{feature}**

## User-defined test steps (one test() block per step):
{test_steps}

## Elements_Config/common.json (app chrome — always present):
```json
{common_map}
```

## Elements_Config/{feature}.json (feature-specific):
```json
{feature_map}
```

## Instructions:
- Start with:
    const common   = require('../Elements_Config/common.json');
    const elements = require('../Elements_Config/{feature}.json');
- Define the sel() helper immediately after the requires.
- Implement EVERY numbered step as a separate test() block.
- Use only keys that exist in the JSON above to build selectors via sel().
- For steps that say "verify/assert": use Playwright expect() assertions.
- For steps that say "click": locator.click() (use .first() if id matches multiple).
- For steps that say "wait": page.waitForSelector() with timeout 30000.
- For steps that say "extract/get": locator.innerText() then console.log().
- Wrap all tests in test.describe('{feature}', () => {{ ... }}).

File: scripts/{feature}.spec.js
"""


def _load_config(feature: str) -> tuple[dict, dict]:
    common_path = ELEMENTS_CONFIG_DIR / "common.json"
    feature_path = ELEMENTS_CONFIG_DIR / f"{feature}.json"

    common = json.loads(common_path.read_text()) if common_path.exists() else {}
    feature_map = json.loads(feature_path.read_text()) if feature_path.exists() else {}

    common.pop("_meta", None)
    feature_map.pop("_meta", None)

    return common, feature_map


def run(
    feature: str,
    test_steps: str = "",
    error_context: str | None = None,
) -> dict:
    """Generate a Playwright test script that reads selectors from Elements_Config/."""
    tracer = get_tracer()
    with tracer.start_as_current_span("agent2.generate") as span:
        span.set_attribute("feature", feature)
        span.set_attribute("has_test_steps", bool(test_steps))

        common_map, feature_map = _load_config(feature)

        if not feature_map:
            raise ValueError(
                f"No element config found for feature '{feature}' in Elements_Config/. "
                "Run Agent 1 first."
            )

        if not test_steps:
            test_steps = (
                "1. Verify all visible elements are present in the DOM.\n"
                "2. Verify disabled elements report as disabled.\n"
                "3. Verify interactive elements are enabled and clickable."
            )

        user_msg = _USER_TEMPLATE.format(
            feature=feature,
            test_steps=test_steps,
            common_map=json.dumps(common_map, indent=2)[:3000],
            feature_map=json.dumps(feature_map, indent=2)[:4000],
        )

        if error_context:
            user_msg += f"\n\n## Previous test failure context (fix these issues):\n{error_context}"

        model = os.getenv("OPENAI_MODEL", "gpt-4o")
        client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])

        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": _SYSTEM_PROMPT},
                {"role": "user", "content": user_msg},
            ],
            max_tokens=4096,
            temperature=0,
        )

        script_content = response.choices[0].message.content.strip()

        if script_content.startswith("```"):
            lines = script_content.splitlines()
            script_content = "\n".join(
                lines[1:-1] if lines[-1].strip() == "```" else lines[1:]
            )

        SCRIPTS_DIR.mkdir(exist_ok=True)
        script_path = SCRIPTS_DIR / f"{feature}.spec.js"
        script_path.write_text(script_content)

        usage = response.usage
        span.set_attribute("script_path", str(script_path))
        span.set_attribute("model", model)
        span.set_attribute("prompt_tokens", usage.prompt_tokens)
        span.set_attribute("completion_tokens", usage.completion_tokens)

        return {
            "script_path": str(script_path),
            "feature": feature,
            "model": model,
            "prompt_tokens": usage.prompt_tokens,
            "completion_tokens": usage.completion_tokens,
        }
