"""
Agent 1 — Element Inspector
Connects to Samsung Magician via CDP, enumerates all elements, and writes
element configs to Elements_Config/:
  Elements_Config/common.json          — app chrome shared across all pages
  Elements_Config/<feature>.json       — feature-specific elements

Test scripts import these files directly by feature name.
"""

import asyncio
import json
import os
from datetime import datetime, timezone
from pathlib import Path

from cdp.client import inspect_all_targets, navigate_to_feature, MagicianNotRunningError
from telemetry.setup import get_tracer

ELEMENTS_CONFIG_DIR = Path(__file__).parent.parent / "Elements_Config"

# Elements whose IDs start with these prefixes are shared chrome (always visible)
_COMMON_PREFIXES = (
    "mainheaderframeview",
    "modebarframeview",
    "bottomsnbview",
    "snbframeview",
    "topsnbview",
    "deviceinfoview",
)

# Map groupmenuview IDs → canonical feature names
_NAV_FEATURE_MAP: dict[str, str] = {
    "groupmenuview_diagnosisinformation": "diagnostic",
    "groupmenuview_performancemanagement": "performance",
    "groupmenuview_datamanagement": "data_management",
    "groupmenuview_securitysettings": "security",
}

# Fallback: page title keyword → feature
_TITLE_KEYWORD_MAP: dict[str, str] = {
    "health": "health_status",
    "benchmark": "benchmark",
    "secure erase": "secure_erase",
    "over provisioning": "over_provisioning",
    "diagnostic": "diagnostic",
    "firmware": "firmware_update",
    "settings": "settings",
    "encryption": "encryption",
    "performance": "performance",
    "wear": "wear_leveling",
    "samsung magician": "main_window",
}


def _classify_element(el: dict) -> str:
    for attr in ("id", "dataTestId", "name", "ariaLabel"):
        val = el.get(attr)
        if val:
            return str(val).lower().replace(" ", "_").replace("-", "_")
    role = el.get("role") or el.get("tag", "element")
    text = (el.get("text") or "").strip()[:30].lower().replace(" ", "_")
    return f"{role}_{text}" if text else role


def _detect_feature_from_title(title: str) -> str:
    title_lower = title.lower()
    for keyword, feature in _TITLE_KEYWORD_MAP.items():
        if keyword in title_lower:
            return feature
    return "unknown"


def _is_common(el: dict) -> bool:
    el_id = (el.get("id") or "").lower()
    return any(el_id.startswith(p) for p in _COMMON_PREFIXES)


def _get_feature_from_id(el_id: str) -> str | None:
    """If an element ID directly maps to a feature, return it."""
    for nav_id, feature in _NAV_FEATURE_MAP.items():
        if el_id.lower().startswith(nav_id.lower()):
            return feature
    return None


def _split_elements(
    elements: list[dict],
) -> tuple[dict, dict[str, dict]]:
    """
    Split a flat element list into:
    - common_map: elements that belong to the app chrome (always visible)
    - feature_map: elements grouped by feature prefix
    """
    common_map: dict = {}
    feature_map: dict[str, dict] = {}

    for el in elements:
        key = _classify_element(el)
        entry = {k: v for k, v in el.items() if v is not None and v != ""}

        if _is_common(el):
            common_map[key] = entry
            continue

        feature = _get_feature_from_id(el.get("id") or "")
        if feature:
            feature_map.setdefault(feature, {})[key] = entry
        else:
            # Bucket remainder into a "main_window" feature
            feature_map.setdefault("main_window", {})[key] = entry

    return common_map, feature_map


def run(feature: str | None = None) -> dict:
    """
    Synchronous entry-point called by the LangGraph node.
    Returns a summary dict with paths written and element counts.
    """
    tracer = get_tracer()
    with tracer.start_as_current_span("agent1.inspect") as span:
        span.set_attribute("target_feature", feature or "all")
        try:
            all_targets = asyncio.run(inspect_all_targets())
        except MagicianNotRunningError as exc:
            span.set_attribute("error", str(exc))
            raise

        span.set_attribute("targets_found", len(all_targets))

        # Merge elements from all targets into one flat list
        all_elements: list[dict] = []
        for elements in all_targets.values():
            all_elements.extend(elements)

        common_map, feature_map = _split_elements(all_elements)

        now = datetime.now(timezone.utc).isoformat()
        ELEMENTS_CONFIG_DIR.mkdir(exist_ok=True)

        # Write common config
        common_path = ELEMENTS_CONFIG_DIR / "common.json"
        common_data = {
            "_meta": {
                "description": "App chrome elements shared across all Magician pages",
                "generated_by": "Agent1-Inspector",
                "last_updated": now,
            },
            **common_map,
        }
        common_path.write_text(json.dumps(common_data, indent=2))
        written: list[str] = [str(common_path)]

        # Write per-feature configs
        for feat, elements in feature_map.items():
            if feature and feat != feature:
                continue
            feat_path = ELEMENTS_CONFIG_DIR / f"{feat}.json"
            feat_data = {
                "_meta": {
                    "feature": feat,
                    "generated_by": "Agent1-Inspector",
                    "last_updated": now,
                },
                **elements,
            }
            feat_path.write_text(json.dumps(feat_data, indent=2))
            written.append(str(feat_path))

        span.set_attribute("configs_written", len(written))

        return {
            "configs_written": written,
            "common_element_count": len(common_map),
            "feature_element_counts": {f: len(e) for f, e in feature_map.items()},
        }
