"""
CDP client for connecting to a Electron/Chromium app running with
--remote-debugging-port=9222.
"""

import asyncio
import json
import os
import requests
import websockets
from typing import Any

CDP_HOST = os.getenv("MAGICIAN_DEBUG_HOST", "localhost")
CDP_PORT = int(os.getenv("MAGICIAN_DEBUG_PORT", "9222"))
CDP_BASE = f"http://{CDP_HOST}:{CDP_PORT}"

# Patterns that indicate an element's text content is runtime-dynamic
# (device IDs, measurements, counters, timestamps, percentages, scores)
_DYNAMIC_JS = """
function isDynamic(text) {
  if (!text) return false;
  return (
    // Serial / model numbers: long alphanum strings with mixed case+digits
    /[A-Z0-9]{6,}-[A-Z0-9]{4,}/.test(text) ||
    // Temperature, speeds, sizes
    /\\d+\\s*(°C|MB\\/s|GB\\/s|MiB|GiB|GB|MB|TB|ms|%)/.test(text) ||
    // Pure numeric values (counters, scores)
    /^\\d+(\\.\\d+)?$/.test(text.trim()) ||
    // Time formats  00:00:00
    /\\d{2}:\\d{2}:\\d{2}/.test(text) ||
    // Firmware / version strings
    /^[A-Z0-9]{8,}$/.test(text.trim()) ||
    // Written / health numbers that change over time
    /\\d+\\s*TB\\s*Written|\\d+\\s*TBW/.test(text)
  );
}
"""

# JS that extracts every interactive/named element from the page
_INSPECT_JS = _DYNAMIC_JS + """
(function() {
  const results = [];
  const seen = new Set();

  document.querySelectorAll('*').forEach(el => {
    const id = el.id;
    const role = el.getAttribute('role');
    const ariaLabel = el.getAttribute('aria-label') || '';
    const dataTestId = el.getAttribute('data-testid') || '';
    const name = el.getAttribute('name') || '';

    // Only keep elements that have a stable identifier
    if (!id && !role && !dataTestId && !name) return;

    const key = `${el.tagName}|${id}|${role}|${dataTestId}`;
    if (seen.has(key)) return;
    seen.add(key);

    const rect = el.getBoundingClientRect();
    const visible = rect.width > 0 && rect.height > 0 &&
                    window.getComputedStyle(el).visibility !== 'hidden' &&
                    window.getComputedStyle(el).display !== 'none';

    const rawText = (el.textContent || '').trim().substring(0, 120);

    results.push({
      tag: el.tagName.toLowerCase(),
      id: id || null,
      className: el.className || null,
      role: role,
      ariaLabel: ariaLabel || null,
      ariaDisabled: el.getAttribute('aria-disabled'),
      dataTestId: dataTestId || null,
      name: name || null,
      disabled: el.disabled || false,
      visible: visible,
      text: rawText,
      dynamic: isDynamic(rawText),
      type: el.type || null,
    });
  });

  return results;
})()
"""


class MagicianNotRunningError(RuntimeError):
    pass


def check_magician_running() -> list[dict]:
    """Return CDP targets or raise MagicianNotRunningError."""
    try:
        resp = requests.get(f"{CDP_BASE}/json", timeout=3)
        resp.raise_for_status()
        return resp.json()
    except Exception:
        raise MagicianNotRunningError(
            f"Samsung Magician is not running with --remote-debugging-port={CDP_PORT}.\n"
            f"Please restart Magician with that flag and try again."
        )


async def get_page_elements(ws_url: str) -> list[dict]:
    """Connect to a CDP target and extract all elements via Runtime.evaluate."""
    async with websockets.connect(ws_url, max_size=10 * 1024 * 1024) as ws:
        msg_id = 1

        async def send(method: str, params: dict = {}) -> Any:
            nonlocal msg_id
            payload = {"id": msg_id, "method": method, "params": params}
            msg_id += 1
            await ws.send(json.dumps(payload))
            while True:
                raw = await ws.recv()
                data = json.loads(raw)
                if data.get("id") == payload["id"]:
                    return data

        # Enable Runtime domain
        await send("Runtime.enable")

        result = await send(
            "Runtime.evaluate",
            {
                "expression": _INSPECT_JS,
                "returnByValue": True,
                "awaitPromise": False,
            },
        )

        if "error" in result:
            raise RuntimeError(f"CDP evaluate error: {result['error']}")

        value = result.get("result", {}).get("result", {}).get("value", [])
        return value if isinstance(value, list) else []


async def click_element(ws_url: str, element_id: str) -> None:
    """Click an element by ID using CDP Runtime.evaluate."""
    js = f"document.getElementById('{element_id}')?.click()"
    async with websockets.connect(ws_url, max_size=10 * 1024 * 1024) as ws:
        msg_id = 1

        async def send(method: str, params: dict = {}) -> Any:
            nonlocal msg_id
            payload = {"id": msg_id, "method": method, "params": params}
            msg_id += 1
            await ws.send(json.dumps(payload))
            while True:
                raw = await ws.recv()
                data = json.loads(raw)
                if data.get("id") == payload["id"]:
                    return data

        await send("Runtime.enable")
        await send("Runtime.evaluate", {"expression": js, "returnByValue": True})
        # Brief wait for navigation/re-render
        await asyncio.sleep(1.0)


def navigate_to_feature(ws_url: str, nav_element_id: str) -> None:
    """Synchronously click a nav element to navigate to a feature section."""
    asyncio.run(click_element(ws_url, nav_element_id))


async def inspect_all_targets() -> dict[str, list[dict]]:
    """
    Inspect every available CDP target (page/iframe) and return a mapping of
    target title → element list.
    """
    targets = check_magician_running()
    pages = [t for t in targets if t.get("type") in ("page", "webview")]

    if not pages:
        raise MagicianNotRunningError(
            "No page targets found in Magician CDP. Ensure the app is fully loaded."
        )

    results: dict[str, list[dict]] = {}
    for target in pages:
        title = target.get("title") or target.get("id", "unknown")
        ws_url = target.get("webSocketDebuggerUrl")
        if not ws_url:
            continue
        elements = await get_page_elements(ws_url)
        results[title] = elements

    return results
