import json

data = json.load(open("config/features/unknown.json"))
data.pop("_meta", None)
keys = list(data.keys())
print(f"Total elements: {len(keys)}\n")
print(f"{'Key':<45} {'tag':<12} {'role':<18} {'visible'}")
print("-" * 90)
for k in keys[:40]:
    el = data[k]
    tag = el.get("tag", "?")
    role = str(el.get("role") or "")
    visible = el.get("visible")
    print(f"{k:<45} {tag:<12} {role:<18} {visible}")
